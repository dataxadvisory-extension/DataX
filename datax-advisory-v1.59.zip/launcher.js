// DataX Advisory — kiçik pəncərə: lisenziya, yeniliklər, texniki dəstək və panelin açılması
const $ = id => document.getElementById(id);
$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
// Test kanalı: yeniləyici bu kompüterə kanal.json yazıbsa, yeni versiyalar əvvəlcə bura gəlir
const dxKanal = fetch(chrome.runtime.getURL('kanal.json')).then(r => r.ok ? r.json() : {}).then(j => j && j.kanal === 'test').catch(() => false);
dxKanal.then(t => { if (!t) return; const v = $('ver'); v.textContent += ' · TEST'; v.title = 'Test kanalı: yeni versiyalar əvvəlcə bu kompüterə gəlir'; v.style.color = '#f2b84b'; });

const say = m => { $('lst').textContent = m; };
let winId = null; chrome.windows.getCurrent(w => { winId = w && w.id; });
// Panel istifadəçi kliki ilə açılmalıdır: heç bir gözləmə olmadan çağırılır
function openPanel(fn) {
  if (fn) chrome.storage.local.set({ openFn: { fn, t: Date.now() } });
  if (!chrome.sidePanel || !chrome.sidePanel.open) { chrome.tabs.create({ url: chrome.runtime.getURL('panel.html') }); window.close(); return; }
  chrome.sidePanel.open(winId != null ? { windowId: winId } : {}).then(() => window.close()).catch(e => say('Panel açılmadı: ' + e.message));
}
$('openp').onclick = () => openPanel(null);
$('sup').onclick = async () => {
  const { report } = await chrome.storage.local.get('report');
  if (!report) { say('Hələ dəstək məlumatı yoxdur. Əvvəlcə funksiyanı bir dəfə işlət.'); return; }
  await navigator.clipboard.writeText(JSON.stringify(report, null, 1));
  say('Dəstək məlumatı kopyalandı. İçində məbləğ, VÖEN və ad yoxdur.');
};
// ---- Lisenziya: giris.js ----

// ---- Yeniliklər (həmişə görünür; yeni versiyadan sonra vurğulanır) ----
const CUR = chrome.runtime.getManifest().version, cmp = (a, b) => a.localeCompare(b, undefined, { numeric: true });
$('vcur').textContent = CUR;
(async () => {
  let ch = {}; try { ch = await (await fetch(chrome.runtime.getURL('changes.json'))).json(); } catch (e) {}
  let { seenVer, installVer } = await chrome.storage.local.get(['seenVer', 'installVer']);
  if (!seenVer && !installVer) { installVer = seenVer = CUR; chrome.storage.local.set({ installVer, seenVer }); }   // yeni quraşdırma
  // Yalnız bu kompüterə quraşdırıldıqdan sonra gələn yeniliklər
  const vers = Object.keys(ch).filter(v => cmp(v, CUR) <= 0 && (!installVer || cmp(v, installVer) > 0)).sort((a, b) => cmp(b, a));
  const show = vs => {
    const ul = $('newslist'); ul.replaceChildren();
    vs.forEach(v => { if (vs.length > 1) { const h = document.createElement('li'); h.className = 'v'; h.textContent = 'v' + v; ul.appendChild(h); } (ch[v] || []).forEach(x => { const li = document.createElement('li'); li.textContent = x; ul.appendChild(li); }); });
  };
  const base = seenVer || installVer || '1.17', unseen = vers.filter(v => cmp(v, base) > 0);
  $('newsver').textContent = 'v' + CUR;
  if (!vers.length) { const li = document.createElement('li'); li.textContent = 'Hələ yenilik yoxdur — yeni funksiyalar gələndə burada görünəcək.'; $('newslist').replaceChildren(li); $('newsall').hidden = true; return; }
  if (unseen.length) { show(unseen.slice(0, 3)); $('news').classList.add('fresh'); $('newbadge').hidden = false; $('newsok').hidden = false; }
  else show(vers.slice(0, 1));
  $('newsok').onclick = () => { chrome.storage.local.set({ seenVer: CUR }); $('news').classList.remove('fresh'); $('newbadge').hidden = true; $('newsok').hidden = true; };
  let all = false; $('newsall').onclick = () => { all = !all; show(all ? vers : (unseen.length ? unseen.slice(0, 3) : vers.slice(0, 1))); $('newsall').textContent = all ? 'Qısa göstər' : 'Bütün yeniliklər'; };
})();
// ---- Versiya: GitHub-dakı ən son versiya ilə müqayisə ----
const UPDATE_URL = 'https://raw.githubusercontent.com/dataxadvisory-extension/DataX/main/version.json';
async function checkVer(manual) {
  const st = $('vstate'); st.classList.remove('up'); if (manual) st.textContent = 'Yoxlanılır...';
  chrome.runtime.sendMessage({ type: 'checkUpdate' }, () => void chrome.runtime.lastError);
  try {
    const test = await dxKanal, get = async u => { try { const r = await fetch(u + '?t=' + Date.now(), { cache: 'no-store' }); return r.ok ? await r.json() : null; } catch (e) { return null; } };
    let j = await get(UPDATE_URL); if (!j) throw new Error('yox');
    if (test) { const t = await get(UPDATE_URL.replace('version.json', 'test.json')); if (t && t.version && cmp(t.version, j.version) > 0) j = t; }
    if (j && j.version && cmp(j.version, CUR) > 0) {
      const u = await new Promise(r => { try { chrome.runtime.sendMessage({ type: 'updInfo' }, x => { void chrome.runtime.lastError; r(x || null); }); } catch (e) { r(null); } });
      const age = u && u.son ? (Date.now() - new Date(u.son.replace(' ', 'T')).getTime()) / 36e5 : 1e9;
      st.classList.add('up');
      const rel = j.date ? (Date.now() - Date.parse(j.date)) / 36e5 : 0;
      if (age > 24 && rel > 6) {   // versiya 6 saatdan çoxdur buraxılıb, yeniləyici isə 1 gündür işləməyib (və ya heç quraşdırılmayıb)
        st.textContent = `Yeni versiya ${j.version} var, amma bu kompüterdə avtomatik yeniləmə işləmir. `;
        const a = document.createElement('a'); a.href = '#'; a.textContent = 'Quraşdırma faylını yüklə'; a.style.cssText = 'color:inherit;text-decoration:underline;font-weight:700';
        a.onclick = e => { e.preventDefault(); chrome.tabs.create({ url: 'https://github.com/dataxadvisory-extension/DataX/raw/main/DataX-qurasdirma.zip' }); };
        st.append(a, document.createTextNode(' — açıb "qurasdir.bat"-a bas.'));
      } else st.textContent = `Yeni versiya ${j.version} hazırdır: 15 dəqiqə ərzində özü quraşdırılacaq`;
    }
    else st.textContent = (test ? 'TEST kanalı · ' : '') + 'Ən son versiyadır · avtomatik yeniləmə aktivdir';
  } catch (e) { st.textContent = manual ? 'İnternet yoxdur və ya yoxlama alınmadı' : 'Avtomatik yeniləmə aktivdir'; }
}
$('vchk').onclick = () => checkVer(true);
checkVer(false);
// ---- Texniki dəstək: zəng düyməsi nömrəni də kopyalayır ----
$('telbtn').onclick = e => { try { navigator.clipboard.writeText('+994506562101'); } catch (x) {} say('Nömrə kopyalandı: +994 50 656 21 01'); };

