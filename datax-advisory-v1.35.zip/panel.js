const $ = id => document.getElementById(id);
const st = $('st'), go = $('go');
const MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
// e-taxes-in "Filtr" pəncərəsindəki adlar
const STATUSES = ['Təsdiqləndi', 'Təsdiq gözləyir', 'Düzəliş edildi', 'Düzəlişə qaytarıldı', 'Ləğvə göndərildi', 'Sistem tərəfindən təsdiqləndi', 'Düzəlişə göndərildi', 'Ləğv edildi', 'Silindi', 'Sistem tərəfindən silindi', 'Passiv'];
const STATUS_OFF = ['Ləğv edildi', 'Silindi', 'Sistem tərəfindən silindi'];
const TYPES = [
  'Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura',
  'Malların, işlərin və xidmətlərin vəkalətverən (komitent) tərəfindən agentə (komisyonçuya) verilməsi barədə elektron qaimə-faktura',
  'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin alıcısına (subagentə) təqdim edilməsi barədə elektron qaimə-faktura',
  'Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura',
  'Qaytarma istisna olmaqla VM-in 163-cü maddəsinə əsasən dəqiqləşdirilməsi barədə elektron qaimə-faktura',
  'VM-in 177.5-ci maddəsinə əsasən təqdim edilməsi barədə elektron qaimə-faktura',
  'Malların qaytarılması barədə elektron qaimə-faktura',
  'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin vəkalətverənə (komitentə) qaytarılması barədə elektron qaimə-faktura',
  'Emal prosesi keçmiş, yaxud saxlamaya verilmiş malların qaytarılması barədə elektron qaimə-faktura',
  'Malların ixrac qeydi ilə satışı barədə elektron qaimə-faktura',
  'Aksizli malların (neft məhsulları istisna olmaqla) təsərrüfatdaxili yerdəyişməsi barədə elektron qaimə-faktura',
  'Alınmış avans ödənişləri barədə elektron qaimə-faktura'];
const OTHER = 'Digər növlər (siyahıda olmayan)';
const TAXL = [['menfeet', 'Mənfəət vergisi', 'il'], ['sadelesdirilmis', 'Sadələşdirilmiş vergi', 'rub'], ['gelir', 'Gəlir vergisi', 'il'], ['edvevez', 'Əlavə dəyər vergisi əvəzləşmə', 'ay'],
  ['edv', 'Əlavə dəyər vergisi', 'ay'], ['muzdlu', 'Muzdlu işlə əlaqədar ödəmə mənbəyində tutulmalar', 'rub'], ['omv', 'Ödəmə mənbəyindən tutulan vergi', 'rub']];
const PER = { ay: 'aylıq', rub: 'rüblük', il: 'illik' }, QUARTERS = ['1-ci rüb', '2-ci rüb', '3-cü rüb', '4-cü rüb'];
const ETAX = /^https:\/\/new\.e-taxes\.gov\.az\/eportal(\/|\?|#|$)/;
// Funksiyalar e-taxes-in hansı bölməsində olmasından asılı deyil: aktiv sekmə e-taxes-dirsə o, yoxsa istənilən açıq e-taxes sekməsi götürülür
async function etaxTab() {
  const [a] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (a && ETAX.test(a.url || '')) return a;
  const all = await chrome.tabs.query({ url: 'https://new.e-taxes.gov.az/eportal*' });
  return all.find(t => t.active) || all[0] || null;
}
const FN = {
  vat: { label: 'Qaimələri topla', page: ETAX, idle: 'e-taxes-ə daxil ol, ayları seç və başlat. Hansı bölmədə olduğun fərq etmir.', need: 'Əvvəlcə e-taxes-ə daxil ol (new.e-taxes.gov.az səhifəsi açıq olsun, hansı bölmədə olduğun fərq etmir).' },
  decls: { label: 'Bəyannamələri topla', page: ETAX, idle: 'e-taxes-ə daxil ol, bəyannamənin növünü və dövrü seç və başlat. Hansı bölmədə olduğun fərq etmir.', need: 'Əvvəlcə e-taxes-ə daxil ol (new.e-taxes.gov.az səhifəsi açıq olsun, hansı bölmədə olduğun fərq etmir).' },
  docs: { label: 'Sənədləri hazırla', page: ETAX, idle: 'e-taxes-ə daxil ol, qaimə nömrələrini yaz və başlat. Hansı bölmədə olduğun fərq etmir.', need: 'Əvvəlcə e-taxes-ə daxil ol (new.e-taxes.gov.az səhifəsi açıq olsun, hansı bölmədə olduğun fərq etmir).' },
  anal: { label: 'Analiz pəncərəsini aç', page: /./, idle: 'Düyməni bas: il seç, qaimələr və Əlavə 1 özü yüklənib analiz olunacaq.', need: '' },
  toplu: { label: 'Toplu qaimə pəncərəsini aç', page: /./, idle: 'Düyməni bas: qaimə sətirlərini yapışdırmaq üçün pəncərə açılacaq.', need: '' },
  mal: { label: 'Tutuşdur', page: ETAX, idle: 'e-taxes-ə daxil ol, tarixləri seç və başlat. Hansı bölmədə olduğun fərq etmir.', need: 'Əvvəlcə e-taxes-ə daxil ol (new.e-taxes.gov.az səhifəsi açıq olsun, hansı bölmədə olduğun fərq etmir).' },
  risk: { label: 'Yoxla', page: ETAX, idle: 'e-taxes-ə daxil ol, tarixləri seç və başlat. Hansı bölmədə olduğun fərq etmir.', need: 'Əvvəlcə e-taxes-ə daxil ol (new.e-taxes.gov.az səhifəsi açıq olsun, hansı bölmədə olduğun fərq etmir).' },
  items: { label: 'Malları topla', page: ETAX, idle: 'e-taxes-ə daxil ol, tarixləri seç və başlat. Hansı bölmədə olduğun fərq etmir.', need: 'Əvvəlcə e-taxes-ə daxil ol (new.e-taxes.gov.az səhifəsi açıq olsun, hansı bölmədə olduğun fərq etmir).' }
};
let fn = 'vat', busy = false;
$('ver').textContent = 'v' + chrome.runtime.getManifest().version;

const fmt = v => v == null ? '-' : v.toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const say = (msg, err, ok) => { st.textContent = msg; st.classList.toggle('err', !!err); st.classList.toggle('ok', !!ok); };
const cell = (tr, text, small) => {
  const td = tr.insertCell(); td.textContent = text;
  if (small) { const s = document.createElement('small'); s.textContent = ' ' + small; td.appendChild(s); }
};
// Bölmələr: Qaimə malları, Alt sənədlər, Bəyannamələr. "ƏDV əvəzləşmə" Bəyannamələrin içində bir növdür (fn = 'vat').
const TABS = ['items', 'docs', 'decls', 'anal', 'toplu', 'risk', 'mal'];
const tabOf = f => f === 'vat' ? 'decls' : f;
function declMode() {                                      // Bəyannamələr bölməsində seçilmiş növə görə: əvəzləşmə (vat) və ya ümumi (decls)
  const v = curTax() === 'edvevez';
  $('p-vat').hidden = !v; $('p-gen').hidden = v;
  return v ? 'vat' : 'decls';
}
function pick(f, keepStatus) {
  const t = tabOf(f);
  for (const k of TABS) $('p-' + k).hidden = k !== t;
  $('home').hidden = true; $('crumb').hidden = false; document.body.classList.remove('home');
  if (f === 'vat' && curTax() !== 'edvevez') { const r = document.querySelector('input[name=btype][value=edvevez]'); if (r) { r.checked = true; } }
  fn = t === 'decls' ? declMode() : f;
  go.textContent = FN[fn].label;
  if (!keepStatus && !busy) { say(FN[fn].idle); $('sum').style.display = 'none'; $('stats').style.display = 'none'; }
}
function showHome() { if (busy) return; for (const k of TABS) $('p-' + k).hidden = true; $('home').hidden = false; $('crumb').hidden = true; document.body.classList.add('home'); }
document.querySelectorAll('.card').forEach(b => { b.onclick = () => { if (!busy) pick(b.dataset.fn); }; });
$('back').onclick = showHome;
// Pəncərədən (popup) seçilmiş bölmə
const openReq = o => { if (o && o.fn && Date.now() - (o.t || 0) < 15000 && !busy) pick(o.fn); };
chrome.storage.onChanged.addListener(c => { if (c.openFn) openReq(c.openFn.newValue); });

// ---- seçim siyahıları (status, növ) ----
function buildOpts(boxId, countId, items, onList) {
  const box = $(boxId), mk = (text, checked, all) => {
    const l = document.createElement('label'), i = document.createElement('input'), s = document.createElement('span');
    i.type = 'checkbox'; i.checked = checked; if (all) i.dataset.all = '1'; else i.value = text; s.textContent = text; l.append(i, s); box.appendChild(l); return i;
  };
  const all = mk('Hamısı', false, true), boxes = items.map(t => mk(t, onList.includes(t)));
  const sync = () => { const n = boxes.filter(b => b.checked).length; all.checked = n === boxes.length; all.indeterminate = n > 0 && n < boxes.length; $(countId).textContent = n === boxes.length ? 'hamısı' : n + ' / ' + boxes.length; };
  all.onchange = () => { boxes.forEach(b => { b.checked = all.checked; }); sync(); };
  boxes.forEach(b => { b.onchange = sync; }); sync();
  return () => boxes.filter(b => b.checked).map(b => b.value);
}
let getSt = () => [], getTy = () => [];

function render(s) {
  if (!s) { say(FN[fn].idle); return; }
  const stale = !s.done && Date.now() - s.t > 180000;       // yarımçıq qalmış köhnə iş
  const done = s.done || stale; busy = !done;
  if (s.fn && s.fn !== fn && (busy || !stale)) pick(s.fn, true);
  else if (s.fn === 'vat' && curTax() !== 'edvevez' && (busy || !stale)) pick('vat', true);
  say(stale ? FN[fn].idle : s.msg, /^(Xəta|Natamam)/.test(s.msg), /^Hazırdır/.test(s.msg));
  const sb = $('stats'), tiles = stale ? [] : (s.stats || []);
  sb.style.display = tiles.length ? 'flex' : 'none'; sb.replaceChildren();
  tiles.forEach(t => { const d = document.createElement('div'), b = document.createElement('b'), l = document.createElement('span'); b.textContent = t.v; l.textContent = t.l; d.append(b, l); sb.appendChild(d); });
  go.disabled = busy; $('cancel').style.display = busy ? 'block' : 'none';
  const bar = $('bar');
  if (s.n && busy) { bar.style.display = 'block'; bar.firstChild.style.width = Math.round((s.i || 0) / s.n * 100) + '%'; }
  else bar.style.display = 'none';
  const tb = $('sum'), rows = stale ? [] : (s.summary || []);
  tb.style.display = rows.length ? 'table' : 'none';
  tb.tBodies[0].replaceChildren(); tb.tFoot.replaceChildren();
  rows.forEach(r => {
    const tr = tb.tBodies[0].insertRow(); cell(tr, r.p, r.k);
    if (r.note) { const td = tr.insertCell(); td.colSpan = 3; td.className = 'note'; td.textContent = r.note; return; }
    cell(tr, r.c); cell(tr, fmt(r.t)); cell(tr, fmt(r.v));
  });
  const nums = rows.filter(r => !r.note);
  if (nums.length > 1) {
    const tr = tb.tFoot.insertRow(), sum = k => nums.reduce((a, r) => a + (r[k] || 0), 0);
    cell(tr, 'Cəmi'); cell(tr, sum('c')); cell(tr, fmt(sum('t'))); cell(tr, fmt(sum('v')));
  }
}

const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const now = new Date(), prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
const fillMY = (mId, yId, val) => {
  const [y, m] = val.split('-').map(Number);
  MONTHS.forEach((n, i) => $(mId).add(new Option(n, String(i + 1).padStart(2, '0'))));
  for (let yy = now.getFullYear(); yy >= 2018; yy--) $(yId).add(new Option(yy, yy));
  $(mId).value = String(m).padStart(2, '0'); $(yId).value = String(y);
  if (!$(yId).value) $(yId).value = String(now.getFullYear());
};
const ym = (mId, yId) => $(yId).value + '-' + $(mId).value;
const curTax = () => (document.querySelector('input[name=btype]:checked') || {}).value || 'edv';
const curPer = () => (TAXL.find(x => x[0] === curTax()) || [0, 0, 'ay'])[2];
// seçilmiş dövr → ay aralığı (rüb: 3 ay, il: 12 ay)
const perRange = (mId, yId, end) => { const p = curPer(), y = $(yId).value, v = +$(mId).value; const m = p === 'ay' ? v : p === 'rub' ? (end ? v * 3 : v * 3 - 2) : (end ? 12 : 1); return y + '-' + String(m).padStart(2, '0'); };
const parseNums = () => { const all = $('nums').value.toUpperCase().split(/[\s,;]+/).filter(Boolean); return { ok: [...new Set(all.filter(s => /^[A-Z]{2}\d{6,}$/.test(s)))], bad: all.filter(s => !/^[A-Z]{2}\d{6,}$/.test(s)) }; };
(async () => {
  const { status, range, drange, filters, docs, company, docOpts, lastFn, brange } = await chrome.storage.local.get(['status', 'range', 'drange', 'filters', 'docs', 'company', 'docOpts', 'lastFn', 'brange']);
  const defM = iso(prev).slice(0, 7), okM = v => /^\d{4}-\d{2}$/.test(v || '');
  fillMY('fm', 'fy', range && okM(range.from) ? range.from : defM); fillMY('tm', 'ty', range && okM(range.to) ? range.to : defM);
  if (range && range.kam === false) $('kam').checked = false;
  // Bəyannamələr: növ seçimi və növə görə dövr (aylıq: ay, rüblük: rüb, illik: yalnız il)
  const bt = $('btype');
  TAXL.forEach(([k, t, p], i) => { const l = document.createElement('label'), r = document.createElement('input'), sp = document.createElement('span'), sm = document.createElement('small');
    r.type = 'radio'; r.name = 'btype'; r.value = k; r.checked = (brange && brange.tax ? brange.tax === k : k === 'edv'); sp.textContent = t; sm.textContent = PER[p]; sp.appendChild(sm); l.append(r, sp); bt.appendChild(l); r.onchange = () => { setPer(); if (!busy) pick('decls'); }; });
  for (const y of ['by1', 'by2']) for (let yy = now.getFullYear(); yy >= 2018; yy--) $(y).add(new Option(yy, yy));
  const setPer = (keep) => {
    const p = curPer();
    for (const [m, y, l, w] of [['bm1', 'by1', 'bl1', 'from'], ['bm2', 'by2', 'bl2', 'to']]) {
      const prev = keep && brange && brange[w] && okM(brange[w]) ? brange[w] : (p === 'il' ? (now.getFullYear() - 1) + '-' + (w === 'from' ? '01' : '12') : defM);
      const [yy, mm] = prev.split('-').map(Number);
      $(m).replaceChildren(); $(m).hidden = p === 'il';
      if (p === 'ay') MONTHS.forEach((n, i) => $(m).add(new Option(n, i + 1))); else if (p === 'rub') QUARTERS.forEach((n, i) => $(m).add(new Option(n, i + 1)));
      $(m).value = String(p === 'ay' ? mm : Math.ceil(mm / 3)); $(y).value = String(yy); if (!$(y).value) $(y).value = String(now.getFullYear());
      $(l).firstChild.textContent = (w === 'from' ? 'Başlanğıc ' : 'Son ') + { ay: 'ay', rub: 'rüb', il: 'il' }[p];
    }
  };
  setPer(true);
  if (brange && brange.kam === false) $('bkam').checked = false;
  $('dfrom').value = (drange && drange.from) || iso(new Date(now.getFullYear(), now.getMonth(), 1)); $('dto').value = (drange && drange.to) || iso(now);
  if (drange && drange.dir === 'out') document.querySelector('input[name=dir][value=out]').checked = true;
  getSt = buildOpts('o-st', 'c-st', STATUSES, (filters && filters.st) || STATUSES.filter(x => !STATUS_OFF.includes(x)));
  getTy = buildOpts('o-ty', 'c-ty', [...TYPES, OTHER], (filters && filters.ty) || [...TYPES, OTHER]);
  chrome.storage.local.get('mrange', ({ mrange }) => { const r = mrange || {}; $('mfrom').value = r.from || iso(new Date(now.getFullYear(), 0, 1)); $('mto').value = r.to || iso(now); });
  chrome.storage.local.get('rrange', ({ rrange }) => {
    const r = rrange || {}; $('rfrom').value = r.from || iso(new Date(now.getFullYear(), 0, 1)); $('rto').value = r.to || iso(now);
    if (r.dir === 'out') document.querySelector('input[name=rdir][value=out]').checked = true;
  });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  // Alt sənədlər
  const dd = docs || {};
  $('nums').value = dd.nums || ''; $('dvoen').value = dd.voen || '';
  $('dfrom2').value = dd.from || iso(new Date(now.getFullYear(), now.getMonth(), 1)); $('dto2').value = dd.to || iso(now);
  if (dd.dir === 'in') document.querySelector('input[name=ddir][value=in]').checked = true;
  const subs = () => { for (const k of ['prot', 'hf']) $('s-' + k).hidden = !$('d-' + k).checked; };
  for (const k of ['akt', 'prot', 'hf']) { if (dd[k] === false) $('d-' + k).checked = false; $('d-' + k).onchange = subs; } subs();
  // sənədlərə aid əlavə sahələr (şəhər, müqavilə, bank): yazıldıqca yadda saxlanır
  const oIn = [...document.querySelectorAll('[data-o]')], old = company || {}, oSaved = docOpts || { bank: old.bank || '', code: old.code || '', swift: old.swift || '', corr: old.corr || '', acc: old.acc || '' };
  oIn.forEach(i => { i.value = oSaved[i.dataset.o] || ''; i.oninput = () => chrome.storage.local.set({ docOpts: Object.fromEntries(oIn.map(x => [x.dataset.o, x.value.trim()])) }); });
  chrome.storage.local.get('ownSeen', ({ ownSeen }) => { if (ownSeen && (ownSeen.name || ownSeen.voen)) $('own').textContent = `Son dəfə tapılan: ${ownSeen.name || '?'}, VÖEN ${ownSeen.voen || '?'}.`; });
  $('chkown').onclick = async () => {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!/^https:\/\/new\.e-taxes\.gov\.az\//.test((t && t.url) || '')) { say('Əvvəlcə e-taxes-ə daxil ol (istənilən səhifə olar).', true); return; }
    $('chkown').disabled = true; say('Şirkətin məlumatı axtarılır...');
    chrome.runtime.sendMessage({ type: 'own', tabId: t.id }, r => {
      $('chkown').disabled = false;
      if (!r || !r.ok) { say((r && r.error) || 'Alınmadı.', true); return; }
      const o = r.own;
      if (o.name || o.voen) { $('own').textContent = `Tapıldı: ${o.name || '?'}, VÖEN ${o.voen || '?'}.`; say(`Şirkət: ${o.name || 'ad tapılmadı'}, VÖEN: ${o.voen || 'tapılmadı'}.`, !(o.name && o.voen), !!(o.name && o.voen)); }
      else say('Şirkətin məlumatı tapılmadı. "Dəstək məlumatını kopyala" düyməsinə basıb nəticəni göndər.', true);
    });
  };
  const hint = () => { const has = parseNums().ok.length > 0; $('ddates').style.display = has ? 'none' : 'flex'; $('dhint').textContent = has ? 'Nömrə yazılıb: tarixlərə baxılmır, siyahıda həmin qaimələr axtarılır.' : 'Nömrə yazılmayıbsa, VÖEN-ə uyğun bu tarixlərdəki bütün qaimələr götürülür.'; };
  $('nums').oninput = hint; hint();
  showHome();
  if (status && (!status.done || Date.now() - status.t < 180000)) render(status); else if (status) say(status.msg);
  const { openFn } = await chrome.storage.local.get('openFn'); openReq(openFn);
})();
chrome.storage.onChanged.addListener(c => { if (c.status) render(c.status.newValue); });

async function startDocs() {
  const nums = parseNums(), voen = $('dvoen').value.trim(), from = $('dfrom2').value, to = $('dto2').value;
  const docs = { akt: $('d-akt').checked, prot: $('d-prot').checked, hf: $('d-hf').checked }, dir = document.querySelector('input[name=ddir]:checked').value;
  if (nums.bad.length) { say('Bu nömrələr qaimə nömrəsinə oxşamır: ' + nums.bad.slice(0, 4).join(', ') + '. Nümunə: MT261111186128', true); return; }
  if (voen && !/^\d{10}$/.test(voen)) { say('VÖEN 10 rəqəm olmalıdır.', true); return; }
  if (!nums.ok.length && !voen) { say('Qaimə nömrəsi və ya VÖEN yaz.', true); return; }
  if (!nums.ok.length && (!from || !to || from > to)) { say('Tarixləri düzgün seç: başlanğıc sondan sonra ola bilməz.', true); return; }
  if (!docs.akt && !docs.prot && !docs.hf) { say('Ən azı bir sənəd növü seç.', true); return; }
  const tab = await etaxTab();
  if (!tab) { say(FN.docs.need, true); return; }
  const v = k => document.querySelector(`[data-o="${k}"]`).value.trim();
  const opts = { contractNo: docs.prot ? v('contractNo') : '', contractDate: docs.prot ? v('contractDate') : '',
    bank: docs.hf ? { bank: v('bank'), code: v('code'), swift: v('swift'), corr: v('corr'), acc: v('acc') } : {} };
  await chrome.storage.local.set({ docs: { nums: $('nums').value, voen, from, to, dir, ...docs }, lastFn: 'docs', status: { msg: 'Başlayır...', done: false, t: Date.now(), fn: 'docs' } });
  chrome.runtime.sendMessage({ type: 'start', fn: 'docs', tabId: tab.id, serials: nums.ok, voen, from, to, dir, docs, opts }, r => { if (r && !r.ok && r.error) say(r.error, true); });
}

async function startDecls() {
  const from = perRange('bm1', 'by1', false), to = perRange('bm2', 'by2', true), tax = curTax();
  if (from > to) { say('Dövrləri düzgün seç: başlanğıc sondan sonra ola bilməz.', true); return; }
  const tab = await etaxTab();
  if (!tab) { say(FN.decls.need, true); return; }
  const skipKameral = $('bkam').checked;
  await chrome.storage.local.set({ brange: { from, to, kam: skipKameral, tax }, lastFn: 'decls', status: { msg: 'Başlayır...', done: false, t: Date.now(), fn: 'decls' } });
  chrome.runtime.sendMessage({ type: 'start', fn: 'decls', tabId: tab.id, from, to, taxes: [tax], skipKameral }, r => { if (r && !r.ok && r.error) say(r.error, true); });
}

async function startMal() {
  const from = $('mfrom').value, to = $('mto').value;
  if (!from || !to || from > to) { say('Tarixləri düzgün seç: başlanğıc sondan sonra ola bilməz.', true); return; }
  const tab = await etaxTab();
  if (!tab) { say(FN.mal.need, true); return; }
  const imp = typeof impLines === 'function' ? impLines({ from, to }) : [];
  if (typeof IMP !== 'undefined' && IMP && !imp.length) { say('Gömrük faylında bu tarixlərə aid mal sətri tapılmadı (və ya "Malın adı" və "Miqdar" sütunları seçilməyib).', true); return; }
  await chrome.storage.local.set({ mrange: { from, to }, lastFn: 'mal', status: { msg: 'Başlayır...', done: false, t: Date.now(), fn: 'mal' } });
  chrome.runtime.sendMessage({ type: 'start', fn: 'mal', tabId: tab.id, from, to, imp, auto: $('mauto').checked }, r => { if (r && !r.ok && r.error) say(r.error, true); });
}
async function startRisk() {
  const from = $('rfrom').value, to = $('rto').value, dir = document.querySelector('input[name=rdir]:checked').value;
  if (!from || !to || from > to) { say('Tarixləri düzgün seç: başlanğıc sondan sonra ola bilməz.', true); return; }
  const tab = await etaxTab();
  if (!tab) { say(FN.risk.need, true); return; }
  await chrome.storage.local.set({ rrange: { from, to, dir }, lastFn: 'risk', status: { msg: 'Başlayır...', done: false, t: Date.now(), fn: 'risk' } });
  chrome.runtime.sendMessage({ type: 'start', fn: 'risk', tabId: tab.id, from, to, dir }, r => { if (r && !r.ok && r.error) say(r.error, true); });
}
go.onclick = async () => {
  if (fn === 'anal') { await chrome.storage.local.set({ lastFn: 'anal' }); await chrome.tabs.create({ url: chrome.runtime.getURL('analiz.html') }); return; }
  if (fn === 'toplu') { await chrome.storage.local.set({ lastFn: 'toplu' }); await chrome.tabs.create({ url: chrome.runtime.getURL('toplu.html') }); return; }
  if (fn === 'risk') return startRisk();
  if (fn === 'mal') return startMal();
  if (fn === 'docs') return startDocs();
  if (fn === 'decls') return startDecls();
  const items = fn === 'items';
  const from = items ? $('dfrom').value : ym('fm', 'fy'), to = items ? $('dto').value : ym('tm', 'ty');
  if (!from || !to || from > to) { say('Tarixləri düzgün seç: başlanğıc sondan sonra ola bilməz.', true); return; }
  const tab = await etaxTab();
  if (!tab) { say(FN[fn].need, true); return; }
  const skipKameral = $('kam').checked, dir = document.querySelector('input[name=dir]:checked').value;
  const stOn = getSt(), tyOn = getTy();
  if (items && (!stOn.length || !tyOn.length)) { say('Ən azı bir status və bir qaimə növü seç.', true); return; }
  const statuses = stOn.length === STATUSES.length ? null : { known: STATUSES, on: stOn, other: true };
  const types = tyOn.length === TYPES.length + 1 ? null : { known: TYPES, on: tyOn.filter(x => x !== OTHER), other: tyOn.includes(OTHER) };
  await chrome.storage.local.set({ lastFn: fn, ...(items ? {} : { brange: { ...((await chrome.storage.local.get('brange')).brange || {}), tax: 'edvevez' } }), [items ? 'drange' : 'range']: items ? { from, to, dir } : { from, to, kam: skipKameral }, filters: { st: stOn, ty: tyOn },
    status: { msg: 'Başlayır...', done: false, t: Date.now(), fn } });
  chrome.runtime.sendMessage({ type: 'start', fn, tabId: tab.id, from, to, skipKameral, dir, statuses, types }, r => { if (r && !r.ok && r.error) say(r.error, true); });
};
$('cancel').onclick = () => chrome.runtime.sendMessage({ type: 'cancel' });

$('sup').onclick = async () => {
  const { report } = await chrome.storage.local.get('report');
  if (!report) { say('Hələ dəstək məlumatı yoxdur. Əvvəlcə funksiyanı bir dəfə işlət.', true); return; }
  await navigator.clipboard.writeText(JSON.stringify(report, null, 1));
  say('Dəstək məlumatı kopyalandı. İçində məbləğ, VÖEN və ad yoxdur.');
};

// ---- Lisenziya ----
const LMSG = { yoxdur: 'Bu cihazda DataX Advisory-ni işlətmək üçün lisenziya açarı lazımdır.', imza: 'Saxlanmış açar etibarsızdır. Yeni açar daxil et.', cihaz: 'Saxlanmış açar başqa cihaz üçündür. Bu cihazın kodu ilə yeni açar al.', bitib: 'Lisenziyanın müddəti bitib. Yeni açar al.', format: 'Saxlanmış açar düzgün deyil.', dayandirilib: 'Lisenziya dayandırılıb. Davam etmək üçün əlaqə saxlayın: +994 50 656 21 01.', sinxron: 'Lisenziya 14 gündür yoxlanıla bilmir. İnternetə qoşulun və pəncərəni yenidən açın.' };
const fmtD = s => s ? s.split('-').reverse().join('.') : '';
function showLic(r) {
  $('devid').textContent = r.device || '...';
  document.body.classList.toggle('nolic', !r.ok);
  if (!r.ok) { $('licmsg').textContent = LMSG[r.reason] || LMSG.yoxdur; return; }
  $('licnumv').textContent = r.device || '';
  $('licinfo').textContent = `Lisenziya${r.name ? ': ' + r.name + ',' : ':'} ${fmtD(r.until)}-dək`;
  $('licinfo').classList.toggle('warn', r.days < 15);
  if (r.days < 15) $('licinfo').textContent += ` (${r.days} gün qalıb)`;
}
chrome.runtime.sendMessage({ type: 'checkUpdate' }, () => void chrome.runtime.lastError);
chrome.runtime.sendMessage({ type: 'lic' }, r => { if (r) showLic(r); chrome.runtime.sendMessage({ type: 'lic', sync: true }, r2 => { if (r2) showLic(r2); }); });
$('devcopy').onclick = async () => { try { await navigator.clipboard.writeText($('devid').textContent); $('devcopy').textContent = 'Kopyalandı'; } catch (e) {} };
$('licgo').onclick = () => {
  const key = $('lickey').value.trim(); if (!key) { $('licst').textContent = 'Açarı yapışdır.'; return; }
  $('licst').textContent = 'Yoxlanılır...';
  chrome.runtime.sendMessage({ type: 'setLic', key }, r => {
    if (r && r.ok) { $('licst').textContent = ''; $('lickey').value = ''; showLic(r); return; }
    $('licst').textContent = { imza: 'Açar etibarsızdır.', cihaz: 'Bu açar başqa cihaz üçündür.', bitib: 'Bu açarın müddəti bitib.', dayandirilib: 'Lisenziya hələ dayandırılıb. İdarəetmə panelində bərpa olunmalıdır.', sinxron: 'İnternet bağlantısını yoxla və yenidən cəhd et.', format: 'Açar düzgün deyil: tam kopyalandığını yoxla.' }[r && r.reason] || 'Açar qəbul olunmadı.';
  });
};


$('logout').onclick = () => {
  if (!confirm('Çıxış edilsin? Yenidən daxil olmaq üçün lisenziya açarı lazım olacaq.')) return;
  chrome.storage.local.remove(['license', 'licState'], () => chrome.runtime.sendMessage({ type: 'lic' }, r => { if (r) showLic(r); }));
};
