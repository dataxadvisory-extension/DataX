// new.e-taxes.gov.az giriş səhifəsi (ASAN imza): şirkət siyahısı paneli.
// Yalnız /eportal/login* ünvanlarında işləyir. Paneli Shadow DOM-da qurur ki, portalın CSS-i ilə qarışmasın.
// Şirkətin düyməsinə basanda mobil nömrə və ASAN ID xanaları doldurulur və (ayarda açıqdırsa) portalın "Daxil ol" düyməsi basılır:
// təsdiq sorğusu telefona gedir, təsdiqi ASAN İmza sahibi telefonda edir. PIN burada heç vaxt istənilmir və saxlanmır.
(() => {
  if (window.__dxAsanGiris) return; window.__dxAsanGiris = true;
  const ASAN_PATH = /^\/eportal\/login\/asan\/?$/;

  // ---- portalın real xanaları: id-lər və atributlar; avtomatik yaranan class adlarına bel bağlanmır ----
  function findForm() {
    let phone = document.querySelector('input#phone');
    if (!phone) phone = [...document.querySelectorAll('form input[type=text], form input[type=tel]')].find(i => /\d\d \d{3} \d\d \d\d/.test(i.placeholder || '') || i.maxLength === 9);
    if (!phone) return null;
    const form = phone.form || phone.closest('form'); if (!form) return null;
    const userId = form.querySelector('input#userId') || form.querySelector('input[type=password]');
    const submit = form.querySelector('#loginPageSignInButton') || form.querySelector('button[type=submit]');
    return userId && submit ? { form, phone, userId, submit } : null;
  }
  const visible = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  // Portal dəyəri görsün deyə: native value setter + input/change hadisələri (sadə el.value = ... React-də işləməyə bilər)
  const NATIVE = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  function setNative(el, v) {
    el.focus();
    NATIVE.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  // Captcha və ya xəta görünürsə avtomatik basılmır, yalnız doldurulur
  function blocker() {
    const cap = [...document.querySelectorAll('iframe[src*="captcha" i], .g-recaptcha, [class*="captcha" i], [id*="captcha" i]')].find(visible);
    if (cap) return 'Captcha görünür';
    const err = [...document.querySelectorAll('[role="alert"], .ant-form-item-explain-error, .ant-alert-error, .ant-message-error, .ant-notification-notice-error')].find(e => visible(e) && (e.innerText || '').trim());
    if (err) return 'Portalda xəta görünür: ' + err.innerText.trim().slice(0, 80);
    return '';
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const lic = () => new Promise(res => { try { chrome.runtime.sendMessage({ type: 'lic' }, r => { void chrome.runtime.lastError; res(!!(r && r.ok)); }); } catch (e) { res(false); } });

  // ---- panel (Shadow DOM) ----
  const host = document.createElement('div'); host.id = 'dx-asan-host'; host.style.display = 'none';
  const root = host.attachShadow({ mode: 'closed' });
  const css = `
  :host{all:initial}
  *{box-sizing:border-box}
  .p{position:fixed;top:88px;right:16px;z-index:2147483000;width:300px;max-height:calc(100vh - 110px);display:flex;flex-direction:column;font:13px/1.45 "Segoe UI",system-ui,Arial,sans-serif;color:#e8ecef;background:#1b2128;border:1px solid #37424d;border-radius:14px;box-shadow:0 12px 34px rgba(0,0,0,.35);overflow:hidden}
  @media (max-width:820px){.p{top:auto;right:8px;left:8px;bottom:8px;width:auto;max-height:60vh}}
  .hd{display:flex;align-items:center;gap:8px;padding:10px 12px;background:linear-gradient(135deg,#232b33,#18343a);cursor:pointer;user-select:none}
  .hd b{flex:1;font-size:13.5px}.hd b span{color:#6ea5cc}
  .hd i{font-style:normal;color:#8d99a5;font-size:12px}
  .bd{display:flex;flex-direction:column;min-height:0;padding:10px 12px 8px}
  .c .bd{display:none}
  input[type=search]{width:100%;padding:7px 10px;border:1px solid #37424d;border-radius:8px;background:#14181d;color:#e8ecef;font:inherit;outline:none}
  input[type=search]:focus{border-color:#3fb3a6}
  .ls{margin:8px 0;overflow:auto;min-height:0;max-height:300px}
  .it{display:flex;align-items:center;gap:8px;padding:7px 4px;border-bottom:1px solid #2b343d}
  .it:last-child{border-bottom:0}
  .tx{flex:1;min-width:0}
  .nm{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .sb{color:#8d99a5;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  button{font:inherit;cursor:pointer}
  .go{flex:none;padding:6px 11px;border:0;border-radius:999px;background:linear-gradient(135deg,#3fb3a6,#2f8fa8);color:#fff;font-weight:600;font-size:12.5px}
  .go:hover:not(:disabled){filter:brightness(1.1)}.go:disabled{opacity:.45;cursor:default}
  .em{padding:12px 4px;color:#8d99a5;text-align:center}
  .ft{display:flex;align-items:center;justify-content:space-between;gap:8px;padding-top:6px;border-top:1px solid #2b343d;font-size:12px}
  .ft label{display:flex;align-items:center;gap:6px;cursor:pointer}
  .lk{padding:0;border:0;background:none;color:#6ea5cc;font-size:12px;text-decoration:underline}
  .st{min-height:18px;margin-top:6px;font-size:12px;color:#8eeee4}.st.w{color:#f0a86a}.st.e{color:#ef8a7f}
  .cd{font-size:11.5px;color:#f0a86a}
  .nt{margin-top:4px;font-size:11px;color:#8d99a5}`;
  const style = document.createElement('style'); style.textContent = css; root.appendChild(style);
  const h = (tag, props = {}, ...kids) => { const e = document.createElement(tag); Object.assign(e, props); kids.forEach(k => e.append(k)); return e; };
  const wrap = h('div', { className: 'p' }), head = h('div', { className: 'hd' }, h('b', {}, 'Data', h('span', {}, 'X'), ' · şirkətlər'), h('i', { textContent: '' }));
  const search = h('input', { type: 'search', placeholder: 'Axtar: ad, VÖEN, qeyd...', autocomplete: 'off', spellcheck: false });
  const listEl = h('div', { className: 'ls' }), cdEl = h('div', { className: 'cd' }), stEl = h('div', { className: 'st', role: 'status' });
  const autoCb = h('input', { type: 'checkbox' }), manage = h('button', { className: 'lk', type: 'button', textContent: 'Siyahını idarə et' });
  const ft = h('div', { className: 'ft' }, h('label', {}, autoCb, 'Avtomatik göndər'), manage);
  const note = h('div', { className: 'nt', textContent: 'Təsdiqi telefonda ASAN İmza sahibi edir. PIN burada istənilmir.' });
  wrap.append(head, h('div', { className: 'bd' }, search, listEl, ft, cdEl, stEl, note)); root.appendChild(wrap);

  let S = { list: [], auto: true, sent: null }, collapsed = window.innerWidth <= 820, licOk = true, busy = false;
  const say = (m, k) => { stEl.textContent = m || ''; stEl.className = 'st' + (k ? ' ' + k : ''); };
  const setCollapsed = c => { collapsed = c; wrap.classList.toggle('c', c); head.lastChild.textContent = c ? 'aç' : 'gizlət'; };
  head.onclick = () => setCollapsed(!collapsed);
  manage.onclick = () => { try { chrome.runtime.sendMessage({ type: 'asan-ayarlar' }); } catch (e) { say('Extension yenilənib: səhifəni yenilə.', 'w'); } };
  autoCb.onchange = () => asanSetAuto(autoCb.checked);
  search.oninput = () => render();

  function render() {
    autoCb.checked = S.auto;
    const rows = asanFilter(asanSort(S.list), search.value); listEl.replaceChildren();
    if (!S.list.length) listEl.append(h('div', { className: 'em' }, 'Hələ şirkət yoxdur. "Siyahını idarə et" ilə əlavə et.'));
    else if (!rows.length) listEl.append(h('div', { className: 'em' }, 'Tapılmadı.'));
    for (const c of rows) {
      const sub = [asanPhoneMask(c.phone), c.voen, c.note].filter(Boolean).join(' · ');
      const b = h('button', { className: 'go', type: 'button', textContent: S.auto ? 'Daxil ol' : 'Doldur', title: S.auto ? 'Xanaları doldurub giriş sorğusunu göndərir' : 'Yalnız xanaları doldurur' });
      b.disabled = !licOk || busy; b.onclick = () => use(c);
      listEl.append(h('div', { className: 'it' }, h('div', { className: 'tx' }, h('div', { className: 'nm', textContent: c.name, title: c.name }), h('div', { className: 'sb', textContent: sub, title: sub })), b));
    }
    if (!licOk) say('DataX lisenziyası lazımdır (extension pəncərəsinə bax).', 'w');
    cdTick();
  }
  function cdTick() {
    const left = S.sent ? Math.ceil((S.sent.ts + ASAN_COOLDOWN - Date.now()) / 1000) : 0;
    cdEl.textContent = left > 0 ? `Növbəti avtomatik sorğu: ${left} san sonra` : '';
  }
  setInterval(cdTick, 1000);

  async function use(c) {
    if (busy) return; busy = true; render();
    try {
      if (!(licOk = await lic())) { say('DataX lisenziyası lazımdır (extension pəncərəsinə bax).', 'w'); return; }
      const f = findForm(); if (!f) { say('Giriş formu tapılmadı. "Asan İmza" seçimini aç.', 'e'); return; }
      setNative(f.phone, c.phone); setNative(f.userId, c.asanId);
      await sleep(250);
      const okPhone = f.phone.value.replace(/\D/g, '') === c.phone, okId = f.userId.value === c.asanId;
      await asanTouch(c.id);
      if (!okPhone || !okId) { say('Xanalar doldurulmadı: portal dəyəri qəbul etmədi. Özün yaz.', 'e'); return; }
      const { auto, sent } = await asanGet();
      if (!auto) { say('Xanalar dolduruldu. "Daxil ol" düyməsini özün bas.', ''); return; }
      const bl = blocker();
      if (bl) { say(bl + ': xanalar dolduruldu, "Daxil ol" düyməsini özün bas.', 'w'); return; }
      const left = sent ? Math.ceil((sent.ts + ASAN_COOLDOWN - Date.now()) / 1000) : 0;
      if (left > 0) { say(`Telefona sorğu artıq göndərilib. ${left} san dolmayıb: xanalar dolduruldu, gözlə.`, 'w'); return; }
      if (f.submit.disabled) { say('Xanalar dolduruldu, amma portalın düyməsi aktiv deyil. Özün yoxla.', 'w'); return; }
      await sleep(150);
      await new Promise(r => chrome.storage.local.set({ [ASAN_SENT]: { ts: Date.now(), id: c.id } }, r));
      f.submit.click();
      say(`"${c.name}" üçün sorğu göndərildi. Telefonda ASAN İmza təsdiqini gözlə.`, '');
    } catch (e) { say('Xəta: ' + (e && e.message || e), 'e'); }
    finally { busy = false; render(); }
  }

  // ---- səhifəni izləmə: SPA (ünvan yenilənmədən dəyişir), forma gec yüklənə bilər ----
  function sync() {
    const on = ASAN_PATH.test(location.pathname) && !!findForm();
    if (on && !host.isConnected) document.documentElement.appendChild(host);
    host.style.display = on ? '' : 'none';
  }
  let raf = 0; const kick = () => { if (!raf) raf = setTimeout(() => { raf = 0; sync(); }, 80); };
  new MutationObserver(kick).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('popstate', kick); window.addEventListener('hashchange', kick);
  if (window.navigation && navigation.addEventListener) navigation.addEventListener('navigatesuccess', kick);
  setInterval(sync, 700);                                     // ehtiyat: history.pushState hadisə vermir

  async function load() { S = await asanGet(); render(); }
  chrome.storage.onChanged.addListener(c => { if (c[ASAN_KEY] || c[ASAN_SET] || c[ASAN_SENT]) load(); });
  setCollapsed(collapsed); lic().then(ok => { licOk = ok; load(); }); load(); sync();
})();
