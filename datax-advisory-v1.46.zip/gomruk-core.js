// Gömrük bəyannamələri (egbtrader2.customs.gov.az): GB siyahısı, sənədlərin (GB, invoys, CMR) götürülməsi, PDF birləşdirmə, ZIP.
// Content script kimi işləyir, yəni sorğular portalın öz səhifəsindən (eyni mənşə, mövcud giriş) göndərilir.
// Heç nə dəyişdirilmir və göndərilmir: yalnız siyahıya baxış və sənədlərin yüklənməsi.
const GB = (() => {
  const P = 'ctl00$ContentPlaceHolder1$', GRID = 'ctl00_ContentPlaceHolder1_gvCCDMain';
  const parse = t => new DOMParser().parseFromString(t, 'text/html');
  const clean = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ISO (2026-11-18) -> 18.11.2026
  const dmy = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); return m ? `${m[3]}.${m[2]}.${m[1]}` : ''; };

  // ASP.NET WebForms "postback": cari sənədin bütün xanaları + dəyişdirdiklərimiz. Sənəd + son ünvan qaytarılır.
  async function post(st, over) {
    const form = st.doc.forms[0], fd = new FormData(form);
    for (const [k, v] of Object.entries(over)) fd.set(k, v);
    const r = await fetch(new URL(form.getAttribute('action') || '', st.url).href, { method: 'POST', body: fd, credentials: 'include' });
    if (!r.ok) throw new Error('Portal cavab vermədi (' + r.status + ').');
    const text = await r.text();
    return { doc: parse(text), url: r.url, text };
  }
  async function open(url) {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error('Portal cavab vermədi (' + r.status + ').');
    const text = await r.text(), doc = parse(text);
    if (!doc.forms[0]) throw new Error('Portalın səhifəsi açılmadı. e-gömrükdə yenidən daxil ol.');
    return { doc, url: r.url, text };
  }
  const GOOD = { 1: 'Şəxsən tərtib etdiyim GB-lər', 2: 'Təmsilçi tərəfindən tərtib olunmuş GB-lər (Sahibkar üçün)' };

  // Siyahı səhifəsindən sətirlər. i = sətrin səhifədəki sırası (Select$i üçün).
  function grid(doc) {
    const g = doc.getElementById(GRID); if (!g) return { rows: [], total: 0 };
    const rows = [];
    [...g.rows].filter(r => r.cells.length > 12 && r.querySelector('td')).forEach((r, i) => {
      const c = [...r.cells].map(x => clean(x.textContent));
      const img = r.querySelector('input[type=image]');
      rows.push({ i, id: c[1], status: c[2], type: c[5], opDate: c[6], no: c[7], created: c[8], sender: c[11], receiverCode: c[12], receiver: c[13], declarant: c[15], imgName: img ? img.getAttribute('name') : '' });
    });
    const m = /Sayı\s*:\s*(\d+)/.exec(clean(doc.body.textContent));
    return { rows, total: m ? +m[1] : rows.length };
  }
  const hasPage = (text, n) => text.includes('Page$' + n + '&#39;') || text.includes("Page$" + n + "'") || text.includes('Page$' + n + '"');

  // Siyahını gətir: tarix aralığı, mənbə (1 şəxsən / 2 təmsilçi), yalnız İdxal 40.
  // Qaytarır: { rows: [{..., page, pageDoc}], skipped, total }
  async function search({ from, to, source = 2, only40 = true, onProgress }) {
    let st = await open('GBList.aspx');
    st = await post(st, { [P + 'btnAdSearch']: 'Ətraflı axtarış' });   // portal tarix süzgəcini yalnız "Ətraflı axtarış" açılandan sonra qəbul edir
    st = await post(st, { [P + 'filter']: '3', [P + 'filter2']: String(source), [P + 'f1']: dmy(from), [P + 'f2']: dmy(to), [P + 'ch_d']: 'on', [P + 'btn_addSearch']: 'Axtar' });
    const out = [], pages = []; let page = 1, total = 0;
    for (;;) {
      const g = grid(st.doc); total = g.total || total;
      pages[page] = st;
      g.rows.forEach(r => out.push({ ...r, page }));
      if (onProgress) onProgress(out.length, total);
      if (page > 60 || !hasPage(st.text, page + 1)) break;
      st = await post(st, { __EVENTTARGET: 'ctl00$ContentPlaceHolder1$gvCCDMain', __EVENTARGUMENT: 'Page$' + (page + 1) });
      page++;
    }
    const seen = new Set(), rows = [];
    for (const r of out) { if (seen.has(r.no)) continue; seen.add(r.no); rows.push(r); }
    const keep = rows.filter(r => !only40 || /idxal\s*40\b/i.test(r.type));
    return { rows: keep, skipped: rows.length - keep.length, total: total || rows.length, pages };
  }

  // ---- .adoc (ZIP) içindən PDF-lər ----
  async function inflate(u8) { const s = new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate-raw')); return new Uint8Array(await new Response(s).arrayBuffer()); }
  async function unzipPdfs(buf) {
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength); let e = buf.length - 22;
    while (e >= 0 && dv.getUint32(e, true) !== 0x06054b50) e--;
    if (e < 0) throw new Error('İmzalı fayl (.adoc) oxunmadı.');
    const n = dv.getUint16(e + 10, true); let p = dv.getUint32(e + 16, true); const files = [];
    for (let i = 0; i < n; i++) {
      const method = dv.getUint16(p + 10, true), csz = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), lo = dv.getUint32(p + 42, true);
      const name = new TextDecoder().decode(buf.subarray(p + 46, p + 46 + nl));
      if (/\.pdf$/i.test(name)) {
        const s = lo + 30 + dv.getUint16(lo + 26, true) + dv.getUint16(lo + 28, true), raw = buf.subarray(s, s + csz);
        files.push({ name, data: method === 0 ? raw.slice() : await inflate(raw) });
      }
      p += 46 + nl + xl + cl;
    }
    files.sort((a, b) => a.name.localeCompare(b.name, 'en', { numeric: true }));
    return files;
  }
  const popupUrl = text => { const m = /window\.open\(\s*["'](pdfshow\.aspx[^"']+)["']/.exec(text); return m ? m[1] : ''; };
  async function fileOf(url) {
    const r = await fetch(new URL(url, location.href).href, { credentials: 'include' });
    if (!r.ok) throw new Error('Fayl yüklənmədi (' + r.status + ').');
    return new Uint8Array(await r.arrayBuffer());
  }
  const isPdf = u8 => u8.length > 4 && u8[0] === 0x25 && u8[1] === 0x50 && u8[2] === 0x44 && u8[3] === 0x46;

  // Bir GB-nin sənədləri: { gb: [pdf...], invoys: pdf|null, cmr: pdf|null, other: [{label, data}], warn: [..] }
  async function fetchDocs(row, pageSt, want = { gb: true, inv: true, cmr: true }) {
    const res = { gb: [], other: [], warn: [] };
    if (want.gb) {
      try {
        if (!row.imgName) throw new Error('imzalı fayl düyməsi yoxdur');
        const r = await post(pageSt, { [row.imgName + '.x']: '6', [row.imgName + '.y']: '6' });
        const u = popupUrl(r.text); if (!u) throw new Error('imzalı fayl (.adoc) verilməyib, bəyannamə hələ imzalanmayıb ola bilər');
        const z = await fileOf(u), pdfs = await unzipPdfs(z);
        if (!pdfs.length) throw new Error('imzalı faylda PDF yoxdur');
        res.gb = pdfs.map(f => f.data);
      } catch (e) { res.warn.push('GB: ' + e.message); }
    }
    if (want.inv || want.cmr) {
      try {
        const s2 = await post(pageSt, { __EVENTTARGET: 'ctl00$ContentPlaceHolder1$gvCCDMain', __EVENTARGUMENT: 'Select$' + row.i });
        const ed = await post(s2, { [P + 'btnView']: 'Baxış' });
        const gv = ed.doc.getElementById('ctl00_ContentPlaceHolder1_GV_BC');
        if (!gv) throw new Error('bəyannamənin sənədlər cədvəli açılmadı');
        const links = [...gv.querySelectorAll('a[id$=LinkButton3]')].map(a => ({ label: clean(a.textContent), target: ((a.getAttribute('href') || '').match(/PostBackOptions\(\s*(?:&quot;|"|')([^"'&]+)/) || [])[1] })).filter(l => l.target);
        if (!links.length) res.warn.push('Bu bəyannamədə qoşma sənəd (invoys/CMR) yoxdur.');
        for (const l of links) {
          const isInv = /invoy|invoice/i.test(l.label), isCmr = /^cmr/i.test(l.label);
          if ((isInv && !want.inv) || (isCmr && !want.cmr) || (!isInv && !isCmr && !(want.inv && want.cmr))) continue;
          try {
            const r = await post(ed, { __EVENTTARGET: l.target, __EVENTARGUMENT: '' });
            const u = popupUrl(r.text); if (!u) throw new Error('fayl verilməyib');
            const data = await fileOf(u); if (!isPdf(data)) throw new Error('PDF deyil');
            if (isInv) res.invoys = res.invoys || data; else if (isCmr) res.cmr = res.cmr || data; else res.other.push({ label: l.label, data });
          } catch (e) { res.warn.push(l.label + ': ' + e.message); }
        }
      } catch (e) { res.warn.push('Qoşma sənədlər: ' + e.message); }
    }
    return res;
  }

  // PDF-ləri bir fayla birləşdir (pdf-lib content script ilə birlikdə yüklənir)
  async function merge(list) {
    const L = (self.PDFLib || window.PDFLib); if (!L) throw new Error('PDF kitabxanası yüklənməyib.');
    const out = await L.PDFDocument.create();
    for (const b of list) {
      const src = await L.PDFDocument.load(b, { ignoreEncryption: true });
      (await out.copyPages(src, src.getPageIndices())).forEach(p => out.addPage(p));
    }
    return await out.save();
  }
  const ordered = d => [...(d.gb || []), ...(d.invoys ? [d.invoys] : []), ...(d.cmr ? [d.cmr] : []), ...(d.other || []).map(o => o.data)];

  // ---- ZIP (sıxmadan) ----
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zip(files) { // [{name, data: Uint8Array}]
    const enc = new TextEncoder(), chunks = [], central = []; let off = 0;
    const now = new Date(), dt = ((now.getFullYear() - 1980) << 9 | (now.getMonth() + 1) << 5 | now.getDate()) & 0xFFFF, tm = (now.getHours() << 11 | now.getMinutes() << 5 | now.getSeconds() >> 1) & 0xFFFF;
    for (const f of files) {
      const nm = enc.encode(f.name), d = f.data, crc = crc32(d), n = d.length;
      const lh = new DataView(new ArrayBuffer(30)); lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(10, tm, true); lh.setUint16(12, dt, true); lh.setUint32(14, crc, true); lh.setUint32(18, n, true); lh.setUint32(22, n, true); lh.setUint16(26, nm.length, true);
      const ch = new DataView(new ArrayBuffer(46)); ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(12, tm, true); ch.setUint16(14, dt, true); ch.setUint32(16, crc, true); ch.setUint32(20, n, true); ch.setUint32(24, n, true); ch.setUint16(28, nm.length, true); ch.setUint32(42, off, true);
      chunks.push(new Uint8Array(lh.buffer), nm, d); central.push(new Uint8Array(ch.buffer), nm); off += 30 + nm.length + n;
    }
    const cd = central.reduce((s, c) => s + c.length, 0), end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cd, true); end.setUint32(16, off, true);
    const all = [...chunks, ...central, new Uint8Array(end.buffer)], out = new Uint8Array(all.reduce((s, c) => s + c.length, 0)); let p = 0;
    for (const c of all) { out.set(c, p); p += c.length; }
    return out;
  }
  const safe = s => String(s || '').replace(/[\\/:*?"<>|\s]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 80) || 'fayl';
  function save(data, name, type) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: type || 'application/octet-stream' })); a.download = name;
    (document.body || document.documentElement).appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  }
  return { dmy, post, open, grid, search, fetchDocs, merge, ordered, zip, safe, save, unzipPdfs, sleep, isPdf, GOOD };
})();
if (typeof module !== 'undefined') module.exports = GB;
