// ASAN giriş şirkət siyahısının idarəsi (ayarlar səhifəsi): əlavə et, dəyiş, sil, axtar
const $ = id => document.getElementById(id);
let S = { list: [], auto: true }, editing = null; const shown = new Set();
const h = (tag, props = {}, ...kids) => { const e = document.createElement(tag); Object.assign(e, props); kids.forEach(k => e.append(k)); return e; };
const when = ts => { if (!ts) return 'hələ istifadə olunmayıb'; const d = Math.floor((Date.now() - ts) / 864e5); return d <= 0 ? 'bu gün istifadə olunub' : d === 1 ? 'dünən istifadə olunub' : `${d} gün əvvəl istifadə olunub`; };

function render() {
  $('auto').checked = S.auto;
  const rows = asanFilter(asanSort(S.list), $('q').value), ls = $('ls'); ls.replaceChildren();
  if (!S.list.length) ls.append(h('div', { className: 'empty', textContent: 'Hələ şirkət yoxdur. "+ Şirkət əlavə et" ilə başla.' }));
  else if (!rows.length) ls.append(h('div', { className: 'empty', textContent: 'Tapılmadı.' }));
  for (const c of rows) {
    const eye = h('button', { className: 'lnk', type: 'button', textContent: shown.has(c.id) ? 'gizlət' : 'göstər' });
    eye.onclick = () => { shown.has(c.id) ? shown.delete(c.id) : shown.add(c.id); render(); };
    const sub = h('div', { className: 'sb' }, asanPhoneMask(c.phone), ' · ASAN ID: ', h('code', { textContent: shown.has(c.id) ? c.asanId : '•'.repeat(c.asanId.length) }), ' ', eye);
    if (c.voen) sub.append(' · VÖEN ' + c.voen);
    const sub2 = h('div', { className: 'sb', textContent: [c.note, when(c.lastUsed)].filter(Boolean).join(' · ') });
    const ed = h('button', { type: 'button', textContent: 'Dəyiş' }), rm = h('button', { className: 'del', type: 'button', textContent: 'Sil' });
    ed.onclick = () => open(c);
    rm.onclick = async () => { if (confirm(`"${c.name}" siyahıdan silinsin?`)) { await asanRemove(c.id); if (editing === c.id) close(); } };
    ls.append(h('div', { className: 'it' }, h('div', { className: 'tx' }, h('div', { className: 'nm', textContent: c.name, title: c.name }), sub, sub2), ed, rm));
  }
}
function open(c) {
  editing = c ? c.id : null;
  $('f-name').value = c ? c.name : ''; $('f-phone').value = c ? c.phone.replace(/^(\d{2})(\d{3})(\d{2})(\d{2})$/, '$1 $2 $3 $4') : '';
  $('f-asan').value = c ? c.asanId : ''; $('f-voen').value = c ? c.voen || '' : ''; $('f-note').value = c ? c.note || '' : '';
  $('err').textContent = ''; $('form').classList.add('on'); $('f-name').focus(); $('form').scrollIntoView({ block: 'nearest' });
}
function close() { editing = null; $('form').classList.remove('on'); }
$('add').onclick = () => open(null); $('cancel').onclick = close;
$('save').onclick = async () => {
  const r = await asanUpsert({ id: editing, name: $('f-name').value, phone: $('f-phone').value, asanId: $('f-asan').value, voen: $('f-voen').value, note: $('f-note').value });
  if (r.error) { $('err').textContent = r.error; return; }
  close();
};
$('form').addEventListener('keydown', e => { if (e.key === 'Enter') $('save').click(); if (e.key === 'Escape') close(); });
$('q').oninput = render;
$('auto').onchange = () => asanSetAuto($('auto').checked);
async function load() { S = await asanGet(); render(); }
chrome.storage.onChanged.addListener(c => { if (c[ASAN_KEY] || c[ASAN_SET]) load(); });
load();
