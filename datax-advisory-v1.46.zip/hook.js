// e-taxes səhifəsinin içində işləyir: saytın öz profil sorğusunun cavabını səhifənin yaddaşında saxlayır
// (şirkətin adı və VÖEN-i sənədlərə yazılsın deyə). Heç nə heç yerə göndərilmir.
(() => {
  if (window.__dxProf) return;
  const store = window.__dxProf = [], auth = window.__dxAuth = {};
  const want = u => /\/api\/[^?]*(profile|taxpayer|userinfo|user-info)/i.test(String(u || ''));
  const isApi = u => /\/api\//.test(String(u || ''));
  const keep = k => /^(authorization|x-[\w-]+|token|access-token)$/i.test(k);
  const take = h => {
    try {
      if (!h) return;
      if (Array.isArray(h)) h.forEach(([k, v]) => { if (keep(k)) auth[k] = v; });
      else if (typeof h.forEach === 'function') h.forEach((v, k) => { if (keep(k)) auth[k] = v; });
      else Object.keys(h).forEach(k => { if (keep(k)) auth[k] = h[k]; });
    } catch (e) {}
  };
  const of = window.fetch;
  window.fetch = async function (input, init) {
    let u = '';
    try { u = typeof input === 'string' ? input : (input && input.url) || ''; if (isApi(u)) { take(init && init.headers); if (typeof input !== 'string' && input && input.headers) take(input.headers); } } catch (e) {}
    const res = await of.apply(this, arguments);
    try { if (want(u) && store.length < 8) res.clone().json().then(j => store.push(j)).catch(() => {}); } catch (e) {}
    return res;
  };
  const X = XMLHttpRequest.prototype, oo = X.open, oh = X.setRequestHeader;
  X.open = function (m, u) {
    try {
      this.__dxU = String(u || '');
      if (want(u)) this.addEventListener('load', () => { try { if (store.length < 8) store.push(this.responseType === 'json' ? this.response : JSON.parse(this.responseText)); } catch (e) {} });
    } catch (e) {}
    return oo.apply(this, arguments);
  };
  X.setRequestHeader = function (k, v) { try { if (isApi(this.__dxU) && keep(k)) auth[k] = v; } catch (e) {} return oh.apply(this, arguments); };
})();
