// Bəyannamə doldurma → ƏDV bəyannaməsi, əvəzləşmə faylı (Əlavə 1, sətir 308)
// ƏDV depozit (sub-uçot) hesabından çıxarış oxunur; paylama fon skriptində (api.js → runEvezApi)
(() => {
  const $ = id => document.getElementById(id);
  const MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
  const low = s => String(s == null ? '' : s).toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();
  const numv = v => { if (typeof v === 'number') return v; const s = String(v == null ? '' : v).replace(/[\s ]/g, ''); if (!s) return 0; const t = s.includes(',') && s.includes('.') ? (s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '')) : s.replace(',', '.'); const n = Number(t); return isNaN(n) ? 0 : n; };
  const f2 = v => (Math.round((v || 0) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const say = (msg, err, ok) => { const s = $('est'); s.textContent = msg; s.classList.toggle('err', !!err); s.classList.toggle('ok', !!ok); };

  // Növ seçimi: Vahid / ƏDV
  const show = () => { const t = $('btype').value; $('t-vahid').hidden = t !== 'vahid'; $('t-edv').hidden = t !== 'edv'; try { localStorage.setItem('dxBtype', t); } catch (e) {} };
  try { const t = localStorage.getItem('dxBtype'); if (t && [...$('btype').options].some(o => o.value === t && !o.disabled)) $('btype').value = t; } catch (e) {}
  $('btype').onchange = show; show();

  // Dövr və tarixçə siyahıları
  const now = new Date();
  for (let k = 0; k < 36; k++) { const d = new Date(now.getFullYear(), now.getMonth() - k, 1); $('eper').add(new Option(`${MONTHS[d.getMonth()]} ${d.getFullYear()}`, `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`)); }
  { const d = new Date(now.getFullYear(), now.getMonth() - 1, 1); $('eper').value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; }
  const fillHist = () => { const y = +$('eper').value.slice(0, 4), cur = $('ehist').value; $('ehist').replaceChildren(); for (let k = y; k >= Math.max(2019, y - 6); k--) $('ehist').add(new Option(k, k)); $('ehist').value = cur && +cur <= y ? cur : String(y - 2); };
  fillHist();

  // Təyinatdan qaimə nömrələri: mətn 35 simvoldan bir yeni sətrə bölünür ("MT2501 12141⏎200"), ona görə həm boşluqla, həm boşluqsuz birləşdirilir
  function refsOf(text, ser, num) {
    const out = new Map(), add = (s, n, strong) => { const k = n; const o = out.get(k); if (!o) out.set(k, { ser: s || '', num: n, strong }); else { if (s && !o.ser) o.ser = s; o.strong = o.strong || strong; } };
    const sn = String(num || '').replace(/\D/g, ''); if (sn) add(String(ser || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6), sn, true);
    const lines = String(text || '').toUpperCase().split(/\r?\n/), hasSer = /[A-Z]{2}\d{4}/.test(lines.join(''));
    for (const t of [lines.join(' '), lines.join('')]) {
      for (const m of t.matchAll(/([A-Z]{2}\d{4})\s*(\d{8})(?!\d)/g)) add(m[1], m[2], true);
      for (const m of t.matchAll(/(?<![\dA-Z])(\d{8})(?!\d)/g)) add('', m[1], hasSer);
    }
    return [...out.values()];
  }
  let st = null;
  function parse(sheets) {
    for (const sh of sheets) {
      const R = sh.rows || [];
      const hi = R.findIndex(r => r && r.some(v => low(v) === 'vöen') && r.some(v => /məxaric/.test(low(v))));
      if (hi < 0) continue;
      const H = R[hi].map(low), sub = (R[hi + 1] || []).map(low), c = re => H.findIndex(h => re.test(h));
      const cV = c(/^vöen$/), cN = c(/adı/), cD = c(/tarix/), cOut = c(/məxaric/), cP = c(/təyinat/), cS = c(/status/);
      const cSer = sub.findIndex(h => /seriya/.test(h)), cNum = sub.findIndex(h => /nömrə/.test(h));
      const top = R.slice(0, hi).map(r => (r || []).map(v => String(v == null ? '' : v)));
      let own = '', company = '', from = '', to = '';
      for (const r of top) for (const v of r) {
        const m = v.match(/^(.*\S)\s*-\s*(\d{10})\s*$/); if (m && !own) { own = m[2]; company = m[1].replace(/\s+/g, ' '); }
        const a = v.match(/(\d{4}-\d{2}-\d{2})\s*\(dən\)/); if (a) from = a[1]; const b = v.match(/(\d{4}-\d{2}-\d{2})\s*\(dək\)/); if (b) to = b[1];
      }
      const pays = []; let ownTr = 0, notDone = 0, inCnt = 0;
      for (let ri = hi + 1; ri < R.length; ri++) {
        const r = R[ri]; if (!r) continue; const voen = String(r[cV] == null ? '' : r[cV]).replace(/\D/g, ''); if (!/^\d{10}$/.test(voen)) continue;
        const out = numv(r[cOut]); if (!(out > 0)) { inCnt++; continue; }
        if (cS >= 0 && r[cS] && !/icra olundu/i.test(String(r[cS]))) { notDone++; continue; }
        if (own && voen === own) { ownTr++; continue; }
        const dm = String(r[cD] || '').match(/(\d{2})[-.](\d{2})[-.](\d{4})/); if (!dm) continue;
        const purpose = String(r[cP] == null ? '' : r[cP]);
        pays.push({ i: ri, dnum: +(dm[3] + dm[2] + dm[1]), date: `${dm[1]}.${dm[2]}.${dm[3]}`, ym: `${dm[3]}-${dm[2]}`, voen, name: String(r[cN] || '').trim().replace(/\s+/g, ' '), vat: Math.round(out * 100) / 100,
          purpose: purpose.replace(/\s*\n\s*/g, ' / '), refs: refsOf(purpose, cSer >= 0 ? r[cSer] : '', cNum >= 0 ? r[cNum] : '') });
      }
      return { own, company, from, to, pays, ownTr, notDone, inCnt };
    }
    throw new Error('Bu fayl ƏDV depozit hesabından çıxarışa oxşamır: "VÖEN" və "Məxaric" sütunları tapılmadı.');
  }
  const monthPays = () => st ? st.pays.filter(p => p.ym === $('eper').value) : [];
  function refresh() {
    const P = monthPays(), sum = P.reduce((t, p) => t + p.vat, 0);
    $('ego').disabled = !P.length || busy;
    $('esum').textContent = st ? (P.length ? `${$('eper').selectedOptions[0].text}: ${P.length} ödəniş, ödənilmiş ƏDV ${f2(sum)} AZN, ${new Set(P.map(p => p.voen)).size} təchizatçı.` : `${$('eper').selectedOptions[0].text} ayına aid ödəniş yoxdur — dövrü yoxla.`) : 'Çıxarışı seç.';
  }
  $('eper').onchange = () => { fillHist(); refresh(); };
  async function load(file) {
    const el = $('efi'); el.className = 'info'; el.textContent = 'Oxunur...'; $('epv').replaceChildren(); $('edl').style.display = 'none'; $('etiles').style.display = 'none';
    try {
      st = parse(await readTable(file));
      if (st.from) { const v = st.from.slice(0, 7); if ([...$('eper').options].some(o => o.value === v)) { $('eper').value = v; fillHist(); } }
      $('ed').classList.add('done'); $('ed').querySelector('b').textContent = file.name;
      const skip = [st.inCnt && `${st.inCnt} mədaxil`, st.ownTr && `${st.ownTr} öz hesabları arasında köçürmə`, st.notDone && `${st.notDone} icra olunmamış`].filter(Boolean);
      el.innerHTML = `<span class="ok">✓ ${esc(st.company || 'Şirkət')}${st.own ? ' · VÖEN ' + st.own : ''}</span>${st.from ? ` · ${st.from.split('-').reverse().join('.')} – ${st.to.split('-').reverse().join('.')}` : ''} · ${st.pays.length} məxaric ödənişi` + (skip.length ? ` (nəzərə alınmadı: ${skip.join(', ')})` : '');
    } catch (e) { st = null; el.className = 'info err'; el.textContent = e.message; }
    refresh();
  }
  { const drop = $('ed'), input = drop.querySelector('input');
    input.onchange = () => input.files[0] && load(input.files[0]);
    drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); }; drop.ondragleave = () => drop.classList.remove('over');
    drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); e.dataTransfer.files[0] && load(e.dataTransfer.files[0]); };
    drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } }; }

  // İşə salma
  let busy = false;
  const setBusy = on => { busy = on; $('estop').style.display = on ? 'inline-block' : 'none'; refresh(); };
  async function etaxTab() { const all = await chrome.tabs.query({ url: 'https://new.e-taxes.gov.az/eportal*' }); return all.find(t => t.active) || all[0] || null; }
  $('ego').onclick = async () => {
    const P = monthPays(); if (!P.length) return;
    const tab = await etaxTab();
    if (!tab) { say('Əvvəlcə e-taxes-ə daxil ol (new.e-taxes.gov.az başqa sekmədə açıq olsun), sonra yenidən bas.', true); return; }
    setBusy(true); $('epv').replaceChildren(); $('edl').style.display = 'none'; $('etiles').style.display = 'none'; say('Başlayır...');
    chrome.runtime.sendMessage({ type: 'evezFetch', tabId: tab.id, own: st.own, period: $('eper').value, histFrom: +$('ehist').value, payments: P }, r => {
      if (chrome.runtime.lastError || !r || !r.ok) { setBusy(false); say((r && r.error) || 'Başlamadı. Extension-u yenidən yüklə.', true); }
    });
  };
  $('estop').onclick = () => chrome.runtime.sendMessage({ type: 'cancel' });
  chrome.storage.onChanged.addListener(ch => { if (busy && ch.status && ch.status.newValue && !ch.status.newValue.done) say(ch.status.newValue.msg); });
  chrome.runtime.onMessage.addListener(m => { if (m.type === 'evezData') { setBusy(false); m.ok ? result(m) : say('Xəta: ' + m.error, true); } });

  async function result(m) {
    const { rows, unalloc, missing, notes, stats } = m;
    const base = rows.reduce((t, r) => t + r.base, 0), paid = rows.reduce((t, r) => t + r.paid, 0), left = unalloc.reduce((t, u) => t + u.left, 0);
    const tiles = [['Ödəniş', stats.pays, f2(stats.payVat) + ' ƏDV'], ['Fayla düşən qaimə', rows.length, f2(paid) + ' ƏDV'], ['Əsas məbləğ', f2(base), 'fayldakı D sütunu'],
      ['Köhnə qaimə', rows.filter(r => /köhnə/.test(r.how)).length, 'təyinatda göstərilməyən'], ['Salınmayan ödəniş', unalloc.length, f2(left) + ' ƏDV', unalloc.length > 0], ['Bəyannamə', stats.decl, 'əvvəlki Əlavə 1 oxundu']];
    $('etiles').replaceChildren(...tiles.map(([l, v, s, red]) => { const d = document.createElement('div'); if (red) d.className = 'r'; d.innerHTML = '<b></b><span></span><small></small>'; d.children[0].textContent = v; d.children[1].textContent = l; d.children[2].textContent = s; return d; }));
    $('etiles').style.display = 'grid';
    // Yükləmə düymələri — fayl yalnız basanda yüklənir
    const box = $('edl'); box.replaceChildren();
    if (rows.length) {
      const data = await window.dxFill('vb-edv308.xlsx', 1, rows.map(r => [308, r.ser, /^0/.test(r.num) ? r.num : Number(r.num), r.base]));
      const b = document.createElement('button'); b.type = 'button'; b.textContent = '⬇ Əvəzləşmə faylını yüklə (e-taxes üçün)';
      b.onclick = () => { window.dxSave(data, `DataX-edv-evezlesme-308-${$('eper').value}.xlsx`); b.textContent = '✓ Əvəzləşmə faylı yükləndi'; }; box.append(b);
    }
    const r2 = document.createElement('button'); r2.type = 'button'; r2.textContent = '⬇ Yoxlama hesabatı (Excel)';
    r2.onclick = () => chrome.runtime.sendMessage({ type: 'dl', group: 'evez' }, x => { if (x && x.ok) r2.textContent = '✓ Yoxlama hesabatı yükləndi'; else say((x && x.error) || 'Yüklənmədi.', true); });
    box.append(r2); box.style.display = 'flex';
    // Cədvəllər
    const pv = $('epv'); let h = '';
    h += `<h3 class="sub">Əvəzləşmə faylına düşən qaimələr (${rows.length})</h3>`;
    h += rows.length ? `<div class="scroll"><table class="pv"><tr><th>Tarix</th><th>Seriya / nömrə</th><th>Satıcı</th><th>ƏDV-yə cəlb edilən</th><th>Qaimənin ƏDV-si</th><th>Əvvəl əvəzləşib</th><th>Bu ay ödənilib (ƏDV)</th><th>Əsas məbləğ (D)</th><th>Necə tapıldı</th></tr>` +
      rows.map(r => `<tr><td>${esc(r.date.slice(0, 10))}</td><td>${esc(r.ser)} ${esc(r.num)}</td><td>${esc(r.name)}<br><small style="color:var(--mute)">${r.voen}</small></td><td class="n">${f2(r.b18)}</td><td class="n">${f2(r.invVat)}</td><td class="n">${r.prev ? f2(r.prev) : ''}</td><td class="n">${f2(r.paid)}</td><td class="n"><b>${f2(r.base)}</b></td><td>${esc(r.how)}${r.full ? '' : '<br><small style="color:var(--mute)">qalıq tam bağlanmadı</small>'}</td></tr>`).join('') +
      `<tr class="tot"><td colspan="6">Cəmi</td><td class="n">${f2(paid)}</td><td class="n">${f2(base)}</td><td></td></tr></table></div>` : '<p class="or">Heç bir ödəniş əvəzləşməyən qaiməyə bağlanmadı.</p>';
    h += `<h3 class="sub${unalloc.length ? ' r' : ''}">Əvəzləşməyə salınmayan ödənişlər (${unalloc.length})</h3>`;
    h += unalloc.length ? `<p class="or">Bu ödənişlər fayla düşmədi — yoxla: qaiməsi gəlməyib, avansdır, yoxsa artıq ödənilib.</p><div class="scroll"><table class="pv"><tr><th>Tarix</th><th>Təchizatçı</th><th>Ödənilmiş ƏDV</th><th>Salınmayan</th><th>Səbəb</th><th>Təyinat</th></tr>` +
      unalloc.map(u => `<tr><td>${esc(u.date)}</td><td>${esc(u.name)}<br><small style="color:var(--mute)">${u.voen}</small></td><td class="n">${f2(u.vat)}</td><td class="n w">${f2(u.left)}</td><td class="w">${esc(u.why)}</td><td><small>${esc(u.purpose)}</small></td></tr>`).join('') + '</table></div>' : '<p class="or">Bütün ödənişlər qaimələrə bağlandı.</p>';
    // Tam salınmayan ödənişlər artıq yuxarıdakı cədvəldədir; burada yalnız başqa qaimələrə paylanan ödənişlər üçün qeyd
    const whole = new Set(unalloc.filter(u => u.left >= u.vat - 0.004).map(u => u.i));
    const extra = [...notes.map(n => n[1]), ...missing.filter(x => !whole.has(x[4])).map(x => x[5] ? `${x[0]}: təyinatdakı qaimə (${x[3]}) hələ təsdiqlənməyib (${x[5]}) — fayla salınmadı, ödəniş ${x[2]}-in digər əvəzləşməyən qaimələrinə paylandı (varsa).` : `${x[0]}: təyinatdakı qaimə (${x[3]}) ${x[2]} qaimələri arasında tapılmadı — ödəniş onun digər əvəzləşməyən qaimələrinə paylandı.`)];
    if (extra.length) h += `<h3 class="sub">Qeydlər</h3><ul class="how">${extra.slice(0, 15).map(t => `<li>${esc(t)}</li>`).join('')}${extra.length > 15 ? `<li>… və daha ${extra.length - 15} (yoxlama hesabatında)</li>` : ''}</ul>`;
    pv.innerHTML = h;
    say(`Hazırdır (${stats.sec} san): ${rows.length} qaimə əvəzləşmə faylına düşdü, Əsas məbləğ cəmi ${f2(base)} AZN.` + (unalloc.length ? ` ${unalloc.length} ödəniş əvəzləşməyə salınmadı — aşağıda bax.` : '') + ' Faylı yükləmək üçün düyməni bas.', false, true);
  }
})();
