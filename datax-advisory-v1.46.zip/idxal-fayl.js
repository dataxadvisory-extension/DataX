// Mal hərəkəti üçün gömrük idxal hesabatı (Excel/CSV): sütunlar avtomatik tanınır, lazım olsa istifadəçi düzəldir.
// readTable() analiz-core.js-dəndir.
const IMP_F = [
  ['name', 'Malın adı', /(mal[ıi]n )?(ad[ıi]|təsviri)|təsvir|naimenov|наименован|описан|description|goods/i, /göndər|alıcı|şirkət|idxalçı|bəyannaməçi|ölkə/i],
  ['code', 'Mal kodu (ƏMTN)', /əmtn|xi̇f|xif|tn ?ved|тн ?вэд|kod|hs ?code|код/i, /gömrük orqan|poçt|ölkə|valyuta|prosedur|rejim|vahid/i],
  ['qty', 'Miqdar', /miqdar|количеств|quantity|say[ıi]/i, /yer|paket|qablaşd/i],
  ['unit', 'Ölçü vahidi', /ölçü|vahid|единиц|unit/i, null],
  ['date', 'Tarix', /tarix|дата|date/i, /doğum|müqavilə|invoys|faktura/i],
  ['gb', 'GB nömrəsi', /bəyannamə|gb|декларац|qeydiyyat n/i, /tarix|növ|tip/i],
  ['sum', 'Dəyər (AZN)', /statistik dəyər|gömrük dəyəri|dəyər|стоимост|value|məbləğ/i, /valyuta|kurs|ədv|rüsum|aksiz|vergi/i]];
const impLow = s => String(s == null ? '' : s).toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();
let IMP = null;   // { file, rows, hi, map }
function impHeader(rows) {
  let best = -1, bs = 0;
  for (let r = 0; r < Math.min(rows.length, 20); r++) {
    const sc = IMP_F.reduce((a, f) => a + ((rows[r] || []).some(h => f[2].test(impLow(h)) && !(f[3] && f[3].test(impLow(h)))) ? 1 : 0), 0);
    if (sc > bs) { bs = sc; best = r; }
  }
  return bs >= 2 ? best : -1;
}
function impAuto(header) {
  const map = {}, used = new Set();
  for (const [k, , m, x] of IMP_F) {
    const c = header.findIndex((h, i) => !used.has(i) && m.test(impLow(h)) && !(x && x.test(impLow(h))));
    if (c >= 0) { map[k] = c; used.add(c); }
  }
  return map;
}
function impRender() {
  const box = $('impmap'); box.replaceChildren();
  if (!IMP) { box.hidden = true; return; }
  box.hidden = false;
  const header = IMP.rows[IMP.hi] || [];
  for (const [k, label] of IMP_F) {
    const l = document.createElement('label'), s = document.createElement('select');
    l.className = 'f'; l.append(label, s);
    s.add(new Option('— yoxdur —', ''));
    header.forEach((h, i) => s.add(new Option(String(h || '(boş)').slice(0, 40), i)));
    s.value = IMP.map[k] != null ? String(IMP.map[k]) : '';
    s.onchange = () => { if (s.value === '') delete IMP.map[k]; else IMP.map[k] = +s.value; impInfo(); };
    box.appendChild(l);
  }
  impInfo();
}
function impInfo() {
  const need = ['name', 'qty'].filter(k => IMP.map[k] == null);
  $('impinfo').className = 'info' + (need.length ? ' err' : '');
  $('impinfo').textContent = need.length ? 'Seç: ' + need.map(k => IMP_F.find(f => f[0] === k)[1]).join(', ')
    : `✓ ${impLines(null).length} mal sətri tanındı. Sütunlar səhvdirsə, aşağıdan düzəlt.`;
}
const impNum = v => { if (typeof v === 'number') return v; const s = String(v == null ? '' : v).replace(/[\s ]/g, ''); const t = s.includes(',') && s.includes('.') ? s.replace(/,/g, '') : s.replace(',', '.'); const n = parseFloat(t); return isNaN(n) ? 0 : n; };
function impDate(v) {
  const s = String(v == null ? '' : v).trim(); let m;
  if ((m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})/))) return +(m[3] + m[2].padStart(2, '0') + m[1].padStart(2, '0'));
  if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})/))) return +(m[1] + m[2] + m[3]);
  if (/^\d{5}(\.\d+)?$/.test(s)) { const d = new Date(Math.round((+s - 25569) * 86400000)); return d.getUTCFullYear() * 10000 + (d.getUTCMonth() + 1) * 100 + d.getUTCDate(); }
  return 0;
}
// Seçilmiş tarix aralığındakı sətirlər (tarix sütunu yoxdursa hamısı)
function impLines(range) {
  if (!IMP || IMP.map.name == null || IMP.map.qty == null) return [];
  const M = IMP.map, g = (r, k) => M[k] == null ? '' : r[M[k]];
  const fromN = range ? +range.from.replace(/-/g, '') : 0, toN = range ? +range.to.replace(/-/g, '') : 99999999;
  return IMP.rows.slice(IMP.hi + 1).map(r => ({ name: String(g(r, 'name') || '').trim(), code: String(g(r, 'code') || '').replace(/\D/g, ''), unit: String(g(r, 'unit') || '').trim(),
    q: impNum(g(r, 'qty')), sum: impNum(g(r, 'sum')), dnum: impDate(g(r, 'date')), gb: String(g(r, 'gb') || '').trim() }))
    .filter(x => x.name && x.q > 0 && (!x.dnum || (x.dnum >= fromN && x.dnum <= toN)));
}
$('impfile').onchange = async e => {
  const f = e.target.files[0]; IMP = null; $('impinfo').className = 'info'; $('impinfo').textContent = f ? 'Oxunur...' : '';
  if (!f) { impRender(); return; }
  try {
    const sheets = await readTable(f); let pick = null;
    for (const sh of sheets) { const hi = impHeader(sh.rows); if (hi >= 0) { pick = { file: f.name, rows: sh.rows, hi }; break; } }
    if (!pick) pick = { file: f.name, rows: sheets[0].rows, hi: 0 };
    pick.map = impAuto(pick.rows[pick.hi] || []); IMP = pick; impRender();
  } catch (err) { $('impinfo').className = 'info err'; $('impinfo').textContent = err.message; impRender(); }
};
$('impclr').onclick = () => { IMP = null; $('impfile').value = ''; $('impinfo').textContent = ''; impRender(); };
