// ASAN giriş şirkət siyahısı: ümumi məntiq (content script, ayarlar səhifəsi və testlər üçün).
// Məlumat yalnız chrome.storage.local-dadır (sync istifadə olunmur), heç bir serverə göndərilmir. PIN heç vaxt istənilmir və saxlanmır.
const ASAN_KEY = 'asanCompanies', ASAN_SET = 'asanSettings', ASAN_SENT = 'asanLastSend';
const ASAN_COOLDOWN = 60000;                                 // ardıcıl sorğular arasında minimum fasilə (ms)

// Mobil nömrə: +994 50 597 15 67 / 050 597 15 67 / 505971567 → "505971567" (9 rəqəm); səhvdirsə '' qaytarır
function asanPhone(v) {
  let d = String(v == null ? '' : v).replace(/\D/g, '');
  if (d.startsWith('994') && d.length === 12) d = d.slice(3);
  else if (d.startsWith('0') && d.length === 10) d = d.slice(1);
  return /^\d{9}$/.test(d) ? d : '';
}
// Maskalı göstəriş: +994 50 *** ** 67
const asanPhoneMask = d => /^\d{9}$/.test(d || '') ? `+994 ${d.slice(0, 2)} *** ** ${d.slice(7)}` : '';
const asanIdOk = v => /^[A-Za-z0-9]{1,6}$/.test(String(v || '').trim());
const asanVoenOk = v => v === '' || /^\d{10}$/.test(String(v || '').trim());
const asanLow = s => String(s == null ? '' : s).toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();

// Ən son istifadə edilən yuxarıda; istifadə olunmayanlar addan sonra
function asanSort(list) {
  return list.slice().sort((a, b) => (b.lastUsed || 0) - (a.lastUsed || 0) || asanLow(a.name).localeCompare(asanLow(b.name), 'az'));
}
// Axtarış: ad, VÖEN, qeyd və nömrənin son rəqəmləri üzrə
function asanFilter(list, q) {
  q = asanLow(q); if (!q) return list;
  return list.filter(c => asanLow(c.name).includes(q) || asanLow(c.voen).includes(q) || asanLow(c.note).includes(q) || (c.phone || '').includes(q.replace(/\D/g, '') || '\u0000'));
}
const asanNewId = () => 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

const asanGet = () => new Promise(res => chrome.storage.local.get([ASAN_KEY, ASAN_SET, ASAN_SENT], r => res({
  list: Array.isArray(r[ASAN_KEY]) ? r[ASAN_KEY] : [], auto: !(r[ASAN_SET] && r[ASAN_SET].auto === false), sent: r[ASAN_SENT] || null })));
const asanSaveList = list => new Promise(res => chrome.storage.local.set({ [ASAN_KEY]: list }, res));
const asanSetAuto = on => new Promise(res => chrome.storage.local.set({ [ASAN_SET]: { auto: !!on } }, res));
// Şirkət əlavə et / dəyiş. Səhv varsa { error } qaytarır
async function asanUpsert(c) {
  const name = String(c.name || '').trim(), phone = asanPhone(c.phone), asanId = String(c.asanId || '').trim(), voen = String(c.voen || '').trim(), note = String(c.note || '').trim();
  if (!name) return { error: 'Şirkətin adını yaz.' };
  if (!phone) return { error: 'Mobil nömrə 9 rəqəm olmalıdır (məs. 50 597 15 67).' };
  if (!asanIdOk(asanId)) return { error: 'ASAN ID (istifadəçi ID) 1-6 simvol olmalıdır, yalnız hərf və rəqəm.' };
  if (!asanVoenOk(voen)) return { error: 'VÖEN 10 rəqəm olmalıdır (və ya boş burax).' };
  const { list } = await asanGet(), i = c.id ? list.findIndex(x => x.id === c.id) : -1;
  if (i > -1) list[i] = { ...list[i], name, phone, asanId, voen, note };
  else list.push({ id: asanNewId(), name, phone, asanId, voen, note, lastUsed: 0, created: Date.now() });
  await asanSaveList(list); return { ok: true };
}
async function asanRemove(id) { const { list } = await asanGet(); await asanSaveList(list.filter(x => x.id !== id)); }
async function asanTouch(id) { const { list } = await asanGet(), c = list.find(x => x.id === id); if (c) { c.lastUsed = Date.now(); await asanSaveList(list); } }
