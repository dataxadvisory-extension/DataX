// Toplu e-qaimə: cədvəl sətirləri → qaimələr → e-taxes paketi (zip: vhf-inf/vhf.mf + hər qaimə üçün XML, versiya 304)
// analiz-core.js-dən istifadə edir: num(), normVoen(), readTable()

// Cədvəlin sütunları (e-taxes "Təqdim etmə cədvəli" ilə eyni sıra)
const TCOLS = [
  { k: 'no', h: '№', m: /^(№|no\.?$|sıra|sira)/ },
  { k: 'voen', h: 'Alıcının VÖEN-i', m: /vöen|voen/ },
  { k: 'ad', h: 'Alıcının adı', m: /alıcının adı|alıcı adı|alıcının adi/ },
  { k: 'kod', h: 'Malın kodu', m: /mal(ın)? kodu/ },
  { k: 'mal', h: 'Malın adı', m: /mal(ın)? adı/ },
  { k: 'eqin', h: 'ƏQİN', m: /əqin|eqin|bar ?kod/ },
  { k: 'vahid', h: 'Ölçü vahidi', m: /ölçü/ },
  { k: 'miq', h: 'Malın miqdarı', m: /miqdar/ },
  { k: 'qiy', h: 'Malın buraxılış qiyməti', m: /qiymət/ },
  { k: 'akd', h: 'Aksiz dərəcəsi(%)', m: /aksiz dərəcə/ },
  { k: 'akm', h: 'Aksiz məbləği', m: /aksiz məbləğ/ },
  { k: 'yol', h: 'Yol vergisi məbləği', m: /yol vergisi/ },
  { k: 'e18', h: 'ƏDV-yə 18 faiz dərəcə ilə cəlb edilən', m: /18/ },
  { k: 'e0', h: 'ƏDV-yə 0 dərəcə ilə cəlb edilən məbləğ', m: /(^|\D)0 dərəcə/ },
  { k: 'azad', h: 'ƏDV-dən azad olunan', m: /azad/ },
  { k: 'edvsiz', h: 'ƏDV-yə cəlb edilməyən məbləğ', m: /cəlb edilməyən/ },
  { k: 'esas', h: 'Əsas', m: /^əsas/ },
  { k: 'elave', h: 'Əlavə', m: /^əlavə$/ }
];
const TNUM = ['miq', 'qiy', 'akd', 'akm', 'yol', 'e18', 'e0', 'azad', 'edvsiz'];
const TSPLIT = ['e18', 'e0', 'azad', 'edvsiz'];
const NOVU = { 'ədv': 'e18', 'edv': 'e18', 'sıfır': 'e0', 'sifir': 'e0', 'azad': 'azad', 'ədvsiz': 'edvsiz', 'edvsiz': 'edvsiz' };
const tlow = s => String(s == null ? '' : s).toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();
const blank = v => v == null || String(v).trim() === '';

// Başlıq sətrini tapır: VÖEN və mal adı olan sətir. Tapılmasa sütunlar e-taxes sırası ilə (A..R) götürülür.
function tHeader(rows) {
  for (let i = 0; i < Math.min(rows.length, 15); i++) {
    const r = (rows[i] || []).map(tlow);
    if (!r.some(c => /vöen|voen/.test(c)) || !r.some(c => /mal(ın)? adı/.test(c))) continue;
    const map = {}, used = new Set();
    for (const f of TCOLS) { const c = r.findIndex((h, j) => !used.has(j) && h && f.m.test(h) && !(f.k === 'e18' && !/ədv|edv/.test(h)) && !(f.k === 'e0' && /aksiz/.test(h))); if (c > -1) { map[f.k] = c; used.add(c); } }
    const nv = r.findIndex(h => /vergi növü|vergi novu/.test(h)); if (nv > -1) map.novu = nv;
    return { hi: i, map };
  }
  const map = {}; TCOLS.forEach((f, j) => { map[f.k] = j; });
  return { hi: -1, map };
}
// Faylın/yapışdırılmış mətnin sətirlərini e-taxes sırasına (18 sütun + vergi növü) gətirir
function tNormalize(rows) {
  const { hi, map } = tHeader(rows), out = [];
  for (let i = hi + 1; i < rows.length; i++) {
    const r = rows[i] || [], o = TCOLS.map(f => map[f.k] == null ? '' : r[map[f.k]] == null ? '' : r[map[f.k]]);
    if (map.novu != null) o.novu = r[map.novu];
    if (['no', 'voen', 'mal', 'miq', 'qiy'].every(k => blank(o[TCOLS.findIndex(f => f.k === k)]))) continue;   // boş və ya yalnız düsturlu sətir
    out.push(o);
  }
  return out;
}
// Excel-dən kopyalanmış mətn (TSV): dırnaq içində sətir sonu və tab ola bilər
function tParseTsv(text) {
  const rows = []; let row = [], cur = '', q = false, i = 0;
  text = String(text).replace(/\r\n?/g, '\n');
  while (i < text.length) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
    else if (ch === '"' && cur === '') q = true;
    else if (ch === '\t') { row.push(cur); cur = ''; }
    else if (ch === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; }
    else cur += ch;
    i++;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(c => String(c).trim() !== ''));
}

const fx = (v, d) => { const p = Math.pow(10, d); return (Math.round((v || 0) * p + (v >= 0 ? 1e-9 : -1e-9)) / p).toFixed(d); };
const rnd = (v, d) => +fx(v, d);
const numStr = v => { const n = rnd(v, 6); return String(n); };

// Yoxlama və qaimələrə bölmə. rows: [[18 dəyər], ...] (+ .novu). Nəticə: { invoices, issues: [{ r, c, lvl, msg }], skipped }
function tBuild(rows) {
  const K = {}; TCOLS.forEach((f, j) => { K[f.k] = j; });
  const issues = [], groups = new Map(); let skipped = 0;
  const add = (r, k, lvl, msg) => issues.push({ r, c: k == null ? -1 : K[k], lvl, msg });
  rows.forEach((row, r) => {
    const g = k => row[K[k]], s = k => String(g(k) == null ? '' : g(k)).trim();
    const noS = s('no').replace(/\.0+$/, ''), voenRaw = s('voen');
    if (TCOLS.every((f, j) => String(row[j] == null ? '' : row[j]).trim() === '')) return;          // tam boş sətir
    if (noS && !/\d/.test(noS) && /[a-zəöüğıçş]/i.test(voenRaw)) { skipped++; add(r, null, 'info', 'Başlıq sətri kimi görünür, buraxıldı.'); return; }
    const v = {};
    for (const k of TNUM) { const t = s(k); if (t === '') { v[k] = 0; continue; } const n = num(g(k)); if (n == null) { add(r, k, 'err', `"${TCOLS[K[k]].h}" rəqəm deyil: ${t}`); v[k] = 0; } else v[k] = n; }
    if (!/^\d+$/.test(noS)) add(r, 'no', 'err', '№ (sıra nömrəsi) rəqəm olmalıdır. Eyni nömrəli sətirlər bir qaimədə birləşir.');
    const voen = normVoen(voenRaw);
    if (voen.length !== 10) add(r, 'voen', 'err', `Alıcının VÖEN-i 10 rəqəm olmalıdır: ${voenRaw || 'boşdur'}`);
    if (!s('kod')) add(r, 'kod', 'err', 'Malın kodu boşdur.');
    if (!s('mal')) add(r, 'mal', 'err', 'Malın adı boşdur.');
    if (!s('vahid')) add(r, 'vahid', 'err', 'Ölçü vahidi boşdur.');
    if (!(v.miq > 0)) add(r, 'miq', 'err', 'Malın miqdarı sıfırdan böyük olmalıdır.');
    if (v.qiy < 0) add(r, 'qiy', 'err', 'Buraxılış qiyməti mənfi ola bilməz.');
    const eq = s('eqin').replace(/\.0+$/, '');
    if (/e\+?\d/i.test(eq)) add(r, 'eqin', 'err', 'ƏQİN qısaldılıb (məs. 4,76E+12). Excel-də sütunu "Rəqəm" (0) formatına çevirib yenidən köçür.');
    const base = rnd(v.miq * v.qiy + v.akm, 4);
    let split = TSPLIT.reduce((a, k) => a + v[k], 0);
    if (split === 0 && base !== 0) {
      const nv = NOVU[tlow(row.novu)];
      if (nv) { v[nv] = base; split = base; }
      else add(r, 'e18', 'err', 'ƏDV bölgüsü boşdur: 18%, 0%, azad və ya cəlb edilməyən sütunlarından birində məbləğ olmalıdır.');
    }
    if (split !== 0 && Math.abs(split - base) > 0.011) add(r, 'e18', 'warn', `ƏDV bölgüsünün cəmi (${fx(split, 2)}) miqdar × qiymət + aksiz (${fx(base, 2)}) ilə uyğun deyil.`);
    const key = noS || '#' + r;
    if (!groups.has(key)) groups.set(key, { no: noS, voen, ad: s('ad'), esas: s('esas'), elave: s('elave'), rows: [], first: r });
    const grp = groups.get(key);
    if (grp.voen !== voen && voen) add(r, 'voen', 'err', `№ ${noS} qaiməsinin sətirlərində fərqli VÖEN var (${grp.voen} və ${voen}). Bir qaimə bir alıcıya olmalıdır.`);
    grp.rows.push({ r, kod: s('kod').replace(/\.0+$/, ''), mal: s('mal'), eqin: eq || '0', vahid: s('vahid'), ...v });
  });
  const invoices = [...groups.values()].map(gp => {
    const items = gp.rows.map(x => {
      const c6 = rnd(x.miq * x.qiy, 4), c9 = rnd(c6 + x.akm, 4), c14 = rnd(x.e18 * 0.18, 4), c16 = rnd(c9 + c14 + x.yol, 4);
      return { ...x, c6, c9, c14, c16 };
    });
    const sum = k => items.reduce((a, x) => a + x[k], 0);
    const tot = { c1: sum('c6'), c2: sum('akm'), c3: sum('c9'), c4: sum('e18'), c5: sum('edvsiz'), c6: sum('azad'), c7: sum('e0'), c8: sum('c14'), c9: sum('c16'), c10: sum('yol') };
    return { no: gp.no, voen: gp.voen, ad: gp.ad, esas: gp.esas, elave: gp.elave, items, tot, first: gp.first };
  });
  return { invoices, issues, skipped };
}

const txe = s => String(s == null ? '' : s).replace(/[^\x09\x0A\x0D\x20-퟿-�]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function tInvoiceXml(head, inv, seller) {
  const rows = inv.items.map(x => `            <row no="0">
                <c1>${txe(x.kod)}</c1>
                <c2>${txe(x.mal)}</c2>
          	    <c3>${txe(x.vahid)}</c3>
				<c4>${numStr(x.miq)}</c4>
				<c5>${fx(x.qiy, 9)}</c5>
				<c6>${fx(x.c6, 4)}</c6>
				<c7>${numStr(x.akd)}</c7>
				<c8>${fx(x.akm, 4)}</c8>
				<c9>${fx(x.c9, 4)}</c9>
				<c10>${fx(x.e18, 4)}</c10>
				<c11>${fx(x.edvsiz, 4)}</c11>
				<c12>${fx(x.azad, 4)}</c12>
				<c13>${fx(x.e0, 4)}</c13>
				<c14>${fx(x.c14, 4)}</c14>
				<c15>${fx(x.yol, 4)}</c15>
				<c16>${fx(x.c16, 4)}</c16>
				<c17>${txe(x.eqin)}</c17>
				<productId>0</productId>
            </row>
`).join('');
  const t = inv.tot;
  return head + `	<qaimeKime>${txe(inv.voen)}</qaimeKime>
	<qaimeKimden>${txe(seller)}</qaimeKimden>
	<ds />
	<dn />
	<des>${txe(inv.esas)}</des>
	<des2>${txe(inv.elave)}</des2>
	<ma></ma>
	<mk />
	<product>
		<qaimeTable>
${rows}		</qaimeTable>
		<qaimeYekunTable>
			<row>
				<c1>${fx(t.c1, 2)}</c1>
				<c2>${fx(t.c2, 2)}</c2>
				<c3>${fx(t.c3, 2)}</c3>
				<c4>${fx(t.c4, 2)}</c4>
				<c5>${fx(t.c5, 2)}</c5>
				<c6>${fx(t.c6, 2)}</c6>
				<c7>${fx(t.c7, 2)}</c7>
				<c8>${fx(t.c8, 2)}</c8>
				<c9>${fx(t.c9, 2)}</c9>
				<c10>${fx(t.c10, 4)}</c10>
			</row>
		</qaimeYekunTable>
	</product>
</root>`;
}
const tYmd = d => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
// Paketin faylları: [{ name, text }] (sıra: qovluq, manifest, qaimələr)
function tPackage(head, invoices, seller, date = new Date()) {
  const ymd = tYmd(date);
  return [{ name: 'vhf-inf/', text: '' }, { name: 'vhf-inf/vhf.mf', text: 'VHF-Manifest-Version: 1.0' },
    ...invoices.map((inv, i) => ({ name: `C_QAIME_${i + 1}_${seller}_${inv.voen}_${ymd}_v_304.xml`, text: tInvoiceXml(head, inv, seller) }))];
}
