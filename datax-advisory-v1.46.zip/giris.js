// DataX — giriş: telefon nömrəsi ilə (lisenziya serveri), köhnə açarla giriş də qalır. popup.html və panel.html birlikdə istifadə edir.
(() => {
  const G = id => document.getElementById(id);
  const fmtD = s => s ? String(s).split('-').reverse().join('.') : '';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  let contact = '+994 50 597 15 67';
  G('lic').innerHTML = `
    <h1>Daxil ol</h1>
    <p class="sub" id="licmsg">Telefon nömrəni yaz. İlk dəfə daxil olanda <b>7 günlük pulsuz sınaq</b> özü başlayır.</p>
    <label class="f">Telefon nömrəsi<input id="lphone" type="tel" inputmode="tel" autocomplete="tel" placeholder="050 123 45 67"></label>
    <label class="f" id="lnamebox">Ad və ya şirkət <span style="font-weight:400;color:var(--mute)">(ilk dəfə)</span><input id="lname" autocomplete="organization" placeholder="Məs. Aysel Məmmədova"></label>
    <label class="f" id="lcodebox" hidden>Hesab kodu<input id="lcode" maxlength="8" autocomplete="off" spellcheck="false" placeholder="6 simvol" style="text-transform:uppercase;letter-spacing:2px"></label>
    <button id="licgo" type="button">Daxil ol</button>
    <div id="licst"></div>
    <details id="lkey" style="margin-top:14px"><summary style="cursor:pointer;color:var(--mute);font-size:12.5px">Lisenziya açarım var</summary>
      <div class="f" style="margin-top:8px">Bu cihazın kodu</div>
      <div class="dev"><code id="devid">...</code><button type="button" class="lnk" id="devcopy">Kopyala</button></div>
      <label class="f">Lisenziya açarı<textarea id="lickey" rows="3" spellcheck="false" placeholder="Açarı bura yapışdır"></textarea></label>
      <button id="lickeygo" type="button" class="lnk">Açarla aktivləşdir</button>
    </details>`;
  ['lphone', 'lname', 'lcode'].forEach(id => G(id).style.cssText += ';display:block;width:100%;margin-top:5px;padding:9px 11px;border:1px solid var(--line);border-radius:9px;background:var(--stone2,#fff);color:var(--ink);font:inherit;font-size:14px');
  G('lic').querySelectorAll('label.f').forEach(l => { l.style.display = l.hidden ? 'none' : 'block'; l.style.marginBottom = '10px'; });
  const showCode = on => { G('lcodebox').hidden = !on; G('lcodebox').style.display = on ? 'block' : 'none'; };
  const LMSG = {
    yoxdur: 'Telefon nömrəni yaz. İlk dəfə daxil olanda <b>7 günlük pulsuz sınaq</b> özü başlayır.',
    imza: 'Saxlanmış lisenziya etibarsızdır. Yenidən daxil ol.', cihaz: 'Saxlanmış lisenziya başqa kompüter üçündür. Yenidən daxil ol.', format: 'Saxlanmış lisenziya düzgün deyil. Yenidən daxil ol.',
    bitib: () => `Lisenziyanın müddəti bitib. Uzatmaq üçün əlaqə saxla: <b>${esc(contact)}</b> (WhatsApp və zəng). Ödənişdən sonra DataX-i yenidən aç.`,
    dayandirilib: () => `Lisenziya dayandırılıb. Əlaqə: <b>${esc(contact)}</b>.`,
    basqa: 'Bu hesab başqa kompüterdə açılıb. Burada işləmək üçün yenidən daxil ol (hesab kodu lazım olacaq).',
    sinxron: 'Lisenziya bir neçə gündür yoxlanıla bilmir. İnternetə qoşul və pəncərəni yenidən aç.'
  };
  window.showLic = function (r) {
    if (!r) return;
    if (r.acc && r.acc.contact) contact = r.acc.contact;
    G('devid').textContent = r.device || '...';
    document.body.classList.toggle('nolic', !r.ok);
    if (!r.ok) { const m = LMSG[r.reason] || LMSG.yoxdur; G('licmsg').innerHTML = typeof m === 'function' ? m() : m; if (r.acc && r.acc.phone && !G('lphone').value) G('lphone').value = r.acc.phone; return; }
    const a = r.acc || {}, plan = a.plan ? a.plan + ', ' : '';
    const info = G('licinfo'); info.textContent = `${a.name || r.name ? (a.name || r.name) + ' · ' : ''}${plan}${fmtD(r.until)}-dək`;
    const warn = r.days <= 5; info.classList.toggle('warn', warn);
    if (warn) info.textContent += r.days <= 0 ? ' — bu gün bitir! Uzatmaq üçün: ' + contact : ` — ${r.days} gün qalıb. Uzatmaq üçün: ${contact}`;
    const num = G('licnumv'); if (num) { num.textContent = a.code || r.device || ''; const lab = num.parentElement; if (lab && lab.firstChild && lab.firstChild.nodeType === 3) lab.firstChild.textContent = a.code ? 'Hesab kodu: ' : 'Lisenziya nömrəsi: '; num.title = a.code ? 'Başqa kompüterdə daxil olmaq üçün bu kod lazımdır' : ''; }
  };
  const st = (t, ok) => { G('licst').textContent = t; G('licst').style.color = ok ? 'var(--teal,#0f8f84)' : ''; };
  G('licgo').onclick = () => {
    const phone = G('lphone').value.trim(); if (!phone) { st('Telefon nömrəni yaz.'); G('lphone').focus(); return; }
    G('licgo').disabled = true; st('Yoxlanılır...', true);
    chrome.runtime.sendMessage({ type: 'login', phone, name: G('lname').value.trim(), code: G('lcode').value.trim() }, r => {
      G('licgo').disabled = false;
      if (chrome.runtime.lastError || !r) { st('Cavab gəlmədi. Extension-u yenidən yüklə.'); return; }
      if (r.need === 'code') { showCode(true); G('lcode').focus(); }
      if (!r.ok) { st(r.err || (LMSG[r.reason] && typeof LMSG[r.reason] === 'string' ? LMSG[r.reason] : 'Daxil olmaq alınmadı.')); return; }
      st(''); showCode(false); G('lcode').value = '';
      window.showLic(r);
      if (r.isNew && r.acc && r.acc.code) alert(`Xoş gəldin! ${fmtD(r.until)}-dək pulsuz sınaq başladı.\n\nHesab kodun: ${r.acc.code}\nBaşqa kompüterdə daxil olmaq üçün bu kod lazım olacaq (DataX-in aşağısında da görünür).`);
    });
  };
  G('lphone').onkeydown = G('lname').onkeydown = G('lcode').onkeydown = e => { if (e.key === 'Enter') G('licgo').click(); };
  G('devcopy').onclick = async () => { try { await navigator.clipboard.writeText(G('devid').textContent); G('devcopy').textContent = 'Kopyalandı'; } catch (e) {} };
  G('lickeygo').onclick = () => {
    const key = G('lickey').value.trim(); if (!key) { st('Açarı yapışdır.'); return; }
    st('Yoxlanılır...', true);
    chrome.runtime.sendMessage({ type: 'setLic', key }, r => {
      if (r && r.ok) { st(''); G('lickey').value = ''; window.showLic(r); return; }
      st({ imza: 'Açar etibarsızdır.', cihaz: 'Bu açar başqa cihaz üçündür.', bitib: 'Bu açarın müddəti bitib.', dayandirilib: 'Lisenziya dayandırılıb.', sinxron: 'İnternet bağlantısını yoxla və yenidən cəhd et.', format: 'Açar düzgün deyil: tam kopyalandığını yoxla.' }[r && r.reason] || 'Açar qəbul olunmadı.');
    });
  };
  const lo = G('logout');
  if (lo) lo.onclick = () => {
    if (!confirm('Çıxış edilsin? Yenidən daxil olmaq üçün telefon nömrən lazım olacaq.')) return;
    chrome.runtime.sendMessage({ type: 'logout' }, r => window.showLic(r));
  };
  chrome.runtime.sendMessage({ type: 'checkUpdate' }, () => void chrome.runtime.lastError);
  chrome.runtime.sendMessage({ type: 'lic' }, r => { window.showLic(r); chrome.runtime.sendMessage({ type: 'lic', sync: true }, r2 => window.showLic(r2)); });
})();
