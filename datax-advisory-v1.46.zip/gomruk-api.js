// e.customs.gov.az səhifəsində: DataX istəyəndə idxal/ixrac hesabatını istifadəçinin açıq sessiyası ilə alır (yalnız oxuma)
(() => {
  if (window.__dxGomrukApi) return; window.__dxGomrukApi = true;
  const API = 'https://c2b-fbusiness.customs.gov.az/api/v1/dictionaries/report';
  function parseCsv(s) {
    const rows = []; let row = [], f = '', q = false;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === '"') { if (s[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
      else if (c === '"') q = true; else if (c === ',') { row.push(f); f = ''; }
      else if (c === '\n') { row.push(f.replace(/\r$/, '')); rows.push(row); row = []; f = ''; } else f += c;
    }
    if (f || row.length) { row.push(f.replace(/\r$/, '')); rows.push(row); }
    return rows;
  }
  const num = v => { const n = parseFloat(String(v || '').replace(/\s/g, '').replace(',', '.')); return isNaN(n) ? 0 : n; };
  const dnum = s => { const m = String(s || '').match(/(\d{2})\.(\d{2})\.(\d{4})/); return m ? +(m[3] + m[2] + m[1]) : 0; };
  function token() {
    try { const st = JSON.parse(localStorage.getItem('__store__') || '{}'); if (st.localToken) return st.localToken;
      for (const v of Object.values(st)) { const o = typeof v === 'string' && v.startsWith('{') ? JSON.parse(v) : v; if (o && o.localToken) return o.localToken; } } catch (e) {}
    return '';
  }
  // Bir sorğu ən çox 1 il: təqvim illərinə bölünür
  function chunks(from, to) {
    const out = []; for (let y = +from.slice(0, 4); y <= +to.slice(0, 4); y++) out.push([y === +from.slice(0, 4) ? from : `${y}-01-01`, y === +to.slice(0, 4) ? to : `${y}-12-31`]);
    return out;
  }
  async function report(tok, order, a, b) {
    const r = await fetch(`${API}?order=${order}&exportType=csv`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok, lang: 'az', requestSource: 'ECustoms' }, body: JSON.stringify({ dateFrom: a, dateTo: b }) });
    const t = await r.text();
    if (r.status === 401) throw new Error('e-gömrük sessiyası bitib — e-gömrükə yenidən daxil ol');
    if (!r.ok) { if (/"code"\s*:\s*"041"/.test(t)) return []; throw new Error(`hesabat alınmadı (HTTP ${r.status})`); }
    const R = parseCsv(t), H = (R[0] || []).map(h => h.trim().toUpperCase()), c = k => H.indexOf(k);
    if (c('GOODS_CODE') < 0) throw new Error('hesabatın formatı tanınmadı');
    return R.slice(1).filter(x => x.length > 5 && x[c('REG_NUMBER')]).map(x => {
      const q1 = String(x[c('QUANTITY1')] || ''), m = q1.match(/^\s*([\d.,]+)\s*(.*)$/);
      const q = m ? num(m[1]) : num(x[c('NETTO')]), unit = m && m[2].trim() ? m[2].trim() : 'kq';
      return { gb: x[c('REG_NUMBER')], dnum: dnum(x[c('PROCESS_DATE')]), rejim: x[c('REJIM')] || '', code: String(x[c('GOODS_CODE')] || '').replace(/\D/g, ''),
        name: String(x[c('GOODS_NAME')] || '').replace(/\s*\n\s*/g, ' / ').trim(), q, unit, sum: num(x[c('STATISTIC_COST')]),
        fees: num(x[c('GR_YIG')]) + num(x[c('T2025')]) + num(x[c('AKSIZ')]), vat: num(x[c('ADV')]),
        // Statistik dəyər valyutadadır; AZN maya dəyəri: ƏDV bazası (ödənilmiş ƏDV / 0,18 = gömrük dəyəri + rüsum + aksiz) + yığımlar
        costAzn: num(x[c('ADV')]) > 0 ? Math.round((num(x[c('ADV')]) / 0.18 + num(x[c('GR_YIG')])) * 100) / 100 : null, voen: String(x[c('KOD_EXP')] || '').replace(/\D/g, '') };
    });
  }
  async function run({ from, to }) {
    const tok = token(); if (!tok) return { error: 'e-gömrükə daxil olunmayıb' };
    const out = { imp: [], exp: [] };
    for (const [a, b] of chunks(from, to)) { out.imp.push(...await report(tok, 0, a, b)); out.exp.push(...await report(tok, 1, a, b)); }
    return out;
  }
  // DataX-a bu sekmənin e-gömrük olduğunu bildir (əlavə icazə tələb etmədən tapılsın)
  try { chrome.runtime.sendMessage({ type: 'dxCustomsHere' }).catch(() => {}); } catch (e) {}
  chrome.runtime.onMessage.addListener((m, s, send) => {
    if (!m || m.type !== 'dxCustoms') return;
    run(m).then(send, e => send({ error: String(e && e.message || e) }));
    return true;
  });
})();
