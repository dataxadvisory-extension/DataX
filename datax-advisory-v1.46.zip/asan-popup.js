// Popup-dakı "ASAN giriş siyahısı" düyməsi: ayarlar səhifəsini açır
(() => { const b = document.getElementById('asanbtn'); if (b) b.onclick = () => { chrome.runtime.openOptionsPage(); window.close(); }; })();
