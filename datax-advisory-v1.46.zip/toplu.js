// Toplu e-qaimə: səhifənin idarəsi (cədvəl, yapışdırma, fayl, yoxlama, paket)
const $ = id => document.getElementById(id);
$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
chrome.runtime.sendMessage({ type: 'lic' }, r => { document.body.classList.toggle('nolic', !(r && r.ok)); });
const NC = TCOLS.length, NUMK = new Set(['no', 'voen', 'kod', 'eqin', ...TNUM]);
const fmt = v => (Math.round((v || 0) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const say = (msg, err, ok) => { const s = $('st'); s.textContent = msg; s.classList.toggle('err', !!err); s.classList.toggle('ok', !!ok); };
let rows = [], res = null, saveT = 0, valT = 0;
const tbody = $('grid').tBodies[0];
const str = v => v == null ? '' : String(v);
const newRow = () => { const r = Array(NC).fill(''); return r; };

// ---- yaddaş (pəncərə bağlansa itməsin; yalnız bu kompüterdə) ----
function persist() { clearTimeout(saveT); saveT = setTimeout(() => chrome.storage.local.set({ topluDraft: { rows: rows.map(r => ({ v: r.map(str), novu: r.novu || '' })), seller: $('seller').value.trim() } }), 400); }
chrome.storage.local.get(['topluDraft', 'ownSeen'], ({ topluDraft, ownSeen }) => {
  if (topluDraft && topluDraft.rows) rows = topluDraft.rows.map(x => Object.assign(x.v.slice(0, NC).concat(Array(Math.max(0, NC - x.v.length)).fill('')), x.novu ? { novu: x.novu } : {}));
  $('seller').value = (topluDraft && topluDraft.seller) || (ownSeen && ownSeen.voen) || '';
  render();
});

// ---- cədvəl ----
(() => {
  const tr = $('grid').tHead.insertRow(), th = t => { const e = document.createElement('th'); e.textContent = t; tr.appendChild(e); return e; };
  th('').style.minWidth = '34px';
  TCOLS.forEach(f => th(f.h));
  th('Sil').style.minWidth = '40px';
})();
function render() {
  const frag = document.createDocumentFragment();
  rows.forEach((r, i) => {
    const tr = document.createElement('tr'); tr.dataset.r = i;
    const idx = tr.insertCell(); idx.className = 'idx'; idx.textContent = i + 1;
    TCOLS.forEach((f, c) => { const td = tr.insertCell(); td.contentEditable = 'plaintext-only'; td.spellcheck = false; td.dataset.c = c; td.textContent = str(r[c]); if (NUMK.has(f.k)) td.classList.add('n'); });
    const d = tr.insertCell(); d.className = 'del'; const b = document.createElement('button'); b.type = 'button'; b.title = 'Sətri sil'; b.textContent = '×'; b.onclick = () => { rows.splice(i, 1); render(); }; d.appendChild(b);
    frag.appendChild(tr);
  });
  tbody.replaceChildren(frag);
  $('empty').hidden = rows.length > 0;
  validate(); persist();
}
tbody.addEventListener('input', e => {
  const td = e.target.closest('td[data-c]'); if (!td) return;
  rows[+td.parentNode.dataset.r][+td.dataset.c] = td.textContent.trim();
  clearTimeout(valT); valT = setTimeout(validate, 250); persist();
});
tbody.addEventListener('keydown', e => {
  const td = e.target.closest('td[data-c]'); if (!td) return;
  if (e.key === 'Enter') { e.preventDefault(); const nx = tbody.rows[+td.parentNode.dataset.r + 1]; if (nx) nx.cells[+td.dataset.c + 1].focus(); }
});

// ---- yapışdırma: Excel-dən kopyalanmış sətirlər ----
function pasteText(text, td) {
  const m = tParseTsv(text); if (!m.length) return;
  const hasHead = tHeader(m).hi > -1;
  if (!td || hasHead) {                                     // başlıqla birgə və ya boş yerə: sütunlar başlığa görə, sona əlavə olunur
    const add = tNormalize(m); if (!add.length) { say('Yapışdırılan məlumatda qaimə sətri tapılmadı.', true); return; }
    if (rows.length && rows.every(r => r.every(v => str(v).trim() === ''))) rows = [];
    rows.push(...add); render(); say(`${add.length} sətir əlavə olundu.`, false, true); return;
  }
  const r0 = +td.parentNode.dataset.r, c0 = +td.dataset.c;    // xanadan başlayaraq (Excel kimi) yerləşdirilir
  m.forEach((line, i) => { const r = r0 + i; while (rows.length <= r) rows.push(newRow()); line.forEach((v, j) => { if (c0 + j < NC) rows[r][c0 + j] = v.trim(); }); });
  render(); say(m.length > 1 ? `${m.length} sətir yapışdırıldı.` : 'Yapışdırıldı.', false, true);
}
document.addEventListener('paste', e => {
  const t = e.target;
  if (t && t.tagName === 'INPUT') return;
  const td = t && t.closest ? t.closest('td[data-c]') : null;
  const text = e.clipboardData.getData('text/plain');
  if (!text) return;
  if (td && !/[\t\n]/.test(text.replace(/\n$/, ''))) {          // tək dəyər: xananın içinə adi mətn kimi
    e.preventDefault(); document.execCommand('insertText', false, text.replace(/\n$/, '')); return;
  }
  e.preventDefault(); pasteText(text, td);
});

// ---- fayl ----
const drop = $('d-file'), finput = drop.querySelector('input');
async function loadFile(f) {
  if (!f) return; say('Oxunur...');
  try {
    const sheets = await readTable(f);
    let best = null;
    for (const s of sheets) { const h = tHeader(s.rows); if (h.hi > -1) { const n = tNormalize(s.rows); if (!best || n.length > best.length) best = n; } }
    if (!best) throw new Error('Faylda başlıq sətri tanınmadı: "Alıcının VÖEN-i" və "Malın adı" sütunları olmalıdır. Nümunəni yükləyib ona uyğun doldurun.');
    if (!best.length) throw new Error('Faylda qaimə sətri tapılmadı.');
    if (rows.length && !confirm(`Cədvəldə ${rows.length} sətir var. Fayldakı ${best.length} sətir onların yerinə qoyulsun? (Ləğv: sona əlavə olunsun)`)) rows.push(...best); else rows = best;
    render(); say(`"${f.name}": ${best.length} sətir oxundu.`, false, true);
  } catch (e) { say(e.message, true); }
  finput.value = '';
}
finput.onchange = () => loadFile(finput.files[0]);
drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); finput.click(); } };
drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
drop.ondragleave = () => drop.classList.remove('over');
drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); loadFile(e.dataTransfer.files[0]); };
$('wrapt').ondragover = e => e.preventDefault();
$('wrapt').ondrop = e => { e.preventDefault(); loadFile(e.dataTransfer.files[0]); };

$('addrow').onclick = () => { rows.push(newRow()); render(); const tr = tbody.rows[rows.length - 1]; if (tr) tr.cells[1].focus(); };
$('clear').onclick = () => { if (!rows.length || confirm('Cədvəldəki bütün sətirlər silinsin?')) { rows = []; render(); say(''); $('next').style.display = 'none'; } };
$('tplbtn').onclick = () => chrome.runtime.sendMessage({ type: 'xlsx', direct: true, filename: 'DataX toplu qaimə nümunəsi.xlsx', sheets: [
  { name: 'Qaimələr', header: TCOLS.map(f => f.h), rows: [], keep: true, numeric: false },
  { name: 'Qaydalar', header: ['Necə doldurmalı'], numeric: false, rows: [
    ['Hər sətir bir mal və ya xidmətdir. Eyni "№" (sıra nömrəsi) yazılan sətirlər bir e-qaimədə birləşir, hər yeni nömrə yeni qaimədir.'],
    ['Alıcının VÖEN-i 10 rəqəm olmalıdır. Bir qaimənin bütün sətirlərində VÖEN eyni olmalıdır.'],
    ['ƏDV bölgüsü: məbləği (miqdar × qiymət + aksiz) uyğun sütuna yazın: 18% ilə cəlb edilən, 0% ilə cəlb edilən, ƏDV-dən azad və ya ƏDV-yə cəlb edilməyən.'],
    ['ƏQİN (barkod) sütununu Excel-də "Rəqəm" (0) formatında saxlayın ki, 4,76E+12 kimi qısalmasın. ƏQİN yoxdursa, 0 yazın.'],
    ['Əsas: qaimənin əsası (məs. müqavilə). Əlavə: əlavə qeyd. Bunlar qaimənin ilk sətrindən götürülür.'],
    ['Sətirləri kopyalayıb DataX-in "Toplu e-qaimə" pəncərəsindəki cədvələ yapışdırın və ya bu faylı orada seçin.']] }] }, r => {
  if (r && !r.ok) say(r.error || 'Nümunə yüklənmədi.', true); else say('Nümunə Yükləmələr qovluğuna endirildi.', false, true);
});

// ---- satıcı ----
const sellerOk = () => /^\d{10}$/.test($('seller').value.trim());
$('seller').addEventListener('input', () => { validate(); persist(); });
$('ownbtn').onclick = async () => {
  const [tab] = await chrome.tabs.query({ url: 'https://new.e-taxes.gov.az/*' });
  if (!tab) { $('i-seller').className = 'info err'; $('i-seller').textContent = 'Açıq e-taxes səhifəsi tapılmadı: e-taxes-ə daxil olub səhifəni açıq saxlayın.'; return; }
  $('i-seller').className = 'info'; $('i-seller').textContent = 'Axtarılır...';
  chrome.runtime.sendMessage({ type: 'own', tabId: tab.id }, r => {
    if (!r || !r.ok || !r.own || !r.own.voen) { $('i-seller').className = 'info err'; $('i-seller').textContent = (r && r.error) || 'VÖEN tapılmadı. Əl ilə yazın.'; return; }
    $('seller').value = r.own.voen; $('i-seller').className = 'info'; $('i-seller').textContent = r.own.name || ''; validate(); persist();
  });
};

// ---- yoxlama ----
function validate() {
  res = tBuild(rows);
  for (const tr of tbody.rows) for (const td of tr.cells) { td.classList.remove('err', 'warn'); td.removeAttribute('title'); }
  const marks = {};
  for (const it of res.issues) {
    const tr = tbody.rows[it.r]; if (!tr) continue;
    const td = it.c < 0 ? tr.cells[0] : tr.cells[it.c + 1];
    if (it.lvl !== 'info') { td.classList.add(it.lvl === 'err' ? 'err' : td.classList.contains('err') ? 'err' : 'warn'); }
    td.title = (td.title ? td.title + '\n' : '') + it.msg;
    marks[it.lvl] = (marks[it.lvl] || 0) + 1;
  }
  let prev = null;
  for (const tr of tbody.rows) { const v = str(rows[+tr.dataset.r][0]).trim(); tr.classList.toggle('inv', prev !== null && v !== prev); prev = v; }
  const ul = $('issues'); ul.replaceChildren();
  res.issues.slice(0, 60).forEach(it => {
    const li = document.createElement('li'); li.className = it.lvl; const a = document.createElement('a'); a.textContent = `Sətir ${it.r + 1}`;
    a.onclick = () => { const tr = tbody.rows[it.r]; if (tr) { const td = tr.cells[it.c < 0 ? 1 : it.c + 1]; td.focus(); td.scrollIntoView({ block: 'center', inline: 'center' }); } };
    li.append(a, ': ' + it.msg); ul.appendChild(li);
  });
  if (res.issues.length > 60) { const li = document.createElement('li'); li.textContent = `... və daha ${res.issues.length - 60} qeyd.`; ul.appendChild(li); }
  const inv = res.invoices, errs = marks.err || 0, warns = marks.warn || 0, sumT = k => inv.reduce((a, x) => a + x.tot[k], 0);
  const tiles = $('tiles');
  if (inv.length) {
    tiles.style.display = 'grid';
    tiles.innerHTML = '';
    [['Qaimə', inv.length, true], ['Sətir', inv.reduce((a, x) => a + x.items.length, 0), true], ['ƏDV-yə 18% cəlb edilən', fmt(sumT('c4'))], ['Ödənilməli ƏDV', fmt(sumT('c8'))], ['Yekun məbləğ', fmt(sumT('c9'))]].forEach(([l, v]) => {
      const d = document.createElement('div'), b = document.createElement('b'), s = document.createElement('span'); b.textContent = v; s.textContent = l; d.append(b, s); tiles.appendChild(d);
    });
  } else tiles.style.display = 'none';
  const sOk = sellerOk(); $('seller').classList.toggle('bad', !!$('seller').value && !sOk);
  $('cnt').textContent = !rows.length ? '' : errs ? `${errs} səhv düzəldilməlidir${warns ? `, ${warns} xəbərdarlıq` : ''}.` : !sOk ? 'Satıcının (sizin) VÖEN-ini yazın.' : `${inv.length} qaimə paketlənməyə hazırdır${warns ? ` · ${warns} xəbərdarlıq` : ''}.`;
  $('go').disabled = !inv.length || !!errs || !sOk;
}

// ---- paket ----
// Hazır fayl dərhal yüklənmir: «Yüklə» düyməsi (fayl fon skriptində saxlanır)
function offerDl(group, label) {
  const b = $('dlx'); b.style.display = 'inline-block'; b.className = ''; b.textContent = label; b.disabled = false;
  b.onclick = () => { b.disabled = true; chrome.runtime.sendMessage({ type: 'dl', group }, r => { b.disabled = false; if (r && r.ok) { b.className = 'done'; b.textContent = '✓ Yükləndi — yenidən yüklə'; } else say((r && r.error) || 'Yüklənmədi.', true); }); };
}
$('go').onclick = async () => {
  validate(); if ($('go').disabled) return;
  const warns = res.issues.filter(i => i.lvl === 'warn').length;
  if (warns && !confirm(`${warns} xəbərdarlıq var (sarı xanalar). Yenə də paketlənsin?`)) return;
  $('go').disabled = true; say('Paket hazırlanır...'); $('dlx').style.display = 'none'; $('next').style.display = 'none';
  try {
    const head = await (await fetch(chrome.runtime.getURL('tpl/qaime-304.xml'))).text();
    const seller = $('seller').value.trim(), files = tPackage(head, res.invoices, seller);
    const r = await new Promise(ok => chrome.runtime.sendMessage({ type: 'paket', filename: `paket_${tYmd(new Date())}.zip`, files }, ok));
    if (!r || !r.ok) throw new Error((r && r.error) || 'Paket yüklənmədi.');
    say(`Hazırdır: ${res.invoices.length} qaimə paketləndi. Yükləmək üçün «Paketi yüklə» düyməsini bas.`, false, true);
    offerDl(r.group, '⬇ Paketi yüklə');
    $('next').style.display = 'block';
  } catch (e) { say('Xəta: ' + e.message, true); }
  validate();
};
