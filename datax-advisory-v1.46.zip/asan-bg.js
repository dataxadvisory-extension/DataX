// ASAN giriş funksiyası üçün arxa plan: giriş səhifəsindəki paneldən "Siyahını idarə et" basılanda ayarlar səhifəsini açır
chrome.runtime.onMessage.addListener(m => {
  if (m && m.type === 'asan-ayarlar') chrome.runtime.openOptionsPage();
  return false;
});
