// egbtrader2.customs.gov.az / GBList.aspx: "DataX · Gömrük sənədləri" paneli.
// Tarix aralığı üzrə İdxal 40 bəyannamələrini siyahılayır; hər GB üçün GB (imzalı PDF), invoys və CMR PDF-lərini yükləyir.
// Panel Shadow DOM-dadır. Portalda heç nə dəyişdirilmir və göndərilmir: yalnız baxış və yükləmə.
(() => {
  if (window.__dxGomruk || !/GBList\.aspx$/i.test(location.pathname)) return; window.__dxGomruk = true;
  const h = (tag, props = {}, ...kids) => { const e = document.createElement(tag); Object.assign(e, props); kids.forEach(k => e.append(k)); return e; };
  const lic = () => new Promise(res => { try { chrome.runtime.sendMessage({ type: 'lic' }, r => { void chrome.runtime.lastError; res(!!(r && r.ok)); }); } catch (e) { res(false); } });
  const host = document.createElement('div'); host.id = 'dx-gomruk-host';
  const root = host.attachShadow({ mode: 'closed' });
  root.appendChild(h('style', { textContent: `
  :host{all:initial}*{box-sizing:border-box}
  .fab{position:fixed;right:14px;bottom:14px;z-index:2147483000;padding:9px 16px;border:0;border-radius:999px;background:linear-gradient(135deg,#3fb3a6,#2f8fa8);color:#fff;font:600 13px "Segoe UI",system-ui,Arial,sans-serif;cursor:pointer;box-shadow:0 8px 22px rgba(0,0,0,.35)}
  .p{position:fixed;right:14px;bottom:14px;z-index:2147483001;width:min(640px,calc(100vw - 28px));max-height:calc(100vh - 28px);display:none;flex-direction:column;font:13px/1.45 "Segoe UI",system-ui,Arial,sans-serif;color:#e8ecef;background:#1b2128;border:1px solid #37424d;border-radius:14px;box-shadow:0 12px 34px rgba(0,0,0,.45);overflow:hidden}
  .p.on{display:flex}.hd{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:linear-gradient(135deg,#223038,#1b2a30);font-weight:600}.hd span{color:#6ea5cc}.hd button{background:none;border:0;color:#8d99a5;font-size:18px;cursor:pointer}
  .bd{padding:12px 14px;overflow:auto}
  .row{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin-bottom:10px}
  label{display:block;font-size:12px;color:#8d99a5}input[type=date],select{display:block;margin-top:3px;padding:6px 8px;border:1px solid #37424d;border-radius:8px;background:#14181d;color:#e8ecef;font:inherit;color-scheme:dark}
  label.ck{display:flex;align-items:center;gap:6px;color:#c9ccce;font-size:12.5px}
  button.b{padding:7px 14px;border:1px solid #37424d;border-radius:999px;background:#262e37;color:#e8ecef;font:inherit;cursor:pointer}button.b:hover{border-color:#2a9488}button.b:disabled{opacity:.5;cursor:default}
  button.pri{border:0;background:linear-gradient(135deg,#3fb3a6,#2f8fa8);color:#fff;font-weight:600}
  .st{min-height:20px;margin:6px 0;font-size:12.5px;color:#8d99a5}.st.err{color:#ef8a7f}.st.ok{color:#7fd8a8}.st.warn{color:#f0a86a}
  .ls{border:1px solid #2b343d;border-radius:10px;max-height:300px;overflow:auto}
  .it{display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid #2b343d}.it:last-child{border-bottom:0}
  .tx{flex:1;min-width:0}.no{font-weight:600}.sb{color:#8d99a5;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .mini{padding:3px 9px;border:1px solid #37424d;border-radius:999px;background:#262e37;color:#e8ecef;font:12px inherit;cursor:pointer}.mini:hover{border-color:#2a9488}.mini:disabled{opacity:.5;cursor:default}
  .ft{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:10px}.nt{margin-top:8px;color:#8d99a5;font-size:11.5px}
  ` }));
  const fab = h('button', { className: 'fab', type: 'button', textContent: 'DataX · Gömrük sənədləri' });
  const today = new Date(), iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const from = h('input', { type: 'date', value: iso(new Date(today.getFullYear(), today.getMonth(), 1)) }), to = h('input', { type: 'date', value: iso(today) });
  const src = h('select', {}, h('option', { value: '2', textContent: 'Təmsilçi tərəfindən (Sahibkar üçün)' }), h('option', { value: '1', textContent: 'Şəxsən tərtib etdiyim' }));
  const only = h('input', { type: 'checkbox', checked: true }), mode = h('select', {}, h('option', { value: 'one', textContent: 'Hər GB bir PDF (GB + invoys + CMR)' }), h('option', { value: 'sep', textContent: 'Hər sənəd ayrıca (hər GB üçün qovluq)' }));
  const go = h('button', { className: 'b pri', type: 'button', textContent: 'Siyahını gətir' }), stEl = h('div', { className: 'st', role: 'status' }), ls = h('div', { className: 'ls' });
  const all = h('input', { type: 'checkbox', checked: true }), dl = h('button', { className: 'b pri', type: 'button', textContent: 'Seçilənləri yüklə (ZIP)', disabled: true }), stop = h('button', { className: 'b', type: 'button', textContent: 'Dayandır', style: 'display:none' });
  const p = h('div', { className: 'p' },
    h('div', { className: 'hd' }, h('div', {}, 'Data', h('span', {}, 'X'), ' · Gömrük sənədləri'), h('button', { type: 'button', textContent: '×', title: 'Bağla', onclick: () => { p.classList.remove('on'); fab.style.display = ''; } })),
    h('div', { className: 'bd' },
      h('div', { className: 'row' }, h('label', {}, 'Tarixdən', from), h('label', {}, 'Tarixədək', to), h('label', {}, 'Mənbə', src), go),
      h('div', { className: 'row' }, h('label', { className: 'ck' }, only, 'Yalnız "İdxal 40" (qısa idxal bəyannamələri göstərilmir)')),
      stEl, ls,
      h('div', { className: 'ft' }, h('label', { className: 'ck' }, all, 'Hamısı'), h('label', {}, mode), dl, stop),
      h('div', { className: 'nt', textContent: 'Fayllar yalnız bu kompüterə yüklənir. Portalda heç nə dəyişdirilmir.' })));
  root.append(fab, p);
  fab.onclick = async () => { p.classList.add('on'); fab.style.display = 'none'; if (!(await lic())) say('DataX lisenziyası aktiv deyil. Əlavənin pəncərəsindən lisenziya açarını daxil et.', 'err'); };
  const say = (m, k) => { stEl.textContent = m || ''; stEl.className = 'st' + (k ? ' ' + k : ''); };

  let rows = [], pages = [], busy = false, cancel = false; const sel = new Set();
  const refreshDl = () => { dl.disabled = busy || !sel.size; dl.textContent = sel.size ? `Seçilənləri yüklə (${sel.size})` : 'Seçilənləri yüklə'; all.checked = rows.length > 0 && sel.size === rows.length; };
  const lock = on => { busy = on; go.disabled = on; stop.style.display = on ? '' : 'none'; ls.querySelectorAll('button,input').forEach(e => { e.disabled = on; }); refreshDl(); };
  function render() {
    ls.replaceChildren(); if (!rows.length) { ls.append(h('div', { className: 'it', style: 'color:#8d99a5', textContent: 'Siyahı boşdur.' })); refreshDl(); return; }
    rows.forEach(r => {
      const cb = h('input', { type: 'checkbox', checked: sel.has(r.no) }); cb.onchange = () => { cb.checked ? sel.add(r.no) : sel.delete(r.no); refreshDl(); };
      const btn = (t, what) => { const b = h('button', { className: 'mini', type: 'button', textContent: t, title: what === 'all' ? 'GB + invoys + CMR bir PDF' : t + ' PDF-i yüklə' }); b.onclick = () => one(r, what); return b; };
      ls.append(h('div', { className: 'it' }, cb, h('div', { className: 'tx' }, h('div', { className: 'no', textContent: r.no + ' · ' + r.opDate }), h('div', { className: 'sb', textContent: [r.sender, r.declarant].filter(Boolean).join(' · '), title: r.sender })), btn('GB', 'gb'), btn('Invoys', 'inv'), btn('CMR', 'cmr'), btn('Hamısı', 'all')));
    }); refreshDl();
  }
  all.onchange = () => { sel.clear(); if (all.checked) rows.forEach(r => sel.add(r.no)); render(); };

  go.onclick = async () => {
    if (busy) return; if (!(await lic())) { say('DataX lisenziyası aktiv deyil.', 'err'); return; }
    if (!from.value || !to.value || from.value > to.value) { say('Tarix aralığını düzgün seç (başlanğıc bitişdən böyük ola bilməz).', 'err'); return; }
    lock(true); say('Siyahı gətirilir...'); sel.clear();
    try {
      const r = await GB.search({ from: from.value, to: to.value, source: +src.value, only40: only.checked, onProgress: (n, t) => say(`Siyahı gətirilir: ${n}/${t || '?'}`) });
      rows = r.rows; pages = r.pages; rows.forEach(x => sel.add(x.no));
      say(rows.length ? `${rows.length} bəyannamə tapıldı` + (r.skipped ? ` (${r.skipped} qısa idxal və digər bəyannamə göstərilmir).` : '.') : 'Bu aralıqda uyğun bəyannamə tapılmadı' + (r.skipped ? ` (${r.skipped} digər növ göstərilmir).` : '.'), rows.length ? 'ok' : 'warn');
    } catch (e) { rows = []; say('Xəta: ' + e.message, 'err'); }
    render(); lock(false);
  };

  // Bir GB-nin sənədlərini götür və PDF/PDF-lər kimi qaytar
  async function bundle(r, want) { return GB.fetchDocs(r, pages[r.page], want); }
  async function one(r, what) {
    if (busy) return; if (!(await lic())) { say('DataX lisenziyası aktiv deyil.', 'err'); return; }
    lock(true); say(`${r.no}: sənədlər yüklənir...`);
    try {
      const want = { gb: what === 'gb' || what === 'all', inv: what === 'inv' || what === 'all', cmr: what === 'cmr' || what === 'all' };
      const d = await bundle(r, want);
      let list = what === 'gb' ? d.gb : what === 'inv' ? (d.invoys ? [d.invoys] : []) : what === 'cmr' ? (d.cmr ? [d.cmr] : []) : GB.ordered(d);
      if (!list.length) { say(`${r.no}: ${what === 'gb' ? 'GB' : what === 'inv' ? 'Invoys' : what === 'cmr' ? 'CMR' : 'sənəd'} tapılmadı. ${d.warn.join(' ')}`, 'err'); }
      else { const pdf = list.length === 1 ? list[0] : await GB.merge(list); GB.save(pdf, `${r.no}${what === 'all' ? '' : '_' + { gb: 'GB', inv: 'Invoys', cmr: 'CMR' }[what]}.pdf`, 'application/pdf'); say(`${r.no}: yükləndi.` + (d.warn.length ? ' Diqqət: ' + d.warn.join(' ') : ''), d.warn.length ? 'warn' : 'ok'); }
    } catch (e) { say(`${r.no}: xəta: ${e.message}`, 'err'); }
    lock(false);
  }
  stop.onclick = () => { cancel = true; say('Dayandırılır...', 'warn'); };
  dl.onclick = async () => {
    if (busy || !sel.size) return; if (!(await lic())) { say('DataX lisenziyası aktiv deyil.', 'err'); return; }
    const todo = rows.filter(r => sel.has(r.no)), files = [], bad = []; cancel = false; lock(true);
    try {
      for (let i = 0; i < todo.length && !cancel; i++) {
        const r = todo[i]; say(`${i + 1}/${todo.length}: ${r.no} yüklənir...`);
        try {
          const d = await bundle(r, { gb: true, inv: true, cmr: true });
          if (d.warn.length) bad.push(`${r.no}: ${d.warn.join(' ')}`);
          if (!GB.ordered(d).length) continue;
          if (mode.value === 'sep') {
            const dir = GB.safe(r.no) + '/'; d.gb.forEach((b, k) => files.push({ name: `${dir}GB${d.gb.length > 1 ? '_' + (k + 1) : ''}.pdf`, data: b }));
            if (d.invoys) files.push({ name: dir + 'Invoys.pdf', data: d.invoys }); if (d.cmr) files.push({ name: dir + 'CMR.pdf', data: d.cmr }); d.other.forEach(o => files.push({ name: `${dir}${GB.safe(o.label)}.pdf`, data: o.data }));
          } else { const list = GB.ordered(d); files.push({ name: GB.safe(r.no) + '.pdf', data: list.length === 1 ? list[0] : await GB.merge(list) }); }
        } catch (e) { bad.push(`${r.no}: ${e.message}`); }
        await GB.sleep(150);
      }
      if (files.length) {
        const name = `DataX-GB-${from.value}_${to.value}`;
        if (files.length === 1 && mode.value === 'one') GB.save(files[0].data, files[0].name, 'application/pdf'); else GB.save(GB.zip(files), name + '.zip', 'application/zip');
      }
      say((cancel ? 'Dayandırıldı. ' : '') + (files.length ? `Yükləndi: ${new Set(files.map(f => f.name.split('/')[0])).size} bəyannamə.` : 'Heç bir sənəd yüklənmədi.') + (bad.length ? ` Problemlər (${bad.length}): ` + bad.slice(0, 4).join(' | ') : ''), bad.length || !files.length ? 'warn' : 'ok');
    } catch (e) { say('Xəta: ' + e.message, 'err'); }
    lock(false);
  };
  const mount = () => { if (!host.isConnected) (document.body || document.documentElement).appendChild(host); };
  mount(); new MutationObserver(mount).observe(document.documentElement, { childList: true });
})();
