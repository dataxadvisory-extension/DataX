// DataX Advisory — kiçik pəncərə: lisenziya, yeniliklər, texniki dəstək və panelin açılması
const $ = id => document.getElementById(id);
$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
const say = m => { $('lst').textContent = m; };
let winId = null; chrome.windows.getCurrent(w => { winId = w && w.id; });
// Panel istifadəçi kliki ilə açılmalıdır: heç bir gözləmə olmadan çağırılır
function openPanel(fn) {
  if (fn) chrome.storage.local.set({ openFn: { fn, t: Date.now() } });
  if (!chrome.sidePanel || !chrome.sidePanel.open) { chrome.tabs.create({ url: chrome.runtime.getURL('panel.html') }); window.close(); return; }
  chrome.sidePanel.open(winId != null ? { windowId: winId } : {}).then(() => window.close()).catch(e => say('Panel açılmadı: ' + e.message));
}
$('openp').onclick = () => openPanel(null);
$('sup').onclick = async () => {
  const { report } = await chrome.storage.local.get('report');
  if (!report) { say('Hələ dəstək məlumatı yoxdur. Əvvəlcə funksiyanı bir dəfə işlət.'); return; }
  await navigator.clipboard.writeText(JSON.stringify(report, null, 1));
  say('Dəstək məlumatı kopyalandı. İçində məbləğ, VÖEN və ad yoxdur.');
};
// ---- Lisenziya ----
const LMSG = { yoxdur: 'Bu cihazda DataX Advisory-ni işlətmək üçün lisenziya açarı lazımdır.', imza: 'Saxlanmış açar etibarsızdır. Yeni açar daxil et.', cihaz: 'Saxlanmış açar başqa cihaz üçündür. Bu cihazın kodu ilə yeni açar al.', bitib: 'Lisenziyanın müddəti bitib. Yeni açar al.', format: 'Saxlanmış açar düzgün deyil.', dayandirilib: 'Lisenziya dayandırılıb. Davam etmək üçün əlaqə saxlayın: +994 50 656 21 01.', sinxron: 'Lisenziya 14 gündür yoxlanıla bilmir. İnternetə qoşulun və pəncərəni yenidən açın.' };
const fmtD = s => s ? s.split('-').reverse().join('.') : '';
function showLic(r) {
  $('devid').textContent = r.device || '...';
  document.body.classList.toggle('nolic', !r.ok);
  if (!r.ok) { $('licmsg').textContent = LMSG[r.reason] || LMSG.yoxdur; return; }
  $('licnumv').textContent = r.device || '';
  $('licinfo').textContent = `Lisenziya${r.name ? ': ' + r.name + ',' : ':'} ${fmtD(r.until)}-dək`;
  $('licinfo').classList.toggle('warn', r.days < 15);
  if (r.days < 15) $('licinfo').textContent += ` (${r.days} gün qalıb)`;
}
chrome.runtime.sendMessage({ type: 'checkUpdate' }, () => void chrome.runtime.lastError);
chrome.runtime.sendMessage({ type: 'lic' }, r => { if (r) showLic(r); chrome.runtime.sendMessage({ type: 'lic', sync: true }, r2 => { if (r2) showLic(r2); }); });
$('devcopy').onclick = async () => { try { await navigator.clipboard.writeText($('devid').textContent); $('devcopy').textContent = 'Kopyalandı'; } catch (e) {} };
$('licgo').onclick = () => {
  const key = $('lickey').value.trim(); if (!key) { $('licst').textContent = 'Açarı yapışdır.'; return; }
  $('licst').textContent = 'Yoxlanılır...';
  chrome.runtime.sendMessage({ type: 'setLic', key }, r => {
    if (r && r.ok) { $('licst').textContent = ''; $('lickey').value = ''; showLic(r); return; }
    $('licst').textContent = { imza: 'Açar etibarsızdır.', cihaz: 'Bu açar başqa cihaz üçündür.', bitib: 'Bu açarın müddəti bitib.', dayandirilib: 'Lisenziya hələ dayandırılıb. İdarəetmə panelində bərpa olunmalıdır.', sinxron: 'İnternet bağlantısını yoxla və yenidən cəhd et.', format: 'Açar düzgün deyil: tam kopyalandığını yoxla.' }[r && r.reason] || 'Açar qəbul olunmadı.';
  });
};

// ---- Yeniliklər (həmişə görünür; yeni versiyadan sonra vurğulanır) ----
const CUR = chrome.runtime.getManifest().version, cmp = (a, b) => a.localeCompare(b, undefined, { numeric: true });
$('vcur').textContent = CUR;
(async () => {
  let ch = {}; try { ch = await (await fetch(chrome.runtime.getURL('changes.json'))).json(); } catch (e) {}
  const vers = Object.keys(ch).filter(v => cmp(v, CUR) <= 0).sort((a, b) => cmp(b, a));
  const show = vs => {
    const ul = $('newslist'); ul.replaceChildren();
    vs.forEach(v => { if (vs.length > 1) { const h = document.createElement('li'); h.className = 'v'; h.textContent = 'v' + v; ul.appendChild(h); } (ch[v] || []).forEach(x => { const li = document.createElement('li'); li.textContent = x; ul.appendChild(li); }); });
  };
  const { seenVer } = await chrome.storage.local.get('seenVer'), base = seenVer || '1.17', unseen = vers.filter(v => cmp(v, base) > 0);
  $('newsver').textContent = 'v' + CUR;
  if (unseen.length) { show(unseen.slice(0, 3)); $('news').classList.add('fresh'); $('newbadge').hidden = false; $('newsok').hidden = false; }
  else show(vers.slice(0, 1));
  $('newsok').onclick = () => { chrome.storage.local.set({ seenVer: CUR }); $('news').classList.remove('fresh'); $('newbadge').hidden = true; $('newsok').hidden = true; };
  let all = false; $('newsall').onclick = () => { all = !all; show(all ? vers : (unseen.length ? unseen.slice(0, 3) : vers.slice(0, 1))); $('newsall').textContent = all ? 'Qısa göstər' : 'Bütün yeniliklər'; };
})();
// ---- Versiya: GitHub-dakı ən son versiya ilə müqayisə ----
const UPDATE_URL = 'https://raw.githubusercontent.com/dataxadvisory-extension/DataX/main/version.json';
async function checkVer(manual) {
  const st = $('vstate'); st.classList.remove('up'); if (manual) st.textContent = 'Yoxlanılır...';
  chrome.runtime.sendMessage({ type: 'checkUpdate' }, () => void chrome.runtime.lastError);
  try {
    const r = await fetch(UPDATE_URL + '?t=' + Date.now(), { cache: 'no-store' }), j = await r.json();
    if (j && j.version && cmp(j.version, CUR) > 0) { st.textContent = `Yeni versiya ${j.version} hazırdır: 2 saat ərzində özü quraşdırılacaq`; st.classList.add('up'); }
    else st.textContent = 'Ən son versiyadır · avtomatik yeniləmə aktivdir';
  } catch (e) { st.textContent = manual ? 'İnternet yoxdur və ya yoxlama alınmadı' : 'Avtomatik yeniləmə aktivdir'; }
}
$('vchk').onclick = () => checkVer(true);
checkVer(false);
// ---- Texniki dəstək: zəng düyməsi nömrəni də kopyalayır ----
$('telbtn').onclick = e => { try { navigator.clipboard.writeText('+994506562101'); } catch (x) {} say('Nömrə kopyalandı: +994 50 656 21 01'); };

$('logout').onclick = () => {
  if (!confirm('Çıxış edilsin? Yenidən daxil olmaq üçün lisenziya açarı lazım olacaq.')) return;
  chrome.storage.local.remove(['license', 'licState'], () => chrome.runtime.sendMessage({ type: 'lic' }, r => { if (r) showLic(r); }));
};
