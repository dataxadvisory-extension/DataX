@echo off
chcp 65001 >nul
echo DataX yenilenir...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0datax-yenileyici.ps1" -SetChannel keep
echo.
pause
