// Vahid bəyannamə (muzdlu iş): əməkhaqqı cədvəlindən e-taxes Əlavə 1 Hissə 1 və Hissə 3 faylları
// readTable / unzip analiz-core.js-dəndir. Hər şey brauzerdə, yerli işlənir.
(() => {
  const $ = id => document.getElementById(id);
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;
  chrome.runtime.sendMessage({ type: 'lic' }, r => { document.body.classList.toggle('nolic', !(r && r.ok)); });
  const say = (msg, err, ok) => { const s = $('st'); s.textContent = msg; s.classList.toggle('err', !!err); s.classList.toggle('ok', !!ok); };
  const low = s => String(s == null ? '' : s).toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();
  const fold = s => low(s).replace(/i̇/g, 'i').replace(/[əıöüçşğ]/g, c => ({ ə: 'e', ı: 'i', ö: 'o', ü: 'u', ç: 'c', ş: 's', ğ: 'g' })[c]);
  const numv = v => { if (typeof v === 'number') return v; const s = String(v == null ? '' : v).replace(/[\s ]/g, ''); if (!s) return NaN; const t = s.includes(',') && s.includes('.') ? (s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '')) : s.replace(',', '.'); const n = Number(t); return isNaN(n) ? NaN : n; };
  const f2 = v => (Math.round((v || 0) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const fin = v => { const s = String(v == null ? '' : v).toUpperCase().replace(/\s/g, ''); return /^[0-9A-Z]{7}$/.test(s) && /\d/.test(s) ? s : ''; };
  const MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
  const REASONS = ['1-İşçinin ödənişli əsas məzuniyyətdən və müvafiq hallarda əlavə məzuniyyətlərindən istifadə etməsi', '2-İşçinin sosial məzuniyyətlərindən istifadə etməsi',
    '3-İşçinin ödənişsiz məzuniyyətlərindən istifadə etməsi', '4-İşçinin təhsil məzuniyyətlərindən istifadə etməsi', '5-İşçinin xəstələnməsi', '6-Əmək müqaviləsinə xitam verilməsi', '7-Növbəli iş vaxtı',
    '8-Ayın ortası işə qəbul olma', '9-Qeyd olunan ay üzrə işəgötürənlə əmək müqaviləsi bağlanılmamışdır.', '10-İşçinin işəmuzd işləməsi',
    '11-İşçinin qanunvericiliklə nəzərdə tutulmuş hallarda və qaydada dövlət və ictimai vəzifələrin yerinə yetirilməsinə cəlb edildiyi müddət'];
  // Sütun rolları: [açar, ad, başlıq sözləri (fold edilmiş), istisna sözlər, məcburi]
  const ROLES = [
    ['name', 'Soyadı, adı, atasının adı', /soyad|s\.?a\.?a|ad[iı], soyad|isci|emekdas|ishci|ф\.?и\.?о|full ?name|^ad$|adi$/, /vezife|bolme|sobe|ata ad[iı]$/, true],
    ['fin', 'FİN', /fin|f\.i\.n|pin|şəxsiyyət|sexsiyyet/, null, true],
    ['gross', 'Hesablanmış əmək haqqı (cəmi)', /hesablan|cemi hesab|emek ?haqq|maas|gross|umumi gelir|cemi gelir|hesablanmis/, /odenil|odenecek|xalis|net|tutul|vergi|dsmf|mdss|sigorta|avans|isziz|tibbi|kart|bank|ezamiyye|mezuniyyet haqq/, true],
    ['days', 'Faktiki iş günləri', /faktiki|isledig|is gun|islenmis|gun say|islenen gun|islediyi gun/, /mezun|xeste|odenissiz|norma|ayin is/, false],
    ['norm', 'Ayın iş günü norması', /ayin is|norma|is gunu normasi|ayin gun/, /faktiki/, false],
    ['main', 'Əsas iş yeri (Bəli/Xeyr)', /esas is|evezci|evezcilik/, null, false],
    ['nonsal', 'Əmək haqqının tərkibinə daxil olmayan gəlirlər', /terkibine daxil olmayan|diger gelir|maddi yardim|hediyye|kompensasiya/, null, false],
    ['exempt', 'Azadolunan və güzəştli gəlir', /azad olunan|azadolunan|guzest|azad/, null, false],
    ['itax', 'Gəlir vergisi (azadolma düsturdan oxunur)', /gelir vergisi|^gv$/, /isegoturen|odenilmeli/, false],
    ['nodsmf', 'MDSS-yə cəlb olunmayan məbləğ', /mdss.*cel.*olunmayan|dsmf.*cel.*olunmayan/, null, false],
    ['noissiz', 'İşsizlik sığortasına cəlb olunmayan', /issizlik.*cel.*olunmayan/, null, false],
    ['notibb', 'Tibbi sığortaya cəlb olunmayan', /tibbi.*cel.*olunmayan/, null, false]];
  // İşləmədiyi gün sütunları → səbəb nömrəsi
  const ABS = [[/odenissiz/, 3], [/sosial|analiq|usaq|hamilelik/, 2], [/tehsil/, 4], [/xeste|bulleten|emek qabiliyyet/, 5], [/mezun/, 1]];
  const slots = [null, null, null];
  let src = [], ents = [];   // yüklənmiş fayllar və başlığı tanınan bütün vərəqlər
  const choice = new Map(); let askedOpen = false;   // səbəbi bilinməyən günlər üçün istifadəçi seçimi   // { file, sheets, si, hi, header, map, abs: {col: reason} }

  // Rüb seçimi
  const nowY = new Date().getFullYear();
  for (let y = nowY; y >= nowY - 2; y--) for (let q = 4; q >= 1; q--) $('q').add(new Option(`${y}, ${q}-cü rüb (${MONTHS[q * 3 - 3]} – ${MONTHS[q * 3 - 1]})`, `${y}.${q}`));
  const curQ = Math.floor(new Date().getMonth() / 3) + 1; $('q').value = curQ === 1 ? `${nowY - 1}.4` : `${nowY}.${curQ - 1}`;
  const qInfo = () => { const [y, q] = $('q').value.split('.').map(Number); return { y, q, m: [0, 1, 2].map(i => MONTHS[q * 3 - 3 + i]) }; };
  const paintMonths = () => { const { m } = qInfo(); m.forEach((n, i) => { $('mn' + i).textContent = `${i + 1}-ci ay: ${n}`; $('nl' + i).textContent = n; }); };
  $('q').onchange = () => { paintMonths(); if (ents.length) { choice.clear(); askedOpen = false; assign(); } }; paintMonths();
  // Vərəqin (və ya faylın) adından ay və il: "İyul 2026", "IYUL", "Avq.2026", "07.2026", "2026-07"
  const MPRE = ['yan', 'fev', 'mart', 'apr', 'may', 'iyun', 'iyul', 'avq', 'sen', 'okt', 'noy', 'dek'];
  function monthOf(name) {
    const nm = fold(name).replace(/[_]/g, ' '), ym = nm.match(/20\d\d/), yr = ym ? +ym[0] : null;
    let m = MPRE.findIndex(p => new RegExp('(^|[^a-z])' + p).test(nm));
    if (m < 0) { const a = nm.match(/(?:^|\D)(0?[1-9]|1[0-2])[.\-\/ ]+20\d\d(?:\D|$)/) || nm.match(/20\d\d[.\-\/ ]+(0?[1-9]|1[0-2])(?:\D|$)/); if (a) m = +a[1] - 1; }
    return m < 0 ? null : { m, y: yr };
  }

  // Başlıq sətri: ən çox rol sözünə uyğun gələn sətir (+ yuxarıdakı 2 sətir birləşdirilir)
  function headerOf(rows) {
    let best = -1, bs = 0;
    for (let r = 0; r < Math.min(rows.length, 30); r++) {
      const cells = (rows[r] || []).map(fold); let sc = 0;
      for (const [, , re, ex] of ROLES) if (cells.some(h => h && re.test(h) && !(ex && ex.test(h)))) sc++;
      if (sc > bs) { bs = sc; best = r; }
    }
    if (best < 0) return null;
    const width = Math.max(...rows.slice(best, best + 30).map(r => (r || []).length), 0);
    // Yuxarı sətirlərdəki qrup başlıqları (birləşdirilmiş xanalar, məs. "HESABLANIB") sağdakı sütunlara da aiddir
    const up = [rows[best - 2], rows[best - 1]].map(r => (r || []).filter(v => String(v || '').trim()).length >= 2 ? r : null).map(r => { const o = []; let last = ''; for (let c = 0; c < width; c++) { const v = r && r[c] ? String(r[c]).trim() : ''; if (v) last = v; else if (!(rows[best] && rows[best][c])) last = ''; o.push(v || last); } return o; });
    const header = Array.from({ length: width }, (_, c) => [up[0][c], up[1][c], rows[best] && rows[best][c] ? String(rows[best][c]).trim() : ''].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(' / '));
    return { hi: best, header };
  }
  // Sütunları tanı: həm başlığa, həm də məzmuna görə
  function autoMap(rows, hi, header) {
    const data = rows.slice(hi + 1).filter(r => r && r.some(v => String(v || '').trim())).slice(0, 300);
    const col = c => data.map(r => r[c]);
    const map = {}, used = new Set();
    // FİN — məzmuna görə (7 simvol, rəqəm + hərf)
    let bestF = -1, bf = 0;
    header.forEach((_, c) => { const v = col(c).filter(x => String(x || '').trim()), k = v.filter(x => fin(x)).length; if (v.length && k / v.length > bf && k >= 1) { bf = k / v.length; bestF = c; } });
    if (bestF >= 0 && bf >= 0.5) { map.fin = bestF; used.add(bestF); }
    // Hesablanmış gəlir: üstünlük sırası ilə ("cəmi hesablanıb" > "hesablanmış" > "əmək haqqı")
    const GROSS = [/cemi hesab|hesablan(mis|an)? ?cemi|umumi hesab|cemi gelir/, /hesablanmis emek|hesablanmis|hesablanib/, /gross|umumi gelir/, /emek ?haqq|maas/];
    const gx = ROLES.find(x => x[0] === 'gross')[3], gx2 = /vezife maas|tarif|stavka|norma|gunluk|saatliq/;
    // "CƏMİ" sütunu "HESABLANIB" qrupunun (əməkhaqqı, mükafat, məzuniyyət) dərhal arxasındadırsa — ümumi hesablanmış gəlir odur
    { const c = header.findIndex((h, i) => i > 0 && !used.has(i) && /^cemi$/.test(fold(String(h).split(' / ').pop())) && /hesablan|mukafat|mezuniyyet|emek ?haqq/.test(fold(header[i - 1]))); if (c >= 0) { map.gross = c; used.add(c); } }
    if (map.gross == null) for (const re of GROSS) { const c = header.findIndex((h, i) => !used.has(i) && h && re.test(fold(h)) && !gx.test(fold(h)) && !gx2.test(fold(h))); if (c >= 0) { map.gross = c; used.add(c); break; } }
    for (const [key, , re, ex] of ROLES) {
      if (map[key] != null) continue;
      const c = header.findIndex((h, i) => !used.has(i) && h && re.test(fold(h)) && !(ex && ex.test(fold(h))));
      if (c >= 0) { map[key] = c; used.add(c); }
    }
    // Ad — tapılmayıbsa: 2+ sözdən ibarət mətn sütunu
    if (map.name == null) {
      const c = header.findIndex((_, i) => !used.has(i) && col(i).filter(x => /^\p{L}+(\s+\p{L}+){1,3}$/u.test(String(x || '').trim())).length >= Math.max(1, data.length * 0.5));
      if (c >= 0) { map.name = c; used.add(c); }
    }
    // İşləmədiyi günlər (məzuniyyət, xəstəlik və s.) — yalnız "gün" sütunları
    const abs = {};
    header.forEach((h, c) => {
      if (used.has(c)) return; const f = fold(h);
      if (/haqq|mebleg|pul|azn|manat|odenis meb|hesablan|tutul/.test(f)) return;
      const hit = ABS.find(([re]) => re.test(f)); if (!hit) return;
      const vals = col(c).map(numv).filter(v => !isNaN(v));
      if (!/gun/.test(f) && !(vals.length && vals.every(v => Number.isInteger(v) && v >= 0 && v <= 31))) return;
      abs[c] = hit[1];
    });
    return { map, abs };
  }
  function selectEl(header, val, allowNone = true) {
    const s = document.createElement('select');
    if (allowNone) s.add(new Option('— yoxdur —', ''));
    header.forEach((h, i) => s.add(new Option(`${String.fromCharCode(65 + (i % 26))}${i >= 26 ? Math.floor(i / 26) : ''}: ${String(h || '(boş)').slice(0, 50)}`, i)));
    s.value = val != null ? String(val) : '';
    return s;
  }
  function render(i) {
    const S = slots[i], box = $('m' + i); box.replaceChildren();
    if (ents.length) {
      const d = document.createElement('div'); d.className = 'sheet'; d.style.margin = '0 0 4px'; d.append('Vərəq:');
      const s = document.createElement('select'); s.add(new Option('— bu ay yoxdur —', ''));
      ents.forEach((x, k) => s.add(new Option(src.length > 1 ? `${src[x.fi].name} · ${x.nm}` : (x.nm || `Vərəq ${x.k + 1}`), k)));
      s.value = S ? String(S.ei) : ''; s.onchange = () => { choice.clear(); askedOpen = false; if (s.value === '') { slots[i] = null; render(i); refresh(); } else useSheet(i, +s.value); };
      d.append(s); box.append(d);
    }
    if (!S) { info(i); return; }
    const det = document.createElement('details'); det.className = 'map'; det.open = ['name', 'fin', 'gross'].some(k => S.map[k] == null);
    det.innerHTML = '<summary>Tanınan sütunlar (yoxla, lazım olsa dəyiş)</summary>';
    const g = document.createElement('div'); g.className = 'grid';
    for (const [key, label, , , req] of ROLES) {
      const l = document.createElement('label'); l.textContent = label + (req ? ' *' : '');
      const s = selectEl(S.header, S.map[key]); s.onchange = () => { if (s.value === '') delete S.map[key]; else S.map[key] = +s.value; info(i); refresh(); };
      g.append(l, s);
    }
    const sep = document.createElement('label'); sep.textContent = 'İşləmədiyi gün sütunları:'; sep.style.cssText = 'grid-column:1/-1;margin-top:6px;color:var(--steel)'; g.append(sep);
    S.header.forEach((h, c) => {
      if (!h || Object.values(S.map).includes(c)) return;
      const f = fold(h); if (!(c in S.abs) && !/gun|mezun|xeste|bulleten/.test(f)) return;
      const l = document.createElement('label'); l.textContent = String(h).slice(0, 40);
      const s = document.createElement('select'); s.add(new Option('— hesaba alma —', ''));
      REASONS.forEach((r, k) => s.add(new Option(r.slice(0, 60), k + 1))); s.value = S.abs[c] ? String(S.abs[c]) : '';
      s.onchange = () => { if (s.value === '') delete S.abs[c]; else S.abs[c] = +s.value; info(i); };
      g.append(l, s);
    });
    det.append(g); box.append(det); info(i);
  }
  // Gəlir vergisi düsturundan azad olunan məbləğ: məs. IF(N7<=200,0,IF(N7<=2500,(N7-200)*3%,...)) → 200 (gəlir 200-dən azdırsa — gəlirin özü)
  function xlParse(src) {
    const T = []; let i = 0;
    while (i < src.length) {
      const r = src.slice(i), m = /^\s+/.exec(r) || /^"(?:[^"]|"")*"/.exec(r) || /^(?:'[^']+'|[A-Za-z0-9_.]+)!\$?[A-Z]{1,3}\$?\d+/.exec(r) || /^\$?[A-Z]{1,3}\$?\d+(?![\w(])/.exec(r) || /^\d+(?:\.\d+)?(?:E[+-]?\d+)?/i.exec(r) || /^[A-Za-z_][\w.]*(?=\()/.exec(r) || /^(?:<=|>=|<>|[-+*/^&%=<>(),;])/.exec(r);
      if (!m) throw new Error('düstur');
      const t = m[0]; i += t.length; if (/^\s/.test(t)) continue;
      T.push(/^"/.test(t) ? { k: 's', v: t.slice(1, -1) } : /!/.test(t) ? { k: 'x' } : /^\$?[A-Z]{1,3}\$?\d+$/.test(t) ? { k: 'r', v: t.replace(/\$/g, '') } : /^\d/.test(t) ? { k: 'n', v: +t } : /^[A-Za-z_]/.test(t) ? { k: 'f', v: t.toUpperCase().replace(/^_XLFN\./, '') } : { k: 'o', v: t === ';' ? ',' : t });
    }
    let p = 0; const pk = () => T[p], eat = v => { if (pk() && pk().k === 'o' && pk().v === v) { p++; return true; } return false; };
    const bin = (next, ops) => () => { let l = next(); while (pk() && pk().k === 'o' && ops.includes(pk().v)) { const op = T[p++].v; l = { op, a: l, b: next() }; } return l; };
    const prim = () => {
      const t = T[p++]; if (!t) throw new Error('düstur');
      if (t.k === 'o' && t.v === '-') return { op: 'neg', a: post() };
      if (t.k === 'o' && t.v === '+') return post();
      if (t.k === 'o' && t.v === '(') { const e = cmp(); eat(')'); return e; }
      if (t.k === 'f') { eat('('); const args = []; if (!eat(')')) { do args.push(cmp()); while (eat(',')); eat(')'); } return { fn: t.v, args }; }
      return t;
    };
    const post = () => { let e = prim(); while (eat('%')) e = { op: '%', a: e }; return e; };
    const pow = bin(post, ['^']), mul = bin(pow, ['*', '/']), add = bin(mul, ['+', '-']), cat = bin(add, ['&']), cmp = bin(cat, ['=', '<>', '<=', '>=', '<', '>']);
    const e = cmp(); return e;
  }
  function exemptOf(ft, rows) {
    const cell = ref => { const c = colIdx(ref), r = +ref.replace(/^[A-Z]+/, '') - 1; return numv((rows[r] || [])[c]); };
    const ev = e => {
      if (!e) return NaN; if (e.k === 'n') return e.v; if (e.k === 'r') { const v = cell(e.v); return isNaN(v) ? 0 : v; } if (e.k === 's' || e.k === 'x') return NaN;
      if (e.fn) { const a = e.args.map(ev); switch (e.fn) {
        case 'IF': return a[0] ? ev(e.args[1]) : e.args.length > 2 ? ev(e.args[2]) : 0;
        case 'ROUND': case 'ROUNDUP': case 'ROUNDDOWN': return Math.round(a[0] * 10 ** (a[1] || 0)) / 10 ** (a[1] || 0);
        case 'MAX': return Math.max(...a); case 'MIN': return Math.min(...a); case 'SUM': return a.reduce((t, x) => t + x, 0);
        case 'AND': return a.every(Boolean); case 'OR': return a.some(Boolean); case 'ABS': return Math.abs(a[0]); default: return NaN; } }
      const A = ev(e.a), B = e.b ? ev(e.b) : 0;
      switch (e.op) { case 'neg': return -A; case '%': return A / 100; case '+': return A + B; case '-': return A - B; case '*': return A * B; case '/': return A / B; case '^': return A ** B;
        case '=': return Math.abs(A - B) < 1e-9; case '<>': return A !== B; case '<=': return A <= B + 1e-9; case '>=': return A >= B - 1e-9; case '<': return A < B; case '>': return A > B; }
      return NaN;
    };
    const refs = e => !e ? [] : e.k === 'r' ? [e.v] : e.fn ? e.args.flatMap(refs) : [...refs(e.a), ...refs(e.b)];
    let e = xlParse(ft.replace(/^=/, ''));
    const all = refs(e); if (!all.length) return NaN;
    const cnt = {}; all.forEach(r => { cnt[r] = (cnt[r] || 0) + 1; }); const X = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a])[0], xv = cell(X);
    if (!(xv > 0)) return NaN;
    while (e.fn === 'IF') e = ev(e.args[0]) ? e.args[1] : e.args[2];           // gəlirə uyğun pillə
    if (!e) return xv;
    if (Math.abs(ev(e)) < 0.005) return xv;                                     // vergi 0 — bütün gəlir azaddır
    const hasX = n => refs(n).includes(X);
    const find = n => {                                                         // (X - K) * dərəcə → K
      if (!n) return NaN;
      if (n.fn && /^ROUND/.test(n.fn)) return find(n.args[0]);
      if (n.fn === 'MAX' || n.fn === 'MIN') { const k = n.args.filter(hasX); return k.length === 1 ? find(k[0]) : NaN; }
      if (n.op === '%') return find(n.a);
      if (n.op === '*' || n.op === '/') return hasX(n.a) && !hasX(n.b) ? find(n.a) : n.op === '*' && hasX(n.b) && !hasX(n.a) ? find(n.b) : NaN;
      if (n.op === '-' && hasX(n.a) && !hasX(n.b)) { const k = ev(n.b); return n.a.k === 'r' && n.a.v === X && k > 0 ? Math.min(k, xv) : NaN; }
      if (n.op === '+') return 0;                                               // sabit + (X-K)*dərəcə: bu pillədə azadolma yoxdur
      if (n.k === 'r' && n.v === X) return 0;
      return NaN;
    };
    const k = find(e); return isNaN(k) ? NaN : Math.round(k * 100) / 100;
  }
  function rowsOf(S) {
    const M = S.map, out = [], Y = S.yellow || {}, RD = S.red || {}, GR = S.green || {};
    // Tabel hissəsi (1..31 gün sütunları) varsa, sarı gün xanaları sayılır; yoxdursa sarı sətir = məzuniyyət
    const dayCols = S.header.map((h, c) => /^(\d{1,2})$/.test(String(h).split(' / ').pop().trim()) && +String(h).split(' / ').pop() <= 31 ? c : -1).filter(c => c >= 0);
    const tabel = dayCols.length >= 10 ? new Set(dayCols) : null;
    // Bəzək üçün bütöv sarı sütun (məs. "Cəmi") məzuniyyət deyil: işçilərin 60%-dən çoxunda sarı olan sütun nəzərə alınmır
    const dataRi = []; for (let ri = S.hi + 1; ri < S.rows.length; ri++) if (S.rows[ri] && fin(S.rows[ri][M.fin])) dataRi.push(ri);
    const styledOf = MAP => { const cnt = {}; dataRi.forEach(ri => new Set(MAP[ri] || []).forEach(c => { cnt[c] = (cnt[c] || 0) + 1; })); return new Set(Object.keys(cnt).filter(c => dataRi.length >= 4 && cnt[c] / dataRi.length > 0.6).map(Number)); };
    const styled = styledOf(Y), stR = styledOf(RD), stG = styledOf(GR);
    const marked = (MAP, st, ri) => (MAP[ri] || []).some(c => c < S.header.length && !st.has(c));
    // Sətirdəki qeyd: "26-31 öz hes məz" → ödənişsiz məzuniyyət, "xəstə / bülleten" → xəstəlik
    const noteOf = (r, ri) => { const t = fold(r.filter((v, c) => c !== M.name && c !== M.fin && typeof v === 'string').join(' ')); return /oz\s*hes|odenissiz|maassiz/.test(t) ? 3 : /xeste|bulleten|bulleten/.test(t) ? 5 : 0; };
    for (let ri = S.hi + 1; ri < S.rows.length; ri++) {
      const r = S.rows[ri]; if (!r) continue; const f = fin(r[M.fin]); if (!f) continue;
      const yc = [...new Set(Y[ri] || [])].filter(c => c < S.header.length && !styled.has(c)), yellow = yc.length > 0, yDays = tabel ? yc.filter(c => tabel.has(c)).length : 0;
      const g = k => M[k] == null ? NaN : numv(r[M[k]]);
      const mainRaw = M.main == null ? '' : fold(r[M.main]);
      const main = !mainRaw ? $('mainDef').value : /xeyr|evez|elave|no|0/.test(mainRaw) && !/esas|beli|yes/.test(mainRaw) ? 'Xeyr' : 'Bəli';
      const abs = {}; for (const [c, rs] of Object.entries(S.abs)) { const v = numv(r[c]); if (v > 0) abs[rs] = (abs[rs] || 0) + v; }
      let exempt = g('exempt');
      if (isNaN(exempt) && M.itax != null) { const ft = S.formulas && S.formulas[ri] && S.formulas[ri][M.itax]; if (ft) { try { exempt = exemptOf(ft, S.rows); } catch (e) { exempt = NaN; } } }
      out.push({ fin: f, name: String(r[M.name] || '').trim().replace(/\s+/g, ' '), main, days: g('days'), norm: g('norm'), gross: g('gross'), nonsal: g('nonsal'), exempt, nodsmf: g('nodsmf'), noissiz: g('noissiz'), notibb: g('notibb'), abs, yellow, yDays,
        red: marked(RD, stR, ri), green: marked(GR, stG, ri), note: noteOf(r, ri) });
    }
    return out;
  }
  function info(i) {
    const S = slots[i], el = $('i' + i); if (!S) { el.className = 'info'; el.textContent = ents.length ? 'Bu ay üçün vərəq tapılmadı — varsa, yuxarıdan seç.' : ''; return; }
    const need = ['name', 'fin', 'gross'].filter(k => S.map[k] == null).map(k => ROLES.find(x => x[0] === k)[1]);
    if (need.length) { el.className = 'info err'; el.textContent = 'Seç: ' + need.join(', '); return; }
    const R = rowsOf(S), tot = R.reduce((t, x) => t + (x.gross || 0), 0);
    const yl = new Set(R.filter(x => x.yellow).map(x => x.fin)).size, nf = new Set(R.map(x => x.fin)).size, rl = new Set(R.filter(x => x.red).map(x => x.fin)).size, gl = new Set(R.filter(x => x.green).map(x => x.fin)).size;
    el.className = 'info'; el.innerHTML = `<span class="ok">✓ ${nf} işçi</span>, hesablanmış cəmi ${f2(tot)} AZN` + (Object.keys(S.abs).length ? `, ${Object.keys(S.abs).length} işləmədiyi gün sütunu` : '') + (yl ? `, ${yl} işçi sarı — ödənişli məzuniyyət` : '') + (rl ? `, ${rl} işçi qırmızı — xitam` : '') + (gl ? `, ${gl} işçi yaşıl — işə qəbul` : '') + (R.length > nf ? `, ${R.length - nf} işçi 2 vəzifədə` : '');
  }
  function useSheet(n, ei) {
    const E = ents[ei], sh = src[E.fi].sheets[E.k];
    slots[n] = { file: src[E.fi].name, ei, si: E.k, hi: E.h.hi, header: E.h.header, rows: sh.rows, yellow: sh.yellow || {}, red: sh.red || {}, green: sh.green || {}, formulas: sh.formulas || {}, ...autoMap(sh.rows, E.h.hi, E.h.header) };
    render(n); refresh();
  }
  // Rübün ayları: vərəq adına görə; tək vərəqli fayllarda fayl adına görə; ad yoxdursa — ardıcıl
  function assign() {
    const { y, q } = qInfo(), m0 = q * 3 - 3;
    const hit = (nm, n) => { const o = monthOf(nm); return o && o.m === m0 + n && (o.y == null || o.y === y); };
    let pick = [0, 1, 2].map(n => ents.findIndex(x => hit(x.nm, n)));
    pick = pick.map((p, n) => p >= 0 ? p : ents.findIndex(x => src[x.fi].sheets.length === 1 && hit(src[x.fi].name, n)));
    if (pick.every(p => p < 0) && !ents.some(x => monthOf(x.nm) || monthOf(src[x.fi].name))) pick = [0, 1, 2].map(n => n < ents.length ? n : -1);
    [0, 1, 2].forEach(n => { if (pick[n] >= 0) useSheet(n, pick[n]); else { slots[n] = null; render(n); } });
    $('months').style.display = 'grid';
    const { m: mn } = qInfo(), miss = mn.filter((_, n) => pick[n] < 0), el = $('fi');
    el.className = miss.length ? 'info err' : 'info';
    el.innerHTML = miss.length ? `Faylda bu aylar tapılmadı: ${miss.join(', ')}. Rübü yoxla və ya aşağıda vərəqi özün seç.` : `<span class="ok">✓ Rübün 3 ayı tapıldı</span> — aşağıda yoxla.`;
    refresh();
  }
  async function load(files) {
    const el = $('fi'); el.className = 'info'; el.textContent = 'Oxunur...'; askedOpen = false; choice.clear();
    try {
      src = [];
      for (const f of files) { const sheets = (await readTable(f)).filter(s => s.rows && s.rows.length); if (sheets.length) src.push({ name: f.name, sheets }); }
      if (!src.length) throw new Error('Faylda məlumat tapılmadı.');
      ents = src.flatMap((s, fi) => s.sheets.map((sh, k) => ({ fi, k, nm: sh.name || '', h: headerOf(sh.rows) }))).filter(x => x.h);
      if (!ents.length) throw new Error('Əməkhaqqı cədvəli tanınmadı: başlıq sətri (ad, FİN, hesablanmış) tapılmadı.');
      $('d').classList.add('done'); $('d').querySelector('b').textContent = src.map(s => s.name).join(', ');
      assign();
    } catch (e) { src = []; ents = []; slots.fill(null); [0, 1, 2].forEach(render); $('months').style.display = 'none'; el.className = 'info err'; el.textContent = e.message; }
    refresh();
  }
  {
    const drop = $('d'), input = drop.querySelector('input');
    input.onchange = () => input.files.length && load([...input.files]);
    drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
    drop.ondragleave = () => drop.classList.remove('over');
    drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); e.dataTransfer.files.length && load([...e.dataTransfer.files]); };
    drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } };
  }
  const ready = () => slots.some(S => S && ['name', 'fin', 'gross'].every(k => S.map[k] != null));
  function refresh() {
    $('go').disabled = !ready();
    const n = slots.filter(Boolean).length; $('sum').textContent = n ? `${n} ay tapılıb. Yoxla və "Faylları hazırla" düyməsini bas.` : 'Əməkhaqqı cədvəlini seç.';
  }

  // ---------- Şablonun doldurulması (e-taxes-in öz Excel nümunəsi) ----------
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zip(files) {
    const enc = new TextEncoder(), chunks = [], central = []; let off = 0;
    const now = new Date(), dt = ((now.getFullYear() - 1980) << 9 | (now.getMonth() + 1) << 5 | now.getDate()) & 0xFFFF, tm = (now.getHours() << 11 | now.getMinutes() << 5 | now.getSeconds() >> 1) & 0xFFFF;
    for (const f of files) {
      const nm = enc.encode(f.name), d = f.data, crc = crc32(d), n = d.length;
      const lh = new DataView(new ArrayBuffer(30)); lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(10, tm, true); lh.setUint16(12, dt, true); lh.setUint32(14, crc, true); lh.setUint32(18, n, true); lh.setUint32(22, n, true); lh.setUint16(26, nm.length, true);
      const ch = new DataView(new ArrayBuffer(46)); ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(12, tm, true); ch.setUint16(14, dt, true); ch.setUint32(16, crc, true); ch.setUint32(20, n, true); ch.setUint32(24, n, true); ch.setUint16(28, nm.length, true); ch.setUint32(42, off, true);
      chunks.push(new Uint8Array(lh.buffer), nm, d); central.push(new Uint8Array(ch.buffer), nm); off += 30 + nm.length + n;
    }
    const cd = central.reduce((s, c) => s + c.length, 0), end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cd, true); end.setUint32(16, off, true);
    const all = [...chunks, ...central, new Uint8Array(end.buffer)], out = new Uint8Array(all.reduce((s, c) => s + c.length, 0)); let p = 0;
    for (const c of all) { out.set(c, p); p += c.length; }
    return out;
  }
  const NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  const colName = i => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  // rows: [[value|null,...]] — firstRow-dan başlayaraq; stil şablonun firstRow sətrindən götürülür
  async function fillTemplate(path, firstRow, rows) {
    const buf = await (await fetch(chrome.runtime.getURL(path))).arrayBuffer(), z = await unzip(buf);
    const xml = await z.read('xl/worksheets/sheet1.xml'), doc = new DOMParser().parseFromString(xml, 'application/xml');
    const sd = doc.getElementsByTagNameNS(NS, 'sheetData')[0], style = {};
    let lastCol = 0;
    for (const r of Array.from(sd.getElementsByTagNameNS(NS, 'row'))) {
      const n = +r.getAttribute('r');
      if (n === firstRow) for (const c of Array.from(r.getElementsByTagNameNS(NS, 'c'))) { const ci = colIdx(c.getAttribute('r')); style[ci] = c.getAttribute('s'); lastCol = Math.max(lastCol, ci); }
      if (n >= firstRow) sd.removeChild(r);
    }
    rows.forEach((vals, k) => {
      const rn = firstRow + k, row = doc.createElementNS(NS, 'row'); row.setAttribute('r', rn);
      for (let ci = 0; ci <= Math.max(lastCol, vals.length - 1); ci++) {
        const v = vals[ci], c = doc.createElementNS(NS, 'c'); c.setAttribute('r', colName(ci) + rn); if (style[ci] != null) c.setAttribute('s', style[ci]);
        if (v != null && v !== '') {
          if (typeof v === 'number') { const e = doc.createElementNS(NS, 'v'); e.textContent = String(Math.round(v * 100) / 100); c.appendChild(e); }
          else { c.setAttribute('t', 'inlineStr'); const is = doc.createElementNS(NS, 'is'), t = doc.createElementNS(NS, 't'); t.textContent = String(v); is.appendChild(t); c.appendChild(is); }
        }
        row.appendChild(c);
      }
      sd.appendChild(row);
    });
    const dim = doc.getElementsByTagNameNS(NS, 'dimension')[0]; if (dim) dim.setAttribute('ref', `A1:${colName(lastCol)}${Math.max(firstRow, firstRow + rows.length - 1)}`);
    const out = new XMLSerializer().serializeToString(doc), enc = new TextEncoder(), files = [];
    for (const name of z.names) files.push({ name, data: enc.encode(name === 'xl/worksheets/sheet1.xml' ? out : await z.read(name)) });
    return zip(files);
  }
  function save(data, name) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  }
  

  window.dxFill = fillTemplate; window.dxSave = save;   // ƏDV əvəzləşmə bölməsi də istifadə edir
  $('go').onclick = async () => {
    $('go').disabled = true; say('Hazırlanır...'); chrome.runtime.sendMessage({ type: 'use', fn: 'vahid' }, () => void chrome.runtime.lastError); $('warn').style.display = 'none'; $('dlbox').style.display = 'none';
    try {
      const { y, q, m: mn } = qInfo(), months = slots.map(S => S && ['name', 'fin', 'gross'].every(k => S.map[k] != null) ? rowsOf(S) : null);
      const emp = new Map(), dup = [];
      months.forEach((R, mi) => R && R.forEach(x => {
        const e = emp.get(x.fin) || { fin: x.fin, name: x.name, m: [null, null, null] };
        if (e.m[mi]) {   // eyni işçi 2 vəzifədə: məbləğlər toplanır, iş günləri toplanmır (ən böyüyü götürülür)
          dup.push(`${x.name} — ${mn[mi]}`); const o = e.m[mi];
          ['gross', 'nonsal', 'exempt', 'nodsmf', 'noissiz', 'notibb'].forEach(k => { if (!isNaN(x[k])) o[k] = (isNaN(o[k]) ? 0 : o[k]) + x[k]; });
          ['days', 'norm'].forEach(k => { if (!isNaN(x[k])) o[k] = isNaN(o[k]) ? x[k] : Math.max(o[k], x[k]); });
          for (const [r, d] of Object.entries(x.abs)) o.abs[r] = Math.max(o.abs[r] || 0, d);
          if (x.main === 'Bəli') o.main = 'Bəli'; o.yellow = o.yellow || x.yellow; o.yDays = Math.max(o.yDays || 0, x.yDays || 0); o.red = o.red || x.red; o.green = o.green || x.green; o.note = o.note || x.note;
        }
        else e.m[mi] = { ...x, abs: { ...x.abs } };
        if (!e.name && x.name) e.name = x.name; emp.set(x.fin, e);
      }));
      const list = [...emp.values()].sort((a, b) => a.name.localeCompare(b.name, 'az'));
      if (!list.length) throw new Error('Heç bir işçi tapılmadı: FİN sütununu yoxla.');
      // Hissə 1: A №, B ad, C FİN; hər ay 11 sütun: əsas iş, gün, gəlir, o cümlədən, HYS, TP, azad, MDSS-yə cəlb olunmayan, MDSS(HYS), işsizlik, tibbi
      const nv = v => isNaN(v) ? null : v;
      const h1 = list.map((e, k) => { const r = [k + 1, e.name, e.fin]; e.m.forEach(x => { r.push(...(x ? [x.main, nv(x.days), nv(x.gross) ?? 0, nv(x.nonsal), null, null, nv(x.exempt), nv(x.nodsmf), null, nv(x.noissiz), nv(x.notibb)] : Array(11).fill(null))); }); return r; });
      // Hissə 3: işləmədiyi günlər. Səbəb: cədvəldəki sütun (məzuniyyət, xəstəlik...) və ya avtomatik —
      // rübün əvvəlində yoxdursa "8-işə qəbul", sonunda yoxdursa "6-xitam"; qalanlarını istifadəçi seçir
      const loaded = [0, 1, 2].filter(mi => months[mi]);
      const mode = arr => { const c = new Map(); arr.filter(v => v > 0).forEach(v => c.set(v, (c.get(v) || 0) + 1)); return [...c.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || 0; };
      const mNorm = [0, 1, 2].map(mi => { const u = numv($('n' + mi).value); return u > 0 ? u : months[mi] ? mode(months[mi].map(x => x.norm)) : 0; });
      // Rübdən kənar aylar da faylda ola bilər (məs. İYUN, OKTYABR) — işçinin orada olub-olmadığına baxılır
      const finCache = new Map();
      const finsAt = x => { if (!finCache.has(x)) { const sh = src[x.fi].sheets[x.k], { map } = autoMap(sh.rows, x.h.hi, x.h.header); finCache.set(x, map.fin == null ? null : new Set(sh.rows.slice(x.h.hi + 1).map(r => r && fin(r[map.fin])).filter(Boolean))); } return finCache.get(x); };
      const absM = x => { const o = monthOf(x.nm) || (src[x.fi].sheets.length === 1 ? monthOf(src[x.fi].name) : null); return o ? (o.y || y) * 12 + o.m : null; };
      const sheetAt = t => { const x = ents.find(x => absM(x) === t && finsAt(x)) || null; return x && finsAt(x); };
      // Ayın əvvəlki aylarında işçi var idimi: əvvəlcə dərhal əvvəlki ay, yoxdursa ondan əvvəlki bütün aylar; heç biri yoxdursa — null (məlum deyil)
      const before = t => { const p = sheetAt(t - 1); if (p) return p; const all = ents.filter(x => absM(x) != null && absM(x) < t && finsAt(x)); if (!all.length) return null; const u = new Set(); all.forEach(x => finsAt(x).forEach(f => u.add(f))); return u; };
      const m0 = q * 3 - 3, T = mi => y * 12 + m0 + mi, nextF = sheetAt(T(3));
      const h3 = [], warns = [], open = [], noPrev = [];
      for (const e of list) {
        const D = {}; const add = (r, mi, d) => { if (!(d > 0)) return; D[r] = D[r] || [null, null, null]; D[r][mi] = Math.round(((D[r][mi] || 0) + d) * 100) / 100; };
        e.m.forEach((x, mi) => { if (!x) return; Object.entries(x.abs).forEach(([r, d]) => add(+r, mi, d)); if (x.yDays > 0 && !x.abs[1]) { add(1, mi, x.yDays); x.abs = { ...x.abs, 1: x.yDays }; } });
        const pres = loaded.filter(mi => e.m[mi]), fp = pres[0], lp = pres[pres.length - 1];
        for (const mi of loaded) {
          const x = e.m[mi];
          if (!x) {                                                          // bütün ay cədvəldə yoxdur
            if (!(mNorm[mi] > 0)) { warns.push(`${e.name} (${e.fin}) — ${mn[mi]}: cədvəldə yoxdur. Hissə 3 üçün gün sayı lazımdır — yuxarıda bu ayın iş günü normasını yaz və yenidən bas.`); continue; }
            if (mi < fp) add(8, mi, mNorm[mi]); else if (mi > lp) add(6, mi, mNorm[mi]);
            else open.push({ e, mi, gap: mNorm[mi], why: 'bu ayın cədvəlində yoxdur' });
            continue;
          }
          // Ümumi iş vaxtı: yuxarıda yazılan norma, yoxdursa ayın ən çox rast gəlinən norması (işçinin öz norması daha azdırsa da — məs. 21 gün vs 27)
          const norm = numv($('n' + mi).value) > 0 ? numv($('n' + mi).value) : mNorm[mi] > 0 ? mNorm[mi] : x.norm;
          if (!(norm > 0) || isNaN(x.days)) { if ((x.yellow && !x.yDays) || x.red || x.green) warns.push(`${e.name} — ${mn[mi]}: ${x.red ? 'qırmızıdır (xitam)' : x.green ? 'yaşıldır (işə qəbul)' : 'sarıdır (məzuniyyət)'}, amma ${isNaN(x.days) ? 'faktiki iş günü' : 'ayın iş günü norması'} tapılmadı — günləri hesablamaq olmadı.`); continue; }
          const gap = Math.round((norm - x.days - Object.values(x.abs).reduce((t, d) => t + d, 0)) * 100) / 100;
          if (gap <= 0) continue;
          // Cədvəldəki işarələr: qeyd (öz hesabına / xəstəlik) → rəng: qırmızı — xitam, yaşıl — işə qəbul, sarı — ödənişli məzuniyyət
          if (x.note && !x.abs[x.note]) { add(x.note, mi, gap); continue; }
          if (x.red) { add(6, mi, gap); continue; }
          if (x.green) { add(8, mi, gap); continue; }
          if (x.yellow && !x.yDays && !x.abs[1]) { add(1, mi, gap); continue; }
          if (mi === fp && loaded.some(k => k < mi && !e.m[k])) add(8, mi, gap);            // ayın ortası işə qəbul
          else if (mi === lp && loaded.some(k => k > mi && !e.m[k])) add(6, mi, gap);        // ayın ortası xitam
          else if (mi === fp && (() => { const B = before(T(mi)); if (B) return !B.has(e.fin); noPrev.push(`${e.name} — ${mn[mi]}`); return true; })()) add(8, mi, gap);   // əvvəlki aylarda yoxdur, bu ay əlavə olunub, günlər natamam → ayın ortası işə qəbul
          else if (mi === lp && mi === loaded[loaded.length - 1] && nextF && !nextF.has(e.fin)) add(6, mi, gap);   // sonrakı ayda yoxdur → xitam
          else add(7, mi, gap);                                                                 // rənglənməyib, işə qəbul/xitam deyil → növbəli iş vaxtı
        }
        // İstifadəçinin seçdiyi səbəblər
        for (const o of open.filter(o => o.e === e)) { const r = +(choice.get(e.fin + '|' + o.mi) || 0); if (r) add(r, o.mi, o.gap); }
        for (const r of Object.keys(D).map(Number).sort((a, b) => a - b)) h3.push([h3.length + 1, e.name, e.fin, ...D[r], REASONS[r - 1]]);
      }
      if (open.length) {
        const tb = $('open'); tb.replaceChildren();
        const t = document.createElement('table'); t.className = 'pv'; t.innerHTML = '<tr><th>İşçi</th><th>FİN</th><th>Ay</th><th>Gün</th><th>Səbəb</th></tr>';
        for (const o of open) {
          const tr = document.createElement('tr'); tr.innerHTML = `<td>${o.e.name}</td><td>${o.e.fin}</td><td>${mn[o.mi]}</td><td class="n">${o.gap}</td>`;
          const td = document.createElement('td'), sl = document.createElement('select'); sl.add(new Option('— Hissə 3-ə yazma —', ''));
          REASONS.forEach((r, k) => sl.add(new Option(r.slice(0, 70), k + 1))); if (!choice.has(o.e.fin + '|' + o.mi) && o.hint) choice.set(o.e.fin + '|' + o.mi, String(o.hint)); sl.value = choice.get(o.e.fin + '|' + o.mi) || '';
          sl.onchange = () => { choice.set(o.e.fin + '|' + o.mi, sl.value); }; td.title = o.why; td.append(sl); tr.append(td); t.append(tr);
        }
        const h = document.createElement('p'); h.className = 'lead'; h.style.margin = '14px 0 4px';
        h.innerHTML = `<b>Səbəbi bilinməyən işləmədiyi günlər (${open.length}):</b> səbəbi seç və "Faylları hazırla"-nı yenidən bas. Boş saxlasan, Hissə 3-ə yazılmır.`;
        tb.append(h, t); tb.style.display = 'block';
        if (!askedOpen) { askedOpen = true; say(`${open.length} hal üçün işləmədiyi günlərin səbəbi bilinmir — aşağıda seç və yenidən bas (və ya boş saxlayıb yenidən bas).`, true); refresh(); return; }
      } else $('open').style.display = 'none';
      const tag = `${y}-${q}rub`;
      const b1 = await fillTemplate('vb-hisse1.xlsx', 10, h1);
      const b3 = h3.length ? await fillTemplate('vb-hisse3.xlsx', 7, h3) : null;
      // Fayllar dərhal yüklənmir — «Yüklə» düymələri
      const box = $('dlbox'); box.replaceChildren();
      const btn = (label, data, name) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = label; b.onclick = () => { save(data, name); b.textContent = '✓ ' + label.replace(/^⬇\s*/, '') + ' — yükləndi'; }; box.append(b); };
      btn('⬇ Hissə 1 faylını yüklə', b1, `DataX-vahid-hisse1-${tag}.xlsx`);
      if (b3) btn('⬇ Hissə 3 faylını yüklə', b3, `DataX-vahid-hisse3-${tag}.xlsx`);
      box.style.display = 'flex';
      // Önizləmə
      const tot = [0, 1, 2].map(mi => list.reduce((t, e) => t + (e.m[mi] && !isNaN(e.m[mi].gross) ? e.m[mi].gross : 0), 0));
      $('pv').innerHTML = `<table class="pv"><tr><th>Ay</th><th>İşçi</th><th>Hesablanmış gəlir, cəmi</th><th>İşləmədiyi gün sətri</th></tr>` +
        [0, 1, 2].map(mi => `<tr><td>${mn[mi]}</td><td class="n">${list.filter(e => e.m[mi]).length}</td><td class="n">${f2(tot[mi])}</td><td class="n">${h3.filter(r => r[3 + mi]).length}</td></tr>`).join('') + '</table>';
      if (noPrev.length) warns.push(`Əvvəlki ayın cədvəli faylda olmadığı üçün bu işçilərin natamam günləri "8-Ayın ortası işə qəbul" kimi yazıldı (yoxla — əvvəldən işləyirdilərsə, faylda əvvəlki ayın vərəqini də saxla): ` + noPrev.join('; '));

      if (warns.length) { $('warn').textContent = 'Yoxla:\n• ' + warns.slice(0, 30).join('\n• ') + (warns.length > 30 ? `\n… və daha ${warns.length - 30}` : ''); $('warn').style.display = 'block'; }
      say(`Hazırdır: ${list.length} işçi` + (dup.length ? ` (${dup.length} halda işçi 2 vəzifədə — məbləğlər birləşdirildi, iş günləri toplanmadı)` : '') + `. Hissə 1` + (h3.length ? ` və Hissə 3 (${h3.length} sətir)` : ' (işləmədiyi gün yoxdur, Hissə 3 faylı yaradılmadı)') + ' Faylları aşağıdakı düymələrlə yüklə.', false, true);
    } catch (e) { say('Xəta: ' + e.message, true); }
    refresh();
  };
})();
