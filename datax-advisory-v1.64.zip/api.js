// =====================================================================================
// e-taxes-in öz məlumat xidməti (API). Sayt səhifələri bu ünvanlardan JSON alır; extension da
// istifadəçinin açıq sessiyası ilə eyni ünvanlara müraciət edir. Səhifəyə klik, çərçivə lazım deyil.
// Xidmət cavab verməsə, köhnə üsul (səhifəni oxumaq) işə düşür.
// =====================================================================================

// Səhifədə (MAIN world) işləyir: sorğuları saytın öz giriş açarı ilə göndərir
async function etApi(reqs, conc) {
  const key = () => localStorage.getItem('aztax-jwt');
  if (!key()) return { error: 'sessiya tapılmadı' };
  const wait = ms => new Promise(z => setTimeout(z, ms));
  const one = async r => {
    for (let a = 0; a < 3; a++) {
      try {
        const res = await fetch(r.u, { method: r.m || 'GET', credentials: 'include',
          headers: { 'x-authorization': 'Bearer ' + key(), accept: 'application/json, text/plain, */*', ...(r.b ? { 'content-type': 'application/json' } : {}) },
          body: r.b ? JSON.stringify(r.b) : undefined });
        if (res.status === 401) return { st: 401, error: 'HTTP 401' };
        if (res.status >= 500 || res.status === 429) { await wait(700 * (a + 1)); if (a < 2) continue; }
        const t = await res.text();
        if (!res.ok) return { st: res.status, error: 'HTTP ' + res.status + (t ? ': ' + t.slice(0, 160) : '') };
        try { return { st: res.status, data: t ? JSON.parse(t) : null }; } catch (e) { return { st: res.status, error: 'cavab JSON deyil' }; }
      } catch (e) { if (a === 2) return { error: String(e && e.message || e) }; await wait(500); }
    }
    return { error: 'cavab yoxdur' };
  };
  const out = new Array(reqs.length); let i = 0;
  await Promise.all(Array.from({ length: Math.max(1, Math.min(conc || 6, reqs.length)) }, async () => { while (i < reqs.length) { const k = i++; out[k] = await one(reqs[k]); } }));
  return { out };
}

const apiErr = m => Object.assign(new Error('API: ' + m), { apiFail: true });
const SESSION_END = 'e-taxes sessiyası bitib. Saytda səhifəni yenilə, yenidən daxil ol və təkrar başlat.';
async function api(tabId, reqs, conc = 6) {
  if (!reqs.length) return [];
  let r;
  try { r = (await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: etApi, args: [reqs, conc] }))[0].result; }
  catch (e) { throw apiErr('skript: ' + e.message); }
  if (!r) throw apiErr('cavab yoxdur');
  if (r.error) throw apiErr(r.error);
  if (r.out.some(x => x && x.st === 401)) throw apiErr('HTTP 401 (sessiya qəbul edilmədi)');
  return r.out;
}
async function api1(tabId, u, m, b) { const [x] = await api(tabId, [{ u, m, b }], 1); if (x.error) throw apiErr(x.error); return x.data; }
// Əvvəl API, alınmasa köhnə üsul
async function apiFirst(name, apiFn, domFn, m) {
  try { return await apiFn(m); }
  catch (e) {
    if (!e.apiFail || cancel) throw e;
    await chrome.storage.local.set({ apiXeta: { funksiya: name, xeta: mask(e.message), t: Date.now() } });
    log('Birbaşa oxuma alınmadı, səhifə üsulu ilə davam edilir...');
    return domFn(m);
  }
}
const run = m => apiFirst('elave1', runVatApi, runVatDom, m);
const runItems = m => apiFirst('mallar', runItemsApi, runItemsDom, m);
const runDocs = m => apiFirst('altSenedler', runDocsApi, runDocsDom, m);
const runDecls = m => apiFirst('beyannameler', runDeclsApi, runDeclsDom, m);

const MONTHS_UP = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
const ord = n => n + (n === 3 || n === 4 ? '-cü' : '-ci');
const p2 = n => String(n).padStart(2, '0');
const isoDmy = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}):(\d{2}))?/); return m ? `${m[3]}.${m[2]}.${m[1]}` + (m[4] ? ` ${m[4]}:${m[5]}:${m[6]}` : '') : String(s || ''); };
const isoN = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? +(m[1] + m[2] + m[3]) : 0; };
const nstr = v => v == null || v === '' || isNaN(+v) ? '' : String(Math.round(+v * 10000) / 10000);          // Excel üçün nöqtəli
const ncom = v => v == null || v === '' || isNaN(+v) ? '' : String(Math.round(+v * 10000) / 10000).replace('.', ',');   // hesabat üçün vergüllü

// ---------------- Bəyannamə siyahısı ----------------
const D_TYPE = { CURRENT: 'Cari', CLARIFYING: 'Dəqiqləşdirilmiş', CAMERAL: 'Kameral', CAMERAL_AUDIT: 'Kameral', KAMERAL: 'Kameral' };
const D_STAT = { CONFIRMED: 'Təsdiqlənib', SENT: 'Göndərilib', SUBMITTED: 'Göndərilib', REJECTED: 'İmtina edilib', DRAFT: 'Qaralama', ON_REVIEW: 'Baxılır' };
function apiDecl(x, listYear) {
  const p = x.reportingPeriod || {}, y = +p.year || +String(x.registrationDate || '').slice(0, 4) || 0, m = +p.month || 1, t = String(p.type || '').toUpperCase();
  let a = 1, b = 12, period = `${y}`;
  if (t === 'MONTH') { a = b = m; period = `${MONTHS_UP[m - 1] || m} ${y}`; }
  else if (t === 'QUARTER') { const q = Math.floor((m - 1) / 3) + 1; a = q * 3 - 2; b = q * 3; period = `${ord(q)} rüb ${y}`; }
  else if (/HALF/.test(t)) { const h = m > 6 ? 2 : 1; a = h * 6 - 5; b = h * 6; period = `${ord(h)} yarımil ${y}`; }
  return { docNo: String(x.registrationNumber || x.id), period, type: D_TYPE[x.declarationType] || x.declarationType || '', date: isoDmy(String(x.registrationDate || x.submissionDate || '').slice(0, 10)),
    status: D_STAT[x.declarationStatus] || x.declarationStatus || '', amount: x.taxAmount == null ? '' : ncom(x.taxAmount), kameral: !!x.cameralAudit || /CAMERAL|KAMERAL/i.test(x.declarationType || ''), ver: x.obligationTypeVersion || '', section: x.taxName || '', taxCode: x.taxCode || '',
    last: x.lastClarifying || '', ts: Date.parse(x.submissionDate || x.registrationDate || '') || 0, year: y, month: a, pr: { y, a, b }, listYear, rawStatus: x.declarationStatus || '' };
}
async function apiDeclList(tabId, years) {
  const out = await api(tabId, years.map(y => ({ u: `/api/po/declaration/public/v1/declaration/list?year=${y}` })), 3);
  const by = new Map(), notes = [];
  out.forEach((x, i) => {
    const arr = x && x.data && x.data.declarations;
    if (!Array.isArray(arr)) { notes.push(`${years[i]}: ${x && x.error ? mask(x.error) : 'gözlənilməz cavab'}`); return; }
    arr.forEach(w => { const d = w && (w.declaration || w); if (d && (d.registrationNumber || d.id)) { const v = apiDecl(d, years[i]); if (!by.has(v.docNo)) by.set(v.docNo, v); } });
  });
  if (notes.length === years.length) throw apiErr('bəyannamə siyahısı: ' + notes.join('; '));
  return { list: [...by.values()].filter(d => !/DRAFT|DELETE|CANCEL|REJECT/i.test(d.rawStatus)), notes };
}
// Eyni dövr üçün ən son bəyannamə: saytın "son dəqiqləşmə" işarəsi, sonra göndərilmə vaxtı
const declBetter = (x, b) => { if (!b) return true; const r = d => d.last === 'LAST' ? 1 : 0; return r(x) !== r(b) ? r(x) > r(b) : x.ts !== b.ts ? x.ts > b.ts : x.docNo > b.docNo; };
const yearsFor = (fy, ty) => { const nowY = new Date().getFullYear(), ys = []; for (let y = fy; y <= Math.min(ty + 1, nowY); y++) ys.push(y); return ys.length ? ys : [fy]; };

// ---------------- FUNKSİYA 1: ƏDV Əlavə 1 qaimələri ----------------
const A1_HDR = ['Sıra №', 'Satıcının VÖEN-i', 'Qaimənin seriyası', 'Qaimənin nömrəsi', 'Qaimənin tarixi', 'Ümumi məbləğ (ƏDV-siz)', 'ƏDV məbləği', 'Ödənilmiş məbləğ', 'Ödənilmiş ƏDV məbləği'];
async function runVatApi({ tabId, from, to, skipKameral }) {
  const t0 = Date.now();
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), years = yearsFor(fy, ty);
  log('Bəyannamələr siyahısı alınır...');
  const { list, notes: yearNotes } = await apiDeclList(tabId, years);
  const vat = list.filter(d => d.taxCode === '_0300' || /^əlavə dəyər vergisi$/i.test(d.section.trim()));
  const inRange = vat.filter(x => { const v = x.year * 12 + x.month; return v >= fy * 12 + fm && v <= ty * 12 + tm; });
  const best = {};
  inRange.filter(x => !(skipKameral && x.kameral)).forEach(x => { const k = x.year * 12 + x.month; if (declBetter(x, best[k])) best[k] = x; });
  const sel = Object.values(best).sort((a, b) => a.year * 12 + a.month - (b.year * 12 + b.month));
  const baseReport = { versiya: VERSION, funksiya: 'elave1', rejim: 'api', iller: years, ilQeydleri: yearNotes, siyahi: { hamisi: list.length, edv: vat.length, araliqda: inRange.length, kameral: inRange.filter(x => x.kameral).length } };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş aylarda ƏDV bəyannaməsi tapılmadı.');

  const summaries = [], rows = [], notes = []; let done = 0, ok = 0, skip = 0, err = 0, total = 0;
  const short = t => t === 'Cari' ? 'Cari' : /^Dəqiq/.test(t) ? 'Dəqiq.' : t;
  const report = () => log(`${done} / ${sel.length} bəyannamə oxundu.`, false, { i: done, n: sel.length, summary: summaries.filter(Boolean) });
  report();
  const url = (d, off) => `/api/po/declaration/public/v1/calc/VAT_APPENDIX_1_REPORT_PERIOD_INVOICE?reg_number=${d.docNo}&offset=${off}&maxCount=1000`;
  const parts = new Array(sel.length).fill(null).map(() => []), errs = new Array(sel.length).fill(null);
  for (let s = 0; s < sel.length && !cancel; s += 12) {
    const chunk = sel.slice(s, s + 12), out = await api(tabId, chunk.map(d => ({ u: url(d, 0) })), 6);
    for (let j = 0; j < chunk.length; j++) {
      const i = s + j, x = out[j];
      if (x.error) { errs[i] = x.error; continue; }
      let arr; try { arr = JSON.parse((x.data || {}).calcPartJson || '[]'); } catch (e) { errs[i] = 'format'; continue; }
      if (!Array.isArray(arr)) { errs[i] = 'format'; continue; }
      parts[i] = arr;
      for (let off = 1000; arr.length === 1000 && off < 50000; off += 1000) {                  // çox böyük siyahı: davamı
        const y = await api1(tabId, url(chunk[j], off)); arr = JSON.parse((y || {}).calcPartJson || '[]'); parts[i].push(...arr);
      }
    }
    if (out.every(x => x.error) && s === 0) throw apiErr('Əlavə 1: ' + out[0].error);
    for (let j = 0; j < chunk.length; j++) {
      const i = s + j, d = sel[i], arr = parts[i];
      if (errs[i]) { err++; summaries[i] = { p: d.period, k: short(d.type), note: 'oxunmadı' }; notes.push(['Xəta', d.period + ' / ' + d.type, d.docNo, mask(errs[i])]); }
      else if (!arr.length) { skip++; summaries[i] = { p: d.period, k: short(d.type), note: 'Əlavə 1 yoxdur' }; notes.push(['Məlumat', d.period + ' / ' + d.type, d.docNo, 'Əlavə 1 boşdur və ya açıq deyil, keçildi']); }
      else {
        ok++; total += arr.length;
        arr.sort((a, b) => (a.rowOrder || 0) - (b.rowOrder || 0)).forEach((r, k) => rows.push([d.period, d.type, d.docNo, k + 1, r.tin || '', r.documentSerial || '', r.documentNumber || '', isoDmy(r.documentDate), nstr(r.amount), nstr(r.vat), nstr(r.paidAmount), nstr(r.paidVat)]));
        summaries[i] = { p: d.period, k: short(d.type), c: arr.length, t: arr.reduce((a, r) => a + (+r.amount || 0), 0), v: arr.reduce((a, r) => a + (+r.vat || 0), 0) };
      }
      done++;
    }
    report();
  }
  yearNotes.forEach(n => notes.push(['Xəbərdarlıq', n.split(':')[0] + '-ci il', '', 'Bu ilin siyahısı alınmadı: ' + n.split(': ')[1]]));
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan aylar fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...baseReport, saniye: sec, secilen: sel.length, oxundu: ok, elave1Yox: skip, xeta: err, xetalar: [...new Set(errs.filter(Boolean).map(mask))].slice(0, 5) } });
  await saveXlsx(`DataX-elave1-${from}_${to}.xlsx`, [
    { name: 'Əlavə 1 qaimələri', header: ['Dövr', 'Növ', 'Sənəd nömrəsi', ...A1_HDR], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Bəyannamə', 'Sənəd nömrəsi', 'Qeyd'], rows: notes, numeric: false }]);
  const ps = [`${ok} bəyannamədən ${total} qaimə`]; if (skip) ps.push(`${skip} bəyannamədə Əlavə 1 yoxdur`); if (err) ps.push(`${err} bəyannamə oxunmadı`);
  log((err || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san): ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true, { i: sel.length, n: sel.length, summary: summaries.filter(Boolean), hasErrors: !!err });
}

// ---------------- Qaimələr ----------------
const INV_STATUS = { approved: 'Təsdiqləndi', cancelationRefused: 'Təsdiqləndi', correctionRefused: 'Təsdiqləndi', onApproval: 'Təsdiq gözləyir', updateApproval: 'Düzəliş edildi',
  updateRequested: 'Düzəlişə qaytarıldı', cancelRequested: 'Ləğvə göndərildi', approvedBySystem: 'Sistem tərəfindən təsdiqləndi', onApprovalEdited: 'Düzəlişə göndərildi',
  canceled: 'Ləğv edildi', cancelled: 'Ləğv edildi', deleted: 'Silindi', deletedBySystem: 'Sistem tərəfindən silindi', deactivated: 'Passiv' };
const INV_KIND = { defaultInvoice: 'Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura',
  agent: 'Malların, işlərin və xidmətlərin vəkalətverən (komitent) tərəfindən agentə (komisyonçuya) verilməsi barədə elektron qaimə-faktura',
  resale: 'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin alıcısına (subagentə) təqdim edilməsi barədə elektron qaimə-faktura',
  recycling: 'Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura',
  taxCodex163: 'Qaytarma istisna olmaqla VM-in 163-cü maddəsinə əsasən dəqiqləşdirilməsi barədə elektron qaimə-faktura',
  taxCodex177_5: 'VM-in 177.5-ci maddəsinə əsasən təqdim edilməsi barədə elektron qaimə-faktura',
  returnInvoice: 'Malların qaytarılması barədə elektron qaimə-faktura',
  returnByAgent: 'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin vəkalətverənə (komitentə) qaytarılması barədə elektron qaimə-faktura',
  returnRecycled: 'Emal prosesi keçmiş, yaxud saxlamaya verilmiş malların qaytarılması barədə elektron qaimə-faktura',
  exportNoteInvoice: 'Malların ixrac qeydi ilə satışı barədə elektron qaimə-faktura',
  exciseGoodsTransfer: 'Aksizli malların (neft məhsulları istisna olmaqla) təsərrüfatdaxili yerdəyişməsi barədə elektron qaimə-faktura',
  advanceInvoice: 'Alınmış avans ödənişləri barədə elektron qaimə-faktura',
  mtkInvoice: 'Yaşayış və qeyri-yaşayış sahələrinə görə ödənilmiş əlavə dəyər vergisinin qaytarılması' };
const ST_MAIN = ['approved', 'onApproval', 'updateApproval', 'updateRequested', 'cancelRequested', 'approvedBySystem', 'onApprovalEdited', 'deactivated', 'cancelationRefused', 'correctionRefused'];
const ST_GONE = ['canceled', 'deleted', 'deletedBySystem'];
const KINDS = ['defaultInvoice', 'agent', 'resale', 'recycling', 'taxCodex163', 'taxCodex177_5', 'returnInvoice', 'returnByAgent', 'returnRecycled', 'exportNoteInvoice', 'exciseGoodsTransfer', 'advanceInvoice'];
const ITEM_HDR = ['Sıra №', 'Malın kodu', 'Malın adı', 'Təsnifat üzrə adı', 'Barkod', 'Ölçü vahidi', 'Miqdarı', 'Vahidinin qiyməti', 'Cəmi məbləğ', 'Aksiz dərəcəsi', 'Aksiz məbləği',
  'ƏDV-yə 18% cəlb edilən', 'ƏDV-yə cəlb edilməyən', 'ƏDV-yə 0% cəlb edilən', 'ƏDV-dən azad', 'Yol vergisi', 'ƏDV məbləği', 'Yekun məbləğ'];
const dmyDash = n => { const s = String(n); return `${s.slice(6, 8)}-${s.slice(4, 6)}-${s.slice(0, 4)} 00:00`; };
const nextDay = n => { const s = String(n), d = new Date(Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8) + 1)); return d.getUTCFullYear() * 10000 + (d.getUTCMonth() + 1) * 100 + d.getUTCDate(); };
// İl-il bölünmüş tarix aralıqları (sayt uzun aralığı qəbul etməyə bilər)
const yearChunks = (fromN, toN) => { const out = []; for (let y = Math.floor(fromN / 10000); y <= Math.floor(toN / 10000); y++) out.push([Math.max(fromN, y * 10000 + 101), Math.min(toN, y * 10000 + 1231)]); return out; };

async function apiInvList(tabId, dir, fromN, toN, extra, onPage) {
  const u = `/api/po/invoice/public/v2/invoice/find.${dir === 'out' ? 'outbox' : 'inbox'}`;
  const body = (a, b, statuses) => ({ sortBy: 'creationDate', sortAsc: true, statuses, types: ['current', 'corrected'], kinds: KINDS, serialNumber: null, senderTin: null, senderName: null,
    productName: null, productCode: null, receiverTin: null, receiverName: null, creationDateFrom: dmyDash(a), creationDateTo: dmyDash(nextDay(b)), amountFrom: null, amountTo: null, actionOwner: null, ...(extra || {}) });
  const all = [], seen = new Set(); let pages = 0, goneOk = true;
  for (const [a, b] of yearChunks(fromN, toN)) {
    let statuses = [...ST_MAIN, ...ST_GONE];
    for (let off = 0; !cancel; off += 50) {
      let [x] = await api(tabId, [{ u, m: 'POST', b: { ...body(a, b, statuses), offset: off, maxCount: 50 } }], 1);
      if (x.error && off === 0 && statuses.length > ST_MAIN.length && x.st === 400) { statuses = ST_MAIN; goneOk = false; [x] = await api(tabId, [{ u, m: 'POST', b: { ...body(a, b, statuses), offset: 0, maxCount: 50 } }], 1); }
      if (x.error) throw apiErr('qaimə siyahısı: ' + x.error);
      const arr = x.data && x.data.invoices; if (!Array.isArray(arr)) throw apiErr('qaimə siyahısı: gözlənilməz cavab');
      arr.forEach(v => { if (v && v.id && !seen.has(v.id)) { seen.add(v.id); all.push(v); } });
      pages++; if (onPage) onPage(pages, all.length);
      if (arr.length < 50 || pages > 600) break;
    }
  }
  return { all, pages, goneOk };
}
function invRow(v, dir) {
  const cp = (dir === 'out' ? v.receiver : v.sender) || {};
  return { id: v.id, src: v.sourceSystem || 'avis', serial: v.serialNumber || '', date: isoDmy(v.createdAt), dnum: isoN(v.createdAt), voen: cp.tin || cp.fin || cp.pin || '', name: cp.name || '',
    type: INV_KIND[v.kind] || v.kind || '', status: INV_STATUS[v.status] || v.status || '', basis: v.invoiceComment || '', total: v.amount, vat: v.vat, corrected: v.type === 'corrected' };
}
const itemRows = items => (items || []).map((it, k) => {
  const g = it.productGroup || {}, vat = (+it.vat18 || 0) * 0.18, base = (+it.cost || 0) + (+it.excise || 0) + (+it.roadTax || 0);
  return [String(k + 1), g.code || '', it.productName || '', (g.name && g.name.az) || '', it.barcode || '', (it.unitFromDict && it.unitFromDict.name && it.unitFromDict.name.az) || it.unit || '',
    nstr(it.quantity), nstr(it.pricePerUnit), nstr(it.cost), nstr(it.exciseRate), nstr(it.excise), nstr(it.vat18), nstr(it.vatFree), nstr(it.vat0), nstr(it.exempt), nstr(it.roadTax), nstr(vat), nstr(base + vat)];
});
// Qaimələrin içi (mallar). progress(n) hər hissədən sonra
async function apiInvItems(tabId, sel, progress) {
  const results = new Array(sel.length).fill(null);
  for (let s = 0; s < sel.length && !cancel; s += 40) {
    const chunk = sel.slice(s, s + 40), out = await api(tabId, chunk.map(d => ({ u: `/api/po/invoice/public/v2/invoice/${encodeURIComponent(d.id)}?sourceSystem=${encodeURIComponent(d.src)}` })), 8);
    if (s === 0 && out.every(x => x.error)) throw apiErr('qaimənin içi: ' + out[0].error);
    out.forEach((x, j) => {
      const v = x.data;
      if (x.error || !v || !Array.isArray(v.items)) { results[s + j] = { error: x.error || 'qaimənin içi boş gəldi' }; return; }
      results[s + j] = { header: ITEM_HDR, rows: itemRows(v.items),
        info: { esas: v.invoiceComment || '', qeyd: v.invoiceComment2 || '', created: isoDmy(v.createdAt),
          parties: [v.sender, v.receiver].filter(Boolean).map(p => ({ voen: p.tin || p.pin || '', name: p.name || '' })) } };
    });
    progress(Math.min(sel.length, s + chunk.length));
  }
  return results;
}

// ---------------- FUNKSİYA 2: Qaimə üzrə mallar və xidmətlər ----------------
async function runItemsApi({ tabId, from, to, dir, statuses, types }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  log(`"${tab}" siyahısı alınır...`);
  const L = await apiInvList(tabId, dir, fromN, toN, null, (p, n) => log(`"${tab}" siyahısı alınır: ${n} qaimə...`, false, { stats: [{ l: 'Səhifə', v: p }, { l: 'Qaimə', v: n }] }));
  const inDates = L.all.map(v => invRow(v, dir)).filter(d => d.dnum >= fromN && d.dnum <= toN);
  const nz = s => String(s || '').toLocaleLowerCase('az').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const pick = (f, v, unknown) => { if (!f) return true; const k = nz(v); if (f.on.some(x => nz(x) === k)) return true; if (f.known.some(x => nz(x) === k)) return false; unknown.add(v || '(boş)'); return f.other !== false; };
  const unkS = new Set(), unkT = new Set();
  const sel = inDates.filter(x => pick(statuses, x.status, unkS) & pick(types, x.type, unkT)).sort((a, b) => a.dnum - b.dnum || a.date.localeCompare(b.date));
  const base = { versiya: VERSION, funksiya: 'mallar', rejim: 'api', bolme: tab, sehife: L.pages, siyahi: L.all.length, legvSilinmisAlindi: L.goneOk,
    secim: { tarixde: inDates.length, secilen: sel.length, taninmayanStatus: [...unkS].slice(0, 8), taninmayanNov: [...unkT].slice(0, 8) } };
  await chrome.storage.local.set({ report: base });
  if (!inDates.length) throw new Error(`"${tab}" bölməsində bu tarix aralığında qaimə tapılmadı.`);
  if (!sel.length) throw new Error(`Bu tarixlərdə ${inDates.length} qaimə var, amma heç biri seçdiyin status və növə uyğun deyil.`);
  const stats = d => [{ l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }];
  const results = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimə oxundu.`, false, { i: d, n: sel.length, stats: stats(d) }));

  const rows = [], notes = []; let items = 0, ok = 0, empty = 0, err = 0;
  sel.forEach((d, i) => {
    const res = results[i]; if (!res) return;
    if (res.error) { err++; notes.push(['Xəta', d.serial, d.date, mask(res.error)]); return; }
    const info = res.info, meta = [d.date, d.voen, d.name, d.serial, d.type, d.status, info.esas || d.basis || '', info.qeyd || ''];
    if (!res.rows.length) { empty++; notes.push(['Məlumat', d.serial, d.date, 'Mal sətri yoxdur']); return; }
    ok++; items += res.rows.length;
    res.rows.forEach(row => { const code = String(row[1] || '').trim(); rows.push([...meta, code ? (code.startsWith('99') ? 'Xidmət' : 'Mal') : '', ...row]); });
  });
  if (unkS.size) notes.push(['Məlumat', '', '', 'Tanınmayan status: ' + [...unkS].join('; ')]);
  if (unkT.size) notes.push(['Məlumat', '', '', 'Tanınmayan növ: ' + [...unkT].join('; ')]);
  if (!L.goneOk && statuses && statuses.on.some(x => /ləğv edildi|silindi/i.test(x))) notes.push(['Xəbərdarlıq', '', '', 'Ləğv edilmiş və silinmiş qaimələr sayt tərəfindən verilmədi.']);
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan qaimələr fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...base, saniye: sec, oxundu: ok, bos: empty, xeta: err, xetalar: [...new Set(results.filter(r => r && r.error).map(r => mask(r.error)))].slice(0, 4) } });
  await saveXlsx(`DataX-mallar-${dir === 'out' ? 'gonderilen' : 'gelen'}-${from}_${to}.xlsx`, [
    { name: 'Mallar və xidmətlər', header: ['İmzalanma tarixi', 'VÖEN', 'Adı', 'Seriya və nömrə', 'Qaimənin növü', 'Status', 'Əsas', 'Əlavə qeyd', 'Mal/xidmət', ...ITEM_HDR], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Seriya və nömrə', 'Tarix', 'Qeyd'], rows: notes, numeric: false }]);
  const ps = [`${tab}: ${sel.length} qaimə` + (sel.length < inDates.length ? ` (tarixdə ${inDates.length}, seçimə uyğun ${sel.length})` : ''), `${items} mal/xidmət sətri`];
  if (empty) ps.push(`${empty} qaimədə sətir yoxdur`); if (err) ps.push(`${err} qaimə oxunmadı`);
  log((err || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true,
    { i: sel.length, n: sel.length, hasErrors: !!err, stats: [{ l: 'Qaimə', v: sel.length }, { l: 'Mal sətri', v: items }, { l: 'Saniyə', v: sec }] });
}

// ---------------- FUNKSİYA: Riskli VÖEN yoxlaması ----------------
// e-taxes-in açıq xidməti: /api/po/authless/public/v1/authless/payers/risk/{VÖEN} → { risky, riskyPayerInfoList }
const RISK_U = v => `/api/po/authless/public/v1/authless/payers/risk/${encodeURIComponent(v)}`;
const riskText = list => (list || []).map(o => o && typeof o === 'object'
  ? Object.entries(o).map(([k, v]) => [k, v && typeof v === 'object' ? (v.az || v.name && (v.name.az || v.name) || '') : v]).filter(([, v]) => v != null && v !== '' && typeof v !== 'object').map(([k, v]) => `${fldName(k)}: ${/^\d{4}-\d{2}-\d{2}/.test(String(v)) ? isoDmy(v) : v}`).join(', ')
  : String(o)).filter(Boolean).join(' | ');
async function runRiskApi({ tabId, from, to, dir }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər', who = dir === 'out' ? 'Alıcı' : 'Təchizatçı';
  log(`"${tab}" siyahısı alınır...`);
  const L = await apiInvList(tabId, dir, fromN, toN, null, (p, n) => log(`"${tab}" siyahısı alınır: ${n} qaimə...`, false, { stats: [{ l: 'Səhifə', v: p }, { l: 'Qaimə', v: n }] }));
  const gone = /ləğv edildi|silindi/i;
  const inv = L.all.map(v => invRow(v, dir)).filter(d => d.dnum >= fromN && d.dnum <= toN && !gone.test(d.status));
  if (!inv.length) throw new Error(`"${tab}" bölməsində bu tarix aralığında qaimə tapılmadı.`);
  const by = new Map();
  for (const d of inv) {
    const k = String(d.voen || '').trim(); if (!k) continue;
    const g = by.get(k) || { voen: k, name: d.name, n: 0, total: 0, vat: 0, first: d.dnum, firstD: d.date, last: d.dnum, lastD: d.date, inv: [] };
    g.n++; g.total += +d.total || 0; g.vat += +d.vat || 0; g.inv.push(d);
    if (d.dnum < g.first) { g.first = d.dnum; g.firstD = d.date; } if (d.dnum > g.last) { g.last = d.dnum; g.lastD = d.date; }
    by.set(k, g);
  }
  const list = [...by.values()], chk = list.filter(g => /^\d{10}$/.test(g.voen));
  const stats = (d, r) => [{ l: who, v: list.length }, { l: 'Yoxlandı', v: d }, { l: 'Riskli', v: r }];
  let risky = 0, errs = 0;
  for (let s = 0; s < chk.length && !cancel; s += 20) {
    const part = chk.slice(s, s + 20), out = await api(tabId, part.map(g => ({ u: RISK_U(g.voen) })), 4);
    if (s === 0 && out.every(x => x.error)) throw new Error('Risk xidməti cavab vermədi: ' + mask(out[0].error));
    out.forEach((x, j) => {
      const g = part[j];
      if (x.error || !x.data || typeof x.data.risky !== 'boolean') { g.res = 'Yoxlanmadı'; g.info = x.error ? mask(x.error) : 'gözlənilməz cavab'; errs++; return; }
      g.res = x.data.risky ? 'RİSKLİ' : 'Riskli deyil'; g.info = riskText(x.data.riskyPayerInfoList); if (x.data.risky) risky++;
    });
    const d = Math.min(chk.length, s + part.length);
    log(`${d} / ${chk.length} ${who.toLowerCase()} yoxlandı.`, false, { i: d, n: chk.length, stats: stats(d, risky) });
  }
  list.forEach(g => { if (!g.res) { g.res = /^\d{10}$/.test(g.voen) ? 'Yoxlanmadı' : 'Fiziki şəxs (yoxlanmır)'; if (!g.info && cancel) g.info = 'Dayandırıldı'; } });
  const rank = r => r === 'RİSKLİ' ? 0 : r === 'Yoxlanmadı' ? 1 : 2;
  list.sort((a, b) => rank(a.res) - rank(b.res) || b.vat - a.vat);
  const n2 = v => nstr(Math.round(v * 100) / 100);
  const rows = list.map(g => [g.voen, g.name, g.res, g.info || '', String(g.n), n2(g.total), n2(g.vat), g.firstD.slice(0, 10), g.lastD.slice(0, 10)]);
  const bad = list.filter(g => g.res === 'RİSKLİ');
  const rInv = bad.flatMap(g => g.inv.sort((a, b) => a.dnum - b.dnum).map(d => [d.date, d.serial, d.voen, d.name, d.type, d.status, d.basis, nstr(d.total), nstr(d.vat)]));
  const sumBad = bad.reduce((a, g) => a + g.vat, 0);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { versiya: VERSION, funksiya: 'risk', rejim: 'api', bolme: tab, qaime: inv.length, yoxlanan: chk.length, riskli: risky, xeta: errs, saniye: sec } });
  const today = new Date().toLocaleDateString('ru-RU');
  await saveXlsx(`DataX-riskli-voen-${dir === 'out' ? 'alicilar' : 'techizatcilar'}-${from}_${to}.xlsx`, [
    { name: who + 'lar', header: ['VÖEN', 'Adı', 'Nəticə', 'Risk məlumatı', 'Qaimə sayı', 'Məbləğ', 'ƏDV', 'İlk qaimə', 'Son qaimə'], rows, keep: true, numCols: [4, 5, 6] },
    { name: 'Riskli qaimələr', header: ['İmzalanma tarixi', 'Seriya və nömrə', 'VÖEN', 'Adı', 'Qaimənin növü', 'Status', 'Əsas', 'Yekun məbləğ', 'ƏDV məbləği'], rows: rInv, keep: true },
    { name: 'Qeydlər', header: ['Qeyd'], numeric: false, rows: [
      [`Yoxlama tarixi: ${today}. Mənbə: e-taxes "Riskli vergi ödəyiciləri barədə məlumatın verilməsi" xidməti.`],
      [`Nəticə yoxlama anına aiddir: ödəyici sonradan riskli siyahıya düşə və ya çıxa bilər.`],
      [`${tab}: ${from} – ${to}, ləğv edilmiş və silinmiş qaimələr daxil edilməyib.`],
      ...(errs ? [[`${errs} VÖEN yoxlanmadı (xidmət cavab vermədi). Bir azdan təkrar yoxla.`]] : []),
      ...(cancel ? [['Dayandırıldı: bütün VÖEN-lər yoxlanmayıb.']] : [])] }]);
  const ps = [`${list.length} ${who.toLowerCase()}, ${inv.length} qaimə`, risky ? `${risky} RİSKLİ (ƏDV ${ncom(Math.round(sumBad * 100) / 100)})` : 'riskli tapılmadı'];
  if (errs) ps.push(`${errs} yoxlanmadı`);
  log((errs || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true,
    { i: chk.length, n: chk.length, hasErrors: !!errs, stats: stats(chk.length, risky) });
}
const runRisk = m => runRiskApi(m).catch(e => { throw e.apiFail ? new Error('e-taxes cavab vermədi (' + e.message.replace(/^API: /, '') + '). Səhifəni yenilə və təkrar başlat.') : e; });

// ---------------- FUNKSİYA: Mal hərəkəti uyğunluğu ----------------
// Gələn (+) və göndərilən (−) qaimələrin mal sətirləri ad + ölçü vahidi üzrə birləşdirilir; tarix sırası ilə qalıq hesablanır.
const STOCK_SKIP = ['advanceInvoice', 'taxCodex163', 'taxCodex177_5', 'exciseGoodsTransfer', 'mtkInvoice'];
const AZF = { 'ə': 'e', 'ı': 'i', 'i̇': 'i', 'ö': 'o', 'ü': 'u', 'ç': 'c', 'ş': 's', 'ğ': 'g' };
const normName = s => String(s || '').toLocaleLowerCase('az').replace(/i̇/g, 'i').replace(/[əıöüçşğ]/g, c => AZF[c]).replace(/[^\p{L}\p{N}]+/gu, '');
// Ölçü vahidi → əsas vahid və əmsal (25 000 kq alınıb 25 ton satılıbsa, ikisi də 25 000 kq sayılır)
const UNIT_BASE = { kq: ['kq', 1], kg: ['kq', 1], кг: ['kq', 1], kilogram: ['kq', 1], kiloqram: ['kq', 1], ton: ['kq', 1000], t: ['kq', 1000], tn: ['kq', 1000], тн: ['kq', 1000], т: ['kq', 1000], tonna: ['kq', 1000],
  sentner: ['kq', 100], qram: ['kq', 0.001], qr: ['kq', 0.001], q: ['kq', 0.001], gr: ['kq', 0.001], g: ['kq', 0.001], gram: ['kq', 0.001], г: ['kq', 0.001], mq: ['kq', 1e-6], mg: ['kq', 1e-6],
  l: ['litr', 1], lt: ['litr', 1], litr: ['litr', 1], liter: ['litr', 1], л: ['litr', 1], ml: ['litr', 0.001], мл: ['litr', 0.001], m3: ['m3', 1], м3: ['m3', 1], kubmetr: ['m3', 1],
  m: ['metr', 1], metr: ['metr', 1], meter: ['metr', 1], м: ['metr', 1], pm: ['metr', 1], sm: ['metr', 0.01], cm: ['metr', 0.01], см: ['metr', 0.01], mm: ['metr', 0.001], мм: ['metr', 0.001], km: ['metr', 1000],
  m2: ['m2', 1], м2: ['m2', 1], kvm: ['m2', 1], kvadratmetr: ['m2', 1], sm2: ['m2', 0.0001],
  ədəd: ['ədəd', 1], eded: ['ədəd', 1], ed: ['ədəd', 1], əd: ['ədəd', 1], ad: ['ədəd', 1], шт: ['ədəd', 1], pcs: ['ədəd', 1], pc: ['ədəd', 1] };
const unitKey = s => String(s || '').toLocaleLowerCase('az').replace(/i̇/g, 'i').replace(/[^\p{L}\p{N}]+/gu, '');
const unitBase = s => { const k = unitKey(s), b = UNIT_BASE[k]; return b ? { u: b[0], f: b[1] } : { u: String(s || '').trim().toLocaleLowerCase('az') || '-', f: 1 }; };
const normUnit = s => unitBase(s).u;
const normTok = s => String(s || '').toLocaleLowerCase('az').replace(/i̇/g, 'i').replace(/[əıöüçşğ]/g, c => AZF[c]).replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const digSig = s => (String(s || '').match(/\d+/g) || []).join(',');
function lev(a, b) {
  if (a === b) return 0; if (!a.length) return b.length; if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, j) => j), cur = new Array(b.length + 1);
  for (let i = 1; i <= a.length; i++) { cur[0] = i; for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); [prev, cur] = [cur, prev]; }
  return prev[b.length];
}
// İki adın oxşarlığı (0..1). Rəqəmlər (ölçü, marka) fərqlidirsə oxşar sayılmır: "Kabel 3x2,5" ≠ "Kabel 3x1,5"
function nameSim(a, b) {
  if (digSig(a) !== digSig(b)) return 0;
  const ta = normTok(a), tb = normTok(b), ca = ta.replace(/ /g, ''), cb = tb.replace(/ /g, '');
  if (!ca || !cb) return 0;
  const r = 1 - lev(ca, cb) / Math.max(ca.length, cb.length);
  const wa = new Set(ta.split(' ').filter(w => w.length > 1)), wb = new Set(tb.split(' ').filter(w => w.length > 1));
  const inter = [...wa].filter(w => wb.has(w)).length, jac = inter / (new Set([...wa, ...wb]).size || 1);
  const sub = Math.min(ca.length, cb.length) >= 4 && (ca.includes(cb) || cb.includes(ca)) ? 0.85 : 0;
  return Math.max(r, jac, sub);
}
// e-gömrük açıq sekmədədirsə, idxal/ixrac hesabatını onun məzmun skripti (gomruk-api.js) gətirir
async function customsFetch(from, to) {
  const { dxCustomsTabs = [] } = await chrome.storage.session.get('dxCustomsTabs');
  let last = null; const alive = [];
  for (const id of [...dxCustomsTabs].reverse()) {
    try { const r = await chrome.tabs.sendMessage(id, { type: 'dxCustoms', from, to }); alive.push(id); if (r && !r.error) return r; last = r; }
    catch (e) { /* sekmə bağlanıb və ya başqa sayta keçib */ }
  }
  await chrome.storage.session.set({ dxCustomsTabs: alive.reverse() });
  if (last) return last;
  // Sekmə extension yenilənməzdən əvvəl açılıbsa, skript orada yoxdur: indi yerləşdir
  const tabs = await chrome.tabs.query({ url: 'https://e.customs.gov.az/*' }).catch(() => []);
  if (!tabs.length) return { none: true };
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['gomruk-api.js'] });
      const r = await chrome.tabs.sendMessage(t.id, { type: 'dxCustoms', from, to });
      if (r && !r.error) return r; last = r;
    } catch (e) { last = { error: 'e-gömrük səhifəsi cavab vermədi — e-gömrük səhifəsini yenilə (F5) və təkrar başlat' }; }
  }
  return last || { none: true };
}
const newGrp = (unit) => ({ names: new Map(), unit, codes: new Set(), cBuy: new Set(), cSell: new Set(), cImp: new Set(), buyQ: 0, buyS: 0, impQ: 0, impS: 0, impNoVal: 0, sellQ: 0, sellS: 0, expQ: 0,
  retSup: 0, retSupS: 0, retCus: 0, retCusS: 0, ev: [], firstIn: 0, firstOut: 0, impHow: '' });
function grpAdd(g, e) {
  if (e.name && (!e.gb || !g.names.size)) g.names.set(e.name, (g.names.get(e.name) || 0) + (e.gb ? 0 : 1));   // gömrük təsviri yalnız başqa ad yoxdursa
  if (e.code) g.codes.add(e.code);
  const q = e.q, s = e.sum || 0, noVal = e.k === 'imp' && e.sum == null;
  if (e.k === 'buy') { g.buyQ += q; g.buyS += s; if (e.code) g.cBuy.add(e.code); }
  else if (e.k === 'imp') { g.impQ += q; g.impS += s; if (noVal) g.impNoVal += q; if (e.code) g.cImp.add(e.code); }
  else if (e.k === 'sell') { g.sellQ += q; g.sellS += s; if (e.code) g.cSell.add(e.code); }
  else if (e.k === 'exp') g.expQ += q;
  else if (e.k === 'retSup') { g.retSup += q; g.retSupS += s; }
  else if (e.k === 'retCus') { g.retCus += q; g.retCusS += s; }
  const inc = e.k === 'buy' || e.k === 'imp' || e.k === 'retCus';
  if ((e.k === 'buy' || e.k === 'imp') && (!g.firstIn || e.dnum < g.firstIn)) g.firstIn = e.dnum;
  if ((e.k === 'sell' || e.k === 'exp') && (!g.firstOut || e.dnum < g.firstOut)) g.firstOut = e.dnum;
  g.ev.push({ n: e.dnum, q: inc ? q : -q, date: e.date, ser: e.ser });
}
const r2 = v => Math.round(v * 100) / 100, r4 = v => Math.round(v * 10000) / 10000;
// Qrupun göstəriciləri: xalis giriş/çıxış, tarix sırası ilə qalıq, ilk mənfi an, ay sonu qalıqları
function grpStat(g, months) {
  g.ev.sort((a, b) => a.n - b.n || b.q - a.q);                         // eyni gün: əvvəl giriş
  let bal = 0, minBal = 0, negAt = null, mi = 0; const mEnd = [];
  for (const e of g.ev) {
    while (mi < months.length && e.n > months[mi].end) { mEnd.push(r4(bal)); mi++; }
    bal = r4(bal + e.q); if (bal < -1e-6 && !negAt) negAt = e; if (bal < minBal) minBal = bal;
  }
  while (mi < months.length) { mEnd.push(r4(bal)); mi++; }
  const inQ = g.buyQ + g.impQ - g.retSup, inS = g.buyS + g.impS - g.retSupS, saleQ = g.sellQ - g.retCus, saleS = g.sellS - g.retCusS;
  const valQ = inQ - g.impNoVal, avgIn = valQ > 1e-6 && inS > 0 ? inS / valQ : 0, avgOut = saleQ > 1e-6 && saleS > 0 ? saleS / saleQ : 0;
  const main = [...g.names.entries()].sort((a, b) => b[1] - a[1])[0];
  return { g, bal, minBal, negAt, mEnd, inQ, outQ: saleQ + g.expQ, saleQ, avgIn, avgOut, main: main ? main[0] : '' };
}
async function runStockApi({ tabId, from, to, imp, auto }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to), gone = /ləğv edildi|silindi/i;
  const dmy = n => { const s = String(n); return n ? `${s.slice(6, 8)}.${s.slice(4, 6)}.${s.slice(0, 4)}` : ''; };
  const sel = []; let own = '';
  for (const dir of ['in', 'out']) {
    const tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
    log(`"${tab}" siyahısı alınır...`);
    const L = await apiInvList(tabId, dir, fromN, toN, null, (p, n) => log(`"${tab}" siyahısı alınır: ${n} qaimə...`, false, { stats: [{ l: 'Səhifə', v: p }, { l: 'Qaimə', v: n }] }));
    const bySer = new Map();
    L.all.forEach(v => {
      const me = dir === 'out' ? v.sender : v.receiver; if (!own && me && me.tin) own = String(me.tin);
      if (STOCK_SKIP.includes(v.kind)) return;
      const d = invRow(v, dir); if (d.dnum < fromN || d.dnum > toN || gone.test(d.status)) return;
      d.dir = dir; d.ret = /^return/.test(v.kind || '') || /^MQ/i.test(d.serial); const k = d.serial || d.id, o = bySer.get(k);
      if (!o || (d.corrected && !o.corrected) || (d.corrected === o.corrected && d.dnum >= o.dnum)) bySer.set(k, d);   // düzəlişli variant əvvəlkini əvəz edir
    });
    sel.push(...bySer.values());
    if (cancel) break;
  }
  const nIn = sel.filter(d => d.dir === 'in').length, nOut = sel.length - nIn;
  // Gömrük: istifadəçinin seçdiyi fayl, yoxdursa e-gömrükdən avtomatik
  let gb = [], gbSrc = '', gbNote = '';
  if (Array.isArray(imp) && imp.length) { gb = imp.map(x => ({ ...x, kind: 'imp', counted: true, costAzn: x.sum > 0 ? +x.sum : null, costSrc: x.sum > 0 ? 'fayl' : '' })); gbSrc = 'fayl'; }
  else if (auto) {
    log('e-gömrükdən idxal və ixrac hesabatı alınır...');
    const r = await customsFetch(from, to);
    if (r.none) gbNote = 'e-gömrük açıq deyildi: idxal və ixrac hesaba alınmayıb (e-gömrükə başqa sekmədə daxil ol; açıqdırsa səhifəni yenilə — F5 — və təkrar başlat).';
    else if (r.error) gbNote = 'e-gömrük: ' + r.error + '. İdxal və ixrac hesaba alınmayıb.';
    else {
      const all = [...(r.imp || []).map(x => ({ ...x, kind: 'imp' })), ...(r.exp || []).map(x => ({ ...x, kind: 'exp' }))];
      const vo = [...new Set(all.map(x => x.voen).filter(Boolean))];
      if (own && vo.length && !vo.includes(own)) gbNote = `e-gömrükdə başqa şirkət açıqdır (VÖEN ${vo.join(', ')}), e-taxes-də isə ${own}. İdxal və ixrac hesaba alınmayıb.`;
      else {
        gb = all.map(x => ({ ...x, costAzn: null, counted: x.kind === 'imp' ? (!x.rejim || /^4[02]/.test(x.rejim)) : (!x.rejim || /^1/.test(x.rejim)) }));
        gbSrc = 'e-gömrük';
        if (!gb.length) gbNote = 'e-gömrükdə bu dövrdə idxal və ixrac bəyannaməsi tapılmadı.';
      }
    }
  }
  // İdxal malının maya dəyəri invoys dəyərindən: GB-lər e-gömrükün "Gömrük bəyannamələri" səhifəsindən oxunur (açıqdırsa)
  let invNote = '';
  const impUse = gb.filter(x => x.kind === 'imp' && x.counted && x.gb && (!x.dnum || (x.dnum >= fromN && x.dnum <= toN)));
  if (impUse.length && gbSrc === 'e-gömrük') {
    const regs = [...new Set(impUse.map(x => x.gb))];
    log(`İdxal: ${regs.length} GB üzrə invoys dəyəri və məzənnə oxunur...`);
    const msg = { type: 'dxGbInv', from: String(fromN).replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3'), to: String(toN).replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3'), regs };
    const { dxGbTabs = [] } = await chrome.storage.session.get('dxGbTabs');
    let res = null;
    for (const id of [...dxGbTabs].reverse()) { try { res = await chrome.tabs.sendMessage(id, msg); if (res && res.map) break; } catch (e) { res = null; } }
    // Səhifə DataX yenilənməzdən əvvəl açılıbsa, orada skript işləmir: indi yerləşdirilir
    if (!res || !res.map) {
      const tabs = await chrome.tabs.query({ url: 'https://egbtrader2.customs.gov.az/*' }).catch(() => []);
      for (const t of tabs) {
        try {
          await chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['pdf-lib.min.js', 'gomruk-core.js', 'gomruk.js'] });
          res = await chrome.tabs.sendMessage(t.id, msg); if (res && res.map) break;
        } catch (e) { res = null; }
      }
    }
    if (!res || !res.map) invNote = 'İdxal malının maya dəyəri hesablanmadı: "Gömrük bəyannamələri" siyahısı (egbtrader2.customs.gov.az, GBList səhifəsi) açıq deyildi — invoys dəyəri və məzənnə oradan oxunur. Miqdar qalığa daxildir, dəyər boş qalıb. e-gömrükdə Gömrük bəyannaməsi bölməsini aç (bəyannamələrin siyahısı görünsün), sonra hesabatı təkrar başlat.';
    else {
      const used = new Map(); let ok = 0;
      const isV = p => p.code === '32' || p.code === '85' || /^18\s*%/.test(String(p.rate || '').trim());
      for (const x of impUse) {
        const g = res.map[x.gb]; if (!g || !g.goods || !g.goods.length) continue;
        const k = x.gb + '|' + x.code, n = used.get(k) || 0, same = g.goods.filter(y => y.code === String(x.code || '').replace(/\D/g, ''));
        const y = same[n] || (g.goods.length === 1 ? g.goods[0] : null); used.set(k, n + 1);
        if (!y || !(g.rate > 0) || !Array.isArray(y.pays)) continue;
        const rate = g.rate / (g.coeff || 1), invAzn = y.inv * rate;
        // GB üzrə (mala bağlı olmayan) ödənişlər mallar arasında gömrük dəyərinə görə bölünür; ƏDV maya dəyərinə daxil edilmir (əvəzləşdirilir)
        const cvT = g.goods.reduce((t, z) => t + (z.cv || 0), 0) || 1, decl = (g.declPays || []).filter(p => !isV(p)).reduce((t, p) => t + p.sum, 0) * (y.cv || 0) / cvT;
        const fees = y.pays.filter(p => !isV(p)).reduce((t, p) => t + p.sum, 0) + decl;
        x.inv = y.inv; x.cur = g.currency; x.rate = rate; x.terms = g.terms; x.fees = Math.round(fees * 100) / 100;
        x.costAzn = Math.round((invAzn + fees) * 100) / 100; x.costSrc = 'invoys'; ok++;
      }
      const miss = impUse.length - ok;
      invNote = `İdxal: ${ok} sətirin maya dəyəri = invoys dəyəri × GB məzənnəsi + GB-dəki rüsum, aksiz və yığımlar (idxal ƏDV-si daxil deyil — əvəzləşdirilir; daşıma xərcləri bu hesabata daxil deyil, tam maya dəyəri üçün "Maya dəyəri" funksiyasından istifadə et)` + (miss ? `; ${miss} sətir üçün GB məlumatı oxunmadı — onların dəyəri boş qalıb (statistik dəyər maya dəyəri kimi götürülmür)` : '') + '.' + (res.errs && res.errs.length ? ' Qeyd: ' + res.errs.slice(0, 3).join('; ') : '');
    }
    if (invNote) log(invNote);
  }
  const gbUse = gb.filter(x => x.counted && x.q > 0 && x.name !== undefined && (!x.dnum || (x.dnum >= fromN && x.dnum <= toN)));
  if (!nIn && !nOut && !gbUse.length) throw new Error('Bu tarix aralığında gələn və göndərilən qaimə tapılmadı.');
  const res = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimənin malları oxundu.`, false, { i: d, n: sel.length, stats: [{ l: 'Gələn', v: nIn }, { l: 'Göndərilən', v: nOut }, { l: 'Oxundu', v: d }] }));
  // Hadisələr (hamısı əsas vahiddə)
  const E = []; let errs = 0, svc = 0, lines = 0, conv = 0;
  sel.forEach((d, i) => {
    const r = res[i]; if (!r) return; if (r.error) { errs++; return; }
    r.rows.forEach(row => {
      const code = String(row[1] || '').trim(), name = String(row[2] || '').trim(), ub = unitBase(row[5]), q0 = +row[6] || 0, sum = +row[8] || 0;
      if (code.startsWith('99')) { svc++; return; }                  // xidmətlər anbara düşmür
      if (!name || !q0) return; lines++; if (ub.f !== 1) conv++;
      const k = d.ret ? (d.dir === 'out' ? 'retSup' : 'retCus') : (d.dir === 'in' ? 'buy' : 'sell');   // MQ: göndərilən = təchizatçıya qaytarma, gələn = alıcının qaytarması
      E.push({ k, code, name, unit: ub.u, q: q0 * ub.f, sum, dnum: d.dnum, date: d.date.slice(0, 10), ser: d.serial });
    });
  });
  const splitModels = x => {
    const re = /([A-Za-z][A-Za-z0-9()\- ]{1,24}?)\s*[-–]\s*([\d][\d\s.,]*)\s*(kq|kg|ton)\b/gi, parts = []; let m;
    while ((m = re.exec(String(x.name || '')))) parts.push({ model: m[1].replace(/^.*?:\s*/, '').trim(), q: parseFloat(m[2].replace(/\s/g, '').replace(',', '.')) * (/ton/i.test(m[3]) ? 1000 : 1) });
    const tot = parts.reduce((t, p) => t + p.q, 0), q = (+x.q || 0) * unitBase(x.unit || 'kq').f;
    if (parts.length < 2 || Math.abs(tot - q) > 0.5) return [x];
    return parts.map(p => ({ ...x, name: p.model, q: p.q, unit: 'kq', sum: (+x.sum || 0) * p.q / q, fees: (+x.fees || 0) * p.q / q, costAzn: x.costAzn != null ? x.costAzn * p.q / q : null, vat: (+x.vat || 0) * p.q / q, part: true }));
  };
  const GB = gbUse.flatMap(splitModels).map(x => { const ub = unitBase(x.unit || 'kq'); return { k: x.kind, code: String(x.code || '').replace(/\D/g, ''), name: String(x.name || '').replace(/^\s*\d+\s*[.)]\s*/, '').trim(), unit: ub.u, q: (+x.q || 0) * ub.f,
    sum: x.kind !== 'imp' ? 0 : x.costAzn != null ? +x.costAzn : null, dnum: x.dnum || fromN, date: dmy(x.dnum || fromN), ser: (x.kind === 'exp' ? 'İxrac GB ' : 'GB ') + (x.gb || ''), vat: +x.vat || 0, gb: true }; });
  // 1) Kod üzrə qruplar (əsas icmal): e-qaimə və gömrük eyni 10 rəqəmli ƏMTN kodundan istifadə edir
  const C = new Map(), ckey = e => (e.code ? 'k:' + e.code : 'a:' + normName(e.name)) + '|' + e.unit;
  for (const e of [...E, ...GB]) { const k = ckey(e); if (!C.has(k)) C.set(k, newGrp(e.unit)); grpAdd(C.get(k), e); }
  // 2) Ad üzrə qruplar (təfərrüat); gömrük sətri satış malına kod + ad/model ilə bağlanır
  const P = new Map();
  for (const e of E) { const k = normName(e.name) + '|' + e.unit; if (!P.has(k)) P.set(k, newGrp(e.unit)); grpAdd(P.get(k), e); }
  let gbLinked = 0, gbNew = 0;
  const modelToks = s => (normTok(s).match(/[a-z]*\d[a-z0-9]*/g) || []).filter(t => t.length >= 3 && /[a-z]/.test(t));
  // Sürət: adları söz başlanğıclarına və koda görə indekslə (hər GB sətri bütün mallarla müqayisə edilməsin)
  const wk = t => normTok(t).split(' ').filter(w => w.length >= 3).map(w => w.slice(0, 4));
  const pW = new Map(), pC = new Map(), addI = (M, k, x) => { if (!M.has(k)) M.set(k, new Set()); M.get(k).add(x); };
  for (const x of P.values()) { x.codes.forEach(c => addI(pC, c, x)); for (const n of x.names.keys()) wk(n).forEach(w => addI(pW, w, x)); }
  for (const e of GB) {
    let best = null, how = '';
    const cands = e.code ? [...(pC.get(e.code) || [])].filter(x => x.unit === e.unit) : [];
    if (cands.length === 1) { best = cands[0]; how = 'kod eyni'; }
    else if (cands.length > 1) {
      const desc = normTok(e.name), byModel = cands.filter(x => [...x.names.keys()].some(n => modelToks(n).some(t => desc.includes(t))));
      if (byModel.length === 1) { best = byModel[0]; how = 'kod və model eyni'; }
      else {
        let bv = 0; for (const x of cands) { const v = Math.max(...[...x.names.keys()].map(n => nameSim(n, e.name))); if (v > bv) { bv = v; best = x; } }
        if (bv >= 0.8) how = `kod eyni, ad oxşar (${Math.round(bv * 100)}%)`;
        else { best = cands.sort((a, b) => (b.sellQ + b.expQ) - (a.sellQ + a.expQ))[0]; how = 'kod eyni (ən çox satılan mala)'; }
      }
    } else {
      const near = new Set(); wk(e.name).forEach(w => (pW.get(w) || []).forEach(x => { if (near.size < 300) near.add(x); }));
      let bv = 0; for (const x of near) { if (x.unit !== e.unit) continue; const v = Math.max(...[...x.names.keys()].map(n => nameSim(n, e.name))); if (v >= 0.8 && v > bv) { bv = v; best = x; how = `ad oxşar (${Math.round(v * 100)}%)`; } }
    }
    if (best) gbLinked++; else { gbNew++; best = newGrp(e.unit); best.impHow = 'yalnız gömrükdə'; P.set('gb:' + normName(e.name) + '|' + e.unit + '|' + e.code, best); }
    grpAdd(best, e); if (how && !best.impHow.includes(how)) best.impHow = best.impHow ? best.impHow + '; ' + how : how;
    if (e.code) addI(pC, e.code, best); wk(e.name).forEach(w => addI(pW, w, best));
  }
  // Aylar
  const months = []; for (let y = Math.floor(fromN / 10000), m = Math.floor(fromN / 100) % 100; y * 100 + m <= Math.floor(toN / 100); m === 12 ? (y++, m = 1) : m++) months.push({ lab: `${String(m).padStart(2, '0')}.${y}`, end: y * 10000 + m * 100 + 31 });
  const CS = [...C.values()].map(g => grpStat(g, months)), codeNeg = new Map();
  CS.forEach(x => [...x.g.codes].forEach(c => codeNeg.set(c + '|' + x.g.unit, x.bal < -1e-6)));
  // Ad üzrə risklər
  const hasGb = gbSrc !== '';
  const prod = [...P.values()].map(g => {
    const x = grpStat(g, months), flags = []; let lvl = 0;
    if (x.outQ > 1e-6 && x.inQ <= 1e-6 && !g.retSup) { flags.push(hasGb ? 'Satılıb, alışı yoxdur (nə e-qaimədə, nə gömrükdə)' : 'Satılıb, alışı yoxdur'); lvl = 2; }
    else if (g.buyQ + g.impQ - g.retSup < -1e-6) { flags.push('Təchizatçıya qaytarılan dövrdəki alışdan çoxdur (alış dövrdən əvvəl ola bilər)'); lvl = 1; }
    else if (g.sellQ - g.retCus < -1e-6) { flags.push('Alıcıdan qaytarılan dövrdəki satışdan çoxdur (satış dövrdən əvvəl ola bilər)'); lvl = 1; }
    if (!flags.length && x.bal < -1e-6) { flags.push(`Mənfi qalıq: ${ncom(r4(x.bal))} ${g.unit} (ilk dəfə ${x.negAt.date}, ${x.negAt.ser})`); lvl = 2; }
    else if (x.negAt && !flags.length) { flags.push(`Alışdan əvvəl satılıb: ${x.negAt.date}, ${x.negAt.ser}`); lvl = Math.max(lvl, 1); }
    if (x.avgIn && x.avgOut && x.avgOut < x.avgIn * 0.98) { flags.push(`Maya dəyərindən aşağı satış (orta maya ${ncom(r4(x.avgIn))}, satış ${ncom(r4(x.avgOut))} / ${g.unit})`); lvl = Math.max(lvl, 1); }
    const codeDiff = g.cBuy.size && g.cSell.size && [...g.cSell].some(c => !g.cBuy.has(c) && !g.cImp.has(c));
    if (codeDiff) { flags.push('Alış və satışda fərqli təsnifat kodu'); lvl = Math.max(lvl, 1); }
    if (lvl === 2 && g.codes.size && [...g.codes].every(c => codeNeg.get(c + '|' + g.unit) === false)) { lvl = 1; flags.push('Kod üzrə yekun qalıq mənfi deyil — ehtimal ki, eyni mal başqa adla alınıb/idxal edilib'); }
    if (g.impQ) flags.push(`Gömrük idxalı: ${ncom(r4(g.impQ))} ${g.unit} (${g.impHow})`);
    if (g.expQ) flags.push(`İxrac: ${ncom(r4(g.expQ))} ${g.unit}`);
    if (g.names.size > 1) flags.push('Ad fərqli yazılıb: ' + [...g.names.keys()].slice(0, 4).join(' / '));
    return { ...x, flags, lvl, codeDiff };
  });
  // Oxşar adlar (alış ↔ satış)
  const buy = prod.filter(x => x.g.buyQ + x.g.impQ > 1e-6), sell = prod.filter(x => x.g.sellQ > 1e-6);
  const idx = new Map(), addIdx = (k, x) => { if (!idx.has(k)) idx.set(k, []); idx.get(k).push(x); };
  const keysOf = x => { const t = normTok(x.main).split(' ').filter(w => w.length >= 3).map(w => 'w:' + w.slice(0, 4)); x.g.codes.forEach(c => t.push('c:' + c)); t.push('n:' + normName(x.main)); return [...new Set(t)]; };
  buy.forEach(x => keysOf(x).forEach(k => addIdx(k, x)));
  const simRows = [], seenPair = new Set();
  for (const y of sell) {
    const cand = new Set(); keysOf(y).forEach(k => (idx.get(k) || []).forEach(x => { if (x !== y && cand.size < 400) cand.add(x); }));
    const found = [];
    for (const x of cand) {
      const sameName = normName(x.main) === normName(y.main), v = sameName ? 1 : nameSim(x.main, y.main);
      if (v < 0.8) continue;
      const pk = x.main + '\u0001' + x.g.unit + '\u0002' + y.main + '\u0001' + y.g.unit; if (seenPair.has(pk)) continue; seenPair.add(pk);
      found.push({ x, v, sameName });
    }
    found.sort((a, b) => b.v - a.v).slice(0, 3).forEach(({ x, v, sameName }) => {
      simRows.push([x.main, y.main, x.g.unit, y.g.unit, String(Math.round(v * 100)), nstr(r4(x.g.buyQ + x.g.impQ)), nstr(r4(y.g.sellQ)), [...x.g.codes].join(', '), [...y.g.codes].join(', '), sameName ? 'Eyni ad, fərqli ölçü vahidi' : 'Ad cüzi fərqlənir']);
      y.flags.push(`Alışda oxşar ad: "${x.main}" (${Math.round(v * 100)}%)`);
      if (x.g.sellQ <= 1e-6) x.flags.push(`Satışda oxşar ad: "${y.main}" (${Math.round(v * 100)}%)`);
      if (!y.lvl) y.lvl = 1; if (!x.lvl) x.lvl = 1;
    });
  }
  prod.sort((a, b) => b.lvl - a.lvl || Math.abs(b.g.sellS) - Math.abs(a.g.sellS));
  // İcmal (kod üzrə qalıq)
  const neg = CS.filter(x => x.bal < -1e-6).sort((a, b) => a.bal - b.bal), pos = CS.filter(x => x.bal > 1e-6).sort((a, b) => b.bal * (b.avgIn || 0) - a.bal * (a.avgIn || 0));
  const zero = CS.length - neg.length - pos.length;
  const codeOf = x => [...x.g.codes].join(', ');
  const icRow = (sec, x) => [sec, codeOf(x), x.main, x.g.unit, nstr(r4(x.g.buyQ - x.g.retSup)), x.g.impQ ? nstr(r4(x.g.impQ)) : '', nstr(r4(x.saleQ)), x.g.expQ ? nstr(r4(x.g.expQ)) : '', nstr(r4(x.bal)),
    x.avgIn ? nstr(r4(x.avgIn)) : '', x.avgIn ? nstr(r2(x.bal * x.avgIn)) : '',
    [sec === 'Mənfi qalıq' && x.negAt ? `İlk dəfə ${x.negAt.date} mənfiyə düşüb (${x.negAt.ser})` : '', sec !== 'Mənfi qalıq' && x.negAt ? `${x.negAt.date} tarixində müvəqqəti mənfiyə düşüb (${x.negAt.ser})` : '',
      x.inQ <= 1e-6 && x.outQ > 0 ? 'alışı yoxdur' : '', x.g.names.size > 1 ? `${x.g.names.size} fərqli adla yazılıb` : ''].filter(Boolean).join('; ')];
  const sumV = a => r2(a.reduce((t, x) => t + (x.avgIn ? x.bal * x.avgIn : 0), 0));
  const icRows = [...neg.map(x => icRow('Mənfi qalıq', x)), ...(neg.length ? [['Cəmi (mənfi)', `${neg.length} mal`, '', '', '', '', '', '', '', '', nstr(sumV(neg)), '']] : []),
    ...pos.map(x => icRow('Qalıq var', x)), ...(pos.length ? [['Cəmi (qalıq)', `${pos.length} mal`, '', '', '', '', '', '', '', '', nstr(sumV(pos)), '']] : []),
    ['Qalığı sıfır olan mallar', `${zero} mal`, '', '', '', '', '', '', '', '', '', '']];
  const icFills = icRows.map(r => r[0] === 'Mənfi qalıq' ? 'risk' : null);
  const mRows = [...neg, ...pos, ...CS.filter(x => Math.abs(x.bal) <= 1e-6)].map(x => [codeOf(x), x.main, x.g.unit, ...x.mEnd.map(v => nstr(v))]);
  const mFills = [...neg, ...pos, ...CS.filter(x => Math.abs(x.bal) <= 1e-6)].map(x => x.minBal < -1e-6 ? (x.bal < -1e-6 ? 'risk' : 'warn') : null);
  const LV = ['Uyğundur', 'Yoxlanmalı', 'Yüksək risk'];
  const rows = prod.map(x => [LV[x.lvl], x.main, x.g.unit, [...x.g.cBuy, ...x.g.cImp].filter((c, i, a) => a.indexOf(c) === i).join(', '), [...x.g.cSell].join(', '), nstr(r4(x.g.buyQ - x.g.retSup)), x.g.impQ ? nstr(r4(x.g.impQ)) : '',
    nstr(r4(x.saleQ)), x.g.expQ ? nstr(r4(x.g.expQ)) : '', nstr(r4(x.bal)), x.avgIn ? nstr(r4(x.avgIn)) : '', x.avgOut ? nstr(r4(x.avgOut)) : '', dmy(x.g.firstIn), dmy(x.g.firstOut), x.flags.join('; '),
    x.g.retSup ? nstr(r4(x.g.retSup)) : '', x.g.retCus ? nstr(r4(x.g.retCus)) : '']);
  const fills = prod.map(x => x.lvl === 2 ? 'risk' : x.lvl === 1 ? 'warn' : null);
  const codeRows = prod.filter(x => x.codeDiff).map(x => [x.main, x.g.unit, [...x.g.cBuy].join(', '), [...x.g.cSell].join(', '), nstr(r2(x.g.sellS))]);
  const nameRows = CS.filter(x => x.g.names.size > 1).flatMap(x => [...x.g.names.entries()].map(([n, c]) => [codeOf(x), x.main, n, String(c)]));
  const gbRows = gb.map(x => [x.kind === 'exp' ? 'İxrac' : 'İdxal', x.gb || '', x.dnum ? dmy(x.dnum) : '', x.rejim || '', x.code || '', String(x.name || '').slice(0, 300), nstr(x.q), x.unit || '', nstr(x.sum || 0), x.inv != null ? nstr(x.inv) : '', x.cur || '', x.rate ? nstr(Math.round(x.rate * 10000) / 10000) : '', nstr(x.fees || 0), x.costAzn != null ? nstr(x.costAzn) : '', x.costSrc === 'invoys' ? 'invoys dəyəri × məzənnə + rüsum, aksiz, yığım' : x.costSrc === 'fayl' ? 'seçilmiş fayldan' : (x.kind === 'imp' ? 'hesablanmadı (invoys oxunmadı)' : ''), nstr(x.vat || 0),
    gbUse.includes(x) ? 'Bəli' : (x.counted ? 'Xeyr (dövrdən kənar)' : 'Xeyr (rejim: ' + (x.rejim || '-') + ')')]);
  // Birləşdirmə vərəqi: istifadəçi mənfi qalıqlı malı oxşar adlı mala siyahıdan seçib birləşdirir, qalıq Excel düsturu ilə yenidən hesablanır
  const bProd = [...prod].sort((a, b) => (a.bal < -1e-6 ? 0 : 1) - (b.bal < -1e-6 ? 0 : 1) || a.main.localeCompare(b.main, 'az'));
  const dupN = new Map(); bProd.forEach(x => dupN.set(x.main, (dupN.get(x.main) || 0) + 1));
  const bKey = x => dupN.get(x.main) > 1 ? `${x.main} [${x.g.unit}]` : x.main, bN = bProd.length + 1, RA = `$A$2:$A$${bN}`, RG = `$G$2:$G$${bN}`, RI = `$I$2:$I$${bN}`, RF = `$F$2:$F$${bN}`;
  const sugg = new Map();   // mənfi qalıqlı mal → oxşar adlı, qalığı müsbət, eyni ölçü vahidli mal
  if (bProd.length <= 4000) for (const y of bProd.filter(x => x.bal < -1e-6)) {
    let best = null, bv = 0; const ks = new Set(keysOf(y)), cand = new Set(); ks.forEach(k => (idx.get(k) || []).forEach(x => cand.add(x)));
    for (const x of cand) { if (x === y || x.g.unit !== y.g.unit || x.bal <= 1e-6) continue; const v = nameSim(x.main, y.main); if (v >= 0.75 && v > bv) { bv = v; best = x; } }
    if (best) sugg.set(y, { x: best, v: bv });
  }
  const bRows = bProd.map((x, i) => { const r = i + 2, sg = sugg.get(x);
    return [bKey(x), x.g.unit, [...x.g.codes].join(', '), nstr(r4(x.g.buyQ - x.g.retSup + x.g.impQ)), nstr(r4(x.saleQ + x.g.expQ)), nstr(r4(x.bal)), '',
      sg ? bKey(sg.x) : '',
      { f: `IF(G${r}="",A${r},IFERROR(IF(INDEX(${RG},MATCH(G${r},${RA},0))="",G${r},INDEX(${RG},MATCH(G${r},${RA},0))),G${r}))`, w: 14 },
      { f: `IF(G${r}<>"","",SUMIF(${RI},A${r},${RF}))`, num: true, w: 14 },
      { f: `IF(G${r}<>"","birləşdirildi → "&G${r},IF(J${r}<-0.0001,"Mənfi qalıq",IF(F${r}<-0.0001,"Birləşmədən sonra qaydasında","")))`, w: 30 }, sg ? String(Math.round(sg.v * 100)) : '']; });
  const vatGb = r2(gbUse.filter(x => x.kind === 'imp').reduce((t, x) => t + (+x.vat || 0), 0));
  const cnt = l => prod.filter(x => x.lvl === l).length;
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { versiya: VERSION, funksiya: 'mal', rejim: 'api', gelen: nIn, gonderilen: nOut, gomruk: gbUse.length, gomrukMenbe: gbSrc || '-', kod: CS.length, menfi: neg.length, mal: prod.length, risk: cnt(2), yoxla: cnt(1), xeta: errs, saniye: sec } });
  await saveXlsx(`DataX-mal-hereketi-${from}_${to}.xlsx`, [
    { name: 'İcmal (qalıq)', header: ['Bölmə', 'Mal kodu', 'Malın adı', 'Ölçü vahidi', 'Alış (e-qaimə, xalis)', 'İdxal (gömrük)', 'Satış (xalis)', 'İxrac', 'Qalıq', 'Orta maya dəyəri', 'Təxmini qalıq dəyəri', 'Qeyd'],
      rows: icRows, fills: icFills, keep: true, numCols: [4, 5, 6, 7, 8, 9, 10] },
    { name: 'Aylar üzrə qalıq', header: ['Mal kodu', 'Malın adı', 'Ölçü vahidi', ...months.map(m => m.lab + ' sonu')], rows: mRows, fills: mFills, numCols: months.map((_, i) => 3 + i) },
    { name: 'Birləşdirmə', header: ['Malın adı', 'Ölçü vahidi', 'Mal kodu', 'Daxil olan (alış + idxal)', 'Çıxan (satış + ixrac)', 'Qalıq', 'Bu mala birləşdir (siyahıdan seç)', 'DataX təklifi', 'Hesabda ad', 'Birləşdirilmiş qalıq', 'Vəziyyət', 'Oxşarlıq %'],
      rows: bRows, keep: true, numCols: [3, 4, 5, 9, 11], negRed: [`F2:F${bN}`, `J2:J${bN}`], lists: [{ sqref: `G2:G${bN}`, src: RA }] },
    { name: 'Mal hərəkəti (ad üzrə)', header: ['Nəticə', 'Malın adı', 'Ölçü vahidi', 'Kod (alış/idxal)', 'Kod (satış)', 'Alış (e-qaimə, xalis)', 'İdxal (gömrük)', 'Satış (xalis)', 'İxrac', 'Qalıq', 'Orta maya dəyəri', 'Orta satış qiyməti', 'İlk alış', 'İlk satış', 'Qeyd', 'Təchizatçıya qaytarılan', 'Alıcıdan qaytarılan'],
      rows, fills, keep: true, numCols: [5, 6, 7, 8, 9, 10, 11, 15, 16] },
    ...(gb.length ? [{ name: 'Gömrük bəyannamələri', header: ['Növ', 'GB nömrəsi', 'Tarix', 'Rejim', 'Mal kodu', 'Malın təsviri', 'Miqdar', 'Ölçü vahidi', 'Statistik dəyər (USD, yalnız məlumat üçün — hesablamada istifadə olunmur)', 'İnvoys dəyəri', 'Valyuta', 'Məzənnə', 'Rüsum, aksiz və yığımlar', 'Maya dəyəri (AZN)', 'Maya dəyəri necə hesablandı', 'İdxal ƏDV-si', 'Hesaba alındı'], rows: gbRows, numCols: [6, 8, 9, 11, 12, 13, 15] }] : []),
    { name: 'Kod fərqləri', header: ['Malın adı', 'Ölçü vahidi', 'Kod (alış)', 'Kod (satış)', 'Satış məbləği'], rows: codeRows, numCols: [4] },
    { name: 'Oxşar adlar', header: ['Alışdakı ad', 'Satışdakı ad', 'Ölçü vahidi (alış)', 'Ölçü vahidi (satış)', 'Oxşarlıq %', 'Alınan miqdar', 'Satılan miqdar', 'Kod (alış)', 'Kod (satış)', 'Səbəb'], rows: simRows, numCols: [4, 5, 6] },
    { name: 'Fərqli yazılışlar', header: ['Mal kodu', 'Əsas ad', 'Qaimədəki yazılış', 'Sətir sayı'], rows: nameRows, numCols: [3] },
    { name: 'Xülasə', header: ['Göstərici', 'Say'], numCols: [1], rows: [
      ['Dövr', `${dmy(fromN)} – ${dmy(toN)}`], ['Gələn qaimə', String(nIn)], ['Göndərilən qaimə', String(nOut)], ['Mal sətri (xidmətlər çıxılmaqla)', String(lines)], ['Ölçü vahidi çevrilən sətir (ton→kq və s.)', String(conv)],
      ['Xidmət sətri (hesaba alınmadı)', String(svc)], ['Gömrük mənbəyi', gbSrc || 'yoxdur'], ['Gömrük bəyannaməsi sətri (hesaba alınan)', String(gbUse.length)], ...(gbUse.length ? [['  ad üzrə mala bağlandı', String(gbLinked)], ['  ayrıca sətir', String(gbNew)], ['İdxalda ödənilmiş ƏDV (gömrük)', nstr(vatGb)]] : []),
      ['Mal kodu (icmal)', String(CS.length)], ['  mənfi qalıqlı', String(neg.length)], ['  qalığı olan', String(pos.length)], ['Mal (ad üzrə)', String(prod.length)], ['Yüksək risk', String(cnt(2))], ['Yoxlanmalı', String(cnt(1))],
      ['Oxşar ad cütü', String(simRows.length)], ...(errs ? [['Oxunmayan qaimə', String(errs)]] : [])] },
    { name: 'Qeydlər', header: ['Qeyd'], numeric: false, rows: [
      ...(gbNote ? [[gbNote]] : []), ...(invNote ? [[invNote]] : []),
      ['Birləşdirmə vərəqi: mənfi qalıqlı mal əslində başqa adla alınıbsa, onun sətrində "Bu mala birləşdir" xanasından (siyahı) alışdakı adı seç — miqdar həmin mala köçür və "Birləşdirilmiş qalıq" dərhal yenidən hesablanır. "DataX təklifi" sütunu oxşar adlı, qalığı olan malı göstərir; düzdürsə, həmin adı seç (bir neçə təklifi birdən qəbul etmək üçün "DataX təklifi" xanalarını kopyalayıb "Bu mala birləşdir" sütununa yapışdırmaq olar). Seçimi silmək üçün xananı boşalt. Qırmızı — hələ də mənfi qalıq.'],
      ['İcmal mal koduna (10 rəqəmli ƏMTN) görə aparılır: e-qaimədə və gömrük bəyannaməsində kod eynidir, adlar isə çox vaxt fərqli yazılır. Kodu olmayan mallar adına görə qruplaşdırılır.'],
      ['Ölçü vahidləri əsas vahidə çevrilir: ton, sentner, qram → kq; ml → litr; sm, mm, km → metr. Məsələn, 25 000 kq alınıb 25 ton satılıbsa, qalıq 0 olur.'],
      ['Dövrün əvvəlinə olan qalıq məlum deyil: dövrdən əvvəl alınmış mallar "mənfi qalıq" kimi görünə bilər. Başlanğıc tarixi şirkətin ilk qaiməsinə yaxın seçmək daha dəqiqdir.'],
      [gbSrc ? `Gömrük (${gbSrc}): idxal alış, ixrac çıxış kimi hesablanır. İdxalda maya dəyəri (AZN) = invoys dəyəri × GB-dəki məzənnə + rüsum, aksiz və gömrük yığımları (e-gömrükdə "Gömrük bəyannamələri" səhifəsi açıq olanda); ƏDV maya dəyərinə daxil deyil. Həmin səhifə açıq deyilsə və ya GB oxunmayıbsa, idxal sətirinin dəyəri boş qalır (statistik dəyər valyutadadır və maya dəyəri deyil — götürülmür); orta alış qiyməti yalnız dəyəri məlum olan miqdarla hesablanır. Daşıma xərcləri bu hesabata daxil deyil. Sərbəst dövriyyə (40/42) idxalı və ixrac rejimləri sayılır.` : 'Gömrük idxalı hesaba alınmayıb: xaricdən alınmış mallar "alışı yoxdur" kimi görünə bilər.'],
      ['Mal qaytarma qaimələri (MQ) satış və ya alış sayılmır: göndərilən MQ alışı, gələn MQ satışı azaldır.'],
      ['Kassa çeki ilə alınmış mallar e-qaimədə olmadığı üçün burda görünmür. Avans, VM-in 163/177.5-ci maddələri üzrə və yerdəyişmə qaimələri, ləğv edilmiş və silinmiş qaimələr hesaba alınmayıb.']] }]);
  const ps = [`${nIn} gələn, ${nOut} göndərilən qaimə` + (gbUse.length ? `, ${gbUse.length} gömrük bəyannaməsi` : ''), `${CS.length} mal kodu`, `${neg.length} mənfi qalıq`, `${cnt(2)} yüksək risk`];
  if (errs) ps.push(`${errs} qaimə oxunmadı`);
  if (gbNote) ps.push(gbNote.split(':')[0].replace(/\.$/, ''));
  log((errs || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true,
    { i: sel.length, n: sel.length, hasErrors: !!errs, stats: [{ l: 'Mal kodu', v: CS.length }, { l: 'Mənfi qalıq', v: neg.length }, { l: 'Gömrük', v: gbUse.length }] });
}
const runStock = m => runStockApi(m).catch(e => { throw e.apiFail ? new Error('e-taxes cavab vermədi (' + e.message.replace(/^API: /, '') + '). Səhifəni yenilə və təkrar başlat.') : e; });

// ---------------- FUNKSİYA 3: Alt sənədlər ----------------
async function ownFromApi(tabId) {
  const d = await api1(tabId, '/api/po/profile/public/v2/profile'), p = (d && d.profile) || d || {};
  const name = p.companyName || p.individualName || '', voen = p.tin || '';
  if (!name && !voen) throw apiErr('profil boşdur');
  const ad = String(p.legalAddress || p.actualAddress || '').toLocaleLowerCase('az'), m = ad.match(/(\p{L}[\p{L}\-]*)\s+şəhəri/u) || ad.match(/(\p{L}[\p{L}\-]*)\s+rayonu/u);
  const city = m ? m[0].replace(/^\p{L}/u, c => c.toLocaleUpperCase('az')) : '';
  return { name: shortName(name), voen, city, menbe: ['profil (birbaşa)'] };
}
async function runDocsApi({ tabId, serials, voen, from, to, dir, docs, opts }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  const want = [...new Set((serials || []).map(s => s.toUpperCase()))], keys = Object.keys(DOCS).filter(k => docs && docs[k]);
  const today = (d => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate())(new Date());
  const found = new Map(); let pages = 0;
  log('Qaimələr axtarılır...');
  if (want.length) {
    for (let i = 0; i < want.length && !cancel; i++) {
      const s = want[i], m = s.match(/^[A-Z]{2}(\d{2})(\d{2})/), y = m ? 2000 + +m[1] : 0, mo = m ? +m[2] : 0;
      const a = y && mo >= 1 && mo <= 12 ? y * 10000 + mo * 100 + 1 : 20190101;
      const b = y && mo >= 1 && mo <= 12 ? Math.min(today, (mo > 9 ? (y + 1) * 10000 + (mo - 9) * 100 : y * 10000 + (mo + 3) * 100) + 1) : today;
      const L = await apiInvList(tabId, dir, a, b, { serialNumber: s }, null); pages += L.pages;
      L.all.filter(v => String(v.serialNumber || '').toUpperCase() === s).forEach(v => found.set(v.id, v));
      log(`Qaimələr axtarılır: ${i + 1} / ${want.length}...`);
    }
  } else {
    const L = await apiInvList(tabId, dir, N(from), N(to), voen ? (dir === 'out' ? { receiverTin: voen } : { senderTin: voen }) : null, null); pages = L.pages;
    L.all.forEach(v => found.set(v.id, v));
  }
  const sel = [...found.values()].map(v => invRow(v, dir)).filter(d => !voen || d.voen === voen).filter(d => want.length || (d.dnum >= N(from) && d.dnum <= N(to))).sort((a, b) => a.dnum - b.dnum || a.date.localeCompare(b.date));
  const notFound = want.filter(s => !sel.some(x => x.serial.toUpperCase() === s));
  const base = { versiya: VERSION, funksiya: 'altSenedler', rejim: 'api', bolme: tab, sehife: pages, secim: { nomre: want.length, voenSecimi: !!voen, tapildi: sel.length, tapilmadi: notFound.length } };
  await chrome.storage.local.set({ report: base });
  if (!sel.length) throw new Error(want.length ? `Yazdığın ${want.length} qaimədən heç biri "${tab}" bölməsində tapılmadı. Bölməni (Gələn/Göndərilən) və nömrələri yoxla.` : `"${tab}" bölməsində bu VÖEN və tarixlərə uyğun qaimə tapılmadı.`);
  const stats = (d, f) => [{ l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }, { l: 'Sənəd', v: f }];
  const results = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimə oxundu.`, false, { i: d, n: sel.length, stats: stats(d, 0) }));
  let own; try { own = await ownFromApi(tabId); } catch (e) { if (e.message === SESSION_END) throw e; own = (await detectOwn(tabId)).own; try { await exec(tabId, rmAllFrames); } catch (e2) {} }
  const o = opts || {}; let files = 0, okInv = 0, err = 0, noOwn = 0, seq = 0; const errs = [];
  for (let i = 0; i < sel.length && !cancel; i++) {
    const d = sel[i], res = results[i]; if (!res) continue;
    if (res.error) { err++; errs.push(res.error); continue; }
    const inv = (res.info.parties || []).find(p => p.voen !== d.voen) || {};
    const me = { name: own.name || shortName(inv.name || ''), voen: own.voen || inv.voen || '', city: own.city };
    const dd = docData(d, res, dir, me, o, ++seq); if (dd.noOwn) noOwn++;
    files += await saveInvoiceDocs(keys, dd.data, dd.items, d.serial);
    okInv++; log(`Sənədlər hazırlanır: ${okInv} / ${sel.length} qaimə...`, false, { i: i + 1, n: sel.length, stats: stats(sel.length, files) });
  }
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ ownSeen: { name: own.name, voen: own.voen, t: Date.now() } });
  await chrome.storage.local.set({ report: { ...base, saniye: sec, senedSayi: files, xeta: err, ozSirket: { menbe: own.menbe, tapilmadi: noOwn }, xetalar: [...new Set(errs.map(mask))].slice(0, 4) } });
  const warn = [];
  if (notFound.length) warn.push(`Tapılmadı: ${notFound.slice(0, 6).join(', ')}${notFound.length > 6 ? ' və daha ' + (notFound.length - 6) : ''}.`);
  if (err) warn.push(`${err} qaimə oxunmadı.`);
  if (noOwn) warn.push(`${noOwn} qaimədə öz şirkətinin adı və ya VÖEN-i tapılmadı, yerinə xətt çəkilib.`);
  log((notFound.length || err ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${okInv} qaimə üçün ${files} sənəd hazırdır. «Yüklə» düyməsini bassan, "Yükləmələr / DataX alt sənədlər" içində hər qaimə üçün bir qovluq (zip) olacaq.` + ((own.name || own.voen) ? `\nŞirkətin: ${own.name || '?'}, VÖEN ${own.voen || '?'}` : '') + (warn.length ? '\n' + warn.join('\n') : ''), true,
    { i: sel.length, n: sel.length, hasErrors: !!(notFound.length || err), stats: [{ l: 'Qaimə', v: okInv }, { l: 'Sənəd', v: files }, { l: 'Tapılmadı', v: notFound.length }] });
}

// ---------------- FUNKSİYA 4: Bəyannamələrin içi ----------------
const SEC_AZ = { common: 'Ümumi məlumat', administrative: 'İnzibati məlumat', payerInfo: 'Vergi ödəyicisi', declarationInfo: 'Bəyannamə', indicators: 'Göstəricilər', term: 'Dövr',
  mainTax: 'Əsas vergi', calculations: 'Hesablamalar', debtorDebt: 'Debitor borclar', refundCalculations: 'Əvəzləşdirilən vergi', totalCalculations: 'Hesablaşmalar',
  vatOperations: 'ƏDV tutulan və tutulmayan əməliyyatlar', reportPeriodInvoiceTotal: 'Əvəzləşdirmə üçün e-qaimələr (cəmi)', agroProductsRetailTotal: 'Kənd təsərrüfatı məhsulları',
  unsoldAgroProducts: 'Satılmamış k/t məhsulları', creditors: 'Kreditorlar', totalCertificateInfo: 'Sertifikatlar', totalObjectInfo: 'Obyektlər' };
const FLD_AZ = { cost: 'Dəyəri', amount: 'Məbləğ', vat: 'ƏDV', paidAmount: 'Ödənilmiş məbləğ', paidVat: 'Ödənilmiş ƏDV', previousDebt: 'Dövrün əvvəlinə borc', incurredDebt: 'Yaranmış borc',
  removedDebt: 'Silinmiş borc', lastDebt: 'Dövrün sonuna borc', mustBePaid: 'Ödənilməli', mustBeReturned: 'Qaytarılmalı', startRemains: 'Dövrün əvvəlinə qalıq', purchased: 'Alınıb', sold: 'Satılıb',
  resultRemains: 'Dövrün sonuna qalıq', tradeSupplementCost: 'Ticarət əlavəsi', tradeSupplementVat: 'Ticarət əlavəsinin ƏDV-si', totalCost: 'Ümumi dəyər', obtainedCost: 'Alınmış dəyər', soldCost: 'Satılmış dəyər',
  taxAmount: 'Vergi məbləği', tax: 'Vergi', rate: 'Dərəcə', taxRate: 'Vergi dərəcəsi', date: 'Tarix', tin: 'VÖEN', name: 'Ad', currency: 'Valyuta', count: 'Say', quantity: 'Miqdar', income: 'Gəlir', expense: 'Xərc',
  departmentCode: 'Vergi orqanının kodu', taxPayerFullName: 'Vergi ödəyicisinin adı', payerType: 'Ödəyicinin növü', taxPayerGroup: 'Ödəyici qrupu', mainActivityCode: 'Əsas fəaliyyət kodu',
  mainActivityName: 'Əsas fəaliyyət', attachmentCount: 'Əlavələrin sayı', declarationType: 'Bəyannamə növü', notificationNo: 'Bildiriş №', type: 'Növ', year: 'İl', month: 'Ay' };
// Saytın öz formalarından çıxarılmış lüğət (forms.json): sətir adları, sütun adları, forma kodları (301.1.1 və s.)
let FORMS = null;
async function loadForms() { if (!FORMS) { try { FORMS = await (await fetch(chrome.runtime.getURL('forms.json'))).json(); } catch (e) { FORMS = { tax: [], forms: {} }; } } return FORMS; }
function formDict(forms, taxCode, ver) {
  const tx = (forms.tax || []).find(x => x.code === taxCode), f = tx && forms.forms[tx.comp]; if (!f) return null;
  const L = f.L || {}, codes = { ...(f.codes || {}), ...((f.byVer || {})[ver] || {}) }, keys = Object.keys(L);
  const strip = s => String(s || '').replace(/^\s*[\d.\-]+\s*-\s*/, '').trim();
  const byInd = {}, bySuffix = {};
  keys.forEach(k => { const i = k.lastIndexOf('.'), last = k.slice(i + 1); if (/^_\w+$/.test(last)) (byInd[last] = byInd[last] || []).push(k); });
  return {
    code: ind => codes[ind] || String(ind).replace(/^_/, ''),
    // göstəricinin adı və aid olduğu bölmə (lang prefiksi)
    row: (ind, hint) => {
      let ks = byInd[ind] || [], suf = ind;
      if (!ks.length) { const c = codes[ind]; if (c) { ks = keys.filter(k => k.endsWith('.' + c)); suf = c; } }
      if (!ks.length) return { label: '', prefix: '' };
      const k = (hint && ks.find(x => x.startsWith(hint + '.'))) || ks[0];
      return { label: strip(L[k]), prefix: k.slice(0, k.length - suf.length - 1) };
    },
    field: (prefix, fld) => { if (prefix) return L[prefix + '.' + fld] || ''; const k = bySuffix[fld] !== undefined ? bySuffix[fld] : (bySuffix[fld] = keys.find(x => x.endsWith('.' + fld) && !/^step\./.test(x)) || ''); return k ? L[k] : ''; },
    title: (prefix, key) => (prefix && L[prefix + '.title']) || L['step.' + key] || ''
  };
}
const camel = k => String(k).replace(/([a-z])([A-Z0-9])/g, '$1 $2').replace(/^./, c => c.toUpperCase());
const secName = k => SEC_AZ[k] || (/^appendix(\d+)$/i.test(k) ? 'Əlavə ' + k.replace(/\D/g, '') : /^section(\d+)$/i.test(k) ? 'Bölmə ' + k.replace(/\D/g, '') : camel(k));
const fldName = k => FLD_AZ[k] || camel(k);
const scal = v => v == null || typeof v !== 'object';
// Bəyannamənin JSON-u → bölmələr (köhnə üsulun formatı): kodlu cədvəllər hesabata, qalan siyahılar ayrıca vərəqə, mətnlər "sahələr"ə
function declToSections(o, dict) {
  const secs = new Map();
  const fl = (prefix, k) => (dict && dict.field(prefix, k)) || fldName(k);
  const S = path => { const t = path.length ? (SEC_AZ[path[0]] || /^appendix\d+$/i.test(path[0]) || !dict ? secName(path[0]) : (dict.title('', path[0]) || secName(path[0]))) : 'Ümumi'; if (!secs.has(t)) secs.set(t, { title: t, side: true, tables: [], fields: [] }); return secs.get(t); };
  const sub = path => path.slice(1).map(secName).join(' / ');
  const walk = (v, path) => {
    if (Array.isArray(v)) {
      const objs = v.filter(x => x && typeof x === 'object' && !Array.isArray(x)); if (!objs.length) return;
      const keys = []; objs.forEach(x => Object.keys(x).forEach(k => { if (!keys.includes(k) && k !== 'id' && k !== 'rowOrder') keys.push(k); }));
      if (objs.every(x => x.indicator != null)) {
        const vk = keys.filter(k => k !== 'indicator' && objs.some(x => scal(x[k])));
        let prefix = ''; const rows = objs.map(x => { const ind = String(x.indicator), r = dict ? dict.row(ind, prefix) : { label: '', prefix: '' }; if (!prefix && r.prefix) prefix = r.prefix;
          return [dict ? dict.code(ind) : ind.replace(/^_/, ''), r.label, ...vk.map(k => typeof x[k] === 'number' ? ncom(x[k]) : scal(x[k]) && x[k] != null ? String(x[k]) : '')]; });
        S(path).tables.push({ title: sub(path), header: ['Kod', 'Göstərici', ...vk.map(k => fl(prefix, k))], coded: { cc: 0, lc: 1, vcols: vk.map((_, i) => i + 2) }, rows });
        objs.forEach((x, i) => keys.filter(k => !scal(x[k])).forEach(k => walk(x[k], [...path, String(x.indicator).replace(/^_/, ''), k])));
      } else {
        const vk = keys.filter(k => objs.some(x => scal(x[k])));
        if (vk.length) S(path).tables.push({ title: sub(path) || secName(path[path.length - 1] || ''), header: vk.map(k => fl('', k)), rows: objs.map(x => vk.map(k => typeof x[k] === 'number' ? ncom(x[k]) : x[k] == null ? '' : String(x[k]))) });
        objs.forEach(x => keys.filter(k => !scal(x[k])).forEach(k => walk(x[k], [...path, k])));
      }
      return;
    }
    if (!v || typeof v !== 'object') return;
    const nums = [], texts = [];
    Object.entries(v).forEach(([k, x]) => { if (typeof x === 'number') nums.push([k, x]); else if (scal(x)) { if (x != null && x !== '') texts.push([k, x]); } else walk(x, [...path, k]); });
    if (nums.length) S(path).tables.push({ title: sub(path), header: ['Kod', 'Dəyər'], coded: { cc: 0, lc: -1, vcols: [1] }, rows: nums.map(([k, x]) => [fl('', k), ncom(x)]) });
    texts.forEach(([k, x]) => S(path).fields.push(['', [sub(path), fl('', k)].filter(Boolean).join(' / '), typeof x === 'boolean' ? (x ? 'Bəli' : 'Xeyr') : String(x)]));
  };
  const ti = o.taxInformation;
  if (o.common) walk(o.common, ['common']);
  if (o.indicators) walk(o.indicators, ['indicators']);
  if (ti && typeof ti === 'object') Object.entries(ti).forEach(([k, v]) => walk(v, [k]));
  Object.entries(o).forEach(([k, v]) => { if (!['common', 'indicators', 'taxInformation', 'taxCode', 'version'].includes(k) && v && typeof v === 'object') walk(v, [k]); });
  return [...secs.values()].filter(s => s.tables.length || s.fields.length);
}
async function runDeclsApi({ tabId, from, to, taxes, skipKameral }) {
  const t0 = Date.now();
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), F = fy * 12 + fm, T = ty * 12 + tm, years = yearsFor(fy, ty);
  log('Bəyannamələr siyahısı alınır...');
  const { list, notes: yearNotes } = await apiDeclList(tabId, years);
  const want = taxes && taxes.length ? new Set(taxes) : null;
  const cand = list.map(x => ({ ...x, tax: taxOf(x.section) })).filter(x => {
    if (want && !want.has(x.tax.k) && !(want.has('diger') && x.tax.k === 'diger')) return false;
    return x.pr.y * 12 + x.pr.b >= F && x.pr.y * 12 + x.pr.a <= T;
  });
  const best = {};
  cand.filter(x => !(skipKameral && x.kameral)).forEach(x => { const k = x.section + '|' + x.pr.y + '|' + x.pr.a + '|' + x.pr.b; if (declBetter(x, best[k])) best[k] = x; });
  const sel = Object.values(best).sort((a, b) => a.tax.ab.localeCompare(b.tax.ab, 'az') || (a.pr.y * 12 + a.pr.a) - (b.pr.y * 12 + b.pr.a));
  const per = {}; list.forEach(x => { const a = taxOf(x.section).ab; per[a] = (per[a] || 0) + 1; });
  const baseReport = { versiya: VERSION, funksiya: 'beyannameler', rejim: 'api', iller: years, ilQeydleri: yearNotes, bolmeler: per, siyahi: list.length, araliqda: cand.length, secilen: sel.length };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş vergi növləri və dövrlər üçün bəyannamə tapılmadı.');

  const forms = await loadForms(), results = new Array(sel.length).fill(null); let done = 0, secCount = 0;
  const report = () => log(`${done} / ${sel.length} bəyannamə oxundu.`, false, { i: done, n: sel.length, stats: [{ l: 'Bəyannamə', v: sel.length }, { l: 'Oxundu', v: done }, { l: 'Bölmə', v: secCount }] });
  report();
  for (let s = 0; s < sel.length && !cancel; s += 12) {
    const chunk = sel.slice(s, s + 12), out = await api(tabId, chunk.map(d => ({ u: `/api/po/declaration/public/v1/base?reg_number=${d.docNo}` })), 6);
    if (s === 0 && out.every(x => x.error)) throw apiErr('bəyannamənin içi: ' + out[0].error);
    out.forEach((x, j) => {
      let r;
      if (x.error) r = { error: x.error };
      else { try { const o = JSON.parse((x.data || {}).baseJson || 'null'), d = chunk[j]; r = o ? { sections: declToSections(o, formDict(forms, d.taxCode || o.taxCode, d.ver || o.version)) } : { error: 'bəyannamənin içi boş gəldi' }; } catch (e) { r = { error: 'format: ' + e.message }; } }
      if (r.sections && !r.sections.length) r = { error: 'bəyannamədə məlumat yoxdur' };
      results[s + j] = r; done++; if (r.sections) secCount += r.sections.length;
    });
    report();
  }
  await declExcel({ sel, results, baseReport, yearNotes: yearNotes.map(n => n), unknownPeriod: [], tpl: {}, learnNotes: [], from, to, t0, apiMode: true });
}

// ---------------- ƏDV əvəzləşmə faylı (308): depozit çıxarışı + gələn qaimələr + əvvəlki Əlavə 1 ----------------
// payments (səhifədə çıxarışdan oxunur): [{ i, dnum, date, voen, name, vat, purpose, refs: [{ ser, num }] }]
// Yalnız təsdiqlənmiş qaimələr əvəzləşdirilə bilər (düzəlişə/ləğvə göndərilmiş qaiməni e-taxes "mövcud deyil" sayır)
const EV_OK = new Set(['approved', 'approvedBySystem', 'cancelationRefused', 'correctionRefused']);
const EV_GONE = new Set(['canceled', 'cancelled', 'deleted', 'deletedBySystem']);
// Əvəzləşməyə yalnız təqdim etmə qaimələri salınır (VM): avans, qaytarma, emal, dəqiqləşdirmə və s. salınmır
const EV_KINDS = new Set(['defaultInvoice', 'resale', 'taxCodex177_5']);
const ev2 = v => Math.round((v + Number.EPSILON) * 100) / 100;
// Qəpiyə qədər aşağı yuvarlaqlaşdırma: e-taxes ƏDV-yə cəlb edilən məbləği 4 rəqəmlə saxlayır (589,1952) — 589,20 yazsaq "çox ola bilməz" xətası verir
const evFloor = v => Math.floor(v * 100 + 1e-6) / 100;
function evSerNum(serial, number) {
  const t = String(serial || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (number != null && String(number).trim() !== '') return { ser: t.slice(0, 6), num: String(number).replace(/\D/g, '') };
  const m = t.match(/^([A-Z]{2}\d{4})(\d+)$/); return m ? { ser: m[1], num: m[2] } : { ser: '', num: t.replace(/\D/g, '') };
}
async function runEvezApi({ tabId, own, period, histFrom, payments, skipKameral = true }) {
  const t0 = Date.now(), [py, pm] = period.split('-').map(Number), P = py * 12 + pm - 1;
  const lastDay = new Date(Date.UTC(py, pm, 0)).getUTCDate(), endN = py * 10000 + pm * 100 + lastDay, fromN = histFrom * 10000 + 101;
  const notes = [];
  // 1) e-taxes-də açıq şirkət çıxarışdakı ilə eynidir?
  try { const me = await ownFromApi(tabId); if (own && me.voen && me.voen !== own) throw new Error(`e-taxes-də ${me.name} (VÖEN ${me.voen}) açıqdır, çıxarış isə VÖEN ${own} üçündür. Düzgün şirkətə keç və yenidən bas.`); }
  catch (e) { if (!e.apiFail) throw e; }
  // 2) Çıxarışdakı təchizatçıların gələn qaimələri (yalnız onların VÖEN-i üzrə)
  const voens = [...new Set(payments.map(p => p.voen))];
  const inv = [], seen = new Set(); let done = 0, ignored = false;
  log(`Gələn qaimələr alınır: 0 / ${voens.length} təchizatçı...`, false, { i: 0, n: voens.length });
  const take = (list, voen) => list.forEach(v => { if (seen.has(v.id)) return; const r = invRow(v, 'in'); if (voen && r.voen !== voen) { ignored = true; return; } seen.add(v.id); r._st = v.status; r._b18 = v.vat18; r._kind = v.kind; inv.push(r); });
  const first = await apiInvList(tabId, 'in', fromN, endN, { senderTin: voens[0] });
  take(first.all, voens[0]); done = 1;
  if (ignored) {                                                     // sayt VÖEN filtrini qəbul etmədi: hamısı bir dəfəyə
    log('Gələn qaimələrin hamısı alınır...'); const all = await apiInvList(tabId, 'in', fromN, endN, null, (p, n) => log(`Gələn qaimələr alınır: ${n}...`)); const vs = new Set(voens);
    all.all.forEach(v => { if (seen.has(v.id)) return; const r = invRow(v, 'in'); if (vs.has(r.voen)) { seen.add(v.id); r._st = v.status; r._b18 = v.vat18; r._kind = v.kind; inv.push(r); } });
  } else {
    let k = 1; await Promise.all(Array.from({ length: 4 }, async () => { while (k < voens.length && !cancel) { const v = voens[k++]; const L = await apiInvList(tabId, 'in', fromN, endN, { senderTin: v }); take(L.all, v); done++; log(`Gələn qaimələr alınır: ${done} / ${voens.length} təchizatçı...`, false, { i: done, n: voens.length }); } }));
  }
  if (cancel) throw new Error('Dayandırıldı.');
  const invs = inv.filter(r => EV_OK.has(r._st) && +r.vat > 0 && EV_KINDS.has(r._kind)).map(r => ({ ...r, ...evSerNum(r.serial), vat: +r.vat, b18: +r._b18 > 0 ? +r._b18 : ev2(+r.vat / 0.18), off: 0, offBase: 0, offIn: [] }));
  // Təsdiqlənməmiş (düzəlişə/ləğvə göndərilmiş, təsdiq gözləyən) qaimələr — təyinatda göstərilibsə, səbəbi deyilir
  const pend = new Map(); inv.filter(r => !EV_OK.has(r._st) && !EV_GONE.has(r._st) && +r.vat > 0 && EV_KINDS.has(r._kind)).forEach(r => { const k = evSerNum(r.serial); pend.set(`${r.voen}|${k.num}`, { ...k, status: r.status }); });
  // Avans (və digər təqdim etmə olmayan) qaimələr — təyinatda göstərilibsə və ya VÖEN-də yalnız onlar varsa, səbəbi deyilir
  inv.filter(r => !EV_KINDS.has(r._kind) && !EV_GONE.has(r._st) && +r.vat > 0).forEach(r => { const k = evSerNum(r.serial); pend.set(`${r.voen}|${k.num}`, { ...k, status: r._kind === 'advanceInvoice' ? 'avans qaiməsidir — əvəzləşməyə salınmır' : 'təqdim etmə qaiməsi deyil — əvəzləşməyə salınmır' }); });
  const advV = new Set(inv.filter(r => r._kind === 'advanceInvoice' && !EV_GONE.has(r._st)).map(r => r.voen));
  // 3) Əvvəlki ayların bəyannamələrində (Əlavə 1) artıq əvəzləşdirilənlər
  log('Əvvəlki ƏDV bəyannamələri (Əlavə 1) oxunur...');
  const years = []; for (let y = histFrom; y <= py; y++) years.push(y);
  const { list } = await apiDeclList(tabId, years);
  const vatD = list.filter(d => d.taxCode === '_0300' || /^əlavə dəyər vergisi$/i.test(d.section.trim()));
  const best = {}; vatD.filter(x => !(skipKameral && x.kameral)).forEach(x => { const k = x.year * 12 + x.month - 1; if (k >= histFrom * 12 && k <= P && declBetter(x, best[k])) best[k] = x; });
  if (best[P]) notes.push(['Məlumat', `${best[P].period} üçün artıq bəyannamə var (№ ${best[P].docNo}). Onun Əlavə 1-i hesaba alınmadı — fayl bu dövr üçün yenidən yığıldı.`]);
  const sel = Object.keys(best).map(Number).filter(k => k < P).map(k => best[k]);
  const byKey = new Map(); invs.forEach(x => byKey.set(`${x.voen}|${x.ser}${x.num}`, x));
  const url = d => `/api/po/declaration/public/v1/calc/VAT_APPENDIX_1_REPORT_PERIOD_INVOICE?reg_number=${d.docNo}&offset=0&maxCount=1000`;
  let declErr = 0;
  for (let s = 0; s < sel.length && !cancel; s += 12) {
    const chunk = sel.slice(s, s + 12), out = await api(tabId, chunk.map(d => ({ u: url(d) })), 6);
    out.forEach((x, j) => {
      if (x.error) { declErr++; notes.push(['Xəta', `${chunk[j].period} bəyannaməsinin Əlavə 1-i oxunmadı — həmin ayın əvəzləşmələri nəzərə alınmadı`]); return; }
      let arr = []; try { arr = JSON.parse((x.data || {}).calcPartJson || '[]'); } catch (e) {}
      (Array.isArray(arr) ? arr : []).forEach(r => { const k = evSerNum(r.documentSerial, r.documentNumber), it = byKey.get(`${r.tin}|${k.ser}${k.num}`); if (it) { it.off += +r.paidVat || 0; it.offBase += +r.paidAmount || 0; it.offIn.push(chunk[j].period); } });
    });
    log(`Əvvəlki bəyannamələr: ${Math.min(s + 12, sel.length)} / ${sel.length}...`, false, { i: Math.min(s + 12, sel.length), n: sel.length });
  }
  if (cancel) throw new Error('Dayandırıldı.');
  invs.forEach(x => { x.rem = ev2(Math.max(0, x.vat - x.off)); x.left = x.rem; x.alloc = []; });
  // 4) Ödənişlərin qaimələrə paylanması: əvvəlcə təyinatda göstərilən qaimələr, qalan məbləğ — həmin VÖEN-in ən köhnə əvəzləşməyən qaimələri
  const byVoen = new Map(); invs.forEach(x => { if (!byVoen.has(x.voen)) byVoen.set(x.voen, []); byVoen.get(x.voen).push(x); });
  byVoen.forEach(a => a.sort((x, y) => x.dnum - y.dnum || x.num.localeCompare(y.num)));
  const allV = new Map(); inv.forEach(r => allV.set(r.voen, (allV.get(r.voen) || 0) + 1));
  const pays = payments.map(p => ({ ...p, left: ev2(p.vat), used: [] })).sort((a, b) => a.dnum - b.dnum || a.i - b.i);
  const give = (p, x, how) => { const t = ev2(Math.min(x.left, p.left)); if (t <= 0) return; x.left = ev2(x.left - t); p.left = ev2(p.left - t); x.alloc.push({ vat: t, how, date: p.date, i: p.i }); p.used.push(`${x.ser} ${x.num}`); };
  const missing = [];
  for (const p of pays) {
    const mine = byVoen.get(p.voen) || [];
    const refs = []; for (const r of p.refs || []) { const c = mine.filter(x => x.num === r.num && (!r.ser || x.ser === r.ser)); const c2 = c.length ? c : mine.filter(x => x.num === r.num); if (c2.length) c2.forEach(x => refs.includes(x) || refs.push(x)); else { const pd = pend.get(`${p.voen}|${r.num}`); if (pd) { p.pend = (p.pend || []).concat(`${pd.ser} ${pd.num} — ${pd.status}`); missing.push([p.date, p.voen, p.name, `${pd.ser} ${pd.num}`, p.i, pd.status]); } else if (r.strong) missing.push([p.date, p.voen, p.name, `${r.ser || ''} ${r.num}`.trim(), p.i]); } }
    p.refN = refs.length;
    refs.sort((a, b) => a.dnum - b.dnum).forEach(x => give(p, x, 'təyinatda göstərilib'));
  }
  for (const p of pays) { if (p.left <= 0.004) continue; for (const x of byVoen.get(p.voen) || []) { if (p.left <= 0.004) break; if (x.left > 0 && x.dnum <= endN) give(p, x, 'köhnə əvəzləşməyən qaimə'); } }
  // 5) Nəticə
  const rows = invs.filter(x => x.alloc.length).map(x => {
    const paid = ev2(x.alloc.reduce((t, a) => t + a.vat, 0)), cap = evFloor(Math.max(0, x.b18 - x.offBase)), full = x.left <= 0.01;
    // Qalıq tam bağlanırsa — qaimənin ƏDV-yə cəlb edilən məbləği (əvvəl əvəzləşən hissə çıxılmaqla); qəpik yuvarlaqlaşdırması onu aşmır
    const base = full ? cap : Math.min(evFloor(paid / 0.18), cap);
    return { ser: x.ser, num: x.num, voen: x.voen, name: x.name, date: x.date, dnum: x.dnum, invVat: x.vat, b18: x.b18, prev: ev2(x.off), paid, base, full, how: [...new Set(x.alloc.map(a => a.how))].join(', '), pays: [...new Set(x.alloc.map(a => a.date))].join(', ') }; }).sort((a, b) => a.dnum - b.dnum || a.num.localeCompare(b.num));
  const unalloc = pays.filter(p => p.left > (p.used.length ? 0.05 : 0.004)).map(p => ({ i: p.i, date: p.date, voen: p.voen, name: p.name, vat: p.vat, left: p.left, purpose: p.purpose,
    why: p.pend && !p.used.length ? (p.pend.some(x => /salınmır/.test(x)) ? `Təyinatdakı qaimə əvəzləşməyə salınmır: ${p.pend.join('; ')}` : `Qaimə hələ təsdiqlənməyib (${p.pend.join('; ')}) — təsdiqlənəndən sonra əvəzləşdirmək olar`) : !allV.get(p.voen) ? `Bu VÖEN-dən ${histFrom} ilindən bəri gələn qaimə yoxdur` : !(byVoen.get(p.voen) || []).length ? (advV.has(p.voen) ? 'Bu VÖEN-dən yalnız avans qaiməsi var — avans qaiməsi əvəzləşməyə salınmır, təqdim etmə qaiməsini gözlə' : 'Bu VÖEN-in qaimələri əvəzləşməyə yararlı deyil (ləğv, təsdiq gözləyir, təqdim etmə qaiməsi deyil)') : p.left < p.vat ? 'Ödəniş qaimələrin əvəzləşməyən qalığından çoxdur — artıq hissə əvəzləşməyə salınmadı' : 'Bu VÖEN-in bütün qaimələri artıq tam əvəzləşib (avans ola bilər)' }));
  const sec = Math.round((Date.now() - t0) / 1000);
  return { rows, unalloc, missing, notes, stats: { pays: pays.length, payVat: ev2(pays.reduce((t, p) => t + p.vat, 0)), inv: invs.length, decl: sel.length, declErr, sec } };
}

// ---------------- Maya dəyəri: seçilmiş GB-lərə aid xərc qaimələri (gömrük panelindən) ----------------
// gbs: [{ no, dnum, plates: [], declarantCode }]. Qaimə sətirləri GB nömrəsinə (sətirdə və ya qeyddə) və maşın nömrəsinə görə bağlanır.
const GB_DGK = '1802077241';    // Gömrük Komitəsinin qaimələri: bu ödənişlər artıq GB-nin ödənişlər bölməsindədir
const GB_SERV = /gömrük|gomruk|broker|bəyannam|daşı|dasi|nəql|neql|logist|ekspedi|trans|terminal|anbar|saxlan|sığorta|sigorta|yük|cargo|kargo|freight|shipping|konteyner|container/i;
const dShift = (n, d) => { const s = String(n), x = new Date(Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8) + d)); return x.getUTCFullYear() * 10000 + (x.getUTCMonth() + 1) * 100 + x.getUTCDate(); };
const dDiff = (a, b) => { const t = n => { const s = String(n); return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8)); }; return Math.round((t(a) - t(b)) / 864e5); };
function gbMatchItem(text, cmt, dnum, gbs) {
  const runs = s => (String(s || '').match(/\d{10,14}/g) || []);
  const hit = r => gbs.filter(g => r === g.no || r === g.no.replace(/^0+/, '') || (r.length >= 12 && g.no.endsWith(r)));
  const share = rs => { const out = {}; const longRs = rs.filter(r => r.length >= 12); if (!longRs.length) return null; let any = false;
    longRs.forEach(r => { const h = hit(r)[0]; if (h) { out[h.no] = (out[h.no] || 0) + 1 / longRs.length; any = true; } }); return { out, any }; };
  let s = share(runs(text));
  if (s) return s.any ? { gb: s.out, why: 'GB nömrəsi' } : { other: true };             // sətirdə başqa GB nömrəsi var
  s = share(runs(cmt));
  if (s) return s.any ? { gb: s.out, why: 'GB nömrəsi (qeyddə)' } : { other: true };
  const T = (String(text || '') + ' ' + String(cmt || '')).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const pl = gbs.filter(g => (g.plates || []).some(p => p.length >= 5 && T.includes(p)) && dDiff(dnum, g.dnum) >= -10 && dDiff(dnum, g.dnum) <= 40)
    .sort((a, b) => Math.abs(dDiff(dnum, a.dnum)) - Math.abs(dDiff(dnum, b.dnum)));
  if (pl.length) return { gb: { [pl[0].no]: 1 }, why: 'maşın nömrəsi ' + pl[0].plates.find(p => T.includes(p)) };
  return null;
}
async function gbExpenses(tabId, gbs) {
  const ds = gbs.map(g => g.dnum).filter(Boolean); if (!ds.length) throw new Error('GB tarixi yoxdur');
  const today = +new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const fromN = dShift(Math.min(...ds), -10), toN = Math.min(today, dShift(Math.max(...ds), 45));
  const L = await apiInvList(tabId, 'in', fromN, toN, null);
  const decl = new Set(gbs.map(g => String(g.declarantCode || '').replace(/\D/g, '')).filter(Boolean));
  const all = L.all.filter(v => !/canceled|deleted/i.test(v.status || '') && !/^return/.test(v.kind || '') && v.kind !== 'advanceInvoice');
  const pre = all.filter(v => { const s = v.sender || {}, tin = String(s.tin || s.pin || '');
    return (tin === GB_DGK || decl.has(tin) || GB_SERV.test(s.name || '') || GB_SERV.test(v.invoiceComment || '') || /\d{12,14}/.test((v.invoiceComment || '') + ' ' + (v.invoiceComment2 || ''))); });
  const sel = pre.slice(0, 300), out = [];
  for (let s = 0; s < sel.length; s += 40) {
    const chunk = sel.slice(s, s + 40), res = await api(tabId, chunk.map(v => ({ u: `/api/po/invoice/public/v2/invoice/${encodeURIComponent(v.id)}?sourceSystem=${encodeURIComponent(v.sourceSystem || 'avis')}` })), 8);
    res.forEach((x, j) => {
      const v = chunk[j], d = x.data || {}, snd = v.sender || {}, tin = String(snd.tin || snd.pin || ''), dnum = isoN(v.createdAt);
      const cmt = [d.invoiceComment || v.invoiceComment, d.invoiceComment2 || v.invoiceComment2].filter(Boolean).join(' · ');
      const items = (Array.isArray(d.items) ? d.items : []).map(it => {
        const net = Math.round(((+it.cost || 0) + (+it.excise || 0) + (+it.roadTax || 0)) * 100) / 100, vat = Math.round((+it.vat18 || 0) * 0.18 * 100) / 100;
        const m = gbMatchItem(it.productName, cmt, dnum, gbs);
        // Gömrük Komitəsinin qaiməsi: GB-dəki 75/85 kodlu ödənişlə eyni ola bilər — avtomatik seçilmir
        return { name: it.productName || '', net, vat, gb: m && m.gb || null, why: m && m.why || '', other: !!(m && m.other), dup: tin === GB_DGK };
      }).filter(it => !it.other && (it.net || it.vat));
      if (!items.length) return;
      const matched = items.some(it => it.gb), cand = !matched && (decl.has(tin) || GB_SERV.test(snd.name || '') || items.some(it => GB_SERV.test(it.name)));
      if (!matched && !cand) return;
      out.push({ id: v.id, serial: v.serialNumber || '', date: isoDmy(v.createdAt).slice(0, 10), dnum, voen: tin, name: snd.name || '', comment: cmt, items, broker: decl.has(tin) });
    });
  }
  out.sort((a, b) => a.dnum - b.dnum);
  return { invoices: out, from: fromN, to: toN, scanned: all.length, checked: sel.length, more: pre.length > sel.length };
}
