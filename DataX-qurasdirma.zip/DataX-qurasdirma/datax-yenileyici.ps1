﻿# DataX Advisory: quraşdırma və avtomatik yeniləyici (Windows, PowerShell 5.1)
# -Install: əlavəni "%LOCALAPPDATA%\DataXAdvisory\extension" qovluğuna qurur və hər 2 saatdan bir işləyən tapşırıq yaradır.
# Parametrsiz: yeniliyi yoxlayır; varsa, imzanı və yoxlama cəmini yoxlayıb faylları yeniləyir. Chrome-dakı əlavə özünü yenidən yükləyir.
# -SetChannel test|stable: bu kompüterin yeniləmə kanalını dəyişir (test — yeni versiyalar əvvəlcə bura gəlir)
param([switch]$Install, [string]$Source = '', [string]$SetChannel = '')
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}

$AppDir  = Join-Path $env:LOCALAPPDATA 'DataXAdvisory'
$ExtDir  = Join-Path $AppDir 'extension'
$LogFile = Join-Path $AppDir 'yenileme.log'
$TaskName = 'DataX Advisory yenileme'

function Write-Log([string]$m) {
  Write-Host $m
  try {
    New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
    Add-Content -Path $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m) -Encoding UTF8
    if ((Get-Item $LogFile).Length -gt 200KB) { $t = Get-Content $LogFile -Tail 300 -Encoding UTF8; Set-Content $LogFile $t -Encoding UTF8 }
  } catch {}
}
function ConvertFrom-B64Url([string]$s) {
  $s = $s.Replace('-', '+').Replace('_', '/')
  switch ($s.Length % 4) { 2 { $s += '==' } 3 { $s += '=' } }
  return [Convert]::FromBase64String($s)
}
function To-B64([string]$s) { return [Convert]::ToBase64String((ConvertFrom-B64Url $s)) }
function Get-ExtVersion([string]$manifest) {
  if (-not (Test-Path -LiteralPath $manifest)) { return [version]'0.0' }
  $j = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json
  return [version]$j.version
}
function Get-Config([string]$dir) {
  $f = Join-Path $dir 'ayarlar.json'
  if (-not (Test-Path -LiteralPath $f)) { throw "ayarlar.json tapılmadı: $f" }
  $c = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($c.extDir) { $script:ExtDir = [string]$c.extDir }   # əlavə başqa qovluqdan yüklənibsə, o qovluq yenilənir
  return $c
}
# Chrome-un DataX-i hansı qovluqdan yüklədiyini tapır (yalnız bu kompüterdə Chrome ayarlarını oxuyur)
function Find-ChromeDataX {
  $root = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
  $found = @()
  if (-not (Test-Path -LiteralPath $root)) { return @() }
  foreach ($prof in (Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)) {
    foreach ($pf in 'Secure Preferences', 'Preferences') {
      $f = Join-Path $prof.FullName $pf
      if (-not (Test-Path -LiteralPath $f)) { continue }
      $txt = ''; try { $txt = [IO.File]::ReadAllText($f) } catch { continue }
      foreach ($m in [regex]::Matches($txt, '"path"\s*:\s*"((?:[^"\\]|\\.)+)"')) {
        $p = $m.Groups[1].Value.Replace('\\', '\').Replace('\/', '/')
        if (-not [IO.Path]::IsPathRooted($p)) { continue }
        $man = Join-Path $p 'manifest.json'
        if (-not (Test-Path -LiteralPath $man)) { continue }
        try { $mj = Get-Content -LiteralPath $man -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
        if ([string]$mj.name -like 'DataX*') { $found += [pscustomobject]@{ Path = $p; Version = [version]$mj.version } }
      }
    }
  }
  return @($found | Sort-Object Version -Descending | Select-Object -ExpandProperty Path -Unique)
}
function Test-Signature($cfg, [string]$text, [string]$sig) {
  $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
  $rsa.FromXmlString('<RSAKeyValue><Modulus>' + (To-B64 $cfg.publicKey.n) + '</Modulus><Exponent>' + (To-B64 $cfg.publicKey.e) + '</Exponent></RSAKeyValue>')
  $sha = New-Object System.Security.Cryptography.SHA256CryptoServiceProvider
  return $rsa.VerifyData([Text.Encoding]::UTF8.GetBytes($text), $sha, (ConvertFrom-B64Url $sig))
}
# Zip-i açır və faylları əlavənin qovluğuna köçürür; manifest.json ən sonda yazılır (əlavə yeniliyi bundan bilir)
function Install-Zip([string]$zip, $expect) {
  $tmp = Join-Path $env:TEMP ('datax-' + [guid]::NewGuid().ToString('N'))
  try {
    Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force
    $man = Join-Path $tmp 'manifest.json'
    $v = Get-ExtVersion $man
    if ($v -eq [version]'0.0') { throw 'Zip-də manifest.json yoxdur' }
    if ($expect -and $v -ne $expect) { throw "Zip içindəki versiya ($v) gözlənilən ($expect) deyil" }
    New-Item -ItemType Directory -Path $ExtDir -Force | Out-Null
    Get-ChildItem -LiteralPath $tmp -Recurse -File | Where-Object { $_.FullName -ne $man } | ForEach-Object {
      $dst = Join-Path $ExtDir ($_.FullName.Substring($tmp.Length).TrimStart('\'))
      New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
      Copy-Item -LiteralPath $_.FullName -Destination $dst -Force
    }
    Copy-Item -LiteralPath $man -Destination (Join-Path $ExtDir 'manifest.json') -Force
    return $v
  } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}
function Get-Channel($cfg) { if ([string]$cfg.kanal -eq 'test') { return 'test' } return 'stable' }
# Əlavə hansı kanalda olduğunu bu fayldan bilir (TEST nişanı)
function Write-ChannelMark($cfg) {
  try {
    $f = Join-Path $ExtDir 'kanal.json'
    if ((Get-Channel $cfg) -eq 'test') { if (Test-Path -LiteralPath $ExtDir) { Set-Content -LiteralPath $f -Value '{"kanal":"test"}' -Encoding ASCII } }
    elseif (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force }
  } catch {}
}
function Invoke-Update($cfg) {
  if (-not $cfg.updateUrl) { Write-Log 'Yenilik ünvanı (updateUrl) yazılmayıb, yoxlama edilmir.'; return }
  $base = ([string]$cfg.updateUrl).TrimEnd('/')
  $wc = New-Object System.Net.WebClient
  $wc.Encoding = [Text.Encoding]::UTF8
  $t = [DateTime]::UtcNow.Ticks
  $vj = $wc.DownloadString($base + '/version.json?t=' + $t) | ConvertFrom-Json
  if ((Get-Channel $cfg) -eq 'test') {
    # Test kanalı: test.json-dakı versiya daha yenidirsə onu götür
    try { $tj = $wc.DownloadString($base + '/test.json?t=' + $t) | ConvertFrom-Json; if ($tj.version -and [version]$tj.version -gt [version]$vj.version) { $vj = $tj } } catch {}
  }
  Write-ChannelMark $cfg
  $cur = Get-ExtVersion (Join-Path $ExtDir 'manifest.json')
  if ([version]$vj.version -le $cur) { Write-Log "Yenilik yoxdur (quraşdırılıb: $cur)."; return }
  if ($vj.file -notmatch '^[A-Za-z0-9._-]+\.zip$') { throw 'version.json-da fayl adı düzgün deyil' }
  if (-not (Test-Signature $cfg ('DATAX|' + $vj.version + '|' + $vj.file + '|' + $vj.sha256) $vj.sig)) { throw 'İmza düzgün deyil: yenilik rədd edildi' }
  $zip = Join-Path $env:TEMP ('datax-' + [guid]::NewGuid().ToString('N') + '.zip')
  try {
    $wc.DownloadFile($base + '/' + $vj.file, $zip)
    $h = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
    if ($h -ne ([string]$vj.sha256).ToLower()) { throw 'Faylın yoxlama cəmi uyğun deyil: yenilik rədd edildi' }
    $v = Install-Zip $zip ([version]$vj.version)
    Write-ChannelMark $cfg
    Write-Log "Yeniləndi: $cur -> $v ($(Get-Channel $cfg) kanalı)"
  } finally { Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue }
}
function Register-UpdateTask {
  $vbs = Join-Path $AppDir 'gizli-isle.vbs'
  $ps  = Join-Path $AppDir 'datax-yenileyici.ps1'
  try {
    $action   = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument ('"' + $vbs + '" "' + $ps + '"')
    $trigger  = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Hours 2) -RepetitionDuration (New-TimeSpan -Days 3650)
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
    Write-Log 'Avtomatik yeniləmə tapşırığı yaradıldı (hər 2 saatdan bir).'
  } catch {
    Write-Log ('Tapşırıq yaradılmadı: ' + $_.Exception.Message)
  }
}

try {
  if ($SetChannel) {
    # Kanalı dəyiş: skripti yerinə köçür, ayarlar.json-a yaz, dərhal yoxla
    if ($SetChannel -notin @('test', 'stable')) { throw 'Kanal test və ya stable olmalıdır' }
    $here = Split-Path -Parent $PSCommandPath
    $fresh = -not (Test-Path -LiteralPath (Join-Path $AppDir 'ayarlar.json'))
    New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
    if ($here -and ((Resolve-Path $here).Path.TrimEnd('\') -ne (Resolve-Path $AppDir).Path.TrimEnd('\'))) {
      Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $AppDir 'datax-yenileyici.ps1') -Force
      foreach ($f in 'gizli-isle.vbs') { if (Test-Path -LiteralPath (Join-Path $here $f)) { Copy-Item -LiteralPath (Join-Path $here $f) -Destination $AppDir -Force } }
      if ($fresh) { if (-not (Test-Path -LiteralPath (Join-Path $here 'ayarlar.json'))) { throw 'ayarlar.json bu qovluqda yoxdur' }; Copy-Item -LiteralPath (Join-Path $here 'ayarlar.json') -Destination $AppDir -Force }
    }
    $cfg = Get-Config $AppDir
    # Əlavə adi yerdə (AppData) deyilsə — Chrome-un yüklədiyi qovluğu tap və onu yenilə
    if (-not (Test-Path -LiteralPath (Join-Path $ExtDir 'manifest.json'))) {
      $dirs = @(Find-ChromeDataX)
      if (-not $dirs.Count) { throw 'Chrome-da DataX tapılmadı. chrome://extensions səhifəsində DataX-in yükləndiyi qovluğu yoxla.' }
      $script:ExtDir = $dirs[0]
      $cfg | Add-Member -NotePropertyName extDir -NotePropertyValue $ExtDir -Force
      Write-Log ('DataX bu qovluqdan yüklənir: ' + $ExtDir)
    }
    if ($fresh) { Register-UpdateTask }
    $cfg | Add-Member -NotePropertyName kanal -NotePropertyValue $SetChannel -Force
    ($cfg | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath (Join-Path $AppDir 'ayarlar.json') -Encoding UTF8
    Write-Log ('Yeniləmə kanalı: ' + $SetChannel)
    Write-ChannelMark $cfg
    try { Invoke-Update $cfg } catch { Write-Log ('Yenilik yoxlanmadı: ' + $_.Exception.Message) }
    Write-Host ''
    if ($SetChannel -eq 'test') { Write-Host 'HAZIRDIR: bu kompüter TEST kanalındadır — yeni versiyalar əvvəlcə bura gələcək.' -ForegroundColor Green }
    else { Write-Host 'HAZIRDIR: bu kompüter adi kanala qaytarıldı.' -ForegroundColor Green }
    Write-Host 'Chrome-da DataX-i bir dəfə yenilə (chrome://extensions → ⟳) və ya Chrome-u bağlayıb aç.'
  } elseif ($Install) {
    if (-not $Source) { $Source = $PSScriptRoot }
    $Source = $Source.TrimEnd('\')
    Write-Log 'DataX Advisory quraşdırılır...'
    New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
    foreach ($f in 'datax-yenileyici.ps1', 'ayarlar.json', 'gizli-isle.vbs') { Copy-Item -LiteralPath (Join-Path $Source $f) -Destination $AppDir -Force }
    $bundled = Get-ChildItem -LiteralPath $Source -Filter 'datax-advisory*.zip' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $bundled) { throw 'Qovluqda datax-advisory*.zip faylı yoxdur' }
    $v = Install-Zip $bundled.FullName $null
    Write-Log "Əlavə quraşdırıldı: versiya $v"
    Register-UpdateTask
    try { Invoke-Update (Get-Config $AppDir) } catch { Write-Log ('Yenilik yoxlanmadı: ' + $_.Exception.Message) }
    try { Set-Clipboard -Value $ExtDir } catch {}
    Write-Host ''
    Write-Host 'HAZIRDIR. İndi Chrome-da:' -ForegroundColor Green
    Write-Host '  1. Ünvan sətrinə chrome://extensions yaz'
    Write-Host '  2. Sağ yuxarıda "Developer mode" (Tərtibatçı rejimi) düyməsini aç'
    Write-Host '  3. "Load unpacked" düyməsinə bas və bu qovluğu seç (ünvan kopyalanıb, Ctrl+V ilə yapışdıra bilərsən):'
    Write-Host ('     ' + $ExtDir) -ForegroundColor Cyan
    Write-Host '  4. Chrome-un sağ yuxarısında DataX ikonuna bas, telefon nömrəni yaz və "Daxil ol" — 1 günlük sınaq özü başlayacaq.'
    Start-Process explorer.exe $AppDir
  } else {
    Invoke-Update (Get-Config $AppDir)
  }
} catch {
  Write-Log ('XƏTA: ' + $_.Exception.Message)
  if ($Install) { exit 1 }
}
