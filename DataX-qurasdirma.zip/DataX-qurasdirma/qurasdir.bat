@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0datax-yenileyici.ps1" -Install -Source "%~dp0."
echo.
pause
