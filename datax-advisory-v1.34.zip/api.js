// =====================================================================================
// e-taxes-in öz məlumat xidməti (API). Sayt səhifələri bu ünvanlardan JSON alır; extension da
// istifadəçinin açıq sessiyası ilə eyni ünvanlara müraciət edir. Səhifəyə klik, çərçivə lazım deyil.
// Xidmət cavab verməsə, köhnə üsul (səhifəni oxumaq) işə düşür.
// =====================================================================================

// Səhifədə (MAIN world) işləyir: sorğuları saytın öz giriş açarı ilə göndərir
async function etApi(reqs, conc) {
  const key = () => localStorage.getItem('aztax-jwt');
  if (!key()) return { error: 'sessiya tapılmadı' };
  const wait = ms => new Promise(z => setTimeout(z, ms));
  const one = async r => {
    for (let a = 0; a < 3; a++) {
      try {
        const res = await fetch(r.u, { method: r.m || 'GET', credentials: 'include',
          headers: { 'x-authorization': 'Bearer ' + key(), accept: 'application/json, text/plain, */*', ...(r.b ? { 'content-type': 'application/json' } : {}) },
          body: r.b ? JSON.stringify(r.b) : undefined });
        if (res.status === 401) return { st: 401, error: 'HTTP 401' };
        if (res.status >= 500 || res.status === 429) { await wait(700 * (a + 1)); if (a < 2) continue; }
        const t = await res.text();
        if (!res.ok) return { st: res.status, error: 'HTTP ' + res.status + (t ? ': ' + t.slice(0, 160) : '') };
        try { return { st: res.status, data: t ? JSON.parse(t) : null }; } catch (e) { return { st: res.status, error: 'cavab JSON deyil' }; }
      } catch (e) { if (a === 2) return { error: String(e && e.message || e) }; await wait(500); }
    }
    return { error: 'cavab yoxdur' };
  };
  const out = new Array(reqs.length); let i = 0;
  await Promise.all(Array.from({ length: Math.max(1, Math.min(conc || 6, reqs.length)) }, async () => { while (i < reqs.length) { const k = i++; out[k] = await one(reqs[k]); } }));
  return { out };
}

const apiErr = m => Object.assign(new Error('API: ' + m), { apiFail: true });
const SESSION_END = 'e-taxes sessiyası bitib. Saytda səhifəni yenilə, yenidən daxil ol və təkrar başlat.';
async function api(tabId, reqs, conc = 6) {
  if (!reqs.length) return [];
  let r;
  try { r = (await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: etApi, args: [reqs, conc] }))[0].result; }
  catch (e) { throw apiErr('skript: ' + e.message); }
  if (!r) throw apiErr('cavab yoxdur');
  if (r.error) throw apiErr(r.error);
  if (r.out.some(x => x && x.st === 401)) throw apiErr('HTTP 401 (sessiya qəbul edilmədi)');
  return r.out;
}
async function api1(tabId, u, m, b) { const [x] = await api(tabId, [{ u, m, b }], 1); if (x.error) throw apiErr(x.error); return x.data; }
// Əvvəl API, alınmasa köhnə üsul
async function apiFirst(name, apiFn, domFn, m) {
  try { return await apiFn(m); }
  catch (e) {
    if (!e.apiFail || cancel) throw e;
    await chrome.storage.local.set({ apiXeta: { funksiya: name, xeta: mask(e.message), t: Date.now() } });
    log('Birbaşa oxuma alınmadı, səhifə üsulu ilə davam edilir...');
    return domFn(m);
  }
}
const run = m => apiFirst('elave1', runVatApi, runVatDom, m);
const runItems = m => apiFirst('mallar', runItemsApi, runItemsDom, m);
const runDocs = m => apiFirst('altSenedler', runDocsApi, runDocsDom, m);
const runDecls = m => apiFirst('beyannameler', runDeclsApi, runDeclsDom, m);

const MONTHS_UP = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
const ord = n => n + (n === 3 || n === 4 ? '-cü' : '-ci');
const p2 = n => String(n).padStart(2, '0');
const isoDmy = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}):(\d{2}))?/); return m ? `${m[3]}.${m[2]}.${m[1]}` + (m[4] ? ` ${m[4]}:${m[5]}:${m[6]}` : '') : String(s || ''); };
const isoN = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? +(m[1] + m[2] + m[3]) : 0; };
const nstr = v => v == null || v === '' || isNaN(+v) ? '' : String(Math.round(+v * 10000) / 10000);          // Excel üçün nöqtəli
const ncom = v => v == null || v === '' || isNaN(+v) ? '' : String(Math.round(+v * 10000) / 10000).replace('.', ',');   // hesabat üçün vergüllü

// ---------------- Bəyannamə siyahısı ----------------
const D_TYPE = { CURRENT: 'Cari', CLARIFYING: 'Dəqiqləşdirilmiş', CAMERAL: 'Kameral', CAMERAL_AUDIT: 'Kameral', KAMERAL: 'Kameral' };
const D_STAT = { CONFIRMED: 'Təsdiqlənib', SENT: 'Göndərilib', SUBMITTED: 'Göndərilib', REJECTED: 'İmtina edilib', DRAFT: 'Qaralama', ON_REVIEW: 'Baxılır' };
function apiDecl(x, listYear) {
  const p = x.reportingPeriod || {}, y = +p.year || +String(x.registrationDate || '').slice(0, 4) || 0, m = +p.month || 1, t = String(p.type || '').toUpperCase();
  let a = 1, b = 12, period = `${y}`;
  if (t === 'MONTH') { a = b = m; period = `${MONTHS_UP[m - 1] || m} ${y}`; }
  else if (t === 'QUARTER') { const q = Math.floor((m - 1) / 3) + 1; a = q * 3 - 2; b = q * 3; period = `${ord(q)} rüb ${y}`; }
  else if (/HALF/.test(t)) { const h = m > 6 ? 2 : 1; a = h * 6 - 5; b = h * 6; period = `${ord(h)} yarımil ${y}`; }
  return { docNo: String(x.registrationNumber || x.id), period, type: D_TYPE[x.declarationType] || x.declarationType || '', date: isoDmy(String(x.registrationDate || x.submissionDate || '').slice(0, 10)),
    status: D_STAT[x.declarationStatus] || x.declarationStatus || '', amount: x.taxAmount == null ? '' : ncom(x.taxAmount), kameral: !!x.cameralAudit || /CAMERAL|KAMERAL/i.test(x.declarationType || ''), ver: x.obligationTypeVersion || '', section: x.taxName || '', taxCode: x.taxCode || '',
    last: x.lastClarifying || '', ts: Date.parse(x.submissionDate || x.registrationDate || '') || 0, year: y, month: a, pr: { y, a, b }, listYear, rawStatus: x.declarationStatus || '' };
}
async function apiDeclList(tabId, years) {
  const out = await api(tabId, years.map(y => ({ u: `/api/po/declaration/public/v1/declaration/list?year=${y}` })), 3);
  const by = new Map(), notes = [];
  out.forEach((x, i) => {
    const arr = x && x.data && x.data.declarations;
    if (!Array.isArray(arr)) { notes.push(`${years[i]}: ${x && x.error ? mask(x.error) : 'gözlənilməz cavab'}`); return; }
    arr.forEach(w => { const d = w && (w.declaration || w); if (d && (d.registrationNumber || d.id)) { const v = apiDecl(d, years[i]); if (!by.has(v.docNo)) by.set(v.docNo, v); } });
  });
  if (notes.length === years.length) throw apiErr('bəyannamə siyahısı: ' + notes.join('; '));
  return { list: [...by.values()].filter(d => !/DRAFT|DELETE|CANCEL|REJECT/i.test(d.rawStatus)), notes };
}
// Eyni dövr üçün ən son bəyannamə: saytın "son dəqiqləşmə" işarəsi, sonra göndərilmə vaxtı
const declBetter = (x, b) => { if (!b) return true; const r = d => d.last === 'LAST' ? 1 : 0; return r(x) !== r(b) ? r(x) > r(b) : x.ts !== b.ts ? x.ts > b.ts : x.docNo > b.docNo; };
const yearsFor = (fy, ty) => { const nowY = new Date().getFullYear(), ys = []; for (let y = fy; y <= Math.min(ty + 1, nowY); y++) ys.push(y); return ys.length ? ys : [fy]; };

// ---------------- FUNKSİYA 1: ƏDV Əlavə 1 qaimələri ----------------
const A1_HDR = ['Sıra №', 'Satıcının VÖEN-i', 'Qaimənin seriyası', 'Qaimənin nömrəsi', 'Qaimənin tarixi', 'Ümumi məbləğ (ƏDV-siz)', 'ƏDV məbləği', 'Ödənilmiş məbləğ', 'Ödənilmiş ƏDV məbləği'];
async function runVatApi({ tabId, from, to, skipKameral }) {
  const t0 = Date.now();
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), years = yearsFor(fy, ty);
  log('Bəyannamələr siyahısı alınır...');
  const { list, notes: yearNotes } = await apiDeclList(tabId, years);
  const vat = list.filter(d => d.taxCode === '_0300' || /^əlavə dəyər vergisi$/i.test(d.section.trim()));
  const inRange = vat.filter(x => { const v = x.year * 12 + x.month; return v >= fy * 12 + fm && v <= ty * 12 + tm; });
  const best = {};
  inRange.filter(x => !(skipKameral && x.kameral)).forEach(x => { const k = x.year * 12 + x.month; if (declBetter(x, best[k])) best[k] = x; });
  const sel = Object.values(best).sort((a, b) => a.year * 12 + a.month - (b.year * 12 + b.month));
  const baseReport = { versiya: VERSION, funksiya: 'elave1', rejim: 'api', iller: years, ilQeydleri: yearNotes, siyahi: { hamisi: list.length, edv: vat.length, araliqda: inRange.length, kameral: inRange.filter(x => x.kameral).length } };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş aylarda ƏDV bəyannaməsi tapılmadı.');

  const summaries = [], rows = [], notes = []; let done = 0, ok = 0, skip = 0, err = 0, total = 0;
  const short = t => t === 'Cari' ? 'Cari' : /^Dəqiq/.test(t) ? 'Dəqiq.' : t;
  const report = () => log(`${done} / ${sel.length} bəyannamə oxundu.`, false, { i: done, n: sel.length, summary: summaries.filter(Boolean) });
  report();
  const url = (d, off) => `/api/po/declaration/public/v1/calc/VAT_APPENDIX_1_REPORT_PERIOD_INVOICE?reg_number=${d.docNo}&offset=${off}&maxCount=1000`;
  const parts = new Array(sel.length).fill(null).map(() => []), errs = new Array(sel.length).fill(null);
  for (let s = 0; s < sel.length && !cancel; s += 12) {
    const chunk = sel.slice(s, s + 12), out = await api(tabId, chunk.map(d => ({ u: url(d, 0) })), 6);
    for (let j = 0; j < chunk.length; j++) {
      const i = s + j, x = out[j];
      if (x.error) { errs[i] = x.error; continue; }
      let arr; try { arr = JSON.parse((x.data || {}).calcPartJson || '[]'); } catch (e) { errs[i] = 'format'; continue; }
      if (!Array.isArray(arr)) { errs[i] = 'format'; continue; }
      parts[i] = arr;
      for (let off = 1000; arr.length === 1000 && off < 50000; off += 1000) {                  // çox böyük siyahı: davamı
        const y = await api1(tabId, url(chunk[j], off)); arr = JSON.parse((y || {}).calcPartJson || '[]'); parts[i].push(...arr);
      }
    }
    if (out.every(x => x.error) && s === 0) throw apiErr('Əlavə 1: ' + out[0].error);
    for (let j = 0; j < chunk.length; j++) {
      const i = s + j, d = sel[i], arr = parts[i];
      if (errs[i]) { err++; summaries[i] = { p: d.period, k: short(d.type), note: 'oxunmadı' }; notes.push(['Xəta', d.period + ' / ' + d.type, d.docNo, mask(errs[i])]); }
      else if (!arr.length) { skip++; summaries[i] = { p: d.period, k: short(d.type), note: 'Əlavə 1 yoxdur' }; notes.push(['Məlumat', d.period + ' / ' + d.type, d.docNo, 'Əlavə 1 boşdur və ya açıq deyil, keçildi']); }
      else {
        ok++; total += arr.length;
        arr.sort((a, b) => (a.rowOrder || 0) - (b.rowOrder || 0)).forEach((r, k) => rows.push([d.period, d.type, d.docNo, k + 1, r.tin || '', r.documentSerial || '', r.documentNumber || '', isoDmy(r.documentDate), nstr(r.amount), nstr(r.vat), nstr(r.paidAmount), nstr(r.paidVat)]));
        summaries[i] = { p: d.period, k: short(d.type), c: arr.length, t: arr.reduce((a, r) => a + (+r.amount || 0), 0), v: arr.reduce((a, r) => a + (+r.vat || 0), 0) };
      }
      done++;
    }
    report();
  }
  yearNotes.forEach(n => notes.push(['Xəbərdarlıq', n.split(':')[0] + '-ci il', '', 'Bu ilin siyahısı alınmadı: ' + n.split(': ')[1]]));
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan aylar fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...baseReport, saniye: sec, secilen: sel.length, oxundu: ok, elave1Yox: skip, xeta: err, xetalar: [...new Set(errs.filter(Boolean).map(mask))].slice(0, 5) } });
  await saveXlsx(`DataX-elave1-${from}_${to}.xlsx`, [
    { name: 'Əlavə 1 qaimələri', header: ['Dövr', 'Növ', 'Sənəd nömrəsi', ...A1_HDR], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Bəyannamə', 'Sənəd nömrəsi', 'Qeyd'], rows: notes, numeric: false }]);
  const ps = [`${ok} bəyannamədən ${total} qaimə`]; if (skip) ps.push(`${skip} bəyannamədə Əlavə 1 yoxdur`); if (err) ps.push(`${err} bəyannamə oxunmadı`);
  log((err || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san): ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true, { i: sel.length, n: sel.length, summary: summaries.filter(Boolean), hasErrors: !!err });
}

// ---------------- Qaimələr ----------------
const INV_STATUS = { approved: 'Təsdiqləndi', cancelationRefused: 'Təsdiqləndi', correctionRefused: 'Təsdiqləndi', onApproval: 'Təsdiq gözləyir', updateApproval: 'Düzəliş edildi',
  updateRequested: 'Düzəlişə qaytarıldı', cancelRequested: 'Ləğvə göndərildi', approvedBySystem: 'Sistem tərəfindən təsdiqləndi', onApprovalEdited: 'Düzəlişə göndərildi',
  canceled: 'Ləğv edildi', cancelled: 'Ləğv edildi', deleted: 'Silindi', deletedBySystem: 'Sistem tərəfindən silindi', deactivated: 'Passiv' };
const INV_KIND = { defaultInvoice: 'Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura',
  agent: 'Malların, işlərin və xidmətlərin vəkalətverən (komitent) tərəfindən agentə (komisyonçuya) verilməsi barədə elektron qaimə-faktura',
  resale: 'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin alıcısına (subagentə) təqdim edilməsi barədə elektron qaimə-faktura',
  recycling: 'Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura',
  taxCodex163: 'Qaytarma istisna olmaqla VM-in 163-cü maddəsinə əsasən dəqiqləşdirilməsi barədə elektron qaimə-faktura',
  taxCodex177_5: 'VM-in 177.5-ci maddəsinə əsasən təqdim edilməsi barədə elektron qaimə-faktura',
  returnInvoice: 'Malların qaytarılması barədə elektron qaimə-faktura',
  returnByAgent: 'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin vəkalətverənə (komitentə) qaytarılması barədə elektron qaimə-faktura',
  returnRecycled: 'Emal prosesi keçmiş, yaxud saxlamaya verilmiş malların qaytarılması barədə elektron qaimə-faktura',
  exportNoteInvoice: 'Malların ixrac qeydi ilə satışı barədə elektron qaimə-faktura',
  exciseGoodsTransfer: 'Aksizli malların (neft məhsulları istisna olmaqla) təsərrüfatdaxili yerdəyişməsi barədə elektron qaimə-faktura',
  advanceInvoice: 'Alınmış avans ödənişləri barədə elektron qaimə-faktura',
  mtkInvoice: 'Yaşayış və qeyri-yaşayış sahələrinə görə ödənilmiş əlavə dəyər vergisinin qaytarılması' };
const ST_MAIN = ['approved', 'onApproval', 'updateApproval', 'updateRequested', 'cancelRequested', 'approvedBySystem', 'onApprovalEdited', 'deactivated', 'cancelationRefused', 'correctionRefused'];
const ST_GONE = ['canceled', 'deleted', 'deletedBySystem'];
const KINDS = ['defaultInvoice', 'agent', 'resale', 'recycling', 'taxCodex163', 'taxCodex177_5', 'returnInvoice', 'returnByAgent', 'returnRecycled', 'exportNoteInvoice', 'exciseGoodsTransfer', 'advanceInvoice'];
const ITEM_HDR = ['Sıra №', 'Malın kodu', 'Malın adı', 'Təsnifat üzrə adı', 'Barkod', 'Ölçü vahidi', 'Miqdarı', 'Vahidinin qiyməti', 'Cəmi məbləğ', 'Aksiz dərəcəsi', 'Aksiz məbləği',
  'ƏDV-yə 18% cəlb edilən', 'ƏDV-yə cəlb edilməyən', 'ƏDV-yə 0% cəlb edilən', 'ƏDV-dən azad', 'Yol vergisi', 'ƏDV məbləği', 'Yekun məbləğ'];
const dmyDash = n => { const s = String(n); return `${s.slice(6, 8)}-${s.slice(4, 6)}-${s.slice(0, 4)} 00:00`; };
const nextDay = n => { const s = String(n), d = new Date(Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8) + 1)); return d.getUTCFullYear() * 10000 + (d.getUTCMonth() + 1) * 100 + d.getUTCDate(); };
// İl-il bölünmüş tarix aralıqları (sayt uzun aralığı qəbul etməyə bilər)
const yearChunks = (fromN, toN) => { const out = []; for (let y = Math.floor(fromN / 10000); y <= Math.floor(toN / 10000); y++) out.push([Math.max(fromN, y * 10000 + 101), Math.min(toN, y * 10000 + 1231)]); return out; };

async function apiInvList(tabId, dir, fromN, toN, extra, onPage) {
  const u = `/api/po/invoice/public/v2/invoice/find.${dir === 'out' ? 'outbox' : 'inbox'}`;
  const body = (a, b, statuses) => ({ sortBy: 'creationDate', sortAsc: true, statuses, types: ['current', 'corrected'], kinds: KINDS, serialNumber: null, senderTin: null, senderName: null,
    productName: null, productCode: null, receiverTin: null, receiverName: null, creationDateFrom: dmyDash(a), creationDateTo: dmyDash(nextDay(b)), amountFrom: null, amountTo: null, actionOwner: null, ...(extra || {}) });
  const all = [], seen = new Set(); let pages = 0, goneOk = true;
  for (const [a, b] of yearChunks(fromN, toN)) {
    let statuses = [...ST_MAIN, ...ST_GONE];
    for (let off = 0; !cancel; off += 50) {
      let [x] = await api(tabId, [{ u, m: 'POST', b: { ...body(a, b, statuses), offset: off, maxCount: 50 } }], 1);
      if (x.error && off === 0 && statuses.length > ST_MAIN.length && x.st === 400) { statuses = ST_MAIN; goneOk = false; [x] = await api(tabId, [{ u, m: 'POST', b: { ...body(a, b, statuses), offset: 0, maxCount: 50 } }], 1); }
      if (x.error) throw apiErr('qaimə siyahısı: ' + x.error);
      const arr = x.data && x.data.invoices; if (!Array.isArray(arr)) throw apiErr('qaimə siyahısı: gözlənilməz cavab');
      arr.forEach(v => { if (v && v.id && !seen.has(v.id)) { seen.add(v.id); all.push(v); } });
      pages++; if (onPage) onPage(pages, all.length);
      if (arr.length < 50 || pages > 600) break;
    }
  }
  return { all, pages, goneOk };
}
function invRow(v, dir) {
  const cp = (dir === 'out' ? v.receiver : v.sender) || {};
  return { id: v.id, src: v.sourceSystem || 'avis', serial: v.serialNumber || '', date: isoDmy(v.createdAt), dnum: isoN(v.createdAt), voen: cp.tin || cp.fin || cp.pin || '', name: cp.name || '',
    type: INV_KIND[v.kind] || v.kind || '', status: INV_STATUS[v.status] || v.status || '', basis: v.invoiceComment || '', total: v.amount, vat: v.vat, corrected: v.type === 'corrected' };
}
const itemRows = items => (items || []).map((it, k) => {
  const g = it.productGroup || {}, vat = (+it.vat18 || 0) * 0.18, base = (+it.cost || 0) + (+it.excise || 0) + (+it.roadTax || 0);
  return [String(k + 1), g.code || '', it.productName || '', (g.name && g.name.az) || '', it.barcode || '', (it.unitFromDict && it.unitFromDict.name && it.unitFromDict.name.az) || it.unit || '',
    nstr(it.quantity), nstr(it.pricePerUnit), nstr(it.cost), nstr(it.exciseRate), nstr(it.excise), nstr(it.vat18), nstr(it.vatFree), nstr(it.vat0), nstr(it.exempt), nstr(it.roadTax), nstr(vat), nstr(base + vat)];
});
// Qaimələrin içi (mallar). progress(n) hər hissədən sonra
async function apiInvItems(tabId, sel, progress) {
  const results = new Array(sel.length).fill(null);
  for (let s = 0; s < sel.length && !cancel; s += 40) {
    const chunk = sel.slice(s, s + 40), out = await api(tabId, chunk.map(d => ({ u: `/api/po/invoice/public/v2/invoice/${encodeURIComponent(d.id)}?sourceSystem=${encodeURIComponent(d.src)}` })), 8);
    if (s === 0 && out.every(x => x.error)) throw apiErr('qaimənin içi: ' + out[0].error);
    out.forEach((x, j) => {
      const v = x.data;
      if (x.error || !v || !Array.isArray(v.items)) { results[s + j] = { error: x.error || 'qaimənin içi boş gəldi' }; return; }
      results[s + j] = { header: ITEM_HDR, rows: itemRows(v.items),
        info: { esas: v.invoiceComment || '', qeyd: v.invoiceComment2 || '', created: isoDmy(v.createdAt),
          parties: [v.sender, v.receiver].filter(Boolean).map(p => ({ voen: p.tin || p.pin || '', name: p.name || '' })) } };
    });
    progress(Math.min(sel.length, s + chunk.length));
  }
  return results;
}

// ---------------- FUNKSİYA 2: Qaimə üzrə mallar və xidmətlər ----------------
async function runItemsApi({ tabId, from, to, dir, statuses, types }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  log(`"${tab}" siyahısı alınır...`);
  const L = await apiInvList(tabId, dir, fromN, toN, null, (p, n) => log(`"${tab}" siyahısı alınır: ${n} qaimə...`, false, { stats: [{ l: 'Səhifə', v: p }, { l: 'Qaimə', v: n }] }));
  const inDates = L.all.map(v => invRow(v, dir)).filter(d => d.dnum >= fromN && d.dnum <= toN);
  const nz = s => String(s || '').toLocaleLowerCase('az').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const pick = (f, v, unknown) => { if (!f) return true; const k = nz(v); if (f.on.some(x => nz(x) === k)) return true; if (f.known.some(x => nz(x) === k)) return false; unknown.add(v || '(boş)'); return f.other !== false; };
  const unkS = new Set(), unkT = new Set();
  const sel = inDates.filter(x => pick(statuses, x.status, unkS) & pick(types, x.type, unkT)).sort((a, b) => a.dnum - b.dnum || a.date.localeCompare(b.date));
  const base = { versiya: VERSION, funksiya: 'mallar', rejim: 'api', bolme: tab, sehife: L.pages, siyahi: L.all.length, legvSilinmisAlindi: L.goneOk,
    secim: { tarixde: inDates.length, secilen: sel.length, taninmayanStatus: [...unkS].slice(0, 8), taninmayanNov: [...unkT].slice(0, 8) } };
  await chrome.storage.local.set({ report: base });
  if (!inDates.length) throw new Error(`"${tab}" bölməsində bu tarix aralığında qaimə tapılmadı.`);
  if (!sel.length) throw new Error(`Bu tarixlərdə ${inDates.length} qaimə var, amma heç biri seçdiyin status və növə uyğun deyil.`);
  const stats = d => [{ l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }];
  const results = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimə oxundu.`, false, { i: d, n: sel.length, stats: stats(d) }));

  const rows = [], notes = []; let items = 0, ok = 0, empty = 0, err = 0;
  sel.forEach((d, i) => {
    const res = results[i]; if (!res) return;
    if (res.error) { err++; notes.push(['Xəta', d.serial, d.date, mask(res.error)]); return; }
    const info = res.info, meta = [d.date, d.voen, d.name, d.serial, d.type, d.status, info.esas || d.basis || '', info.qeyd || ''];
    if (!res.rows.length) { empty++; notes.push(['Məlumat', d.serial, d.date, 'Mal sətri yoxdur']); return; }
    ok++; items += res.rows.length;
    res.rows.forEach(row => { const code = String(row[1] || '').trim(); rows.push([...meta, code ? (code.startsWith('99') ? 'Xidmət' : 'Mal') : '', ...row]); });
  });
  if (unkS.size) notes.push(['Məlumat', '', '', 'Tanınmayan status: ' + [...unkS].join('; ')]);
  if (unkT.size) notes.push(['Məlumat', '', '', 'Tanınmayan növ: ' + [...unkT].join('; ')]);
  if (!L.goneOk && statuses && statuses.on.some(x => /ləğv edildi|silindi/i.test(x))) notes.push(['Xəbərdarlıq', '', '', 'Ləğv edilmiş və silinmiş qaimələr sayt tərəfindən verilmədi.']);
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan qaimələr fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...base, saniye: sec, oxundu: ok, bos: empty, xeta: err, xetalar: [...new Set(results.filter(r => r && r.error).map(r => mask(r.error)))].slice(0, 4) } });
  await saveXlsx(`DataX-mallar-${dir === 'out' ? 'gonderilen' : 'gelen'}-${from}_${to}.xlsx`, [
    { name: 'Mallar və xidmətlər', header: ['İmzalanma tarixi', 'VÖEN', 'Adı', 'Seriya və nömrə', 'Qaimənin növü', 'Status', 'Əsas', 'Əlavə qeyd', 'Mal/xidmət', ...ITEM_HDR], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Seriya və nömrə', 'Tarix', 'Qeyd'], rows: notes, numeric: false }]);
  const ps = [`${tab}: ${sel.length} qaimə` + (sel.length < inDates.length ? ` (tarixdə ${inDates.length}, seçimə uyğun ${sel.length})` : ''), `${items} mal/xidmət sətri`];
  if (empty) ps.push(`${empty} qaimədə sətir yoxdur`); if (err) ps.push(`${err} qaimə oxunmadı`);
  log((err || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true,
    { i: sel.length, n: sel.length, hasErrors: !!err, stats: [{ l: 'Qaimə', v: sel.length }, { l: 'Mal sətri', v: items }, { l: 'Saniyə', v: sec }] });
}

// ---------------- FUNKSİYA: Riskli VÖEN yoxlaması ----------------
// e-taxes-in açıq xidməti: /api/po/authless/public/v1/authless/payers/risk/{VÖEN} → { risky, riskyPayerInfoList }
const RISK_U = v => `/api/po/authless/public/v1/authless/payers/risk/${encodeURIComponent(v)}`;
const riskText = list => (list || []).map(o => o && typeof o === 'object'
  ? Object.entries(o).map(([k, v]) => [k, v && typeof v === 'object' ? (v.az || v.name && (v.name.az || v.name) || '') : v]).filter(([, v]) => v != null && v !== '' && typeof v !== 'object').map(([k, v]) => `${fldName(k)}: ${/^\d{4}-\d{2}-\d{2}/.test(String(v)) ? isoDmy(v) : v}`).join(', ')
  : String(o)).filter(Boolean).join(' | ');
async function runRiskApi({ tabId, from, to, dir }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər', who = dir === 'out' ? 'Alıcı' : 'Təchizatçı';
  log(`"${tab}" siyahısı alınır...`);
  const L = await apiInvList(tabId, dir, fromN, toN, null, (p, n) => log(`"${tab}" siyahısı alınır: ${n} qaimə...`, false, { stats: [{ l: 'Səhifə', v: p }, { l: 'Qaimə', v: n }] }));
  const gone = /ləğv edildi|silindi/i;
  const inv = L.all.map(v => invRow(v, dir)).filter(d => d.dnum >= fromN && d.dnum <= toN && !gone.test(d.status));
  if (!inv.length) throw new Error(`"${tab}" bölməsində bu tarix aralığında qaimə tapılmadı.`);
  const by = new Map();
  for (const d of inv) {
    const k = String(d.voen || '').trim(); if (!k) continue;
    const g = by.get(k) || { voen: k, name: d.name, n: 0, total: 0, vat: 0, first: d.dnum, firstD: d.date, last: d.dnum, lastD: d.date, inv: [] };
    g.n++; g.total += +d.total || 0; g.vat += +d.vat || 0; g.inv.push(d);
    if (d.dnum < g.first) { g.first = d.dnum; g.firstD = d.date; } if (d.dnum > g.last) { g.last = d.dnum; g.lastD = d.date; }
    by.set(k, g);
  }
  const list = [...by.values()], chk = list.filter(g => /^\d{10}$/.test(g.voen));
  const stats = (d, r) => [{ l: who, v: list.length }, { l: 'Yoxlandı', v: d }, { l: 'Riskli', v: r }];
  let risky = 0, errs = 0;
  for (let s = 0; s < chk.length && !cancel; s += 20) {
    const part = chk.slice(s, s + 20), out = await api(tabId, part.map(g => ({ u: RISK_U(g.voen) })), 4);
    if (s === 0 && out.every(x => x.error)) throw new Error('Risk xidməti cavab vermədi: ' + mask(out[0].error));
    out.forEach((x, j) => {
      const g = part[j];
      if (x.error || !x.data || typeof x.data.risky !== 'boolean') { g.res = 'Yoxlanmadı'; g.info = x.error ? mask(x.error) : 'gözlənilməz cavab'; errs++; return; }
      g.res = x.data.risky ? 'RİSKLİ' : 'Riskli deyil'; g.info = riskText(x.data.riskyPayerInfoList); if (x.data.risky) risky++;
    });
    const d = Math.min(chk.length, s + part.length);
    log(`${d} / ${chk.length} ${who.toLowerCase()} yoxlandı.`, false, { i: d, n: chk.length, stats: stats(d, risky) });
  }
  list.forEach(g => { if (!g.res) { g.res = /^\d{10}$/.test(g.voen) ? 'Yoxlanmadı' : 'Fiziki şəxs (yoxlanmır)'; if (!g.info && cancel) g.info = 'Dayandırıldı'; } });
  const rank = r => r === 'RİSKLİ' ? 0 : r === 'Yoxlanmadı' ? 1 : 2;
  list.sort((a, b) => rank(a.res) - rank(b.res) || b.vat - a.vat);
  const n2 = v => nstr(Math.round(v * 100) / 100);
  const rows = list.map(g => [g.voen, g.name, g.res, g.info || '', String(g.n), n2(g.total), n2(g.vat), g.firstD.slice(0, 10), g.lastD.slice(0, 10)]);
  const bad = list.filter(g => g.res === 'RİSKLİ');
  const rInv = bad.flatMap(g => g.inv.sort((a, b) => a.dnum - b.dnum).map(d => [d.date, d.serial, d.voen, d.name, d.type, d.status, d.basis, nstr(d.total), nstr(d.vat)]));
  const sumBad = bad.reduce((a, g) => a + g.vat, 0);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { versiya: VERSION, funksiya: 'risk', rejim: 'api', bolme: tab, qaime: inv.length, yoxlanan: chk.length, riskli: risky, xeta: errs, saniye: sec } });
  const today = new Date().toLocaleDateString('ru-RU');
  await saveXlsx(`DataX-riskli-voen-${dir === 'out' ? 'alicilar' : 'techizatcilar'}-${from}_${to}.xlsx`, [
    { name: who + 'lar', header: ['VÖEN', 'Adı', 'Nəticə', 'Risk məlumatı', 'Qaimə sayı', 'Məbləğ', 'ƏDV', 'İlk qaimə', 'Son qaimə'], rows, keep: true, numCols: [4, 5, 6] },
    { name: 'Riskli qaimələr', header: ['İmzalanma tarixi', 'Seriya və nömrə', 'VÖEN', 'Adı', 'Qaimənin növü', 'Status', 'Əsas', 'Yekun məbləğ', 'ƏDV məbləği'], rows: rInv, keep: true },
    { name: 'Qeydlər', header: ['Qeyd'], numeric: false, rows: [
      [`Yoxlama tarixi: ${today}. Mənbə: e-taxes "Riskli vergi ödəyiciləri barədə məlumatın verilməsi" xidməti.`],
      [`Nəticə yoxlama anına aiddir: ödəyici sonradan riskli siyahıya düşə və ya çıxa bilər.`],
      [`${tab}: ${from} – ${to}, ləğv edilmiş və silinmiş qaimələr daxil edilməyib.`],
      ...(errs ? [[`${errs} VÖEN yoxlanmadı (xidmət cavab vermədi). Bir azdan təkrar yoxla.`]] : []),
      ...(cancel ? [['Dayandırıldı: bütün VÖEN-lər yoxlanmayıb.']] : [])] }]);
  const ps = [`${list.length} ${who.toLowerCase()}, ${inv.length} qaimə`, risky ? `${risky} RİSKLİ (ƏDV ${ncom(Math.round(sumBad * 100) / 100)})` : 'riskli tapılmadı'];
  if (errs) ps.push(`${errs} yoxlanmadı`);
  log((errs || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true,
    { i: chk.length, n: chk.length, hasErrors: !!errs, stats: stats(chk.length, risky) });
}
const runRisk = m => runRiskApi(m).catch(e => { throw e.apiFail ? new Error('e-taxes cavab vermədi (' + e.message.replace(/^API: /, '') + '). Səhifəni yenilə və təkrar başlat.') : e; });

// ---------------- FUNKSİYA: Mal hərəkəti uyğunluğu ----------------
// Gələn (+) və göndərilən (−) qaimələrin mal sətirləri ad + ölçü vahidi üzrə birləşdirilir; tarix sırası ilə qalıq hesablanır.
const STOCK_SKIP = ['advanceInvoice', 'taxCodex163', 'taxCodex177_5', 'exciseGoodsTransfer', 'mtkInvoice'];
const AZF = { 'ə': 'e', 'ı': 'i', 'i̇': 'i', 'ö': 'o', 'ü': 'u', 'ç': 'c', 'ş': 's', 'ğ': 'g' };
const normName = s => String(s || '').toLocaleLowerCase('az').replace(/i̇/g, 'i').replace(/[əıöüçşğ]/g, c => AZF[c]).replace(/[^\p{L}\p{N}]+/gu, '');
const UNIT_EQ = { kg: 'kq', кг: 'kq', kilogram: 'kq', kiloqram: 'kq', ed: 'ədəd', əd: 'ədəd', eded: 'ədəd', шт: 'ədəd', pcs: 'ədəd', pc: 'ədəd', ədəd: 'ədəd', ad: 'ədəd',
  m: 'metr', м: 'metr', metr: 'metr', meter: 'metr', l: 'litr', л: 'litr', litr: 'litr', liter: 'litr', m2: 'm2', м2: 'm2', kvm: 'm2', kvadratmetr: 'm2', m3: 'm3', м3: 'm3', kubmetr: 'm3', t: 'ton', тн: 'ton', ton: 'ton' };
const normUnit = s => { const u = String(s || '').toLocaleLowerCase('az').replace(/[^\p{L}\p{N}]+/gu, ''); return UNIT_EQ[u] || u; };
const normTok = s => String(s || '').toLocaleLowerCase('az').replace(/i̇/g, 'i').replace(/[əıöüçşğ]/g, c => AZF[c]).replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const digSig = s => (String(s || '').match(/\d+/g) || []).join(',');
function lev(a, b) {
  if (a === b) return 0; if (!a.length) return b.length; if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, j) => j), cur = new Array(b.length + 1);
  for (let i = 1; i <= a.length; i++) { cur[0] = i; for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); [prev, cur] = [cur, prev]; }
  return prev[b.length];
}
// İki adın oxşarlığı (0..1). Rəqəmlər (ölçü, marka) fərqlidirsə oxşar sayılmır: "Kabel 3x2,5" ≠ "Kabel 3x1,5"
function nameSim(a, b) {
  if (digSig(a) !== digSig(b)) return 0;
  const ta = normTok(a), tb = normTok(b), ca = ta.replace(/ /g, ''), cb = tb.replace(/ /g, '');
  if (!ca || !cb) return 0;
  const r = 1 - lev(ca, cb) / Math.max(ca.length, cb.length);
  const wa = new Set(ta.split(' ').filter(w => w.length > 1)), wb = new Set(tb.split(' ').filter(w => w.length > 1));
  const inter = [...wa].filter(w => wb.has(w)).length, jac = inter / (new Set([...wa, ...wb]).size || 1);
  const sub = Math.min(ca.length, cb.length) >= 4 && (ca.includes(cb) || cb.includes(ca)) ? 0.85 : 0;
  return Math.max(r, jac, sub);
}
async function runStockApi({ tabId, from, to, imp }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to), gone = /ləğv edildi|silindi/i;
  const sel = [];
  for (const dir of ['in', 'out']) {
    const tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
    log(`"${tab}" siyahısı alınır...`);
    const L = await apiInvList(tabId, dir, fromN, toN, null, (p, n) => log(`"${tab}" siyahısı alınır: ${n} qaimə...`, false, { stats: [{ l: 'Səhifə', v: p }, { l: 'Qaimə', v: n }] }));
    const bySer = new Map();
    L.all.forEach(v => {
      if (STOCK_SKIP.includes(v.kind)) return;
      const d = invRow(v, dir); if (d.dnum < fromN || d.dnum > toN || gone.test(d.status)) return;
      d.dir = dir; d.ret = /^return/.test(v.kind || '') || /^MQ/i.test(d.serial); const k = d.serial || d.id, o = bySer.get(k);
      if (!o || (d.corrected && !o.corrected) || (d.corrected === o.corrected && d.dnum >= o.dnum)) bySer.set(k, d);   // düzəlişli variant əvvəlkini əvəz edir
    });
    sel.push(...bySer.values());
    if (cancel) break;
  }
  const nIn = sel.filter(d => d.dir === 'in').length, nOut = sel.length - nIn;
  if (!nIn && !nOut) throw new Error('Bu tarix aralığında gələn və göndərilən qaimə tapılmadı.');
  const res = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimənin malları oxundu.`, false, { i: d, n: sel.length, stats: [{ l: 'Gələn', v: nIn }, { l: 'Göndərilən', v: nOut }, { l: 'Oxundu', v: d }] }));
  const P = new Map(); let errs = 0, svc = 0, lines = 0;
  sel.forEach((d, i) => {
    const r = res[i]; if (!r) return; if (r.error) { errs++; return; }
    r.rows.forEach(row => {
      const code = String(row[1] || '').trim(), name = String(row[2] || '').trim(), unit = String(row[5] || '').trim(), q = +row[6] || 0, sum = +row[8] || 0;
      if (code.startsWith('99')) { svc++; return; }                  // xidmətlər anbara düşmür
      if (!name || !q) return; lines++;
      const key = normName(name) + '|' + normUnit(unit);
      const p = P.get(key) || { names: new Map(), unit, codeIn: new Set(), codeOut: new Set(), codeImp: new Set(), inQ: 0, inS: 0, outQ: 0, outS: 0, retSup: 0, retCus: 0, impQ: 0, impS: 0, impHow: '', ev: [], firstIn: 0, firstOut: 0 };
      p.names.set(name, (p.names.get(name) || 0) + 1);
      // Mal qaytarma (MQ): göndərilən = təchizatçıya qaytardığımız (alışı azaldır), gələn = alıcının bizə qaytardığı (satışı azaldır)
      if (d.ret && d.dir === 'out') { p.inQ -= q; p.inS -= sum; p.retSup += q; }
      else if (d.ret) { p.outQ -= q; p.outS -= sum; p.retCus += q; }
      else if (d.dir === 'in') { p.inQ += q; p.inS += sum; if (code) p.codeIn.add(code); if (!p.firstIn || d.dnum < p.firstIn) p.firstIn = d.dnum; }
      else { p.outQ += q; p.outS += sum; if (code) p.codeOut.add(code); if (!p.firstOut || d.dnum < p.firstOut) p.firstOut = d.dnum; }
      p.ev.push({ n: d.dnum, q: d.dir === 'in' ? q : -q, date: d.date.slice(0, 10), ser: d.serial });
      P.set(key, p);
    });
  });
  const dmy = n => { const s = String(n); return n ? `${s.slice(6, 8)}.${s.slice(4, 6)}.${s.slice(0, 4)}` : ''; };
  // Gömrük idxalı (istifadəçinin seçdiyi hesabat faylı): alış kimi; satış malına ad, ölçü vahidi və kodun ilk 4 rəqəmi ilə bağlanır
  const impL = Array.isArray(imp) ? imp : []; let impLinked = 0, impNew = 0;
  const c4 = c => String(c || '').replace(/\D/g, '').slice(0, 4);
  for (const L of impL) {
    const q = +L.q || 0, sum = +L.sum || 0; if (!L.name || !q) continue;
    const u = normUnit(L.unit), key = normName(L.name) + '|' + u;
    let p = P.get(key), how = p ? 'ad eyni' : '';
    if (!p) {
      let best = null, bv = 0;
      for (const x of P.values()) {
        if (u && normUnit(x.unit) !== u) continue;
        const xn = [...x.names.keys()][0], codes = [...x.codeIn, ...x.codeOut].map(c4).filter(Boolean);
        const codeOk = L.code && codes.includes(c4(L.code));
        if (L.code && codes.length && !codeOk) continue;
        const v = nameSim(L.name, xn);
        if (v >= 0.8 && v > bv) { bv = v; best = x; how = `ad oxşar (${Math.round(v * 100)}%)` + (codeOk ? ', kod uyğun' : ''); }
      }
      if (!best && L.code && u) {
        const byCode = [...P.values()].filter(x => normUnit(x.unit) === u && x.outQ > 0 && [...x.codeIn, ...x.codeOut].map(c4).includes(c4(L.code)));
        if (byCode.length === 1) { best = byCode[0]; how = 'kod (ilk 4 rəqəm) və ölçü vahidi uyğun'; }
      }
      p = best;
    }
    if (p) impLinked++;
    else { impNew++; p = { names: new Map(), unit: L.unit, codeIn: new Set(), codeOut: new Set(), codeImp: new Set(), inQ: 0, inS: 0, outQ: 0, outS: 0, retSup: 0, retCus: 0, impQ: 0, impS: 0, impHow: 'yalnız gömrükdə', ev: [], firstIn: 0, firstOut: 0 }; p.names.set(L.name, 0); P.set(key, p); }
    p.inQ += q; p.inS += sum; p.impQ += q; p.impS += sum; if (L.code) p.codeImp.add(L.code);
    if (how && !p.impHow.includes(how)) p.impHow = p.impHow ? p.impHow + '; ' + how : how;
    const dn = L.dnum || fromN; if (!p.firstIn || dn < p.firstIn) p.firstIn = dn;
    p.ev.push({ n: dn, q, date: dmy(dn), ser: 'GB ' + (L.gb || '') });
  }

  const r2 = v => Math.round(v * 100) / 100, r4 = v => Math.round(v * 10000) / 10000;
  const prod = [...P.values()].map(p => {
    p.ev.sort((a, b) => a.n - b.n || b.q - a.q);                     // eyni gün: əvvəl giriş
    let bal = 0, minBal = 0, negAt = null;
    for (const e of p.ev) { bal = r4(bal + e.q); if (bal < -1e-6 && !negAt) negAt = e; if (bal < minBal) minBal = bal; }
    const avgIn = p.inQ > 1e-6 ? p.inS / p.inQ : 0, avgOut = p.outQ > 1e-6 ? p.outS / p.outQ : 0;
    const flags = []; let lvl = 0;
    if (p.outQ > 1e-6 && p.inQ <= 1e-6 && !p.retSup) { flags.push(impL.length ? 'Satılıb, alışı yoxdur (nə e-qaimədə, nə gömrükdə)' : 'Satılıb, alışı yoxdur'); lvl = 2; }
    else if (p.inQ < -1e-6) { flags.push('Təchizatçıya qaytarılan dövrdəki alışdan çoxdur (alış dövrdən əvvəl ola bilər)'); lvl = Math.max(lvl, 1); }
    else if (p.outQ < -1e-6) { flags.push('Alıcıdan qaytarılan dövrdəki satışdan çoxdur (satış dövrdən əvvəl ola bilər)'); lvl = Math.max(lvl, 1); }
    if (!flags.length && bal < -1e-6) { flags.push(`Mənfi qalıq: ${ncom(r4(bal))} (ilk dəfə ${negAt.date}, ${negAt.ser})`); lvl = 2; }
    else if (negAt && !flags.length) { flags.push(`Alışdan əvvəl satılıb: ${negAt.date}, ${negAt.ser}`); lvl = Math.max(lvl, 1); }
    if (avgIn && avgOut && avgOut < avgIn * 0.98) { flags.push(`Maya dəyərindən aşağı satış (orta alış ${ncom(r4(avgIn))}, satış ${ncom(r4(avgOut))})`); lvl = Math.max(lvl, 1); }
    const codeDiff = p.codeIn.size && p.codeOut.size && [...p.codeOut].some(c => !p.codeIn.has(c));
    if (codeDiff) { flags.push('Alış və satışda fərqli təsnifat kodu'); lvl = Math.max(lvl, 1); }
    if (p.impQ) flags.push(`Gömrük idxalı: ${ncom(r4(p.impQ))} (${p.impHow})`);
    if (p.names.size > 1) flags.push('Ad fərqli yazılıb: ' + [...p.names.keys()].slice(0, 4).join(' / '));
    const main = [...p.names.entries()].sort((a, b) => b[1] - a[1])[0][0];
    return { p, main, bal, avgIn, avgOut, flags, lvl, codeDiff, negAt };
  }).sort((a, b) => b.lvl - a.lvl || Math.abs(b.p.outS) - Math.abs(a.p.outS));
  // Oxşar adlar: satışdakı ad alışdakı başqa adla cüzi fərqlənir (və ya eyni ad, fərqli ölçü vahidi)
  const buy = prod.filter(x => x.p.inQ > 1e-6 || x.p.retSup), sell = prod.filter(x => x.p.outQ > 1e-6 || x.p.retCus);
  const idx = new Map(), addIdx = (k, x) => { if (!idx.has(k)) idx.set(k, []); idx.get(k).push(x); };
  const keysOf = x => { const t = normTok(x.main).split(' ').filter(w => w.length >= 3).map(w => 'w:' + w.slice(0, 4)); [...x.p.codeIn, ...x.p.codeOut].forEach(c => t.push('c:' + c)); t.push('n:' + normName(x.main)); return [...new Set(t)]; };
  buy.forEach(x => keysOf(x).forEach(k => addIdx(k, x)));
  const simRows = [], seenPair = new Set();
  for (const y of sell) {
    const cand = new Set(); keysOf(y).forEach(k => (idx.get(k) || []).forEach(x => { if (x !== y && cand.size < 400) cand.add(x); }));
    const found = [];
    for (const x of cand) {
      const sameName = normName(x.main) === normName(y.main);
      const v = sameName ? 1 : nameSim(x.main, y.main);
      if (v < 0.8) continue;
      const pk = x.main + '\u0001' + x.p.unit + '\u0002' + y.main + '\u0001' + y.p.unit; if (seenPair.has(pk)) continue; seenPair.add(pk);
      found.push({ x, v, sameName });
    }
    found.sort((a, b) => b.v - a.v).slice(0, 3).forEach(({ x, v, sameName }) => {
      const why = sameName ? 'Eyni ad, fərqli ölçü vahidi' : 'Ad cüzi fərqlənir';
      simRows.push([x.main, y.main, x.p.unit, y.p.unit, String(Math.round(v * 100)), nstr(r4(x.p.inQ)), nstr(r4(y.p.outQ)), [...x.p.codeIn].join(', '), [...y.p.codeOut].join(', '), why]);
      y.flags.push(`Alışda oxşar ad: "${x.main}" (${x.p.unit || '-'}, ${Math.round(v * 100)}%)`);
      if (x.p.outQ <= 1e-6) x.flags.push(`Satışda oxşar ad: "${y.main}" (${y.p.unit || '-'}, ${Math.round(v * 100)}%)`);
      if (!y.lvl) y.lvl = 1; if (!x.lvl) x.lvl = 1;
    });
  }
  prod.sort((a, b) => b.lvl - a.lvl || Math.abs(b.p.outS) - Math.abs(a.p.outS));
  // İcmal: hər mal üzrə nə qədər qalıq qalıb və ya nə qədər mənfiyə düşüb
  const neg = prod.filter(x => x.bal < -1e-6).sort((a, b) => a.bal - b.bal), pos = prod.filter(x => x.bal > 1e-6).sort((a, b) => b.bal * (b.avgIn || 0) - a.bal * (a.avgIn || 0));
  const zero = prod.length - neg.length - pos.length;
  const icRow = (sec, x) => [sec, x.main, x.p.unit, nstr(r4(x.bal)), x.avgIn ? nstr(r4(x.avgIn)) : '', x.avgIn ? nstr(r2(x.bal * x.avgIn)) : '',
    sec === 'Mənfi qalıq' ? (x.negAt ? `İlk dəfə ${x.negAt.date} mənfiyə düşüb (${x.negAt.ser})` : '') + (x.p.inQ <= 1e-6 ? '; alışı yoxdur' : '') : ''];
  const sumV = a => r2(a.reduce((t, x) => t + (x.avgIn ? x.bal * x.avgIn : 0), 0));
  const icRows = [...neg.map(x => icRow('Mənfi qalıq', x)), ...(neg.length ? [['Cəmi (mənfi)', `${neg.length} mal`, '', '', '', nstr(sumV(neg)), '']] : []),
    ...pos.map(x => icRow('Qalıq var', x)), ...(pos.length ? [['Cəmi (qalıq)', `${pos.length} mal`, '', '', '', nstr(sumV(pos)), '']] : []),
    ['Qalığı sıfır olan mallar', `${zero} mal`, '', '', '', '', '']];
  const icFills = icRows.map(r => r[0] === 'Mənfi qalıq' ? 'risk' : null);
  const LV = ['Uyğundur', 'Yoxlanmalı', 'Yüksək risk'];
  const rows = prod.map(x => [LV[x.lvl], x.main, x.p.unit, [...x.p.codeIn].join(', '), [...x.p.codeOut].join(', '), nstr(r4(x.p.inQ)), nstr(r2(x.p.inS)), nstr(r4(x.p.outQ)), nstr(r2(x.p.outS)),
    nstr(r4(x.bal)), x.avgIn ? nstr(r4(x.avgIn)) : '', x.avgOut ? nstr(r4(x.avgOut)) : '', dmy(x.p.firstIn), dmy(x.p.firstOut), x.flags.join('; '), x.p.retSup ? nstr(r4(x.p.retSup)) : '', x.p.retCus ? nstr(r4(x.p.retCus)) : '', x.p.impQ ? nstr(r4(x.p.impQ)) : '', [...x.p.codeImp].join(', ')]);
  const fills = prod.map(x => x.lvl === 2 ? 'risk' : x.lvl === 1 ? 'warn' : null);
  // Kod (ilk 4 rəqəm) + ölçü vahidi üzrə: adlar uyğun gəlməsə də alış + idxal ilə satışı müqayisə
  const K = new Map();
  for (const x of prod) {
    const codes = new Set([...x.p.codeIn, ...x.p.codeOut, ...x.p.codeImp].map(c4).filter(Boolean)); if (codes.size !== 1) continue;
    const k = [...codes][0] + '|' + normUnit(x.p.unit), g = K.get(k) || { c: [...codes][0], unit: x.p.unit, eq: 0, im: 0, out: 0, n: 0 };
    g.eq += x.p.inQ - x.p.impQ; g.im += x.p.impQ; g.out += x.p.outQ; g.n++; K.set(k, g);
  }
  const hsRows = [...K.values()].filter(g => g.out > 1e-6 || g.im > 1e-6).map(g => { const bal = g.eq + g.im - g.out; return [bal < -1e-6 ? 'Satış alışdan çoxdur' : 'Uyğundur', g.c, g.unit, String(g.n), nstr(r4(g.eq)), nstr(r4(g.im)), nstr(r4(g.out)), nstr(r4(bal))]; })
    .sort((a, b) => (a[0] === 'Uyğundur') - (b[0] === 'Uyğundur') || +a[7] - +b[7]);
  const codeRows = prod.filter(x => x.codeDiff).map(x => [x.main, x.p.unit, [...x.p.codeIn].join(', '), [...x.p.codeOut].join(', '), nstr(r2(x.p.outS))]);
  const nameRows = prod.filter(x => x.p.names.size > 1).flatMap(x => [...x.p.names.entries()].map(([n, c]) => [x.main, n, String(c)]));
  const cnt = l => prod.filter(x => x.lvl === l).length;
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { versiya: VERSION, funksiya: 'mal', rejim: 'api', gelen: nIn, gonderilen: nOut, mal: prod.length, risk: cnt(2), yoxla: cnt(1), xeta: errs, saniye: sec } });
  await saveXlsx(`DataX-mal-hereketi-${from}_${to}.xlsx`, [
    { name: 'İcmal (qalıq)', header: ['Bölmə', 'Malın adı', 'Ölçü vahidi', 'Qalıq miqdar', 'Orta alış qiyməti', 'Təxmini qalıq dəyəri', 'Qeyd'], rows: icRows, fills: icFills, keep: true, numCols: [3, 4, 5] },
    { name: 'Mal hərəkəti', header: ['Nəticə', 'Malın adı', 'Ölçü vahidi', 'Kod (alış)', 'Kod (satış)', 'Alınan miqdar (xalis)', 'Alış məbləği (xalis)', 'Satılan miqdar (xalis)', 'Satış məbləği (xalis)', 'Qalıq miqdar', 'Orta alış qiyməti', 'Orta satış qiyməti', 'İlk alış', 'İlk satış', 'Qeyd', 'Təchizatçıya qaytarılan', 'Alıcıdan qaytarılan', 'O cümlədən gömrük idxalı', 'Kod (gömrük)'],
      rows, fills, keep: true, numCols: [5, 6, 7, 8, 9, 10, 11, 15, 16, 17] },
    { name: 'Kod üzrə (4 rəqəm)', header: ['Nəticə', 'Kodun ilk 4 rəqəmi', 'Ölçü vahidi', 'Mal sayı', 'Alış (e-qaimə)', 'İdxal (gömrük)', 'Satış', 'Qalıq'], rows: hsRows, numCols: [4, 5, 6, 7], fills: hsRows.map(r => r[0] === 'Uyğundur' ? null : 'warn') },
    { name: 'Kod fərqləri', header: ['Malın adı', 'Ölçü vahidi', 'Kod (alış)', 'Kod (satış)', 'Satış məbləği'], rows: codeRows, numCols: [4] },
    { name: 'Oxşar adlar', header: ['Alışdakı ad', 'Satışdakı ad', 'Ölçü vahidi (alış)', 'Ölçü vahidi (satış)', 'Oxşarlıq %', 'Alınan miqdar', 'Satılan miqdar', 'Kod (alış)', 'Kod (satış)', 'Səbəb'], rows: simRows, numCols: [4, 5, 6] },
    { name: 'Fərqli yazılışlar', header: ['Birləşdirilən ad', 'Qaimədəki yazılış', 'Sətir sayı'], rows: nameRows, numCols: [2] },
    { name: 'Xülasə', header: ['Göstərici', 'Say'], numCols: [1], rows: [
      ['Dövr', `${dmy(fromN)} – ${dmy(toN)}`], ['Gələn qaimə', String(nIn)], ['Göndərilən qaimə', String(nOut)], ['Mal sətri (xidmətlər çıxılmaqla)', String(lines)], ['Xidmət sətri (hesaba alınmadı)', String(svc)],
      ['Mal (ad + ölçü vahidi)', String(prod.length)], ...(impL.length ? [['Gömrük idxalı sətri', String(impL.length)], ['  satış malına bağlandı', String(impLinked)], ['  ayrıca mal kimi əlavə olundu', String(impNew)]] : []), ['Yüksək risk', String(cnt(2))], ['Yoxlanmalı', String(cnt(1))], ['Oxşar ad cütü (alış ↔ satış)', String(simRows.length)], ['Uyğundur', String(cnt(0))], ...(errs ? [['Oxunmayan qaimə', String(errs)]] : [])] },
    { name: 'Qeydlər', header: ['Qeyd'], numeric: false, rows: [
      ['Mallar adına (böyük-kiçik hərf, boşluq, durğu işarəsi və ə/ı/ö/ü/ç/ş/ğ fərqi nəzərə alınmadan) və ölçü vahidinə görə birləşdirilir.'],
      ['Dövrün əvvəlinə olan qalıq məlum deyil: dövrdən əvvəl alınmış mallar "alışı yoxdur" və ya "mənfi qalıq" kimi görünə bilər. Başlanğıc tarixi şirkətin ilk qaiməsinə yaxın seçmək daha dəqiq nəticə verir.'],
      [impL.length ? 'Gömrük idxalı seçilmiş fayldan götürülüb və alış kimi hesablanıb. Gömrükdəki ad satışdakı addan fərqli olduqda mal ad oxşarlığı (80%+), ölçü vahidi və kodun ilk 4 rəqəmi ilə bağlanır; bağlanmayanlar ayrıca sətir kimi göstərilir və "Kod üzrə (4 rəqəm)" vərəqində müqayisə olunur.' : 'Gömrük idxalı seçilməyib: xaricdən alınmış mallar "alışı yoxdur" kimi görünə bilər. Paneldə "Gömrük idxalı" bölməsindən idxal hesabatını seç.'],
      ['Kassa çeki ilə alınmış mallar e-qaimədə olmadığı üçün burda görünmür.'],
      ['Oxşar adlar: alışdakı və satışdakı adlar 80%-dən çox oxşardırsa (rəqəmlər eyni olmaqla) göstərilir. Belə mallar eyni ola bilər — vergi orqanı fərqli adla yazılmış eyni malı uyğunsuzluq kimi görə bilər, adı hər yerdə eyni yazmaq tövsiyə olunur.'],
      ['Mal qaytarma qaimələri (MQ) satış və ya alış sayılmır: göndərilən MQ alışı, gələn MQ satışı azaldır. Qaytarılan miqdarlar ayrıca sütunlarda göstərilir.'],
      ['Avans, VM-in 163/177.5-ci maddələri üzrə və təsərrüfatdaxili yerdəyişmə qaimələri hesaba alınmayıb. Ləğv edilmiş və silinmiş qaimələr daxil deyil.']] }]);
  const ps = [`${nIn} gələn, ${nOut} göndərilən qaimə` + (impL.length ? `, ${impL.length} gömrük sətri` : ''), `${prod.length} mal`, `${cnt(2)} yüksək risk`, `${cnt(1)} yoxlanmalı`];
  if (errs) ps.push(`${errs} qaimə oxunmadı`);
  log((errs || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true,
    { i: sel.length, n: sel.length, hasErrors: !!errs, stats: [{ l: 'Mal', v: prod.length }, { l: 'Yüksək risk', v: cnt(2) }, { l: 'Yoxlanmalı', v: cnt(1) }] });
}
const runStock = m => runStockApi(m).catch(e => { throw e.apiFail ? new Error('e-taxes cavab vermədi (' + e.message.replace(/^API: /, '') + '). Səhifəni yenilə və təkrar başlat.') : e; });

// ---------------- FUNKSİYA 3: Alt sənədlər ----------------
async function ownFromApi(tabId) {
  const d = await api1(tabId, '/api/po/profile/public/v2/profile'), p = (d && d.profile) || d || {};
  const name = p.companyName || p.individualName || '', voen = p.tin || '';
  if (!name && !voen) throw apiErr('profil boşdur');
  const ad = String(p.legalAddress || p.actualAddress || '').toLocaleLowerCase('az'), m = ad.match(/(\p{L}[\p{L}\-]*)\s+şəhəri/u) || ad.match(/(\p{L}[\p{L}\-]*)\s+rayonu/u);
  const city = m ? m[0].replace(/^\p{L}/u, c => c.toLocaleUpperCase('az')) : '';
  return { name: shortName(name), voen, city, menbe: ['profil (birbaşa)'] };
}
async function runDocsApi({ tabId, serials, voen, from, to, dir, docs, opts }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  const want = [...new Set((serials || []).map(s => s.toUpperCase()))], keys = Object.keys(DOCS).filter(k => docs && docs[k]);
  const today = (d => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate())(new Date());
  const found = new Map(); let pages = 0;
  log('Qaimələr axtarılır...');
  if (want.length) {
    for (let i = 0; i < want.length && !cancel; i++) {
      const s = want[i], m = s.match(/^[A-Z]{2}(\d{2})(\d{2})/), y = m ? 2000 + +m[1] : 0, mo = m ? +m[2] : 0;
      const a = y && mo >= 1 && mo <= 12 ? y * 10000 + mo * 100 + 1 : 20190101;
      const b = y && mo >= 1 && mo <= 12 ? Math.min(today, (mo > 9 ? (y + 1) * 10000 + (mo - 9) * 100 : y * 10000 + (mo + 3) * 100) + 1) : today;
      const L = await apiInvList(tabId, dir, a, b, { serialNumber: s }, null); pages += L.pages;
      L.all.filter(v => String(v.serialNumber || '').toUpperCase() === s).forEach(v => found.set(v.id, v));
      log(`Qaimələr axtarılır: ${i + 1} / ${want.length}...`);
    }
  } else {
    const L = await apiInvList(tabId, dir, N(from), N(to), voen ? (dir === 'out' ? { receiverTin: voen } : { senderTin: voen }) : null, null); pages = L.pages;
    L.all.forEach(v => found.set(v.id, v));
  }
  const sel = [...found.values()].map(v => invRow(v, dir)).filter(d => !voen || d.voen === voen).filter(d => want.length || (d.dnum >= N(from) && d.dnum <= N(to))).sort((a, b) => a.dnum - b.dnum || a.date.localeCompare(b.date));
  const notFound = want.filter(s => !sel.some(x => x.serial.toUpperCase() === s));
  const base = { versiya: VERSION, funksiya: 'altSenedler', rejim: 'api', bolme: tab, sehife: pages, secim: { nomre: want.length, voenSecimi: !!voen, tapildi: sel.length, tapilmadi: notFound.length } };
  await chrome.storage.local.set({ report: base });
  if (!sel.length) throw new Error(want.length ? `Yazdığın ${want.length} qaimədən heç biri "${tab}" bölməsində tapılmadı. Bölməni (Gələn/Göndərilən) və nömrələri yoxla.` : `"${tab}" bölməsində bu VÖEN və tarixlərə uyğun qaimə tapılmadı.`);
  const stats = (d, f) => [{ l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }, { l: 'Sənəd', v: f }];
  const results = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimə oxundu.`, false, { i: d, n: sel.length, stats: stats(d, 0) }));
  let own; try { own = await ownFromApi(tabId); } catch (e) { if (e.message === SESSION_END) throw e; own = (await detectOwn(tabId)).own; try { await exec(tabId, rmAllFrames); } catch (e2) {} }
  const o = opts || {}; let files = 0, okInv = 0, err = 0, noOwn = 0, seq = 0; const errs = [];
  for (let i = 0; i < sel.length && !cancel; i++) {
    const d = sel[i], res = results[i]; if (!res) continue;
    if (res.error) { err++; errs.push(res.error); continue; }
    const inv = (res.info.parties || []).find(p => p.voen !== d.voen) || {};
    const me = { name: own.name || shortName(inv.name || ''), voen: own.voen || inv.voen || '', city: own.city };
    const dd = docData(d, res, dir, me, o, ++seq); if (dd.noOwn) noOwn++;
    files += await saveInvoiceDocs(keys, dd.data, dd.items, d.serial);
    okInv++; log(`Sənədlər hazırlanır: ${okInv} / ${sel.length} qaimə...`, false, { i: i + 1, n: sel.length, stats: stats(sel.length, files) });
  }
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ ownSeen: { name: own.name, voen: own.voen, t: Date.now() } });
  await chrome.storage.local.set({ report: { ...base, saniye: sec, senedSayi: files, xeta: err, ozSirket: { menbe: own.menbe, tapilmadi: noOwn }, xetalar: [...new Set(errs.map(mask))].slice(0, 4) } });
  const warn = [];
  if (notFound.length) warn.push(`Tapılmadı: ${notFound.slice(0, 6).join(', ')}${notFound.length > 6 ? ' və daha ' + (notFound.length - 6) : ''}.`);
  if (err) warn.push(`${err} qaimə oxunmadı.`);
  if (noOwn) warn.push(`${noOwn} qaimədə öz şirkətinin adı və ya VÖEN-i tapılmadı, yerinə xətt çəkilib.`);
  log((notFound.length || err ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${okInv} qaimə üçün ${files} sənəd hazırdır: "Yükləmələr / DataX alt sənədlər" içində hər qaimə üçün bir qovluq (zip) var.` + ((own.name || own.voen) ? `\nŞirkətin: ${own.name || '?'}, VÖEN ${own.voen || '?'}` : '') + (warn.length ? '\n' + warn.join('\n') : ''), true,
    { i: sel.length, n: sel.length, hasErrors: !!(notFound.length || err), stats: [{ l: 'Qaimə', v: okInv }, { l: 'Sənəd', v: files }, { l: 'Tapılmadı', v: notFound.length }] });
}

// ---------------- FUNKSİYA 4: Bəyannamələrin içi ----------------
const SEC_AZ = { common: 'Ümumi məlumat', administrative: 'İnzibati məlumat', payerInfo: 'Vergi ödəyicisi', declarationInfo: 'Bəyannamə', indicators: 'Göstəricilər', term: 'Dövr',
  mainTax: 'Əsas vergi', calculations: 'Hesablamalar', debtorDebt: 'Debitor borclar', refundCalculations: 'Əvəzləşdirilən vergi', totalCalculations: 'Hesablaşmalar',
  vatOperations: 'ƏDV tutulan və tutulmayan əməliyyatlar', reportPeriodInvoiceTotal: 'Əvəzləşdirmə üçün e-qaimələr (cəmi)', agroProductsRetailTotal: 'Kənd təsərrüfatı məhsulları',
  unsoldAgroProducts: 'Satılmamış k/t məhsulları', creditors: 'Kreditorlar', totalCertificateInfo: 'Sertifikatlar', totalObjectInfo: 'Obyektlər' };
const FLD_AZ = { cost: 'Dəyəri', amount: 'Məbləğ', vat: 'ƏDV', paidAmount: 'Ödənilmiş məbləğ', paidVat: 'Ödənilmiş ƏDV', previousDebt: 'Dövrün əvvəlinə borc', incurredDebt: 'Yaranmış borc',
  removedDebt: 'Silinmiş borc', lastDebt: 'Dövrün sonuna borc', mustBePaid: 'Ödənilməli', mustBeReturned: 'Qaytarılmalı', startRemains: 'Dövrün əvvəlinə qalıq', purchased: 'Alınıb', sold: 'Satılıb',
  resultRemains: 'Dövrün sonuna qalıq', tradeSupplementCost: 'Ticarət əlavəsi', tradeSupplementVat: 'Ticarət əlavəsinin ƏDV-si', totalCost: 'Ümumi dəyər', obtainedCost: 'Alınmış dəyər', soldCost: 'Satılmış dəyər',
  taxAmount: 'Vergi məbləği', tax: 'Vergi', rate: 'Dərəcə', taxRate: 'Vergi dərəcəsi', date: 'Tarix', tin: 'VÖEN', name: 'Ad', currency: 'Valyuta', count: 'Say', quantity: 'Miqdar', income: 'Gəlir', expense: 'Xərc',
  departmentCode: 'Vergi orqanının kodu', taxPayerFullName: 'Vergi ödəyicisinin adı', payerType: 'Ödəyicinin növü', taxPayerGroup: 'Ödəyici qrupu', mainActivityCode: 'Əsas fəaliyyət kodu',
  mainActivityName: 'Əsas fəaliyyət', attachmentCount: 'Əlavələrin sayı', declarationType: 'Bəyannamə növü', notificationNo: 'Bildiriş №', type: 'Növ', year: 'İl', month: 'Ay' };
// Saytın öz formalarından çıxarılmış lüğət (forms.json): sətir adları, sütun adları, forma kodları (301.1.1 və s.)
let FORMS = null;
async function loadForms() { if (!FORMS) { try { FORMS = await (await fetch(chrome.runtime.getURL('forms.json'))).json(); } catch (e) { FORMS = { tax: [], forms: {} }; } } return FORMS; }
function formDict(forms, taxCode, ver) {
  const tx = (forms.tax || []).find(x => x.code === taxCode), f = tx && forms.forms[tx.comp]; if (!f) return null;
  const L = f.L || {}, codes = { ...(f.codes || {}), ...((f.byVer || {})[ver] || {}) }, keys = Object.keys(L);
  const strip = s => String(s || '').replace(/^\s*[\d.\-]+\s*-\s*/, '').trim();
  const byInd = {}, bySuffix = {};
  keys.forEach(k => { const i = k.lastIndexOf('.'), last = k.slice(i + 1); if (/^_\w+$/.test(last)) (byInd[last] = byInd[last] || []).push(k); });
  return {
    code: ind => codes[ind] || String(ind).replace(/^_/, ''),
    // göstəricinin adı və aid olduğu bölmə (lang prefiksi)
    row: (ind, hint) => {
      let ks = byInd[ind] || [], suf = ind;
      if (!ks.length) { const c = codes[ind]; if (c) { ks = keys.filter(k => k.endsWith('.' + c)); suf = c; } }
      if (!ks.length) return { label: '', prefix: '' };
      const k = (hint && ks.find(x => x.startsWith(hint + '.'))) || ks[0];
      return { label: strip(L[k]), prefix: k.slice(0, k.length - suf.length - 1) };
    },
    field: (prefix, fld) => { if (prefix) return L[prefix + '.' + fld] || ''; const k = bySuffix[fld] !== undefined ? bySuffix[fld] : (bySuffix[fld] = keys.find(x => x.endsWith('.' + fld) && !/^step\./.test(x)) || ''); return k ? L[k] : ''; },
    title: (prefix, key) => (prefix && L[prefix + '.title']) || L['step.' + key] || ''
  };
}
const camel = k => String(k).replace(/([a-z])([A-Z0-9])/g, '$1 $2').replace(/^./, c => c.toUpperCase());
const secName = k => SEC_AZ[k] || (/^appendix(\d+)$/i.test(k) ? 'Əlavə ' + k.replace(/\D/g, '') : /^section(\d+)$/i.test(k) ? 'Bölmə ' + k.replace(/\D/g, '') : camel(k));
const fldName = k => FLD_AZ[k] || camel(k);
const scal = v => v == null || typeof v !== 'object';
// Bəyannamənin JSON-u → bölmələr (köhnə üsulun formatı): kodlu cədvəllər hesabata, qalan siyahılar ayrıca vərəqə, mətnlər "sahələr"ə
function declToSections(o, dict) {
  const secs = new Map();
  const fl = (prefix, k) => (dict && dict.field(prefix, k)) || fldName(k);
  const S = path => { const t = path.length ? (SEC_AZ[path[0]] || /^appendix\d+$/i.test(path[0]) || !dict ? secName(path[0]) : (dict.title('', path[0]) || secName(path[0]))) : 'Ümumi'; if (!secs.has(t)) secs.set(t, { title: t, side: true, tables: [], fields: [] }); return secs.get(t); };
  const sub = path => path.slice(1).map(secName).join(' / ');
  const walk = (v, path) => {
    if (Array.isArray(v)) {
      const objs = v.filter(x => x && typeof x === 'object' && !Array.isArray(x)); if (!objs.length) return;
      const keys = []; objs.forEach(x => Object.keys(x).forEach(k => { if (!keys.includes(k) && k !== 'id' && k !== 'rowOrder') keys.push(k); }));
      if (objs.every(x => x.indicator != null)) {
        const vk = keys.filter(k => k !== 'indicator' && objs.some(x => scal(x[k])));
        let prefix = ''; const rows = objs.map(x => { const ind = String(x.indicator), r = dict ? dict.row(ind, prefix) : { label: '', prefix: '' }; if (!prefix && r.prefix) prefix = r.prefix;
          return [dict ? dict.code(ind) : ind.replace(/^_/, ''), r.label, ...vk.map(k => typeof x[k] === 'number' ? ncom(x[k]) : scal(x[k]) && x[k] != null ? String(x[k]) : '')]; });
        S(path).tables.push({ title: sub(path), header: ['Kod', 'Göstərici', ...vk.map(k => fl(prefix, k))], coded: { cc: 0, lc: 1, vcols: vk.map((_, i) => i + 2) }, rows });
        objs.forEach((x, i) => keys.filter(k => !scal(x[k])).forEach(k => walk(x[k], [...path, String(x.indicator).replace(/^_/, ''), k])));
      } else {
        const vk = keys.filter(k => objs.some(x => scal(x[k])));
        if (vk.length) S(path).tables.push({ title: sub(path) || secName(path[path.length - 1] || ''), header: vk.map(k => fl('', k)), rows: objs.map(x => vk.map(k => typeof x[k] === 'number' ? ncom(x[k]) : x[k] == null ? '' : String(x[k]))) });
        objs.forEach(x => keys.filter(k => !scal(x[k])).forEach(k => walk(x[k], [...path, k])));
      }
      return;
    }
    if (!v || typeof v !== 'object') return;
    const nums = [], texts = [];
    Object.entries(v).forEach(([k, x]) => { if (typeof x === 'number') nums.push([k, x]); else if (scal(x)) { if (x != null && x !== '') texts.push([k, x]); } else walk(x, [...path, k]); });
    if (nums.length) S(path).tables.push({ title: sub(path), header: ['Kod', 'Dəyər'], coded: { cc: 0, lc: -1, vcols: [1] }, rows: nums.map(([k, x]) => [fl('', k), ncom(x)]) });
    texts.forEach(([k, x]) => S(path).fields.push(['', [sub(path), fl('', k)].filter(Boolean).join(' / '), typeof x === 'boolean' ? (x ? 'Bəli' : 'Xeyr') : String(x)]));
  };
  const ti = o.taxInformation;
  if (o.common) walk(o.common, ['common']);
  if (o.indicators) walk(o.indicators, ['indicators']);
  if (ti && typeof ti === 'object') Object.entries(ti).forEach(([k, v]) => walk(v, [k]));
  Object.entries(o).forEach(([k, v]) => { if (!['common', 'indicators', 'taxInformation', 'taxCode', 'version'].includes(k) && v && typeof v === 'object') walk(v, [k]); });
  return [...secs.values()].filter(s => s.tables.length || s.fields.length);
}
async function runDeclsApi({ tabId, from, to, taxes, skipKameral }) {
  const t0 = Date.now();
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), F = fy * 12 + fm, T = ty * 12 + tm, years = yearsFor(fy, ty);
  log('Bəyannamələr siyahısı alınır...');
  const { list, notes: yearNotes } = await apiDeclList(tabId, years);
  const want = taxes && taxes.length ? new Set(taxes) : null;
  const cand = list.map(x => ({ ...x, tax: taxOf(x.section) })).filter(x => {
    if (want && !want.has(x.tax.k) && !(want.has('diger') && x.tax.k === 'diger')) return false;
    return x.pr.y * 12 + x.pr.b >= F && x.pr.y * 12 + x.pr.a <= T;
  });
  const best = {};
  cand.filter(x => !(skipKameral && x.kameral)).forEach(x => { const k = x.section + '|' + x.pr.y + '|' + x.pr.a + '|' + x.pr.b; if (declBetter(x, best[k])) best[k] = x; });
  const sel = Object.values(best).sort((a, b) => a.tax.ab.localeCompare(b.tax.ab, 'az') || (a.pr.y * 12 + a.pr.a) - (b.pr.y * 12 + b.pr.a));
  const per = {}; list.forEach(x => { const a = taxOf(x.section).ab; per[a] = (per[a] || 0) + 1; });
  const baseReport = { versiya: VERSION, funksiya: 'beyannameler', rejim: 'api', iller: years, ilQeydleri: yearNotes, bolmeler: per, siyahi: list.length, araliqda: cand.length, secilen: sel.length };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş vergi növləri və dövrlər üçün bəyannamə tapılmadı.');

  const forms = await loadForms(), results = new Array(sel.length).fill(null); let done = 0, secCount = 0;
  const report = () => log(`${done} / ${sel.length} bəyannamə oxundu.`, false, { i: done, n: sel.length, stats: [{ l: 'Bəyannamə', v: sel.length }, { l: 'Oxundu', v: done }, { l: 'Bölmə', v: secCount }] });
  report();
  for (let s = 0; s < sel.length && !cancel; s += 12) {
    const chunk = sel.slice(s, s + 12), out = await api(tabId, chunk.map(d => ({ u: `/api/po/declaration/public/v1/base?reg_number=${d.docNo}` })), 6);
    if (s === 0 && out.every(x => x.error)) throw apiErr('bəyannamənin içi: ' + out[0].error);
    out.forEach((x, j) => {
      let r;
      if (x.error) r = { error: x.error };
      else { try { const o = JSON.parse((x.data || {}).baseJson || 'null'), d = chunk[j]; r = o ? { sections: declToSections(o, formDict(forms, d.taxCode || o.taxCode, d.ver || o.version)) } : { error: 'bəyannamənin içi boş gəldi' }; } catch (e) { r = { error: 'format: ' + e.message }; } }
      if (r.sections && !r.sections.length) r = { error: 'bəyannamədə məlumat yoxdur' };
      results[s + j] = r; done++; if (r.sections) secCount += r.sections.length;
    });
    report();
  }
  await declExcel({ sel, results, baseReport, yearNotes: yearNotes.map(n => n), unknownPeriod: [], tpl: {}, learnNotes: [], from, to, t0, apiMode: true });
}
