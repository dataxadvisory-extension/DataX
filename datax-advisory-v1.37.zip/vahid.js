// Vahid bəyannamə (muzdlu iş): əməkhaqqı cədvəlindən e-taxes Əlavə 1 Hissə 1 və Hissə 3 faylları
// readTable / unzip analiz-core.js-dəndir. Hər şey brauzerdə, yerli işlənir.
(() => {
  const $ = id => document.getElementById(id);
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;
  chrome.runtime.sendMessage({ type: 'lic' }, r => { document.body.classList.toggle('nolic', !(r && r.ok)); });
  const say = (msg, err, ok) => { const s = $('st'); s.textContent = msg; s.classList.toggle('err', !!err); s.classList.toggle('ok', !!ok); };
  const low = s => String(s == null ? '' : s).toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();
  const fold = s => low(s).replace(/i̇/g, 'i').replace(/[əıöüçşğ]/g, c => ({ ə: 'e', ı: 'i', ö: 'o', ü: 'u', ç: 'c', ş: 's', ğ: 'g' })[c]);
  const numv = v => { if (typeof v === 'number') return v; const s = String(v == null ? '' : v).replace(/[\s ]/g, ''); if (!s) return NaN; const t = s.includes(',') && s.includes('.') ? (s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '')) : s.replace(',', '.'); const n = Number(t); return isNaN(n) ? NaN : n; };
  const f2 = v => (Math.round((v || 0) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const fin = v => { const s = String(v == null ? '' : v).toUpperCase().replace(/\s/g, ''); return /^[0-9A-Z]{7}$/.test(s) && /\d/.test(s) ? s : ''; };
  const MONTHS = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
  const REASONS = ['1-İşçinin ödənişli əsas məzuniyyətdən və müvafiq hallarda əlavə məzuniyyətlərindən istifadə etməsi', '2-İşçinin sosial məzuniyyətlərindən istifadə etməsi',
    '3-İşçinin ödənişsiz məzuniyyətlərindən istifadə etməsi', '4-İşçinin təhsil məzuniyyətlərindən istifadə etməsi', '5-İşçinin xəstələnməsi', '6-Əmək müqaviləsinə xitam verilməsi', '7-Növbəli iş vaxtı',
    '8-Ayın ortası işə qəbul olma', '9-Qeyd olunan ay üzrə işəgötürənlə əmək müqaviləsi bağlanılmamışdır.', '10-İşçinin işəmuzd işləməsi',
    '11-İşçinin qanunvericiliklə nəzərdə tutulmuş hallarda və qaydada dövlət və ictimai vəzifələrin yerinə yetirilməsinə cəlb edildiyi müddət'];
  // Sütun rolları: [açar, ad, başlıq sözləri (fold edilmiş), istisna sözlər, məcburi]
  const ROLES = [
    ['name', 'Soyadı, adı, atasının adı', /soyad|s\.?a\.?a|ad[iı], soyad|isci|emekdas|ishci|ф\.?и\.?о|full ?name|^ad$|adi$/, /vezife|bolme|sobe|ata ad[iı]$/, true],
    ['fin', 'FİN', /fin|f\.i\.n|pin|şəxsiyyət|sexsiyyet/, null, true],
    ['gross', 'Hesablanmış əmək haqqı (cəmi)', /hesablan|cemi hesab|emek ?haqq|maas|gross|umumi gelir|cemi gelir|hesablanmis/, /odenil|odenecek|xalis|net|tutul|vergi|dsmf|mdss|sigorta|avans|isziz|tibbi|kart|bank|ezamiyye|mezuniyyet haqq/, true],
    ['days', 'Faktiki iş günləri', /faktiki|isledig|is gun|islenmis|gun say|islenen gun|islediyi gun/, /mezun|xeste|odenissiz|norma/, false],
    ['main', 'Əsas iş yeri (Bəli/Xeyr)', /esas is|evezci|evezcilik/, null, false],
    ['nonsal', 'Əmək haqqının tərkibinə daxil olmayan gəlirlər', /terkibine daxil olmayan|diger gelir|maddi yardim|hediyye|kompensasiya/, null, false],
    ['exempt', 'Azadolunan və güzəştli gəlir', /azad olunan|azadolunan|guzest|azad/, null, false],
    ['nodsmf', 'MDSS-yə cəlb olunmayan məbləğ', /mdss.*cel.*olunmayan|dsmf.*cel.*olunmayan/, null, false],
    ['noissiz', 'İşsizlik sığortasına cəlb olunmayan', /issizlik.*cel.*olunmayan/, null, false],
    ['notibb', 'Tibbi sığortaya cəlb olunmayan', /tibbi.*cel.*olunmayan/, null, false]];
  // İşləmədiyi gün sütunları → səbəb nömrəsi
  const ABS = [[/odenissiz/, 3], [/sosial|analiq|usaq|hamilelik/, 2], [/tehsil/, 4], [/xeste|bulleten|emek qabiliyyet/, 5], [/mezun/, 1]];
  const slots = [null, null, null];   // { file, sheets, si, hi, header, map, abs: {col: reason} }

  // Rüb seçimi
  const nowY = new Date().getFullYear();
  for (let y = nowY; y >= nowY - 2; y--) for (let q = 4; q >= 1; q--) $('q').add(new Option(`${y}, ${q}-cü rüb (${MONTHS[q * 3 - 3]} – ${MONTHS[q * 3 - 1]})`, `${y}.${q}`));
  const curQ = Math.floor(new Date().getMonth() / 3) + 1; $('q').value = curQ === 1 ? `${nowY - 1}.4` : `${nowY}.${curQ - 1}`;
  const qInfo = () => { const [y, q] = $('q').value.split('.').map(Number); return { y, q, m: [0, 1, 2].map(i => MONTHS[q * 3 - 3 + i]) }; };
  const paintMonths = () => { const { m } = qInfo(); m.forEach((n, i) => { $('mn' + i).textContent = `${i + 1}-ci ay: ${n}`; $('nl' + i).textContent = n; }); };
  $('q').onchange = paintMonths; paintMonths();

  // Başlıq sətri: ən çox rol sözünə uyğun gələn sətir (+ yuxarıdakı 2 sətir birləşdirilir)
  function headerOf(rows) {
    let best = -1, bs = 0;
    for (let r = 0; r < Math.min(rows.length, 30); r++) {
      const cells = (rows[r] || []).map(fold); let sc = 0;
      for (const [, , re, ex] of ROLES) if (cells.some(h => h && re.test(h) && !(ex && ex.test(h)))) sc++;
      if (sc > bs) { bs = sc; best = r; }
    }
    if (best < 0) return null;
    const width = Math.max(...rows.slice(best, best + 30).map(r => (r || []).length), 0);
    const header = Array.from({ length: width }, (_, c) => [rows[best - 2], rows[best - 1], rows[best]].map(r => r && r[c] ? String(r[c]).trim() : '').filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(' / '));
    return { hi: best, header };
  }
  // Sütunları tanı: həm başlığa, həm də məzmuna görə
  function autoMap(rows, hi, header) {
    const data = rows.slice(hi + 1).filter(r => r && r.some(v => String(v || '').trim())).slice(0, 300);
    const col = c => data.map(r => r[c]);
    const map = {}, used = new Set();
    // FİN — məzmuna görə (7 simvol, rəqəm + hərf)
    let bestF = -1, bf = 0;
    header.forEach((_, c) => { const v = col(c).filter(x => String(x || '').trim()), k = v.filter(x => fin(x)).length; if (v.length && k / v.length > bf && k >= 1) { bf = k / v.length; bestF = c; } });
    if (bestF >= 0 && bf >= 0.5) { map.fin = bestF; used.add(bestF); }
    // Hesablanmış gəlir: üstünlük sırası ilə ("cəmi hesablanıb" > "hesablanmış" > "əmək haqqı")
    const GROSS = [/cemi hesab|hesablan(mis|an)? ?cemi|umumi hesab|cemi gelir/, /hesablanmis emek|hesablanmis|hesablanib/, /gross|umumi gelir/, /emek ?haqq|maas/];
    const gx = ROLES.find(x => x[0] === 'gross')[3], gx2 = /vezife maas|tarif|stavka|norma|gunluk|saatliq/;
    for (const re of GROSS) { const c = header.findIndex((h, i) => !used.has(i) && h && re.test(fold(h)) && !gx.test(fold(h)) && !gx2.test(fold(h))); if (c >= 0) { map.gross = c; used.add(c); break; } }
    for (const [key, , re, ex] of ROLES) {
      if (map[key] != null) continue;
      const c = header.findIndex((h, i) => !used.has(i) && h && re.test(fold(h)) && !(ex && ex.test(fold(h))));
      if (c >= 0) { map[key] = c; used.add(c); }
    }
    // Ad — tapılmayıbsa: 2+ sözdən ibarət mətn sütunu
    if (map.name == null) {
      const c = header.findIndex((_, i) => !used.has(i) && col(i).filter(x => /^\p{L}+(\s+\p{L}+){1,3}$/u.test(String(x || '').trim())).length >= Math.max(1, data.length * 0.5));
      if (c >= 0) { map.name = c; used.add(c); }
    }
    // İşləmədiyi günlər (məzuniyyət, xəstəlik və s.) — yalnız "gün" sütunları
    const abs = {};
    header.forEach((h, c) => {
      if (used.has(c)) return; const f = fold(h);
      if (/haqq|mebleg|pul|azn|manat|odenis meb/.test(f)) return;
      const hit = ABS.find(([re]) => re.test(f)); if (!hit) return;
      const vals = col(c).map(numv).filter(v => !isNaN(v));
      if (!/gun/.test(f) && !(vals.length && vals.every(v => Number.isInteger(v) && v >= 0 && v <= 31))) return;
      abs[c] = hit[1];
    });
    return { map, abs };
  }
  function selectEl(header, val, allowNone = true) {
    const s = document.createElement('select');
    if (allowNone) s.add(new Option('— yoxdur —', ''));
    header.forEach((h, i) => s.add(new Option(`${String.fromCharCode(65 + (i % 26))}${i >= 26 ? Math.floor(i / 26) : ''}: ${String(h || '(boş)').slice(0, 50)}`, i)));
    s.value = val != null ? String(val) : '';
    return s;
  }
  function render(i) {
    const S = slots[i], box = $('m' + i); box.replaceChildren(); if (!S) return;
    if (S.sheets.length > 1) {
      const d = document.createElement('div'); d.className = 'sheet'; d.append('Vərəq:');
      const s = document.createElement('select'); S.sheets.forEach((sh, k) => s.add(new Option(sh.name || `Vərəq ${k + 1}`, k))); s.value = S.si;
      s.onchange = () => { useSheet(i, +s.value); }; d.append(s); box.append(d);
    }
    const det = document.createElement('details'); det.className = 'map'; det.open = ['name', 'fin', 'gross'].some(k => S.map[k] == null);
    det.innerHTML = '<summary>Tanınan sütunlar (yoxla, lazım olsa dəyiş)</summary>';
    const g = document.createElement('div'); g.className = 'grid';
    for (const [key, label, , , req] of ROLES) {
      const l = document.createElement('label'); l.textContent = label + (req ? ' *' : '');
      const s = selectEl(S.header, S.map[key]); s.onchange = () => { if (s.value === '') delete S.map[key]; else S.map[key] = +s.value; info(i); refresh(); };
      g.append(l, s);
    }
    const sep = document.createElement('label'); sep.textContent = 'İşləmədiyi gün sütunları:'; sep.style.cssText = 'grid-column:1/-1;margin-top:6px;color:var(--steel)'; g.append(sep);
    S.header.forEach((h, c) => {
      if (!h || Object.values(S.map).includes(c)) return;
      const f = fold(h); if (!(c in S.abs) && !/gun|mezun|xeste|bulleten/.test(f)) return;
      const l = document.createElement('label'); l.textContent = String(h).slice(0, 40);
      const s = document.createElement('select'); s.add(new Option('— hesaba alma —', ''));
      REASONS.forEach((r, k) => s.add(new Option(r.slice(0, 60), k + 1))); s.value = S.abs[c] ? String(S.abs[c]) : '';
      s.onchange = () => { if (s.value === '') delete S.abs[c]; else S.abs[c] = +s.value; info(i); };
      g.append(l, s);
    });
    det.append(g); box.append(det); info(i);
  }
  function rowsOf(S) {
    const M = S.map, out = [];
    for (const r of S.rows.slice(S.hi + 1)) {
      if (!r) continue; const f = fin(r[M.fin]); if (!f) continue;
      const g = k => M[k] == null ? NaN : numv(r[M[k]]);
      const mainRaw = M.main == null ? '' : fold(r[M.main]);
      const main = !mainRaw ? $('mainDef').value : /xeyr|evez|elave|no|0/.test(mainRaw) && !/esas|beli|yes/.test(mainRaw) ? 'Xeyr' : 'Bəli';
      const abs = {}; for (const [c, rs] of Object.entries(S.abs)) { const v = numv(r[c]); if (v > 0) abs[rs] = (abs[rs] || 0) + v; }
      out.push({ fin: f, name: String(r[M.name] || '').trim().replace(/\s+/g, ' '), main, days: g('days'), gross: g('gross'), nonsal: g('nonsal'), exempt: g('exempt'), nodsmf: g('nodsmf'), noissiz: g('noissiz'), notibb: g('notibb'), abs });
    }
    return out;
  }
  function info(i) {
    const S = slots[i], el = $('i' + i); if (!S) { el.textContent = ''; return; }
    const need = ['name', 'fin', 'gross'].filter(k => S.map[k] == null).map(k => ROLES.find(x => x[0] === k)[1]);
    if (need.length) { el.className = 'info err'; el.textContent = 'Seç: ' + need.join(', '); return; }
    const R = rowsOf(S), tot = R.reduce((t, x) => t + (x.gross || 0), 0);
    el.className = 'info'; el.innerHTML = `<span class="ok">✓ ${R.length} işçi</span>, hesablanmış cəmi ${f2(tot)} AZN` + (Object.keys(S.abs).length ? `, ${Object.keys(S.abs).length} işləmədiyi gün sütunu` : '');
  }
  function useSheet(i, si) {
    const S = slots[i], h = headerOf(S.sheets[si].rows);
    if (!h) { S.si = si; S.hi = 0; S.header = (S.sheets[si].rows[0] || []).map(String); S.map = {}; S.abs = {}; }
    else { Object.assign(S, { si, hi: h.hi, header: h.header }, autoMap(S.sheets[si].rows, h.hi, h.header)); }
    S.rows = S.sheets[si].rows; render(i); refresh();
  }
  async function load(i, file) {
    const el = $('i' + i); el.className = 'info'; el.textContent = 'Oxunur...';
    try {
      const sheets = (await readTable(file)).filter(s => s.rows && s.rows.length);
      if (!sheets.length) throw new Error('Faylda məlumat tapılmadı.');
      const good = sheets.map((s, k) => ({ k, h: headerOf(s.rows) })).filter(x => x.h);
      slots[i] = { file: file.name, sheets }; useSheet(i, good.length ? good[0].k : 0);
      $('d' + i).classList.add('done'); $('d' + i).querySelector('b').textContent = file.name;
      // 3 vərəqli fayl birinci aya atılıbsa: növbəti vərəqlər növbəti aylara
      if (i === 0 && good.length >= 2) for (let n = 1; n < Math.min(3, good.length); n++) if (!slots[n]) {
        slots[n] = { file: file.name, sheets }; useSheet(n, good[n].k);
        $('d' + n).classList.add('done'); $('d' + n).querySelector('b').textContent = `${file.name} · ${sheets[good[n].k].name}`;
      }
    } catch (e) { slots[i] = null; el.className = 'info err'; el.textContent = e.message; render(i); }
    refresh();
  }
  [0, 1, 2].forEach(i => {
    const drop = $('d' + i), input = drop.querySelector('input');
    input.onchange = () => input.files[0] && load(i, input.files[0]);
    drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
    drop.ondragleave = () => drop.classList.remove('over');
    drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); e.dataTransfer.files[0] && load(i, e.dataTransfer.files[0]); };
  });
  const ready = () => slots.some(S => S && ['name', 'fin', 'gross'].every(k => S.map[k] != null));
  function refresh() {
    $('go').disabled = !ready();
    const n = slots.filter(Boolean).length; $('sum').textContent = n ? `${n} ay seçilib. Yoxla və "Faylları hazırla" düyməsini bas.` : 'Ən azı bir ayın cədvəlini seç.';
  }

  // ---------- Şablonun doldurulması (e-taxes-in öz Excel nümunəsi) ----------
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zip(files) {
    const enc = new TextEncoder(), chunks = [], central = []; let off = 0;
    const now = new Date(), dt = ((now.getFullYear() - 1980) << 9 | (now.getMonth() + 1) << 5 | now.getDate()) & 0xFFFF, tm = (now.getHours() << 11 | now.getMinutes() << 5 | now.getSeconds() >> 1) & 0xFFFF;
    for (const f of files) {
      const nm = enc.encode(f.name), d = f.data, crc = crc32(d), n = d.length;
      const lh = new DataView(new ArrayBuffer(30)); lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(10, tm, true); lh.setUint16(12, dt, true); lh.setUint32(14, crc, true); lh.setUint32(18, n, true); lh.setUint32(22, n, true); lh.setUint16(26, nm.length, true);
      const ch = new DataView(new ArrayBuffer(46)); ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(12, tm, true); ch.setUint16(14, dt, true); ch.setUint32(16, crc, true); ch.setUint32(20, n, true); ch.setUint32(24, n, true); ch.setUint16(28, nm.length, true); ch.setUint32(42, off, true);
      chunks.push(new Uint8Array(lh.buffer), nm, d); central.push(new Uint8Array(ch.buffer), nm); off += 30 + nm.length + n;
    }
    const cd = central.reduce((s, c) => s + c.length, 0), end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cd, true); end.setUint32(16, off, true);
    const all = [...chunks, ...central, new Uint8Array(end.buffer)], out = new Uint8Array(all.reduce((s, c) => s + c.length, 0)); let p = 0;
    for (const c of all) { out.set(c, p); p += c.length; }
    return out;
  }
  const NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  const colName = i => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  // rows: [[value|null,...]] — firstRow-dan başlayaraq; stil şablonun firstRow sətrindən götürülür
  async function fillTemplate(path, firstRow, rows) {
    const buf = await (await fetch(chrome.runtime.getURL(path))).arrayBuffer(), z = await unzip(buf);
    const xml = await z.read('xl/worksheets/sheet1.xml'), doc = new DOMParser().parseFromString(xml, 'application/xml');
    const sd = doc.getElementsByTagNameNS(NS, 'sheetData')[0], style = {};
    let lastCol = 0;
    for (const r of Array.from(sd.getElementsByTagNameNS(NS, 'row'))) {
      const n = +r.getAttribute('r');
      if (n === firstRow) for (const c of Array.from(r.getElementsByTagNameNS(NS, 'c'))) { const ci = colIdx(c.getAttribute('r')); style[ci] = c.getAttribute('s'); lastCol = Math.max(lastCol, ci); }
      if (n >= firstRow) sd.removeChild(r);
    }
    rows.forEach((vals, k) => {
      const rn = firstRow + k, row = doc.createElementNS(NS, 'row'); row.setAttribute('r', rn);
      for (let ci = 0; ci <= Math.max(lastCol, vals.length - 1); ci++) {
        const v = vals[ci], c = doc.createElementNS(NS, 'c'); c.setAttribute('r', colName(ci) + rn); if (style[ci] != null) c.setAttribute('s', style[ci]);
        if (v != null && v !== '') {
          if (typeof v === 'number') { const e = doc.createElementNS(NS, 'v'); e.textContent = String(Math.round(v * 100) / 100); c.appendChild(e); }
          else { c.setAttribute('t', 'inlineStr'); const is = doc.createElementNS(NS, 'is'), t = doc.createElementNS(NS, 't'); t.textContent = String(v); is.appendChild(t); c.appendChild(is); }
        }
        row.appendChild(c);
      }
      sd.appendChild(row);
    });
    const dim = doc.getElementsByTagNameNS(NS, 'dimension')[0]; if (dim) dim.setAttribute('ref', `A1:${colName(lastCol)}${Math.max(firstRow, firstRow + rows.length - 1)}`);
    const out = new XMLSerializer().serializeToString(doc), enc = new TextEncoder(), files = [];
    for (const name of z.names) files.push({ name, data: enc.encode(name === 'xl/worksheets/sheet1.xml' ? out : await z.read(name)) });
    return zip(files);
  }
  function save(data, name) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  }
  

  $('go').onclick = async () => {
    $('go').disabled = true; say('Hazırlanır...'); $('warn').style.display = 'none';
    try {
      const { y, q, m: mn } = qInfo(), months = slots.map(S => S && ['name', 'fin', 'gross'].every(k => S.map[k] != null) ? rowsOf(S) : null);
      const emp = new Map(), dup = [];
      months.forEach((R, mi) => R && R.forEach(x => {
        const e = emp.get(x.fin) || { fin: x.fin, name: x.name, m: [null, null, null] };
        if (e.m[mi]) { dup.push(`${x.name} (${x.fin}), ${mn[mi]}`); const o = e.m[mi]; ['gross', 'nonsal', 'exempt', 'nodsmf', 'noissiz', 'notibb', 'days'].forEach(k => { if (!isNaN(x[k])) o[k] = (isNaN(o[k]) ? 0 : o[k]) + x[k]; }); for (const [r, d] of Object.entries(x.abs)) o.abs[r] = (o.abs[r] || 0) + d; }
        else e.m[mi] = { ...x, abs: { ...x.abs } };
        if (!e.name && x.name) e.name = x.name; emp.set(x.fin, e);
      }));
      const list = [...emp.values()].sort((a, b) => a.name.localeCompare(b.name, 'az'));
      if (!list.length) throw new Error('Heç bir işçi tapılmadı: FİN sütununu yoxla.');
      // Hissə 1: A №, B ad, C FİN; hər ay 11 sütun: əsas iş, gün, gəlir, o cümlədən, HYS, TP, azad, MDSS-yə cəlb olunmayan, MDSS(HYS), işsizlik, tibbi
      const nv = v => isNaN(v) ? null : v;
      const h1 = list.map((e, k) => { const r = [k + 1, e.name, e.fin]; e.m.forEach(x => { r.push(...(x ? [x.main, nv(x.days), nv(x.gross) ?? 0, nv(x.nonsal), null, null, nv(x.exempt), nv(x.nodsmf), null, nv(x.noissiz), nv(x.notibb)] : Array(11).fill(null))); }); return r; });
      // Hissə 3: hər işçi + səbəb üzrə bir sətir; günlər aylar üzrə
      const h3 = [], warns = [];
      for (const e of list) {
        const reasons = new Set(); e.m.forEach(x => x && Object.keys(x.abs).forEach(r => reasons.add(+r)));
        // Norma verilibsə: səbəbsiz işləmədiyi günlər
        const missing = [null, null, null];
        e.m.forEach((x, mi) => { const nrm = numv($('n' + mi).value); if (x && nrm > 0 && !isNaN(x.days)) { const absd = Object.values(x.abs).reduce((t, d) => t + d, 0), gap = nrm - x.days - absd; if (gap > 0.0001) { missing[mi] = gap; warns.push(`${e.name} (${e.fin}) — ${mn[mi]}: ${gap} gün işləməyib, səbəbi cədvəldə yoxdur (işə qəbul / xitam ola bilər)`); } } });
        if (e.m.some((x, mi) => !x && months[mi])) warns.push(`${e.name} (${e.fin}) — ${e.m.map((x, mi) => x || !months[mi] ? null : mn[mi]).filter(Boolean).join(', ')}: bu ayın cədvəlində yoxdur (işə qəbul / xitam olubsa, Hissə 3-də səbəb göstərilməlidir)`);
        for (const r of [...reasons].sort((a, b) => a - b)) h3.push([h3.length + 1, e.name, e.fin, ...e.m.map(x => x && x.abs[r] ? x.abs[r] : null), REASONS[r - 1]]);
      }
      const tag = `${y}-${q}rub`;
      const b1 = await fillTemplate('vb-hisse1.xlsx', 10, h1); save(b1, `DataX-vahid-hisse1-${tag}.xlsx`);
      let b3 = null; if (h3.length) { b3 = await fillTemplate('vb-hisse3.xlsx', 7, h3); setTimeout(() => save(b3, `DataX-vahid-hisse3-${tag}.xlsx`), 600); }
      // Önizləmə
      const tot = [0, 1, 2].map(mi => list.reduce((t, e) => t + (e.m[mi] && !isNaN(e.m[mi].gross) ? e.m[mi].gross : 0), 0));
      $('pv').innerHTML = `<table class="pv"><tr><th>Ay</th><th>İşçi</th><th>Hesablanmış gəlir, cəmi</th><th>İşləmədiyi gün sətri</th></tr>` +
        [0, 1, 2].map(mi => `<tr><td>${mn[mi]}</td><td class="n">${list.filter(e => e.m[mi]).length}</td><td class="n">${f2(tot[mi])}</td><td class="n">${h3.filter(r => r[3 + mi]).length}</td></tr>`).join('') + '</table>';
      if (dup.length) warns.unshift('Eyni ayda bir FİN bir neçə sətirdə: məbləğlər toplandı — ' + dup.slice(0, 5).join('; ') + (dup.length > 5 ? ` və daha ${dup.length - 5}` : ''));
      if (warns.length) { $('warn').textContent = 'Yoxla:\n• ' + warns.slice(0, 30).join('\n• ') + (warns.length > 30 ? `\n… və daha ${warns.length - 30}` : ''); $('warn').style.display = 'block'; }
      say(`Hazırdır: ${list.length} işçi. Hissə 1` + (h3.length ? ` və Hissə 3 (${h3.length} sətir)` : ' (işləmədiyi gün yoxdur, Hissə 3 faylı yaradılmadı)') + ' Yükləmələr qovluğundadır.', false, true);
    } catch (e) { say('Xəta: ' + e.message, true); }
    refresh();
  };
})();
