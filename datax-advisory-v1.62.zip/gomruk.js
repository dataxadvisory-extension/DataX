// egbtrader2.customs.gov.az / GBList.aspx: "DataX · Gömrük sənədləri" paneli.
// Tarix aralığı üzrə İdxal 40 bəyannamələrini siyahılayır; hər GB üçün GB (imzalı PDF), invoys və CMR PDF-lərini yükləyir.
// Panel Shadow DOM-dadır. Portalda heç nə dəyişdirilmir və göndərilmir: yalnız baxış və yükləmə.
(() => {
  if (window.__dxGomruk || !/GBList\.aspx$/i.test(location.pathname)) return; window.__dxGomruk = true;
  const h = (tag, props = {}, ...kids) => { const e = document.createElement(tag); Object.assign(e, props); kids.forEach(k => e.append(k)); return e; };
  const lic = () => new Promise(res => { try { chrome.runtime.sendMessage({ type: 'lic' }, r => { void chrome.runtime.lastError; res(!!(r && r.ok)); }); } catch (e) { res(false); } });
  const host = document.createElement('div'); host.id = 'dx-gomruk-host';
  const root = host.attachShadow({ mode: 'closed' });
  root.appendChild(h('style', { textContent: `
  :host{all:initial}*{box-sizing:border-box}
  .fab{position:fixed;right:14px;bottom:14px;z-index:2147483000;padding:9px 16px;border:0;border-radius:999px;background:linear-gradient(135deg,#3fb3a6,#2f8fa8);color:#fff;font:600 13px "Segoe UI",system-ui,Arial,sans-serif;cursor:pointer;box-shadow:0 8px 22px rgba(0,0,0,.35)}
  .p{position:fixed;right:14px;bottom:14px;z-index:2147483001;width:min(640px,calc(100vw - 28px));max-height:calc(100vh - 28px);display:none;flex-direction:column;font:13px/1.45 "Segoe UI",system-ui,Arial,sans-serif;color:#e8ecef;background:#1b2128;border:1px solid #37424d;border-radius:14px;box-shadow:0 12px 34px rgba(0,0,0,.45);overflow:hidden}
  .p.on{display:flex}.hd{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:linear-gradient(135deg,#223038,#1b2a30);font-weight:600}.hd span{color:#6ea5cc}.hd button{background:none;border:0;color:#8d99a5;font-size:18px;cursor:pointer}
  .bd{padding:12px 14px;overflow:auto}
  .row{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin-bottom:10px}
  label{display:block;font-size:12px;color:#8d99a5}input[type=date],select{display:block;margin-top:3px;padding:6px 8px;border:1px solid #37424d;border-radius:8px;background:#14181d;color:#e8ecef;font:inherit;color-scheme:dark}
  label.ck{display:flex;align-items:center;gap:6px;color:#c9ccce;font-size:12.5px}
  button.b{padding:7px 14px;border:1px solid #37424d;border-radius:999px;background:#262e37;color:#e8ecef;font:inherit;cursor:pointer}button.b:hover{border-color:#2a9488}button.b:disabled{opacity:.5;cursor:default}
  button.pri{border:0;background:linear-gradient(135deg,#3fb3a6,#2f8fa8);color:#fff;font-weight:600}
  .st{min-height:20px;margin:6px 0;font-size:12.5px;color:#8d99a5}.st.err{color:#ef8a7f}.st.ok{color:#7fd8a8}.st.warn{color:#f0a86a}
  .ls{border:1px solid #2b343d;border-radius:10px;max-height:300px;overflow:auto}
  .it{display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid #2b343d}.it:last-child{border-bottom:0}
  .tx{flex:1;min-width:0}.no{font-weight:600}.sb{color:#8d99a5;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .mini{padding:3px 9px;border:1px solid #37424d;border-radius:999px;background:#262e37;color:#e8ecef;font:12px inherit;cursor:pointer}.mini:hover{border-color:#2a9488}.mini:disabled{opacity:.5;cursor:default}
  .ft{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:10px}.nt{margin-top:8px;color:#8d99a5;font-size:11.5px}
  .mv{display:none;margin-top:12px;padding-top:10px;border-top:1px solid #2b343d}.mv.on{display:block}.mv h4{margin:0 0 8px;font-size:13px;color:#6ea5cc}
  .xt{width:100%;border-collapse:collapse;font-size:12px}.xt th{position:sticky;top:0;background:#222a32;color:#8d99a5;font-weight:600;text-align:left;padding:5px 6px}.xt td{padding:5px 6px;border-top:1px solid #2b343d;vertical-align:top}
  .xt td.n{text-align:right;white-space:nowrap}.xt .why{color:#7fd8a8;font-size:11px}.xt .dup{color:#f0a86a;font-size:11px}.xt select,.xt input[type=text],.xt input[type=number]{width:100%;padding:3px 5px;border:1px solid #37424d;border-radius:6px;background:#14181d;color:#e8ecef;font:12px inherit;color-scheme:dark}
  .xl{border:1px solid #2b343d;border-radius:10px;max-height:280px;overflow:auto}.xt td:last-child{min-width:150px}
  ` }));
  const fab = h('button', { className: 'fab', type: 'button', textContent: 'DataX · Gömrük sənədləri' });
  const today = new Date(), iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const from = h('input', { type: 'date', value: iso(new Date(today.getFullYear(), today.getMonth(), 1)) }), to = h('input', { type: 'date', value: iso(today) });
  const src = h('select', {}, h('option', { value: '2', textContent: 'Təmsilçi tərəfindən (Sahibkar üçün)' }), h('option', { value: '1', textContent: 'Şəxsən tərtib etdiyim' }));
  const only = h('input', { type: 'checkbox', checked: true }), mode = h('select', {}, h('option', { value: 'one', textContent: 'Hər GB bir PDF (GB + invoys + CMR)' }), h('option', { value: 'sep', textContent: 'Hər sənəd ayrıca (hər GB üçün qovluq)' }));
  const go = h('button', { className: 'b pri', type: 'button', textContent: 'Siyahını gətir' }), stEl = h('div', { className: 'st', role: 'status' }), ls = h('div', { className: 'ls' });
  const all = h('input', { type: 'checkbox', checked: true }), dl = h('button', { className: 'b pri', type: 'button', textContent: 'Seçilənləri yüklə (ZIP)', disabled: true }), stop = h('button', { className: 'b', type: 'button', textContent: 'Dayandır', style: 'display:none' });
  // ---- Maya dəyəri bölməsi ----
  const mcBtn = h('button', { className: 'b pri', type: 'button', textContent: 'Seçilənlərin maya dəyəri', disabled: true });
  const borderFr = h('input', { type: 'checkbox', checked: true });
  const vatPay = h('input', { type: 'checkbox', checked: true }), basis = h('select', {}, h('option', { value: 'cv', textContent: 'Gömrük dəyərinə görə' }), h('option', { value: 'kg', textContent: 'Çəkiyə görə (netto)' }));
  const mvSt = h('div', { className: 'st' }), xl = h('div', { className: 'xl' }), addX = h('button', { className: 'mini', type: 'button', textContent: '+ Əl ilə xərc' });
  const mk = h('button', { className: 'b pri', type: 'button', textContent: 'Excel hazırla' }), mDl = h('button', { className: 'b pri', type: 'button', textContent: '⬇ Yüklə', style: 'display:none' });
  const mv = h('div', { className: 'mv' }, h('h4', { textContent: 'Maya dəyəri' }),
    h('div', { className: 'row' }, h('label', { className: 'ck' }, vatPay, 'ƏDV ödəyicisiyik (idxal ƏDV-si maya dəyərinə daxil edilmir)'), h('label', {}, 'Ümumi xərclərin bölüşdürülməsi', basis)),
    h('div', { className: 'row' }, h('label', { className: 'ck' }, borderFr, 'Sərhədədək daşımanı GB-dən götür (EXW, FCA, FAS, FOB şərtlərində: gömrük dəyəri − invoys dəyəri)')),
    mvSt, h('div', { className: 'nt', style: 'margin:0 0 6px', textContent: 'GB-yə aid xərc qaimələri (e-taxes). İşarəli olanlar maya dəyərinə daxil edilir; GB-ni dəyişə bilərsən.' }), xl,
    h('div', { className: 'ft' }, addX, mk, mDl),
    h('div', { className: 'nt', textContent: 'Alış dəyəri: invoys dəyəri × GB-dəki məzənnə. Rüsum və aksiz malın öz sətrindən, GB-nin ümumi ödənişləri və xərc qaimələri seçilmiş üsulla bölünür. Gömrük Komitəsinin (Azərterminalkompleks) qaimələri GB-dəki xidmət haqqı ilə eyni ola bilər, ona görə avtomatik seçilmir.' }));
  const p = h('div', { className: 'p' },
    h('div', { className: 'hd' }, h('div', {}, 'Data', h('span', {}, 'X'), ' · Gömrük sənədləri və maya dəyəri'), h('button', { type: 'button', textContent: '×', title: 'Bağla', onclick: () => { p.classList.remove('on'); fab.style.display = ''; } })),
    h('div', { className: 'bd' },
      h('div', { className: 'row' }, h('label', {}, 'Tarixdən', from), h('label', {}, 'Tarixədək', to), h('label', {}, 'Mənbə', src), go),
      h('div', { className: 'row' }, h('label', { className: 'ck' }, only, 'Yalnız "İdxal 40" (qısa idxal bəyannamələri göstərilmir)')),
      stEl, ls,
      h('div', { className: 'ft' }, h('label', { className: 'ck' }, all, 'Hamısı'), h('label', {}, mode), dl, stop),
      h('div', { className: 'ft' }, mcBtn),
      mv,
      h('div', { className: 'nt', textContent: 'Fayllar yalnız bu kompüterə yüklənir. Portalda heç nə dəyişdirilmir.' })));
  root.append(fab, p);
  fab.onclick = async () => { p.classList.add('on'); fab.style.display = 'none'; if (!(await lic())) say('DataX lisenziyası aktiv deyil. Əlavənin pəncərəsindən lisenziya açarını daxil et.', 'err'); };
  const say = (m, k) => { stEl.textContent = m || ''; stEl.className = 'st' + (k ? ' ' + k : ''); };

  let rows = [], pages = [], busy = false, cancel = false; const sel = new Set();
  const refreshDl = () => { mcBtn.disabled = busy || !sel.size; dl.disabled = busy || !sel.size; dl.textContent = sel.size ? `Seçilənləri yüklə (${sel.size})` : 'Seçilənləri yüklə'; all.checked = rows.length > 0 && sel.size === rows.length; };
  const lock = on => { busy = on; go.disabled = on; mk.disabled = on; addX.disabled = on; stop.style.display = on ? '' : 'none'; ls.querySelectorAll('button,input').forEach(e => { e.disabled = on; }); refreshDl(); };
  function render() {
    ls.replaceChildren(); if (!rows.length) { ls.append(h('div', { className: 'it', style: 'color:#8d99a5', textContent: 'Siyahı boşdur.' })); refreshDl(); return; }
    rows.forEach(r => {
      const cb = h('input', { type: 'checkbox', checked: sel.has(r.no) }); cb.onchange = () => { cb.checked ? sel.add(r.no) : sel.delete(r.no); refreshDl(); };
      const btn = (t, what) => { const b = h('button', { className: 'mini', type: 'button', textContent: t, title: what === 'all' ? 'GB + invoys + CMR bir PDF' : t + ' PDF-i yüklə' }); b.onclick = () => one(r, what); return b; };
      ls.append(h('div', { className: 'it' }, cb, h('div', { className: 'tx' }, h('div', { className: 'no', textContent: r.no + ' · ' + r.opDate }), h('div', { className: 'sb', textContent: [r.sender, r.declarant].filter(Boolean).join(' · '), title: r.sender })), btn('GB', 'gb'), btn('Invoys', 'inv'), btn('CMR', 'cmr'), btn('Hamısı', 'all')));
    }); refreshDl();
  }
  all.onchange = () => { sel.clear(); if (all.checked) rows.forEach(r => sel.add(r.no)); render(); };

  go.onclick = async () => {
    if (busy) return; if (!(await lic())) { say('DataX lisenziyası aktiv deyil.', 'err'); return; }
    if (!from.value || !to.value || from.value > to.value) { say('Tarix aralığını düzgün seç (başlanğıc bitişdən böyük ola bilməz).', 'err'); return; }
    lock(true); say('Siyahı gətirilir...'); sel.clear();
    try {
      const r = await GB.search({ from: from.value, to: to.value, source: +src.value, only40: only.checked, onProgress: (n, t) => say(`Siyahı gətirilir: ${n}/${t || '?'}`) });
      rows = r.rows; pages = r.pages; rows.forEach(x => sel.add(x.no));
      say(rows.length ? `${rows.length} bəyannamə tapıldı` + (r.skipped ? ` (${r.skipped} qısa idxal və digər bəyannamə göstərilmir).` : '.') : 'Bu aralıqda uyğun bəyannamə tapılmadı' + (r.skipped ? ` (${r.skipped} digər növ göstərilmir).` : '.'), rows.length ? 'ok' : 'warn');
    } catch (e) { rows = []; say('Xəta: ' + e.message, 'err'); }
    render(); lock(false);
  };

  // Bir GB-nin sənədlərini götür və PDF/PDF-lər kimi qaytar
  async function bundle(r, want) { return GB.fetchDocs(r, pages[r.page], want); }
  async function one(r, what) {
    if (busy) return; if (!(await lic())) { say('DataX lisenziyası aktiv deyil.', 'err'); return; }
    lock(true); say(`${r.no}: sənədlər yüklənir...`);
    try {
      const want = { gb: what === 'gb' || what === 'all', inv: what === 'inv' || what === 'all', cmr: what === 'cmr' || what === 'all' };
      const d = await bundle(r, want);
      let list = what === 'gb' ? d.gb : what === 'inv' ? (d.invoys ? [d.invoys] : []) : what === 'cmr' ? (d.cmr ? [d.cmr] : []) : GB.ordered(d);
      if (!list.length) { say(`${r.no}: ${what === 'gb' ? 'GB' : what === 'inv' ? 'Invoys' : what === 'cmr' ? 'CMR' : 'sənəd'} tapılmadı. ${d.warn.join(' ')}`, 'err'); }
      else { const pdf = list.length === 1 ? list[0] : await GB.merge(list); GB.save(pdf, `${r.no}${what === 'all' ? '' : '_' + { gb: 'GB', inv: 'Invoys', cmr: 'CMR' }[what]}.pdf`, 'application/pdf'); say(`${r.no}: yükləndi.` + (d.warn.length ? ' Diqqət: ' + d.warn.join(' ') : ''), d.warn.length ? 'warn' : 'ok'); }
    } catch (e) { say(`${r.no}: xəta: ${e.message}`, 'err'); }
    lock(false);
  }
  stop.onclick = () => { cancel = true; say('Dayandırılır...', 'warn'); };
  dl.onclick = async () => {
    if (busy || !sel.size) return; if (!(await lic())) { say('DataX lisenziyası aktiv deyil.', 'err'); return; }
    const todo = rows.filter(r => sel.has(r.no)), files = [], bad = []; cancel = false; lock(true);
    try {
      for (let i = 0; i < todo.length && !cancel; i++) {
        const r = todo[i]; say(`${i + 1}/${todo.length}: ${r.no} yüklənir...`);
        try {
          const d = await bundle(r, { gb: true, inv: true, cmr: true });
          if (d.warn.length) bad.push(`${r.no}: ${d.warn.join(' ')}`);
          if (!GB.ordered(d).length) continue;
          if (mode.value === 'sep') {
            const dir = GB.safe(r.no) + '/'; d.gb.forEach((b, k) => files.push({ name: `${dir}GB${d.gb.length > 1 ? '_' + (k + 1) : ''}.pdf`, data: b }));
            if (d.invoys) files.push({ name: dir + 'Invoys.pdf', data: d.invoys }); if (d.cmr) files.push({ name: dir + 'CMR.pdf', data: d.cmr }); d.other.forEach(o => files.push({ name: `${dir}${GB.safe(o.label)}.pdf`, data: o.data }));
          } else { const list = GB.ordered(d); files.push({ name: GB.safe(r.no) + '.pdf', data: list.length === 1 ? list[0] : await GB.merge(list) }); }
        } catch (e) { bad.push(`${r.no}: ${e.message}`); }
        await GB.sleep(150);
      }
      if (files.length) {
        const name = `DataX-GB-${from.value}_${to.value}`;
        if (files.length === 1 && mode.value === 'one') GB.save(files[0].data, files[0].name, 'application/pdf'); else GB.save(GB.zip(files), name + '.zip', 'application/zip');
      }
      say((cancel ? 'Dayandırıldı. ' : '') + (files.length ? `Yükləndi: ${new Set(files.map(f => f.name.split('/')[0])).size} bəyannamə.` : 'Heç bir sənəd yüklənmədi.') + (bad.length ? ` Problemlər (${bad.length}): ` + bad.slice(0, 4).join(' | ') : ''), bad.length || !files.length ? 'warn' : 'ok');
    } catch (e) { say('Xəta: ' + e.message, 'err'); }
    lock(false);
  };
  // ---- Maya dəyəri: GB məlumatları + xərc qaimələri → Excel ----
  let mc = { gbs: [], lines: [] };
  const r2 = v => Math.round(v * 100) / 100, f2 = v => (Math.round(v * 100) / 100).toFixed(2), f4 = v => (Math.round(v * 10000) / 10000).toFixed(4);
  const dnumOf = s => { const m = /(\d{2})\.(\d{2})\.(\d{4})/.exec(s || ''); return m ? +(m[3] + m[2] + m[1]) : 0; };
  const VATC = ['32', '85'], isVat = p => VATC.includes(p.code) || /^18\s*%/.test(String(p.rate || '').trim()), PNAME = { '02': 'Gömrük yığımı', '20': 'Gömrük rüsumu', '27': 'Aksiz', '32': 'İdxal ƏDV-si', '85': 'ƏDV (xidmət haqqından)' };
  const ask = msg => new Promise(res => { try { chrome.runtime.sendMessage(msg, r => { void chrome.runtime.lastError; res(r || { error: 'DataX cavab vermədi — səhifəni yenilə (F5)' }); }); } catch (e) { res({ error: 'DataX yenilənib — səhifəni yenilə (F5)' }); } });
  const gbSel = (val) => { const s = h('select', {}, h('option', { value: '', textContent: '— GB seç —' })); mc.gbs.forEach(g => s.add(new Option(g.no, g.no))); s.value = val || ''; return s; };
  function renderX() {
    xl.replaceChildren(); const t = h('table', { className: 'xt' }); t.append(h('tr', {}, ...['', 'Qaimə', 'Xidmət', 'ƏDV-siz', 'ƏDV', 'GB'].map(x => h('th', { textContent: x }))));
    if (!mc.lines.length) t.append(h('tr', {}, h('td', { colSpan: 6, style: 'color:#8d99a5', textContent: 'Bu GB-lərə aid xərc qaiməsi tapılmadı. Lazımdırsa, "+ Əl ilə xərc" ilə əlavə et.' })));
    mc.lines.forEach(L => {
      const cb = h('input', { type: 'checkbox', checked: L.on }); cb.onchange = () => { L.on = cb.checked; };
      let gbCell;
      if (L.shares && Object.keys(L.shares).length > 1 || (L.shares && Object.values(L.shares)[0] < 0.999)) gbCell = h('td', { textContent: Object.entries(L.shares).map(([k, v]) => k + (v < 0.999 ? ` (${Math.round(v * 100)}%)` : '')).join(', ') });
      else { const s = gbSel(L.gb); s.onchange = () => { L.gb = s.value; L.shares = s.value ? { [s.value]: 1 } : null; }; gbCell = h('td', {}, s); }
      if (L.manual) {
        const d = h('input', { type: 'text', value: L.name, placeholder: 'Xərcin adı (məs. daşıma — Bakıdan anbara)' }); d.oninput = () => { L.name = d.value; };
        const a = h('input', { type: 'number', value: L.net || '', step: '0.01', placeholder: '0.00' }); a.oninput = () => { L.net = +a.value || 0; };
        t.append(h('tr', {}, h('td', {}, cb), h('td', { textContent: 'Əl ilə' }), h('td', {}, d), h('td', {}, a), h('td', { className: 'n', textContent: '—' }), gbCell));
      } else t.append(h('tr', {}, h('td', {}, cb), h('td', {}, h('div', { textContent: L.date + ' · ' + L.serial }), h('div', { className: 'sb', textContent: L.sender, title: L.voen + ' ' + L.sender })),
        h('td', {}, h('div', { textContent: L.name.length > 70 ? L.name.slice(0, 70) + '…' : L.name, title: L.name }), L.why ? h('div', { className: 'why', textContent: '✓ ' + L.why }) : '', /daşı|dasi|nəql|neql|logist|ekspedi|freight|cargo|kargo|transport|fraxt|frakt/i.test(L.name) ? h('div', { className: 'why', style: 'color:#6ea5cc', textContent: 'daşıma xərci' }) : '', L.dup ? h('div', { className: 'dup', textContent: 'GB-dəki xidmət haqqı ilə eyni ola bilər' }) : ''),
        h('td', { className: 'n', textContent: f2(L.net) }), h('td', { className: 'n', textContent: f2(L.vat) }), gbCell));
    });
    xl.append(t);
  }
  addX.onclick = () => { if (!mc.gbs.length) return; mc.lines.push({ manual: true, on: true, name: '', net: 0, vat: 0, gb: mc.gbs.length === 1 ? mc.gbs[0].no : '', shares: mc.gbs.length === 1 ? { [mc.gbs[0].no]: 1 } : null }); renderX(); };
  mcBtn.onclick = async () => {
    if (busy || !sel.size) return; if (!(await lic())) { say('DataX lisenziyası aktiv deyil.', 'err'); return; }
    const todo = rows.filter(r => sel.has(r.no)); cancel = false; lock(true); mv.classList.add('on'); mDl.style.display = 'none'; mc = { gbs: [], lines: [] }; renderX();
    const bad = [];
    for (let i = 0; i < todo.length && !cancel; i++) {
      mvSt.textContent = `${i + 1}/${todo.length}: ${todo[i].no} — gömrük məlumatları oxunur...`; mvSt.className = 'st';
      try { const d = await GB.costData(todo[i], pages[todo[i].page]); d.dnum = dnumOf(d.opDate) || dnumOf(d.created); mc.gbs.push(d); } catch (e) { bad.push(`${todo[i].no}: ${e.message}`); }
      await GB.sleep(150);
    }
    if (!mc.gbs.length) { mvSt.textContent = 'GB məlumatları oxunmadı. ' + bad.join(' | '); mvSt.className = 'st err'; lock(false); return; }
    mvSt.textContent = 'e-taxes-də xərc qaimələri axtarılır...';
    const r = await ask({ type: 'gbExpenses', gbs: mc.gbs.map(g => ({ no: g.no, dnum: g.dnum, plates: g.plates, declarantCode: g.declarantCode })) });
    let note = '';
    if (r.none) note = 'e-taxes açıq deyil: xərc qaimələri tapılmadı (e-taxes-ə başqa sekmədə daxil ol və yenidən bas). Xərcləri əl ilə əlavə edə bilərsən.';
    else if (r.error) note = r.error + '. Xərcləri əl ilə əlavə edə bilərsən.';
    else (r.invoices || []).forEach(v => v.items.forEach(it => {
      const shares = it.gb || (mc.gbs.length === 1 ? null : null);
      mc.lines.push({ on: !!it.gb && !it.dup, date: v.date, serial: v.serial, voen: v.voen, sender: v.name, name: it.name, net: it.net, vat: it.vat, why: it.why, dup: it.dup, shares, gb: shares && Object.keys(shares).length === 1 ? Object.keys(shares)[0] : '' });
    }));
    renderX();
    const nAuto = mc.lines.filter(l => l.on).length;
    mvSt.textContent = `${mc.gbs.length} GB oxundu. ` + (note || `${mc.lines.length} xərc sətri tapıldı, ${nAuto}-i avtomatik bağlandı.`) + (bad.length ? ' Oxunmayan: ' + bad.join(' | ') : '') + ' Yoxla və "Excel hazırla"-nı bas.';
    mvSt.className = 'st ' + (note || bad.length ? 'warn' : 'ok');
    lock(false);
  };
  function calc() {
    const vp = vatPay.checked, byKg = basis.value === 'kg', out = [], payRows = [], expRows = [];
    const TRANS = /daşı|dasi|nəql|neql|logist|ekspedi|freight|cargo|kargo|transport|shipping|fraxt|frakt/i, FTERM = /^(EXW|FCA|FAS|FOB)$/i;
    for (const g of mc.gbs) {
      const k = g.rate / (g.coeff || 1), W = g.goods.map(x => byKg ? (x.netto || x.brutto || x.cv) : (x.cv || x.inv * k)), Wt = W.reduce((a, b) => a + b, 0) || 1;
      let declIn = 0, declVat = 0;
      g.declPays.forEach(p => { const isV = isVat(p); if (isV) declVat += p.sum; else declIn += p.sum; payRows.push([g.no, 'GB üzrə', p.code, PNAME[p.code] || 'Kod ' + p.code, f2(p.base), p.rate, f2(p.sum), isV ? (vp ? 'Xeyr (ƏDV əvəzləşdirilir)' : 'Bəli') : 'Bəli']); });
      let exp = 0, trn = 0;
      mc.lines.filter(l => l.on && l.shares && l.shares[g.no] && (l.net || l.vat)).forEach(l => { const sh = l.shares[g.no], amt = (l.net + (vp ? 0 : l.vat || 0)) * sh, isT = TRANS.test(l.name || '');
        if (isT) trn += amt; else exp += amt;
        expRows.push([g.no, l.manual ? 'Əl ilə' : l.date, l.serial || '', l.voen || '', l.sender || '', l.name, isT ? 'Daşıma' : 'Digər', f2(l.net), f2(l.vat || 0), sh < 0.999 ? Math.round(sh * 100) + '%' : '100%', f2(amt), l.why || (l.manual ? 'əl ilə əlavə edilib' : 'seçilib')]); });
      const fTerm = FTERM.test(String(g.terms || '').trim());
      if (fTerm && borderFr.checked) g.goods.forEach(x => { const d = r2(Math.max(0, x.cv - x.inv * k)); if (d > 0) expRows.push([g.no, g.created || g.opDate, '', '', 'GB (' + g.terms + ')', 'Sərhədədək daşıma və sığorta — mal ' + x.n + ' (gömrük dəyəri − invoys dəyəri)', 'Daşıma', f2(d), '0.00', '100%', f2(d), 'GB-dən']); });
      g.goods.forEach((x, i) => {
        const w = W[i] / Wt, buy = x.inv * k; let duty = 0, exc = 0, vat = 0, oth = 0;
        x.pays.forEach(p => { if (p.code === '20') duty += p.sum; else if (p.code === '27') exc += p.sum; else if (isVat(p)) vat += p.sum; else oth += p.sum;
          payRows.push([g.no, 'Mal ' + x.n, p.code, PNAME[p.code] || 'Kod ' + p.code, f2(p.base), p.rate, f2(p.sum), isVat(p) ? (vp ? 'Xeyr (ƏDV əvəzləşdirilir)' : 'Bəli') : 'Bəli']); });
        const bf = fTerm && borderFr.checked ? Math.max(0, x.cv - buy) : 0;
        const fees = oth + declIn * w, tr = trn * w + bf, ex = exp * w, vIn = vp ? 0 : vat + declVat * w, tot = buy + duty + exc + fees + tr + ex + vIn;
        const pos = x.pos.length ? x.pos : [{ name: 'Mal ' + x.n, inv: x.inv, qty: x.netto, unit: 'kq' }], pt = pos.reduce((a, b) => a + b.inv, 0) || 1;
        pos.forEach(ps => { const s2 = (x.pos.length ? ps.inv / pt : 1), q = ps.qty || 0;
          out.push([g.no, g.opDate, x.code, ps.name, q ? String(q) : '', ps.unit, g.currency, f2(ps.inv), f4(k), f2(buy * s2), f2(x.cv * s2), f2(duty * s2), f2(exc * s2), f2(fees * s2), f2(tr * s2), f2(ex * s2), f2(vIn * s2), f2(tot * s2), q ? f4(tot * s2 / q) : '', g.terms || '']); });
      });
    }
    return { out, payRows, expRows };
  }
  mk.onclick = async () => {
    if (busy || !mc.gbs.length) return; lock(true); mDl.style.display = 'none'; mvSt.textContent = 'Excel hazırlanır...'; mvSt.className = 'st';
    const { out, payRows, expRows } = calc(), sum = c => r2(out.reduce((a, r) => a + (+r[c] || 0), 0));
    const total = ['Cəmi', '', '', '', '', '', '', '', '', ...[9, 10, 11, 12, 13, 14, 15, 16, 17].map(c => f2(sum(c))), '', ''];
    const num = [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];
    const sheets = [
      { name: 'Maya dəyəri', header: ['GB nömrəsi', 'GB tarixi', 'Mal kodu', 'Malın adı', 'Miqdar', 'Ölçü vahidi', 'Valyuta', 'İnvoys dəyəri (valyuta)', 'Məzənnə', 'Alış dəyəri (AZN)', 'Gömrük dəyəri (AZN)', 'Gömrük rüsumu', 'Aksiz', 'Gömrük yığımları', 'Daşıma xərcləri', 'Digər xərclər (qaimələr)', 'ƏDV (maya dəyərinə daxil)', 'Maya dəyəri cəmi', 'Vahidin maya dəyəri', 'Təhvil şərti'], rows: [...out, total], numCols: num, total: true, fmt2: true },
      { name: 'Gömrük ödənişləri', header: ['GB nömrəsi', 'Aid olduğu', 'Kod', 'Ödəniş', 'Hesablama üçün əsas', 'Dərəcə', 'Məbləğ (AZN)', 'Maya dəyərinə daxil'], rows: payRows, numCols: [4, 6], fmt2: true },
      { name: 'Xərc qaimələri', header: ['GB nömrəsi', 'Tarix', 'Seriya', 'VÖEN', 'Təchizatçı', 'Xidmət', 'Növ', 'Məbləğ (ƏDV-siz)', 'ƏDV', 'GB-yə düşən pay', 'Maya dəyərinə daxil', 'Necə bağlandı'], rows: expRows, numCols: [7, 8, 10], fmt2: true, keep: true },
      { name: 'Qeydlər', header: ['Qeyd'], numeric: false, keep: true, rows: [
        ['Alış dəyəri = invoys dəyəri × GB-dəki valyuta məzənnəsi (ödəniş günündəki məzənnə fərqi maya dəyərinə yox, məzənnə fərqinə aiddir).'],
        ['Gömrük rüsumu və aksiz hər malın öz sətrindən götürülüb; GB-nin ümumi ödənişləri və xərc qaimələri ' + (basis.value === 'kg' ? 'netto çəkiyə' : 'gömrük dəyərinə') + ' görə bölünüb.'],
        [vatPay.checked ? 'ƏDV ödəyicisi: idxal ƏDV-si və qaimələrin ƏDV-si maya dəyərinə daxil edilməyib (əvəzləşdirilir).' : 'ƏDV ödəyicisi deyil: idxal ƏDV-si və qaimələrin ƏDV-si maya dəyərinə daxil edilib.'],
        ['Daşıma: CIF, CIP, CFR, CPT, DAP, DPU, DDP şərtlərində daşıma satıcının qiymətinə (invoysa) daxildir. EXW, FCA, FAS, FOB şərtlərində sərhədədək daşıma və sığorta GB-dən götürülür (gömrük dəyəri − invoys dəyəri)' + (borderFr.checked ? '' : ' — bu seçim söndürülüb') + '. Sərhəddən anbaradək daşıma qaimədən və ya əl ilə əlavə edilir. Xarici daşıyıcıya ödənilən faktiki fraxt əl ilə yazılırsa, GB-dən götürməni söndür ki, iki dəfə hesablanmasın.'],
        ['Mal bir neçə invoys mövqeyindən ibarətdirsə, malın maya dəyəri mövqelər arasında invoys dəyərinə görə bölünüb.'],
        ['Xərc qaimələri GB nömrəsinə (qaimənin sətrində və ya qeydində) və GB-dəki maşın nömrəsinə görə tapılıb; qalanlarını istifadəçi seçib.']] } ];
    const r = await ask({ type: 'xlsx', filename: `DataX-maya-deyeri-${mc.gbs.length === 1 ? mc.gbs[0].no : mc.gbs.length + '-GB'}.xlsx`, sheets, group: 'maya' });
    if (r && r.ok) { mvSt.textContent = 'Excel hazırdır. Yükləmək üçün «Yüklə» düyməsini bas.'; mvSt.className = 'st ok'; mDl.style.display = ''; mDl.dataset.g = r.group; chrome.runtime.sendMessage({ type: 'use', fn: 'maya' }, () => void chrome.runtime.lastError); }
    else { mvSt.textContent = 'Xəta: ' + ((r && r.error) || 'Excel hazırlanmadı'); mvSt.className = 'st err'; }
    lock(false);
  };
  mDl.onclick = async () => { const r = await ask({ type: 'dl', group: mDl.dataset.g }); if (r && r.ok) { mDl.textContent = '✓ Yükləndi'; setTimeout(() => { mDl.textContent = '⬇ Yüklə'; }, 3000); } else { mvSt.textContent = 'Yüklənmədi: ' + ((r && r.error) || ''); mvSt.className = 'st err'; } };

  // Mal hərəkəti (fon): istənilən GB-lərin invoys dəyəri və məzənnəsi
  try { chrome.runtime.sendMessage({ type: 'dxGbListHere' }).catch(() => {}); } catch (e) {}
  chrome.runtime.onMessage.addListener((m, s, send) => {
    if (!m || m.type !== 'dxGbInv') return;
    (async () => {
      const want = new Set((m.regs || []).map(String)), out = {}, errs = [], t0 = Date.now();
      const rows = [];
      for (const src of [2, 1]) { try { const r = await GB.search({ from: m.from, to: m.to, source: src, only40: false }); r.rows.forEach(x => { if (want.has(x.no) && !rows.some(y => y.no === x.no)) rows.push({ ...x, pages: r.pages }); }); } catch (e) { errs.push(String(e.message || e)); } }
      for (const r of rows) {
        if (Date.now() - t0 > 240000) { errs.push('vaxt bitdi — qalan GB-lər gömrük dəyəri ilə hesablandı'); break; }
        try { out[r.no] = await GB.invData(r, r.pages[r.page]); } catch (e) { errs.push(r.no + ': ' + e.message); }
        await GB.sleep(80);
      }
      return { map: out, found: rows.length, errs };
    })().then(send, e => send({ error: String(e && e.message || e) }));
    return true;
  });

  const mount = () => { if (!host.isConnected) (document.body || document.documentElement).appendChild(host); };
  mount(); new MutationObserver(mount).observe(document.documentElement, { childList: true });
})();
