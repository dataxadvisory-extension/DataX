importScripts('asan-bg.js');                              // ASAN giriş siyahısı (ayrıca fayl)
const ORIGIN = 'https://new.e-taxes.gov.az';
const VERSION = chrome.runtime.getManifest().version;
const CONC = 6;                                            // eyni vaxtda oxunan bəyannamə sayı
const STEP = 'Əvəzləşdirmə üçün elektron qaimələr';        // e-taxes-dəki addımın adı (saytın öz yazısı)
let running = false, cancel = false, capture = null;   // capture: analiz üçün fayllar diskə yox, yaddaşa yazılır
let curFn = 'vat';
const log = (msg, done, extra = {}) => {
  msg = String(msg).replace(/\s*Fayl Yükləmələr qovluğundadır\./, capture ? '' : (done && jobFiles.length ? ' Faylı yükləmək üçün «Yüklə» düyməsini bas.' : ''));
  return chrome.storage.local.set({ status: { msg, done: !!done, t: Date.now(), fn: curFn, ...(done && !capture && jobFiles.length ? { files: jobFiles.slice() } : {}), ...extra } });
};
// ---- Hazır fayllar dərhal yüklənmir: yaddaşda (IndexedDB) saxlanır, istifadəçi «Yüklə» düyməsini basanda yüklənir ----
let jobFiles = [];                       // cari panel işinin hazır faylları (adlar)
const pendDb = () => new Promise((ok, no) => { const r = indexedDB.open('dxPending', 1); r.onupgradeneeded = () => r.result.createObjectStore('g'); r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error); });
async function pendOp(mode, fn) { const db = await pendDb(); return new Promise((ok, no) => { const tx = db.transaction('g', mode), st = tx.objectStore('g'); let out; Promise.resolve(fn(st, v => { out = v; })).catch(no); tx.oncomplete = () => { db.close(); ok(out); }; tx.onerror = () => { db.close(); no(tx.error); }; }); }
const pendGet = g => pendOp('readonly', (st, set) => { const r = st.get(g); r.onsuccess = () => set(r.result || []); });
async function pendAdd(group, file, reset) { const cur = reset ? [] : await pendGet(group); cur.push(file); await pendOp('readwrite', st => { st.put(cur, group); }); }
async function pendClear(group) { if (group === 'job') jobFiles = []; await pendOp('readwrite', st => { st.delete(group); }); }
async function pendDownload(group) {
  const files = await pendGet(group); if (!files.length) throw new Error('Yüklənəcək fayl tapılmadı — işi yenidən başlat.');
  for (const f of files) await chrome.downloads.download({ url: `data:${f.mime};base64,` + f.b64, filename: f.name, conflictAction: 'uniquify' });
  return files.length;
}
const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const mask = s => String(s || '').replace(/\d{6,}/g, '#');

// =====================================================================================
// Lisenziya: yalnız icazə verilmiş cihazda işləyir. Açar DataX-in gizli açarı ilə imzalanır,
// burada yalnız açıq (yoxlama) açarı var. Açar bu cihazın kodu və bitmə tarixi ilə bağlıdır.
// =====================================================================================
const LIC_PUB = {"kty":"RSA","n":"pZ3PW--5yL4Lv38L0jVwoDLnb95RtCy6z4MG7ahRplWbOMhU0GgGh1TtpUnm2UBjM7MECuioknq2JzHKugapjK_jr036TuYruDVh3q7LHxekRF65-3eC3iOsbMVR415GdL_r6ibywuDSP02V4bNIK1yNPNP6ogNJGHxjt-n8tV5-V-Qd4vOtbS_ciDTzYRx10gUYyScv4VsaKJPsvjS9JAqT_vN6ehRnqAbU3Du3BEjXYR1GE4IpUE0Fkle-BXaiW8Qoc5ZC11K8fbekgPA8OhxnveLSCMhlj7r_TlhlDRAWx5e6Z4VgBvdZI7HFfoEwVnToe9p5_gNg4KrXu_zRww","e":"AQAB"};
const b64u = s => { s = String(s || '').replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const r = atob(s), u = new Uint8Array(r.length); for (let i = 0; i < r.length; i++) u[i] = r.charCodeAt(i); return u; };
async function deviceId() {
  const { deviceId: d } = await chrome.storage.local.get('deviceId'); if (d) return d;
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', r = crypto.getRandomValues(new Uint8Array(12));
  const id = 'DX-' + [0, 4, 8].map(i => [...r.slice(i, i + 4)].map(x => A[x % A.length]).join('')).join('-');
  await chrome.storage.local.set({ deviceId: id }); return id;
}
async function checkLicense(keyText) {
  const dev = await deviceId(), st = await chrome.storage.local.get(['license', 'licSeen']);
  const key = String(keyText != null ? keyText : st.license || '').replace(/\s+/g, '');
  if (!key) return { ok: false, device: dev, reason: 'yoxdur' };
  try {
    const [p, s] = key.split('.'); if (!p || !s) throw new Error('format');
    const pk = await crypto.subtle.importKey('jwk', LIC_PUB, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
    const raw = b64u(p);
    if (!await crypto.subtle.verify('RSASSA-PKCS1-v1_5', pk, b64u(s), raw)) return { ok: false, device: dev, reason: 'imza' };
    const L = JSON.parse(new TextDecoder().decode(raw));
    if (L.d !== dev) return { ok: false, device: dev, reason: 'cihaz', name: L.n };
    const now = Math.max(Date.now(), st.licSeen || 0), until = new Date(L.u + 'T23:59:59').getTime();     // saatı geri çəkmək kömək etmir
    if (!(until >= now)) return { ok: false, device: dev, reason: 'bitib', name: L.n, until: L.u };
    if (keyText == null) await chrome.storage.local.set({ licSeen: Math.max(Date.now(), st.licSeen || 0) });
    // Mərkəzi siyahı: idarəetmə panelindən dayandırılıbsa və ya uzun müddət yoxlanıla bilmirsə
    const ls = await chrome.storage.local.get(['licState', 'licSync']);
    if (ls.licState && ls.licState.s === 'dayandirilib') return { ok: false, device: dev, reason: 'dayandirilib', name: L.n };
    if (!ls.licSync) await chrome.storage.local.set({ licSync: Date.now() });
    else if (Date.now() - ls.licSync > LIC_GRACE) return { ok: false, device: dev, reason: 'sinxron', name: L.n };
    return { ok: true, device: dev, name: L.n, until: L.u, days: Math.floor((until - now) / 864e5) };
  } catch (e) { return { ok: false, device: dev, reason: 'format' }; }
}
const LIC_MSG = { yoxdur: 'Lisenziya açarı daxil edilməyib.', imza: 'Açar etibarsızdır.', cihaz: 'Bu açar başqa cihaz üçündür.', bitib: 'Lisenziyanın müddəti bitib.', format: 'Açar düzgün deyil.',
  dayandirilib: 'Lisenziya dayandırılıb. Əlaqə: +994 50 656 21 01', sinxron: 'Lisenziya 14 gündür yoxlanıla bilmir. İnternetə qoşulub DataX-i yenidən açın.' };

// ---- Mərkəzi lisenziya siyahısı (GitHub, gizli açarla imzalı): dayandırma və avtomatik uzatma ----
const LIC_LIST_URL = 'https://raw.githubusercontent.com/dataxadvisory-extension/DataX/main/lisenziyalar.json';
const LIC_GRACE = 14 * 864e5;
let licSyncing = null;
function syncLicList() { return licSyncing || (licSyncing = doSyncLicList().finally(() => { licSyncing = null; })); }
async function doSyncLicList() {
  try {
    const r = await fetch(LIC_LIST_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (r.status === 404) { await chrome.storage.local.set({ licSync: Date.now() }); return { ok: false, http: 404 }; }   // siyahı hələ yayımlanmayıb
    if (!r.ok) return { ok: false, http: r.status };
    const j = await r.json(), data = String(j.data || ''), pk = await crypto.subtle.importKey('jwk', LIC_PUB, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
    if (!await crypto.subtle.verify('RSASSA-PKCS1-v1_5', pk, b64u(j.sig), new TextEncoder().encode(data))) return { ok: false, imza: true };
    const L = JSON.parse(data), dev = await deviceId(), st = await chrome.storage.local.get(['licListT', 'license']);
    if (st.licListT && L.t < st.licListT) return { ok: false, kohne: true };              // köhnə siyahı qəbul edilmir
    const e = (L.list || {})[dev] || null;
    const save = { licListT: L.t, licSync: Date.now(), licState: e ? { s: e.s || 'aktiv' } : null };
    if (e && e.k && e.k !== st.license) { const c = await checkLicense(e.k); if (c.ok || c.reason === 'dayandirilib' || c.reason === 'sinxron') save.license = e.k; }   // uzadılmış açar özü gəlir
    await chrome.storage.local.set(save);
    return { ok: true, state: save.licState };
  } catch (err) { return { ok: false, xeta: String(err && err.message || err) }; }
}
chrome.alarms.create('dx-lic', { periodInMinutes: 180 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'dx-lic') syncLicList(); });
chrome.runtime.onStartup.addListener(() => { syncLicList(); });
chrome.runtime.onInstalled.addListener(() => { syncLicList(); });

// Yenilənmə: yeniləyici proqram faylları diskdə dəyişəndə əlavə özünü yenidən yükləyir
async function diskVersion() { try { return (await (await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })).json()).version; } catch (e) { return null; } }
const vnum = v => String(v || '0').split('.').map(Number).reduce((a, x, i) => a + x * Math.pow(1000, 3 - i), 0);
async function checkUpdate() {
  const v = await diskVersion();
  if (v && vnum(v) > vnum(VERSION) && !running) { await chrome.storage.local.set({ updatedFrom: VERSION }); chrome.runtime.reload(); return true; }
  return false;
}
chrome.alarms.create('dx-update', { periodInMinutes: 15 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'dx-update') checkUpdate(); });
chrome.runtime.onStartup.addListener(() => { checkUpdate(); });

chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m.type === 'lic') { (m.sync ? syncLicList() : Promise.resolve()).then(() => checkLicense()).then(send); return true; }
  if (m.type === 'setLic') {
    syncLicList().then(() => checkLicense(m.key)).then(async r => { if (r.ok) { await chrome.storage.local.set({ license: String(m.key).replace(/\s+/g, ''), licSeen: Date.now() }); } send(r); });
    return true;
  }
  if (m.type === 'checkUpdate') { checkUpdate().then(r => send({ reloading: r })); return true; }
  if (m.type === 'own' || m.type === 'start') {
    checkLicense().then(lic => {
      if (!lic.ok) { const e = LIC_MSG[lic.reason] || 'Lisenziya yoxdur.'; if (m.type === 'start' && !running) { curFn = ['items', 'docs', 'decls', 'risk', 'mal'].includes(m.fn) ? m.fn : 'vat'; log('Xəta: ' + e, true); } send({ ok: false, error: e }); return; }
      handle(m, send);
    });
    return true;
  }
  if (m.type === 'cancel') { cancel = true; send({ ok: true }); return false; }
  if (m.type === 'dl') { pendDownload(m.group || 'job').then(n => send({ ok: true, n }), e => send({ ok: false, error: e.message })); return true; }
  if (m.type === 'xlsx') {                                   // analiz səhifəsindən: hazır vərəqlər → Excel faylı
    checkLicense().then(async lic => {
      if (!lic.ok) { send({ ok: false, error: LIC_MSG[lic.reason] || 'Lisenziya yoxdur.' }); return; }
      try { const group = m.direct ? null : 'x:' + (m.group || m.filename); await saveXlsx(m.filename, m.sheets, group); send({ ok: true, group }); } catch (e) { send({ ok: false, error: e.message }); }
    });
    return true;
  }
  if (m.type === 'dxCustomsHere') {                         // e-gömrük sekməsi özünü bildirir (gomruk-api.js)
    const id = _s && _s.tab && _s.tab.id;
    if (id != null) chrome.storage.session.get('dxCustomsTabs').then(({ dxCustomsTabs = [] }) => chrome.storage.session.set({ dxCustomsTabs: [...dxCustomsTabs.filter(x => x !== id), id].slice(-10) }));
    return;
  }
  if (m.type === 'analFetch') {                              // analiz səhifəsindən: gələn qaimələr + Əlavə 1 avtomatik yüklənir
    checkLicense().then(async lic => {
      if (!lic.ok) { send({ ok: false, error: LIC_MSG[lic.reason] || 'Lisenziya yoxdur.' }); return; }
      if (running) { send({ ok: false, error: 'Başqa iş gedir, bitməsini gözlə.' }); return; }
      send({ ok: true }); running = true; cancel = false; capture = [];
      const OFF = ['Ləğv edildi', 'Silindi', 'Sistem tərəfindən silindi'], ALL = ['Təsdiqləndi', 'Təsdiq gözləyir', 'Düzəliş edildi', 'Düzəlişə qaytarıldı', 'Ləğvə göndərildi', 'Sistem tərəfindən təsdiqləndi', 'Düzəlişə göndərildi', 'Ləğv edildi', 'Silindi', 'Sistem tərəfindən silindi', 'Passiv'];
      let out;
      try {
        curFn = 'items'; log('1 / 2: Daxil olan e-qaimələr yüklənir...');
        await runItems({ fn: 'items', tabId: m.tabId, from: m.dfrom, to: m.dto, dir: 'in', statuses: { known: ALL, on: ALL.filter(x => !OFF.includes(x)), other: true }, types: null });
        const a = capture.find(c => /^DataX-mallar-/.test(c.filename));
        if (cancel) throw new Error('Dayandırıldı.');
        if (!a) throw new Error('Gələn qaimələr alınmadı. Yuxarıdakı mesaja bax.');
        curFn = 'vat'; log('2 / 2: ƏDV bəyannamələrinin Əlavə 1 hissəsi yüklənir...');
        await run({ fn: 'vat', tabId: m.tabId, from: m.mfrom, to: m.mto, skipKameral: !!m.kam });
        const b = capture.find(c => /^DataX-elave1-/.test(c.filename));
        if (cancel) throw new Error('Dayandırıldı.');
        if (!b) throw new Error('Əlavə 1 qaimələri alınmadı. Yuxarıdakı mesaja bax.');
        out = { ok: true, inv: a.b64, decl: b.b64 };
      } catch (e) { out = { ok: false, error: e.message }; }
      capture = null; running = false;
      log(out.ok ? 'Fayllar yükləndi, analiz edilir...' : 'Xəta: ' + out.error, true);
      chrome.runtime.sendMessage({ type: 'analData', ...out }).catch(() => {});
    });
    return true;
  }
  if (m.type === 'evezFetch') {                              // Bəyannamə doldurma → ƏDV əvəzləşmə (308): qaimələr + əvvəlki Əlavə 1 + paylama
    checkLicense().then(async lic => {
      if (!lic.ok) { send({ ok: false, error: LIC_MSG[lic.reason] || 'Lisenziya yoxdur.' }); return; }
      if (running) { send({ ok: false, error: 'Başqa iş gedir, bitməsini gözlə.' }); return; }
      send({ ok: true }); running = true; cancel = false; curFn = 'vahid';
      let out;
      try {
        const res = await runEvezApi(m);
        const n = v => Math.round(v * 100) / 100;
        await saveXlsx(`DataX-edv-evezlesme-308-${m.period}-yoxlama.xlsx`, [
          { name: 'Fayla düşən qaimələr', header: ['Qaimənin tarixi', 'Seriya', 'Nömrə', 'Satıcının VÖEN-i', 'Satıcı', 'ƏDV-yə cəlb edilən məbləğ', 'Qaimənin ƏDV-si', 'Əvvəl əvəzləşib (ƏDV)', 'Bu ay ödənilib (ƏDV)', 'Fayla yazılan Əsas məbləğ', 'Qalıq tam bağlandı', 'Necə tapıldı', 'Ödəniş tarixləri'], numCols: [5, 6, 7, 8, 9],
            rows: res.rows.map(r => [r.date, r.ser, r.num, r.voen, r.name, n(r.b18), n(r.invVat), n(r.prev), n(r.paid), n(r.base), r.full ? 'Bəli' : 'Xeyr', r.how, r.pays]), keep: true },
          { name: 'Salınmayan ödənişlər', header: ['Ödəniş tarixi', 'VÖEN', 'Ad', 'Ödənilmiş ƏDV', 'Salınmayan ƏDV', 'Səbəb', 'Əməliyyatın təyinatı'], numCols: [3, 4],
            rows: res.unalloc.map(u => [u.date, u.voen, u.name, n(u.vat), n(u.left), u.why, u.purpose]), keep: true },
          { name: 'Qeydlər', header: ['Növ', 'Qeyd'], rows: [...res.notes, ...res.missing.map(x => x[5] ? ['Təsdiqlənməyib', `${x[0]} ödənişinin təyinatındakı qaimə (${x[3]}) hələ təsdiqlənməyib: ${x[5]} — fayla salınmadı`] : ['Tapılmadı', `${x[0]} ödənişinin təyinatındakı qaimə (${x[3]}) ${x[2]} (${x[1]}) qaimələri arasında tapılmadı`])], numeric: false }], 'evez');
        out = { ok: true, ...res };
      } catch (e) { out = { ok: false, error: e.message }; }
      running = false;
      log(out.ok ? `Hazırdır: ${out.rows.length} qaimə əvəzləşmə faylına düşdü.` : 'Xəta: ' + out.error, true);
      chrome.runtime.sendMessage({ type: 'evezData', ...out }).catch(() => {});
    });
    return true;
  }
  if (m.type === 'paket') {                                  // toplu e-qaimə səhifəsindən: hazır fayllar → zip paket
    checkLicense().then(async lic => {
      if (!lic.ok) { send({ ok: false, error: LIC_MSG[lic.reason] || 'Lisenziya yoxdur.' }); return; }
      try {
        const u8 = zipStore(m.files); let bin = '';
        for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
        await pendAdd('paket', { name: m.filename, mime: 'application/zip', b64: btoa(bin) }, true);
        await chrome.storage.local.set({ report: { versiya: VERSION, funksiya: 'topluQaime', qaime: m.files.length - 2, bayt: u8.length } });
        send({ ok: true, group: 'paket' });
      } catch (e) { send({ ok: false, error: e.message }); }
    });
    return true;
  }
  send({ ok: false }); return false;
});

function handle(m, send) {
  if (m.type === 'own') {
    if (running) { send({ ok: false, error: 'Başqa iş gedir, bitməsini gözlə.' }); return; }
    ownFromApi(m.tabId).then(own => ({ own, rep: { menbe: 'api' } })).catch(() => detectOwn(m.tabId)).then(async r => {
      await chrome.storage.local.set({ ownSeen: { name: r.own.name, voen: r.own.voen, t: Date.now() }, report: { versiya: VERSION, funksiya: 'ozSirketYoxla', menbe: r.own.menbe, ozSirket: r.rep } });
      send({ ok: true, own: r.own });
    }).catch(e => send({ ok: false, error: e.message })).finally(() => exec(m.tabId, rmAllFrames).catch(() => {}));
    return;
  }
  if (m.type === 'start' && !running) {
    running = true; curFn = ['items', 'docs', 'decls', 'risk', 'mal'].includes(m.fn) ? m.fn : 'vat'; cancel = false;
    pendClear('job').catch(() => {}).then(() => m.fn === 'items' ? runItems(m) : m.fn === 'risk' ? runRisk(m) : m.fn === 'mal' ? runStock(m) : m.fn === 'docs' ? runDocs(m) : m.fn === 'decls' ? runDecls(m) : run(m)).catch(e => log('Xəta: ' + e.message, true)).finally(() => { running = false; checkUpdate(); });
    send({ ok: true });
  } else send({ ok: false, error: 'Başqa iş gedir, bitməsini gözlə.' });
}

const exec = (tabId, func, args = [], allFrames = false) =>
  chrome.scripting.executeScript({ target: { tabId, allFrames }, func, args });
const execFrame = (tabId, frameId, func, args = [], world) =>
  chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, func, args, ...(world ? { world } : {}) });

// ================= Səhifənin içində işləyən funksiyalar (hər biri özü-özünə kifayət etməlidir) =================

// mode = 'list': bəyannamələr siyahısı (bütün səhifələr); mode = 'invoice': Əlavə 1 qaimə cədvəli
async function scrapeTable(mode, waitSec) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const mk = s => (s || '').replace(/\d{6,}/g, '#').replace(/\s+/g, ' ');
  const diag = () => ' | yol=' + mk(location.pathname) + ' | tables=' + document.querySelectorAll('table').length + ' | başlıq=' + mk(document.title);

  if (mode === 'list') {
    const RX = /(\S+)\s+(\d{4})\s*\/\s*(.+?)\s+Sənəd nömrəsi:\s*(\d+)/;
    const MON = { yanvar: 1, fevral: 2, mart: 3, aprel: 4, may: 5, iyun: 6, iyul: 7, avqust: 8, sentyabr: 9, oktyabr: 10, noyabr: 11, dekabr: 12 };
    const mnum = s => MON[s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()] || 0;
    const cells = tr => [...tr.children].filter(c => /^(TD|TH)$/.test(c.tagName));
    const readList = t => {
      const out = [];
      t.querySelectorAll('tr').forEach(tr => {
        const c = cells(tr); if (c.length < 5) return;
        const txt = clean(c[1].innerText); const m = txt.match(RX);
        if (!m || !mnum(m[1])) return;
        const a = tr.querySelector('a[href]');
        out.push({ period: m[1] + ' ' + m[2], month: mnum(m[1]), year: +m[2], type: m[3], docNo: m[4],
          kind: clean((txt.match(/Təqdim edilmə növü:\s*([^|]+)/) || [])[1]), kameral: /kameral/i.test(clean(tr.innerText)),
          date: clean(c[2].innerText), status: clean(c[3].innerText), href: a ? a.getAttribute('href') : '' });
      });
      return out;
    };
    const find = () => [...document.querySelectorAll('table')].find(t => readList(t).length) || null;
    const sig = () => { const t = find(); return t ? readList(t).map(x => x.docNo).join(',') : ''; };
    const waitChange = async old => { for (let i = 0; i < 60; i++) { await sleep(100); const s = sig(); if (s && s !== old) return true; } return false; };
    // Cədvələ aid səhifələmə (Ant Design)
    const pagOf = t => {
      const w = t.closest('.ant-table-wrapper'); let p = w && w.querySelector('.ant-pagination');
      if (p) return p;
      const nextTable = [...document.querySelectorAll('table')].find(x => x !== t && !t.contains(x) && (t.compareDocumentPosition(x) & 4));
      p = [...document.querySelectorAll('.ant-pagination')].find(e => t.compareDocumentPosition(e) & 4);
      return p && (!nextTable || (nextTable.compareDocumentPosition(p) & 2)) ? p : null;
    };
    let t = null;
    for (let i = 0; i < waitSec * 10; i++) { t = find(); if (t) break; await sleep(100); }
    if (!t) return { error: 'Siyahı cədvəli tapılmadı' + diag() };

    const all = new Map(); let pages = 0;
    const take = () => { const tt = find(); if (!tt) return; pages++; readList(tt).forEach(x => all.set(x.docNo, x)); };
    let p = pagOf(t);
    if (p) {
      const first = p.querySelector('.ant-pagination-item-1');
      if (first && !first.classList.contains('ant-pagination-item-active')) { const old = sig(); first.click(); await waitChange(old); }
      for (let n = 0; n < 80; n++) {
        take();
        t = find(); p = t && pagOf(t); if (!p) break;
        const nx = p.querySelector('.ant-pagination-next');
        if (!nx || nx.classList.contains('ant-pagination-disabled') || nx.getAttribute('aria-disabled') === 'true') break;
        const old = sig(); (nx.querySelector('button') || nx).click();
        if (!await waitChange(old)) break;
      }
    } else {
      // Ehtiyat: səhifə nömrələrinə klik
      const nextBtn = (tb, n) => [...document.querySelectorAll('button,li,a,span,div')].find(e =>
        e.childElementCount === 0 && clean(e.textContent) === String(n) && !e.closest('table') && (tb.compareDocumentPosition(e) & 4));
      for (let n = 1; n <= 40; n++) {
        take(); t = find(); if (!t) break;
        const b = nextBtn(t, n + 1); if (!b) break;
        const old = sig(); b.click();
        if (!await waitChange(old)) break;
      }
    }
    return { rows: [...all.values()], pages, paging: p ? 'ant' : 'nömrə' };
  }

  // ---------- Əlavə 1: qaimələr ----------
  const DATE = /^\d{2}\.\d{2}\.\d{4}$/;
  // <parse>
  const parseInvText = text => {
    const tok = text.split(/[\t\r\n]/).map(s => s.replace(/\s+/g, ' ').trim());
    const h = tok.findIndex(t => /^Sıra\s*№?$/i.test(t));
    if (h < 0) return null;
    let k = h + 1;
    while (k < tok.length && !/^\d+$/.test(tok[k])) k++;
    const header = tok.slice(h, k).filter(Boolean);
    const isStart = i => /^\d+$/.test(tok[i]) && /^\d{3}$/.test(tok[i + 1] || '') && /^\d{7,10}$/.test(tok[i + 2] || '') && DATE.test(tok[i + 3] || '');
    const starts = [];
    for (let i = k; i < tok.length; i++) if (isStart(i)) starts.push(i);
    const rows = starts.map((s, n) => {
      let e = n + 1 < starts.length ? starts[n + 1] : tok.length;
      const c = tok.findIndex((t, i) => i > s && /^CƏMİ$/i.test(t));
      if (c > -1 && c < e) e = c;
      const seg = tok.slice(s, e);
      while (seg.length && seg[seg.length - 1] === '') seg.pop();
      return seg;
    }).filter(r => r.length >= 6);
    return { header, rows };
  };
  // </parse>
  const domRows = () => {
    const found = [];
    document.querySelectorAll('*').forEach(e => {
      const n = e.children.length; if (n < 6 || n > 30) return;
      const x = [...e.children].map(c => clean(c.innerText));
      if (!/^\d+$/.test(x[0]) || !x.some(v => DATE.test(v))) return;
      found.push({ el: e, cells: x });
    });
    return found.filter(a => !found.some(b => b !== a && a.el.contains(b.el))).map(r => r.cells);
  };
  const domHeader = () => {
    const leaf = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && clean(e.textContent).startsWith('Qaimənin nömrəsi'));
    let e = leaf;
    for (let i = 0; e && i < 8; i++, e = e.parentElement) {
      if (e.children.length >= 6) {
        const x = [...e.children].map(c => clean(c.innerText));
        if (x.some(v => v.includes('VÖEN'))) return x;
      }
    }
    return [];
  };
  const readNow = () => {
    const d = domRows(); const txt = parseInvText(document.body ? document.body.innerText : '');
    if (d.length && (!txt || d.length >= txt.rows.length)) return { rows: d, header: domHeader() };
    if (txt && txt.rows.length) return { rows: txt.rows, header: txt.header };
    return null;
  };
  const pageInfo = () => {
    const m = (document.body ? document.body.innerText : '').match(/Görünür\s*(\d+)\s*-\s*(\d+)\s*\/\s*(\d+)/);
    return m ? { a: +m[1], b: +m[2], c: +m[3] } : null;
  };
  const sigOf = r => JSON.stringify((r ? r.rows : []).slice(0, 2));
  const pgAnchor = () => [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && /^Görünür/.test(clean(e.textContent)));

  let cur = null, hdr = 0;
  for (let i = 0; i < waitSec * 10; i++) {
    cur = readNow(); if (cur) break;
    if (domHeader().length && ++hdr > 12) return { header: domHeader(), rows: [] };     // cədvəl var, qaimə yoxdur
    await sleep(100);
  }
  if (!cur) return { error: 'Qaimə cədvəli tapılmadı' + diag() };

  const all = []; let prev = '', header = cur.header;
  for (let p = 1; p <= 80; p++) {
    cur = readNow(); if (!cur) break;
    const key = sigOf(cur);
    if (key === prev) break;
    all.push(...cur.rows); prev = key;
    if (!header.length) header = cur.header;
    const inf = pageInfo(); if (inf && inf.b >= inf.c) break;
    const an = pgAnchor(); if (!an) break;
    const b = [...document.querySelectorAll('button,li,a,span,div')].find(e =>
      e.childElementCount === 0 && clean(e.textContent) === String(p + 1) && (an.compareDocumentPosition(e) & 4));
    if (!b) break;
    b.click();
    for (let i = 0; i < 60; i++) { await sleep(100); if (sigOf(readNow()) !== key) break; }
  }
  return { header, rows: all };
}

// Bəyannamənin yan panelində addıma keçir. 'ok' | 'closed' (addım bağlıdır/yoxdur) | 'timeout' (səhifə açılmadı)
async function openStep(label, pathPart) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = e => (e.textContent || '').replace(/\s+/g, ' ').trim();
  const leaf = txt => [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && norm(e) === txt);
  const there = () => location.pathname.includes(pathPart);
  let el = null, loadedAt = 0;
  for (let i = 0; i < 200; i++) {                         // 20 saniyəyə qədər səhifənin açılmasını gözlə
    if (there()) return 'ok';
    el = leaf(label); if (el) break;
    if (!loadedAt && leaf('Ümumi məlumat')) loadedAt = i;
    if (loadedAt && i - loadedAt > 15) return 'closed';     // panel açılıb, amma bu addım yoxdur
    await sleep(100);
  }
  if (!el) return 'timeout';
  // Bağlı kimi görünürsə yenə bir dəfə yoxla, sadəcə az gözlə
  let dis = false;
  for (let e = el, i = 0; e && i < 4; i++, e = e.parentElement)
    if (e.getAttribute('aria-disabled') === 'true' || e.hasAttribute('disabled') || /disabled/i.test(typeof e.className === 'string' ? e.className : '')) dis = true;
  for (let attempt = 0; attempt < (dis ? 1 : 2); attempt++) {
    (leaf(label) || el).click();
    for (let i = 0; i < (dis ? 12 : 25); i++) { await sleep(100); if (there()) return 'ok'; }
  }
  return 'closed';
}

// Dəstək üçün (saytın öz kontekstində işləyir): sorğuların ünvanını və cavabın sütun ADLARINI qeyd edir, dəyərləri yox
function installHook() {
  if (window.__dx) return; const logs = window.__dx = [];
  const path = u => { try { const x = new URL(u, location.href); return x.pathname.replace(/\d{6,}/g, '#').replace(/\b(?=[A-Za-z0-9]*\d)(?=[A-Za-z0-9]*[A-Za-z])[A-Za-z0-9]{10,}\b/g, '#') + (x.search ? '?' + [...x.searchParams.keys()].join('&') : ''); } catch (e) { return '?'; } };
  const shape = (v, d = 0) => {
    if (v === null) return 'null';
    if (Array.isArray(v)) return v.length ? '[' + v.length + 'x] ' + shape(v[0], d + 1) : '[]';
    if (typeof v === 'object') return d > 4 ? '{...}' : '{' + Object.keys(v).slice(0, 40).map(k => k + ': ' + shape(v[k], d + 1)).join(', ') + '}';
    return typeof v;
  };
  const bodyShape = b => { try { return typeof b === 'string' ? shape(JSON.parse(b)).slice(0, 400) : b ? typeof b : null; } catch (e) { return 'mətn'; } };
  const of = window.fetch;
  window.fetch = async function (input, init) {
    const res = await of.apply(this, arguments);
    try {
      const url = typeof input === 'string' ? input : input.url;
      if (/\/api\//.test(url)) {
        const h = init && init.headers ? (init.headers.forEach ? (() => { const a = []; init.headers.forEach((v, k) => a.push(k)); return a; })() : Object.keys(init.headers)) : [];
        const e = { via: 'fetch', method: (init && init.method) || 'GET', url: path(url), status: res.status, basliqlar: h, govde: bodyShape(init && init.body) };
        logs.push(e);
        if ((res.headers.get('content-type') || '').includes('json')) res.clone().json().then(j => { e.cavab = shape(j).slice(0, 1500); }).catch(() => {});
      }
    } catch (e) {}
    return res;
  };
  const X = XMLHttpRequest.prototype, oo = X.open, os = X.send, oh = X.setRequestHeader;
  X.open = function (m, u) { this.__dx = { via: 'xhr', method: m, url: path(u), basliqlar: [] }; return oo.apply(this, arguments); };
  X.setRequestHeader = function (k) { if (this.__dx) this.__dx.basliqlar.push(k); return oh.apply(this, arguments); };
  X.send = function (b) {
    const e = this.__dx;
    if (e && /\/api\//.test(e.url)) {
      e.govde = bodyShape(b); logs.push(e);
      this.addEventListener('load', () => { try { e.status = this.status; const t = this.responseType; const j = t === 'json' ? this.response : (t === '' || t === 'text') ? JSON.parse(this.responseText) : null; if (j) e.cavab = shape(j).slice(0, 1500); } catch (x) {} });
    }
    return os.apply(this, arguments);
  };
}
function readHook() { return (window.__dx || []).slice(-30); }

function mkFrame(tag, url) {
  const f = document.createElement('iframe');
  f.id = tag; f.setAttribute('aria-hidden', 'true'); f.tabIndex = -1;
  f.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;border:0;opacity:0;pointer-events:none;z-index:-1';
  f.src = url; document.body.appendChild(f);
}
function rmFrame(tag) { const f = document.getElementById(tag); if (f) f.remove(); }
function rmAllFrames() { document.querySelectorAll('iframe[id^="dx-"]').forEach(f => f.remove()); }
function getHref() { return location.href; }

// Səhifədə: siyahının ilini dəyişir. { state: 'same' | 'ok' | səbəb, was: əvvəlki il }
async function setYear(year) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const visible = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const press = e => { for (const t of ['mousedown', 'mouseup', 'click']) e.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })); };
  const Y = String(year), isY = s => /^20\d{2}$/.test(s);
  const before = e => { const t = document.querySelector('table'); return !t || !!(t.compareDocumentPosition(e) & 2); };
  const ctl = () => {
    const inp = [...document.querySelectorAll('input')].find(e => visible(e) && isY((e.value || '').trim()) && before(e));
    if (inp) return { el: inp, val: inp.value.trim(), box: inp.closest('.ant-picker') || inp.parentElement || inp };
    const leaf = [...document.querySelectorAll('span, div, button, a')].find(e => e.childElementCount === 0 && visible(e) && isY(clean(e.textContent)) && before(e));
    return leaf ? { el: leaf, val: clean(leaf.textContent), box: leaf.closest('.ant-select, .ant-dropdown-trigger, button') || leaf.parentElement || leaf } : null;
  };
  const listSig = () => [...document.querySelectorAll('tbody tr')].slice(0, 12).map(tr => clean(tr.textContent).slice(0, 80)).join('|');
  let c = null;
  for (let i = 0; i < 100 && !(c = ctl()); i++) await sleep(100);
  if (!c) return { state: 'il seçimi tapılmadı', was: null };
  for (let i = 0; i < 80 && !document.querySelector('tbody tr') && !document.querySelector('.ant-empty'); i++) await sleep(100);
  const was = c.val;
  if (was === Y) return { state: 'same', was };
  const old = listSig();
  const done = async () => {
    for (let i = 0; i < 50; i++) { await sleep(100); const x = ctl(); if (x && x.val === Y) break; }
    const x = ctl(); if (!x || x.val !== Y) return false;
    for (let i = 0; i < 60; i++) { await sleep(100); if (listSig() !== old) break; }
    let last = null, same = 0; for (let i = 0; i < 25 && same < 5; i++) { await sleep(100); const s = listSig(); if (s === last) same++; else { same = 0; last = s; } }
    return true;
  };
  const options = () => [...document.querySelectorAll('*')].filter(e => e.childElementCount === 0 && visible(e) && clean(e.textContent) === Y && e !== c.el && !c.box.contains(e));
  const had = new Set(options());
  for (const target of [...new Set([c.el, c.box, c.box.querySelector && c.box.querySelector('.ant-select-selector, .ant-picker-input, svg')])].filter(Boolean)) {
    press(target); target.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
    let opt = null;
    for (let tries = 0; tries < 3 && !opt; tries++) {
      for (let i = 0; i < 12 && !opt; i++) { await sleep(100); opt = options().find(e => !had.has(e)); }
      if (opt) break;
      const prev = document.querySelector('.ant-picker-header-super-prev-btn');           // il onilliyin içində deyilsə, əvvəlki onilliyə keç
      if (prev && visible(prev) && +Y < +was) press(prev); else break;
    }
    if (opt) { press(opt.closest('td, li, [role="option"], [role="menuitem"], .ant-select-item') || opt); if (await done()) return { state: 'ok', was }; }
  }
  if (c.el.tagName === 'INPUT' && !c.el.readOnly) {              // son cəhd: ili xanaya yaz
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(c.el, Y);
    c.el.dispatchEvent(new Event('input', { bubbles: true })); c.el.dispatchEvent(new Event('change', { bubbles: true }));
    for (const t of ['keydown', 'keypress', 'keyup']) c.el.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    if (await done()) return { state: 'ok', was };
  }
  press(document.body);
  return { state: 'il dəyişmədi', was };
}

// Çərçivədəki siyahıda bəyannaməni tapıb adına klik edir; açılan səhifənin ünvanını qaytarır
async function clickDeclaration(docNo) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const fire = e => { if (typeof e.click === 'function') e.click(); else e.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); };
  const rowOf = () => [...document.querySelectorAll('tr')].find(tr => (tr.textContent || '').includes(docNo));
  const wraps = () => [...document.querySelectorAll('.ant-table-wrapper')];
  for (let i = 0; i < 100 && !document.querySelector('tbody tr'); i++) await sleep(100);
  let row = null;
  outer: for (let w = 0; w < Math.min(6, Math.max(1, wraps().length)); w++) {
    for (let p = 0; p < 60; p++) {
      row = rowOf(); if (row) break outer;
      const wr = wraps()[w], nx = wr && wr.querySelector('.ant-pagination-next');
      if (!nx || nx.classList.contains('ant-pagination-disabled') || nx.getAttribute('aria-disabled') === 'true') break;
      const old = wr.querySelector('tbody').textContent; (nx.querySelector('button') || nx).click();
      for (let i = 0; i < 60; i++) { await sleep(100); const t = wraps()[w]; if (t && t.querySelector('tbody') && t.querySelector('tbody').textContent !== old) break; }
    }
  }
  if (!row) return { error: 'bəyannamə çərçivədəki siyahıda tapılmadı' };
  const opened = () => /\/declaration\/type\//.test(location.pathname);
  for (const t of [row.querySelector('.clickable'), row.querySelector('a'), row.children[1] && row.children[1].querySelector('span'), row].filter(Boolean)) {
    fire(t); for (let j = 0; j < 40; j++) { await sleep(100); if (opened()) return { url: location.pathname + location.search }; }
  }
  return { error: 'bəyannamənin adına klik işləmədi' };
}

// Çərçivədəki siyahıda bəyannaməyə klik edir. Klik səhifəni tam yeniləsə (skript yarımçıq qalır), çərçivənin yeni ünvanı gözlənilir.
async function clickDeclIn(tabId, fid, docNo) {
  let c = null;
  try { c = await inFrame(tabId, fid, clickDeclaration, [docNo]); } catch (e) { c = null; }
  if (c && (c.url || c.error)) return c;
  for (let i = 0; i < 80; i++) {
    try {
      const h = await inFrame(tabId, fid, getHref, []);
      if (h && /\/declaration\/type\//.test(h) && h.includes(docNo)) { const u = new URL(h); return { url: u.pathname + u.search, reloaded: true }; }
    } catch (e) {}
    await sleep(250);
  }
  return { error: 'klik alınmadı: bəyannamə səhifəsi açılmadı' };
}

// ================= Arxa plan məntiqi =================

function navigate(tabId, url) {
  return new Promise(res => {
    const f = async (id, info) => {
      if (id !== tabId || info.status !== 'complete') return;
      try { const t = await chrome.tabs.get(tabId); if ((t.url || '').startsWith(ORIGIN)) done(); } catch (e) { done(); }
    };
    const done = () => { clearTimeout(to); chrome.tabs.onUpdated.removeListener(f); res(); };
    const to = setTimeout(done, 30000);
    chrome.tabs.onUpdated.addListener(f);
    chrome.tabs.update(tabId, { url });
  });
}

const num = s => { const v = parseFloat(String(s || '').replace(/[\s ]/g, '').replace(',', '.')); return isNaN(v) ? 0 : v; };
const dnum = s => { const m = (s || '').match(/(\d{2})\.(\d{2})\.(\d{4})/); return m ? +(m[3] + m[2] + m[1]) : 0; };
const declUrl = (d, tpl) => ORIGIN + (tpl ? tpl.replace('{reg}', d.docNo) : `/eportal/declaration/type/vat/${d.year}.1/confirmation?reg-number=${d.docNo}`);

// Açılmış bəyannamədə Əlavə 1-ə keçir və oxuyur. Əlavə 1 bağlıdırsa { skip: true }
async function readDeclaration(run1) {
  const step = await run1(openStep, [STEP, 'appendix-1']);
  if (step === 'closed') return { skip: true };
  if (step !== 'ok') return { error: 'bəyannamə səhifəsi açılmadı (' + step + ')' };
  return await run1(scrapeTable, ['invoice', 12]);
}
const declInFrame = async (tabId, fid, wantApi) => {
  if (wantApi) { try { await inFrame(tabId, fid, installHook, [], 'MAIN'); } catch (e) {} }
  const res = await readDeclaration((fn, args) => inFrame(tabId, fid, fn, args));
  if (wantApi && res && !res.error && !res.skip) { try { res.api = await inFrame(tabId, fid, readHook, [], 'MAIN'); } catch (e) {} }
  return res;
};
// Bəyannaməni ünvanı ilə görünməz çərçivədə açır (yeni tab yoxdur)
const declByUrl = (tabId, d, tpl, wantApi) => withFrame(tabId, 'dx-d' + d.docNo, declUrl(d, tpl), fid => declInFrame(tabId, fid, wantApi));
// Ünvan məlum deyilsə: çərçivədə siyahını açır, ili seçir, bəyannamənin adına klik edir; ünvan şablonunu da öyrənir
const declByClick = (tabId, d, wantApi) => withFrame(tabId, 'dx-k' + d.docNo, ORIGIN + '/eportal/declarations', async fid => {
  const y = await inFrame(tabId, fid, setYear, [d.year]);
  if (!y || !/^(ok|same)$/.test(y.state)) return { error: 'çərçivədə il seçilmədi: ' + (y && y.state) };
  const c = await clickDeclIn(tabId, fid, d.docNo);
  if (!c || c.error) return { error: (c && c.error) || 'klik alınmadı' };
  const res = await declInFrame(tabId, fid, wantApi);
  if (res && c.url.includes(d.docNo)) res.tpl = c.url.replace(d.docNo, '{reg}');
  return res;
});
// Ehtiyat (çərçivə ümumiyyətlə işləməsə): eyni tabda, yenə yeni tab açmadan
async function openInTab(tabId, d, tpl) {
  await navigate(tabId, declUrl(d, tpl));
  return await readDeclaration(async (fn, args) => (await exec(tabId, fn, args))[0].result);
}

async function runVatDom({ tabId, from, to, skipKameral }) {
  const t0 = Date.now();
  const orig = (await chrome.tabs.get(tabId)).url;
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), nowY = new Date().getFullYear();
  const years = []; for (let y = fy; y <= Math.min(ty + 1, nowY); y++) years.push(y);      // gecikmiş bəyannamə növbəti ilin siyahısında ola bilər
  if (!years.length) years.push(fy);

  // 1) Hər ilin siyahısını oxu
  const byDoc = new Map(), yearNotes = []; let origYear = null, pagesRead = 0;
  for (const y of years) {
    if (cancel) break;
    log(`${y}-ci ilin bəyannamələr siyahısı oxunur...`);
    const st = (await exec(tabId, setYear, [y]))[0].result || { state: 'cavab yoxdur' };
    if (origYear === null && st.was) origYear = st.was;
    if (!/^(ok|same)$/.test(st.state)) { if (y >= fy && y <= ty) yearNotes.push(`${y}: ${st.state}`); continue; }
    const list = (await exec(tabId, scrapeTable, ['list', st.state === 'ok' ? 6 : 12]))[0].result;
    if (!list || list.error) { if (y >= fy && y <= ty && st.state === 'same') yearNotes.push(`${y}: ${mask(list && list.error)}`); continue; }
    pagesRead += list.pages || 0;
    list.rows.forEach(x => { if (!byDoc.has(x.docNo)) byDoc.set(x.docNo, { ...x, listYear: y }); });
  }
  if (origYear && String(years[years.length - 1]) !== origYear) { try { await exec(tabId, setYear, [+origYear]); } catch (e) {} }   // istifadəçinin seçdiyi ili qaytar

  // 2) Hər ay üçün yalnız ən son bəyannamə; seçim aktivdirsə kameral bəyannamələr nəzərə alınmır
  const inRange = [...byDoc.values()].filter(x => { const v = x.year * 12 + x.month; return v >= fy * 12 + fm && v <= ty * 12 + tm; });
  const kameralCount = inRange.filter(x => x.kameral).length, best = {};
  inRange.filter(x => !(skipKameral && x.kameral)).forEach(x => {
    const k = x.year * 12 + x.month, b = best[k];
    if (!b || dnum(x.date) > dnum(b.date) || (dnum(x.date) === dnum(b.date) && x.docNo > b.docNo)) best[k] = x;
  });
  const sel = Object.values(best).sort((a, b) => a.year * 12 + a.month - (b.year * 12 + b.month));
  const baseReport = { versiya: VERSION, funksiya: 'elave1', iller: years, ilQeydleri: yearNotes, siyahi: { setir: byDoc.size, sehife: pagesRead, araliqda: inRange.length, kameral: kameralCount } };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş aylarda bəyannamə tapılmadı.' + (yearNotes.length ? ` Bu illərin siyahısı açılmadı: ${yearNotes.join('; ')}. Saytda ili əl ilə seçib yenidən başlat.` : ''));

  cancel = false;
  const results = new Array(sel.length).fill(null), summaries = new Array(sel.length).fill(null);
  let header = null, doneCount = 0, api = null, mode = 'iframe', apiAsked = false;
  const report = () => log(`${doneCount} / ${sel.length} bəyannamə oxundu. ` + (mode === 'iframe' ? 'Siyahı səhifəsini açıq saxla.' : 'Bu tabı bağlama və toxunma.'),
    false, { i: doneCount, n: sel.length, summary: summaries.filter(Boolean) });
  const short = t => t === 'Cari' ? 'Cari' : /^Dəqiq/.test(t) ? 'Dəqiq.' : t;
  const record = (i, res) => {
    const d = sel[i]; results[i] = res;
    if (res && res.skip) summaries[i] = { p: d.period, k: short(d.type), note: 'Əlavə 1 yoxdur' };
    else if (res && !res.error) {
      if (!header && res.header.length) header = res.header;
      if (res.api && res.api.length) api = res.api;
      const hh = res.header.length ? res.header : (header || []);
      const ti = hh.findIndex(v => /Ümumi məbləğ/.test(v)), vi = hh.findIndex(v => /ƏDV məbləği/.test(v));
      summaries[i] = { p: d.period, k: short(d.type), c: res.rows.length,
        t: ti > -1 ? res.rows.reduce((s, x) => s + num(x[ti]), 0) : null, v: vi > -1 ? res.rows.reduce((s, x) => s + num(x[vi]), 0) : null };
    }
    doneCount++; report();
  };
  report();

  // 3) Hər il üçün bəyannamə ünvanının quruluşunu bir dəfə öyrən (köhnə illərdə fərqli ola bilər)
  const tpl = {}, learnNotes = [];
  try {
    for (const y of [...new Set(sel.map(d => d.year))]) {
      if (cancel) break;
      const i = sel.findIndex(d => d.year === y);
      let res; try { res = await declByClick(tabId, sel[i], !api); } catch (e) { res = { error: 'İstisna: ' + e.message }; }
      if (res && res.tpl) tpl[y] = res.tpl;
      if (res && !res.error) record(i, res); else learnNotes.push(`${y}: ${mask(res && res.error)}`);
    }

    // 4) Qalanları paralel oxu
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(CONC, sel.length) }, async () => {
      while (!cancel && next < sel.length) {
        const i = next++; if (results[i]) continue;
        const wantApi = !api && !apiAsked; if (wantApi) apiAsked = true;
        let res; try { res = await declByUrl(tabId, sel[i], tpl[sel[i].year], wantApi); } catch (e) { res = { error: 'İstisna: ' + e.message }; }
        if (res && res.error && !res.frameFail && !tpl[sel[i].year]) {                 // təxmin edilən ünvan işləmədi: kliklə aç
          let r2; try { r2 = await declByClick(tabId, sel[i], false); } catch (e) { r2 = { error: e.message }; }
          if (r2 && r2.tpl) tpl[sel[i].year] = r2.tpl;
          res = r2 && !r2.error ? r2 : { error: res.error + ' || ' + (r2 && r2.error) };
        }
        if (wantApi && !(res && res.api && res.api.length)) apiAsked = false;
        record(i, res);
      }
    }));
  } finally { try { await exec(tabId, rmAllFrames); } catch (e) {} }

  // Çərçivə ümumiyyətlə açılmayıbsa: həmin bəyannamələri eyni tabda oxu
  const failed = sel.map((_, i) => i).filter(i => results[i] && results[i].frameFail);
  if (failed.length && !cancel) {
    mode = 'main'; doneCount -= failed.length;
    for (const i of failed) {
      if (cancel) break;
      let res; try { res = await openInTab(tabId, sel[i], tpl[sel[i].year]); } catch (e) { res = { error: 'İstisna: ' + e.message }; }
      record(i, res);
    }
    await navigate(tabId, orig);
  }

  const rows = [], notes = []; let total = 0, okCount = 0, skipCount = 0, errCount = 0;
  sel.forEach((d, i) => {
    const res = results[i]; if (!res) return;
    const name = d.period + ' / ' + d.type;
    if (res.skip) { skipCount++; notes.push(['Məlumat', name, d.docNo, 'Əlavə 1 açıq deyil, keçildi']); return; }
    if (res.error) { errCount++; notes.push(['Xəta', name, d.docNo, mask(res.error)]); return; }
    okCount++; total += res.rows.length;
    res.rows.forEach(row => rows.push([d.period, d.type, d.docNo, ...row]));
  });
  yearNotes.forEach(n => notes.push(['Xəbərdarlıq', n.split(':')[0] + '-ci il', '', 'Bu ilin siyahısı açılmadı (' + n.split(': ')[1] + '). Saytda ili əl ilə seçib yenidən başlat.']));
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan aylar fayla düşmədi']);

  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...baseReport, rejim: mode, saniye: sec, secilen: sel.length, oxundu: okCount, elave1Yox: skipCount, xeta: errCount,
    unvan: Object.fromEntries(Object.entries(tpl).map(([y, t]) => [y, t])), oyrenme: learnNotes,
    xetalar: [...new Set(sel.map((d, i) => results[i] && results[i].error ? mask(results[i].error) : null).filter(Boolean))].slice(0, 5), api } });

  await saveXlsx(`DataX-elave1-${from}_${to}.xlsx`, [
    { name: 'Əlavə 1 qaimələri', header: ['Dövr', 'Növ', 'Sənəd nömrəsi', ...(header || [])], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Bəyannamə', 'Sənəd nömrəsi', 'Qeyd'], rows: notes, numeric: false }]);
  const parts = [`${okCount} bəyannamədən ${total} qaimə`];
  if (skipCount) parts.push(`${skipCount} bəyannamədə Əlavə 1 yoxdur`);
  if (errCount) parts.push(`${errCount} bəyannamə oxunmadı`);
  const bad = yearNotes.length ? `\n${yearNotes.map(n => n.split(':')[0]).join(', ')}-ci ilin siyahısı açılmadı: saytda ili əl ilə seçib yenidən başlat.` : '';
  log((bad ? 'Natamam' : 'Hazırdır') + ` (${sec} san): ${parts.join(', ')}.` + (bad || ' Fayl Yükləmələr qovluğundadır.'), true,
    { i: sel.length, n: sel.length, summary: summaries.filter(Boolean), hasErrors: !!errCount || !!bad });
}

// =====================================================================================
// FUNKSİYA 2: Elektron qaimə-fakturaların içindəki mallar və xidmətlər
// =====================================================================================

// Səhifədə işləyir: qaimə siyahısı.
//  mode 'walk': bölməni (Gələnlər / Göndərilənlər) seçir, bütün səhifələri gəzib tarix aralığındakı qaimələri qaytarır
//  mode 'find': (gizli çərçivədə) bölməni seçir və verilmiş seriyalı qaimə görünənə qədər səhifələri gəzir
//  mode 'page': (gizli çərçivədə) yalnız açıq olan səhifəni oxuyur
async function invoiceList(o) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const DT = /(\d{2})\.(\d{2})\.(\d{4})\s+\d{2}:\d{2}/;
  const dn = s => { const m = (s || '').match(DT); return m ? +(m[3] + m[2] + m[1]) : 0; };
  const visible = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const press = e => { for (const t of ['mousedown', 'mouseup', 'click']) e.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })); };
  const off = e => { for (let x = e, i = 0; x && i < 3; i++, x = x.parentElement) if (x.disabled || x.getAttribute('aria-disabled') === 'true' || /disabled/i.test(typeof x.className === 'string' ? x.className : '')) return true; return false; };
  const rowEls = () => {
    let r = [...document.querySelectorAll('tr')].filter(tr => /Seriya və nömrə:/.test(tr.textContent || ''));
    if (!r.length) {                                          // cədvəl deyilsə: mətnə görə sətir konteynerini tap
      const set = new Set();
      [...document.querySelectorAll('*')].filter(e => e.childElementCount === 0 && /Seriya və nömrə/.test(e.textContent || '')).forEach(l => {
        for (let e = l, i = 0; e && i < 9; i++, e = e.parentElement) if (DT.test(e.textContent || '')) { set.add(e); break; }
      });
      r = [...set];
    }
    return r.filter(a => !r.some(b => b !== a && a.contains(b)));
  };
  const serialOf = el => ((el.textContent || '').match(/Seriya və nömrə:\s*([A-Za-z0-9]+)/) || [])[1];
  const sig = () => rowEls().map(serialOf).join(',');
  const waitChange = async (old, ticks = 60) => {
    for (let i = 0; i < ticks; i++) {
      await sleep(100); const s = sig();
      if (s && s !== old) { let last = s, same = 0; for (let k = 0; k < 20 && same < 3; k++) { await sleep(100); const x = sig(); if (x === last) same++; else { same = 0; last = x; } } return true; }
    }
    return false;
  };
  const settle = async ms => { let last = null, same = 0; for (let i = 0; i < ms / 100; i++) { await sleep(100); const s = sig(); if (s === last) { if (++same >= 6) return; } else { same = 0; last = s; } } };
  const isEmpty = () => !!document.querySelector('.ant-empty') || /Məlumat (tapılmadı|yoxdur)/i.test(document.body.innerText);
  // Saytın öz məlumatı (React): sətrə aid qeyddən qaimənin identifikatoru ola biləcək sahələr
  const recOf = el => { try { const k = Object.keys(el).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$')); let f = k && el[k]; for (let i = 0; f && i < 15; i++, f = f.return) { const p = f.memoizedProps; if (p && p.record && typeof p.record === 'object') return p.record; } } catch (e) {} return null; };
  let src = 'yoxdur';
  const readRow = el => {
    const txt = clean(el.innerText), serial = serialOf(el);
    const hm = txt.split('Seriya və nömrə')[0].match(/(\d{6,})\s*\/\s*(.+)$/);
    const leafDate = [...el.querySelectorAll('*')].find(e => e.childElementCount === 0 && DT.test(clean(e.textContent)) && clean(e.textContent).length < 25);
    const date = clean(leafDate ? leafDate.textContent : (txt.match(/\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}(:\d{2})?/) || [''])[0]);
    const tag = el.querySelector('[class*="ant-tag"]'), voen = hm ? hm[1] : '';
    const a = el.querySelector('a[href*="/invoice/view/"]'), href = a ? a.getAttribute('href') : null, key = el.getAttribute('data-row-key');
    const cands = {}, rec = recOf(el);
    if (rec) for (const k of Object.keys(rec).slice(0, 60)) { const v = rec[k]; if ((typeof v === 'string' || typeof v === 'number') && /^[A-Za-z0-9_-]{5,48}$/.test(String(v)) && String(v) !== serial && String(v) !== voen) cands[k] = String(v); }
    if (href) src = 'href'; else if (key && src === 'yoxdur') src = 'rowkey';
    // "Növü: ..." və "Əsas: ..." mətnləri: etiketi daşıyan ən kiçik elementdən oxunur
    const part = (label, stops) => {
      const els = [...el.querySelectorAll('*')].filter(e => (e.textContent || '').includes(label)); if (!els.length) return '';
      const t = clean(els.reduce((a, b) => (b.textContent.length < a.textContent.length ? b : a)).textContent); let v = t.slice(t.indexOf(label) + label.length);
      for (const s of stops) { const k = v.indexOf(s); if (k > -1) v = v.slice(0, k); }
      return clean(v);
    };
    return { serial, voen, name: hm ? clean(hm[2]) : '', date, dnum: dn(date), status: tag ? clean(tag.textContent) : '', type: part('Növü:', ['Əsas:', '|']), basis: part('Əsas:', []),
      total: clean((txt.match(/Yekun məbləğ:\s*([\d\s.,]+)/) || [])[1]), vat: clean((txt.match(/ƏDV məbləği:\s*([\d\s.,]+)/) || [])[1]), href, key, cands };
  };
  const pageRows = () => rowEls().map(readRow).filter(x => x.serial);
  const descOf = rows => { const ds = rows.map(x => x.dnum).filter(Boolean); return ds.length > 1 && ds.every((v, i) => i === 0 || v <= ds[i - 1]); };
  // Dəstək üçün: quruluş (yalnız teqlər və siniflər; mətn yalnız səhifələmə hissəsində və qısa olanda)
  const skel = (e, txt, d = 0) => {
    if (d > 8) return '…';
    const cls = typeof e.className === 'string' && e.className.trim() ? '.' + e.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
    const at = ['href', 'data-row-key', 'role', 'aria-label', 'title', 'aria-disabled', 'type', 'disabled'].filter(n => e.hasAttribute(n)).map(n => n + '=' + e.getAttribute(n).replace(/[A-Za-z0-9]{9,}/g, m => '<' + m.length + '>').slice(0, 40)).join(',');
    const kids = [...e.children].map(c => skel(c, txt, d + 1)).join(' ');
    const own = e.childElementCount === 0 ? clean(e.tagName === 'INPUT' ? e.value : e.textContent) : '';
    return e.tagName.toLowerCase() + cls + (at ? '[' + at + ']' : '') + (kids ? '(' + kids + ')' : own ? (txt && (/^[\d\s/]{1,7}$/.test(own) || (own.length <= 18 && !/\d/.test(own))) ? ':"' + own + '"' : ':T') : '');
  };

  // ---------- çərçivədə: bir səhifə ----------
  if (o.mode === 'page') {
    for (let i = 0; i < 120 && !rowEls().length; i++) { if (i > 25 && isEmpty()) break; await sleep(100); }
    await settle(1200);
    const rows = pageRows();
    return { rows, sig: sig(), desc: descOf(rows), idSource: src };
  }

  // ---------- 1) Bölməni seç ----------
  let tabState = 'tapılmadı';
  for (let i = 0; i < 100 && !rowEls().length && !isEmpty(); i++) await sleep(100);
  const tabEl = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && clean(e.textContent) === o.tab && visible(e));
  if (tabEl) {
    let active = false;
    for (let e = tabEl, i = 0; e && i < 4; i++, e = e.parentElement)
      if (/(^|[-_\s])(active|checked|selected)($|[-_\s])/i.test(typeof e.className === 'string' ? e.className : '') || ['aria-selected', 'aria-checked', 'aria-pressed'].some(a => e.getAttribute(a) === 'true')) active = true;
    if (active) tabState = 'artıq açıq idi';
    else { const old = sig(); press(tabEl); await waitChange(old, 50); await settle(2000); tabState = 'kliklə açıldı'; }
  }
  for (let i = 0; i < 120 && !rowEls().length; i++) { if (i > 25 && isEmpty()) break; await sleep(100); }
  if (!rowEls().length) return { error: `"${o.tab}" bölməsində qaimə görünmür (siyahı boşdur və ya quruluş fərqlidir). Bölmə: ${tabState}.` };

  // ---------- 2) Səhifələmə ----------
  const lastRow = () => { const r = rowEls(); return r[r.length - 1]; };
  const after = e => { const l = lastRow(); return l && !l.contains(e) && (l.compareDocumentPosition(e) & 4); };
  const antPag = () => { const f = rowEls()[0]; if (!f) return null; const w = f.closest('.ant-table-wrapper'); return (w && w.querySelector('.ant-pagination')) || [...document.querySelectorAll('.ant-pagination')].find(after) || null; };
  const urlPage = () => { const v = new URLSearchParams(location.search).get('page'); return v && /^\d+$/.test(v) ? +v : null; };
  const numInputs = () => [...document.querySelectorAll('input')].filter(e => after(e) && visible(e) && !/checkbox|radio|hidden|file/.test(e.type) && /^\d+$/.test((e.value || '').trim()));
  const pageInput = cur => numInputs().find(e => +e.value === cur) || null;
  const totalPages = cur => {
    const p = antPag();
    if (p) { const it = [...p.querySelectorAll('.ant-pagination-item')].map(e => +(e.getAttribute('title') || clean(e.textContent))).filter(Boolean); if (it.length) return Math.max(...it); }
    const inp = pageInput(cur);
    for (let e = inp && inp.parentElement, i = 0; e && i < 3; i++, e = e.parentElement) { const m = clean(e.textContent).match(/\/\s*(\d+)/); if (m) return +m[1]; }
    return null;
  };
  const setInput = (inp, n, enter) => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, String(n));
    inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
    if (!enter) return;
    for (const t of ['keydown', 'keypress', 'keyup']) inp.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    inp.dispatchEvent(new FocusEvent('blur')); inp.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
  };
  // Səhifə nömrəsi xanasının sağındakı düymələr (yazısız ox ikonları): birincisi "növbəti"dir
  const geo = cur => {
    const inp = pageInput(cur); if (!inp) return [];
    const a = inp.getBoundingClientRect(), cy = a.top + a.height / 2;
    const all = [...document.querySelectorAll('button, a, li, [role="button"], [tabindex], svg, i, span[class*="icon"], span[class*="arrow"], span[class*="btn"]')]
      .filter(e => after(e) && visible(e) && !off(e) && !e.contains(inp))
      .filter(e => { const r = e.getBoundingClientRect(); return r.width <= 70 && r.height <= 70 && r.left >= a.right - 2 && r.left - a.right < 260 && Math.abs(r.top + r.height / 2 - cy) < 26; });
    return all.filter(e => !all.some(x => x !== e && x.contains(e))).sort((x, y) => x.getBoundingClientRect().left - y.getBoundingClientRect().left).slice(0, 3);
  };
  let how = null;
  const step = async cur => {                                  // 'ok' | 'end' | 'fail'
    const tot = totalPages(cur); if (tot && cur >= tot) return 'end';
    const names = ['ant', 'named', 'num', 'input', 'geo'];
    for (const name of (how ? [how, ...names.filter(x => x !== how)] : names)) {
      const old = sig(); let el = null;
      if (name === 'ant') { const p = antPag(); el = p && p.querySelector('.ant-pagination-next'); if (el) { if (off(el)) return 'end'; el = el.querySelector('button') || el; } }
      else if (name === 'named') {
        el = [...document.querySelectorAll('[aria-label],[title],[class*="next"],[rel="next"]')].filter(e => after(e) && visible(e)).find(e =>
          /next|növbəti|sonrakı|irəli/i.test((e.getAttribute('aria-label') || '') + ' ' + (e.getAttribute('title') || '') + ' ' + (typeof e.className === 'string' ? e.className : '') + ' ' + (e.getAttribute('rel') || '')));
        if (el && off(el)) return 'end';
      }
      else if (name === 'num') el = [...document.querySelectorAll('button,li,a,span,div')].filter(e => after(e) && visible(e)).find(e => e.childElementCount === 0 && clean(e.textContent) === String(cur + 1) && !off(e));
      else if (name === 'input') {
        const inp = pageInput(cur); if (!inp) continue;
        setInput(inp, cur + 1, true);
        if (await waitChange(old, 45)) { how = name; return 'ok'; }
        if (inp.isConnected) setInput(inp, cur, false);
        continue;
      }
      else if (name === 'geo') { for (const c of geo(cur)) { press(c); if (await waitChange(old, 35)) { how = name; return 'ok'; } } continue; }
      if (el) { press(el); if (await waitChange(old, 60)) { how = name; return 'ok'; } }
    }
    return 'fail';
  };
  // Səhifədəki sətir sayını maksimuma qaldır (az səhifə = daha sürətli)
  const bump = async () => {
    const lab = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && /^Sətirlərin sayı/.test(clean(e.textContent)) && visible(e));
    let ctl = null;
    for (let b = lab, i = 0; b && i < 4 && !ctl; i++, b = b.parentElement) ctl = b.querySelector('select, .ant-select, [role="combobox"]');
    if (!ctl) { const p = antPag(); ctl = p && p.querySelector('.ant-pagination-options .ant-select'); }
    if (!ctl) return 'yoxdur';
    const before = rowEls().length, numOf = e => +((clean(e.textContent).match(/^(\d+)/) || [])[1] || 0);
    if (ctl.tagName === 'SELECT') {
      const mx = Math.max(...[...ctl.options].map(x => +x.value || 0)); if (!(mx > before)) return 'artıq maksimum';
      Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set.call(ctl, String(mx));
      ctl.dispatchEvent(new Event('input', { bubbles: true })); ctl.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      const sel = '.ant-select-item-option, [role="option"]', had = new Set(document.querySelectorAll(sel));
      press(ctl.querySelector('.ant-select-selector') || ctl);
      let opts = [];
      for (let i = 0; i < 15 && !opts.length; i++) { await sleep(100); opts = [...document.querySelectorAll(sel)].filter(e => visible(e) && numOf(e) > 0); }
      const best = opts.sort((a, b) => numOf(b) - numOf(a))[0];
      if (!best || numOf(best) <= before) { if (opts.length || !had.size) press(document.body); return best ? 'artıq maksimum' : 'açılmadı'; }
      press(best);
    }
    for (let i = 0; i < 80; i++) { await sleep(100); if (rowEls().length > before) { await settle(1500); return 'artırıldı: ' + rowEls().length; } }
    return 'dəyişmədi';
  };

  let cur = urlPage() || 1;
  if (!pageInput(cur) && numInputs().length === 1 && !urlPage()) cur = +numInputs()[0].value;
  let startNote = '';
  if (cur > 1) {                                              // 1-ci səhifədən başla
    const old = sig(), p = antPag(), f = p && p.querySelector('.ant-pagination-item-1'), inp = pageInput(cur);
    if (f) press(f); else if (inp) setInput(inp, 1, true);
    if ((f || inp) && await waitChange(old, 50)) cur = 1; else { if (inp && inp.isConnected) setInput(inp, cur, false); startNote = `${cur}-ci səhifədən başlandı`; }
  }
  const size = await bump();
  if (/artırıldı/.test(size)) cur = urlPage() || 1;

  // ---------- çərçivədə: verilmiş qaiməni tap ----------
  if (o.mode === 'find') {
    const has = () => rowEls().some(e => serialOf(e) === o.serial);
    const seen = new Set();
    for (let n = 0; n < o.maxPages; n++) {
      if (has()) return { found: true, pages: n + 1 };
      const s0 = sig(); if (seen.has(s0)) break; seen.add(s0);
      if (await step(cur) !== 'ok') break;
      const u = urlPage(); cur = u && u !== cur ? u : cur + 1;
    }
    return { found: has(), note: `bölmə: ${tabState}, üsul: ${how || 'yoxdur'}, sətir sayı: ${size}` };
  }

  // ---------- əsas səhifədə: hamısını gəz ----------
  const all = new Map(), seenSigs = new Set(); let pages = 0, seen = 0, stop = 'son səhifə', more = false, skeleton = '', sig1 = '', lastSig = '', firstCount = 0;
  const total0 = totalPages(cur), base = location.pathname + location.search;
  const climb = e => { const fr = rowEls()[0]; for (let i = 0; i < 4 && e.parentElement && !e.parentElement.contains(fr); i++) e = e.parentElement; return e; };
  const pagBox = () => { const p = antPag(); if (p) return p; const inp = pageInput(cur) || numInputs()[0]; if (inp) return climb(inp);
    const lab = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && /^Sətirlərin sayı/.test(clean(e.textContent))); return lab ? climb(lab) : null; };
  const pb = pagBox(), pagSkel = pb ? skel(pb, true).slice(0, 1400) : null;
  for (let n = 0; n < o.maxPages; n++) {
    const els = rowEls(); if (!els.length) break;
    lastSig = sig(); if (seenSigs.has(lastSig)) { stop = 'səhifə təkrarlandı'; break; } seenSigs.add(lastSig);
    if (!skeleton) skeleton = skel(els[0], false).slice(0, 1300);
    const rows = pageRows(); pages++; seen += rows.length; if (!sig1) { sig1 = lastSig; firstCount = rows.length; }
    rows.filter(x => x.dnum >= o.fromN && x.dnum <= o.toN).forEach(x => all.set(x.serial, x));
    if (descOf(rows) && rows[0].dnum && rows[0].dnum < o.fromN) { stop = 'tarix aralığından köhnə'; break; }
    const s = await step(cur);
    if (s === 'end') break;
    if (s === 'fail') { const tot = totalPages(cur); if (tot ? cur < tot : rows.length >= firstCount) { stop = 'növbəti səhifəyə keçmək alınmadı'; more = true; } break; }
    const u = urlPage(), nc = u && u !== cur ? u : cur + 1;
    if (nc > cur + 1) { stop = `${cur}-dən ${nc}-ə atlandı`; more = true; }
    cur = nc;
    if (n === o.maxPages - 1) stop = 'səhifə limiti';
  }
  if (pages > 1) { const p = antPag(), f = p && p.querySelector('.ant-pagination-item-1'), inp = pageInput(cur); if (f) press(f); else if (inp) setInput(inp, 1, true); }   // istifadəçini 1-ci səhifəyə qaytar
  return { rows: [...all.values()], pages, seen, stop: stop + (startNote ? ' (' + startNote + ')' : ''), more: more || !!startNote, lastPage: cur, total: total0, base, sig1, lastSig, idSource: src, how, size, skeleton, pagSkel, tabState };
}

// Qaimənin səhifəsində: "Mallar və xidmətlər" cədvəlini oxuyur
async function scrapeItems(waitSec) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const kids = e => [...e.children].map(c => clean(c.innerText));
  const headEl = () => [...document.querySelectorAll('tr')].find(tr => [...tr.children].some(c => /^Sıra\s*№/.test(clean(c.innerText))))
    || [...document.querySelectorAll('*')].find(e => e.children.length >= 6 && e.children.length <= 40 && /^Sıra\s*№/.test(clean(e.children[0].innerText)));
  const read = () => {
    const h = headEl(); if (!h) return null;
    const header = kids(h), n = header.length;
    const rows = [...document.querySelectorAll(h.tagName === 'TR' ? 'tr' : '*')]
      .filter(e => e !== h && e.children.length === n).map(kids)
      .filter(x => /^\d+$/.test(x[0]) && !x.every((v, i) => v === String(i + 1)));        // sütun nömrələri sətri (1 2 3 ...) sayılmır
    return { header, rows };
  };
  let cur = null, stable = 0, last = -1;
  for (let i = 0; i < waitSec * 10; i++) {
    cur = read();
    if (cur) {
      const done = cur.rows.length > 0 || /CƏMİ/.test(document.body.innerText);
      if (done && cur.rows.length === last) { if (++stable >= 3) break; } else stable = 0;
      last = cur.rows.length;
    }
    await sleep(100);
  }
  // Başlıq hissəsi: "Daha ətraflı" açılır, "Əsas" və "Əlavə qeyd" sahələri oxunur
  const leaves = () => [...document.querySelectorAll('body *')].filter(e => e.childElementCount === 0 && clean(e.textContent) && !e.closest('script, style, noscript, template'));
  const field = rx => {
    for (const l of leaves()) {
      const t = clean(l.textContent); if (t.length > 60 || !rx.test(t)) continue;
      const m = t.match(/^[^:]{2,30}:\s*(.+)$/); if (m) return m[1];                       // "Etiket: dəyər" eyni elementdədir
      for (const n of [l.nextElementSibling, l.parentElement && l.parentElement.nextElementSibling]) { const v = n && clean(n.innerText); if (v && !rx.test(v)) return v; }
    }
    return '';
  };
  const info = { more: false };
  if (cur) {
    const more = leaves().find(e => /^Daha ətraflı/i.test(clean(e.textContent)));
    if (more) { info.more = true; (more.closest('a, button') || more).click(); for (let i = 0; i < 15; i++) { await sleep(100); if (field(/^Əlavə qeyd/i)) break; } }
    info.esas = field(/^Əsas\s*:?$|^Əsas\s*:/i); info.qeyd = field(/^Əlavə qeyd/i);
    info.created = field(/yaranma tarixi/i);
    const h1 = headEl(), PV = /^(\d{10})\s*\/\s*(\S.{1,200})$/;
    const pe = [...document.querySelectorAll('*')].filter(e => (!h1 || (h1.compareDocumentPosition(e) & 2)) && !e.contains(h1) && PV.test(clean(e.innerText)));
    info.parties = []; pe.filter(e => !pe.some(x => x !== e && e.contains(x))).forEach(e => { const m = clean(e.innerText).match(PV); if (!info.parties.some(p => p.voen === m[1])) info.parties.push({ voen: m[1], name: m[2].trim() }); });
    // Dəstək üçün: başlıqdakı sahə adları (rəqəmsiz, dırnaqsız qısa etiketlər; dəyərlər yox)
    const h0 = headEl();
    info.labels = leaves().filter(l => { const t = clean(l.textContent); return (!h0 || (h0.compareDocumentPosition(l) & 2)) && !l.closest('h1,h2,title,head') && t.length >= 3 && t.length <= 45 && !/[\d"“”«»]/.test(t) && t !== t.toLocaleUpperCase('az') && l.nextElementSibling && clean(l.nextElementSibling.innerText); }).map(l => clean(l.textContent)).slice(0, 30);
  }
  if (!cur) return { error: 'Mallar cədvəli tapılmadı | yol=' + location.pathname.replace(/[A-Za-z0-9]{9,}/g, m => '<' + m.length + '>') + ' | tables=' + document.querySelectorAll('table').length + ' | mallar=' + /MALLAR/i.test(document.body.innerText) };
  const t = clean((document.querySelector('h1,h2') || {}).textContent);
  return { header: cur.header, rows: cur.rows, info, serial: (t.match(/([A-Z]{2}\d{6,})/) || [])[1] || '', url: location.pathname + location.search };
}

// Çərçivədəki siyahıda verilmiş qaimənin sətrinə klik edir
async function clickInvoiceRow(serial) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const fire = e => { if (typeof e.click === 'function') e.click(); else e.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); };
  for (let i = 0; i < 60; i++) {
    if (location.pathname.includes('/invoice/view/')) return 'ok';
    const leaf = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && (e.textContent || '').includes(serial));
    if (leaf) {
      let row = leaf; for (let k = 0; row.parentElement && k < 9 && !/\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}/.test(row.textContent); k++) row = row.parentElement;
      for (const target of [row.querySelector('a[href*="/invoice/view/"]'), row.querySelector('.clickable'), row.querySelector('a'), row].filter(Boolean)) {
        fire(target);
        for (let j = 0; j < 30; j++) { await sleep(100); if (location.pathname.includes('/invoice/view/')) return 'ok'; }
      }
      return 'klik işləmədi';
    }
    await sleep(100);
  }
  return 'sətir tapılmadı';
}

function frameInfo() { try { return { tag: window.frameElement ? window.frameElement.id : '', href: location.href }; } catch (e) { return { tag: '', href: '' }; } }

async function withFrame(tabId, tag, url, job) {
  await exec(tabId, mkFrame, [tag, url]);
  try {
    let fid = null;
    for (let i = 0; i < 100 && fid === null; i++) {
      try {
        const rs = await exec(tabId, frameInfo, [], true);
        const hit = rs.find(x => x.result && x.result.tag === tag && x.result.href.startsWith(ORIGIN));
        if (hit) fid = hit.frameId;
      } catch (e) {}
      if (fid === null) await sleep(150);
    }
    if (fid === null) return { error: 'gizli çərçivə açılmadı', frameFail: true };
    return await job(fid);
  } finally { try { await exec(tabId, rmFrame, [tag]); } catch (e) {} }
}

const inFrame = async (tabId, fid, fn, args, world) => (await execFrame(tabId, fid, fn, args, world))[0].result;
const idVal = (inv, key) => key === '@rowkey' ? inv.key : (inv.cands || {})[key];
const viewUrl = (inv, tpl) => inv.href ? new URL(inv.href, ORIGIN).href : tpl && idVal(inv, tpl.key) ? ORIGIN + tpl.url.replace('{id}', idVal(inv, tpl.key)) : null;

async function readItems(tabId, fid, wantApi, sec) {
  if (wantApi) { try { await inFrame(tabId, fid, installHook, [], 'MAIN'); } catch (e) {} }
  const res = await inFrame(tabId, fid, scrapeItems, [sec]);
  if (wantApi && res && !res.error) { try { res.api = await inFrame(tabId, fid, readHook, [], 'MAIN'); } catch (e) {} }
  return res;
}
const openByUrl = (tabId, url, n, wantApi, sec = 12) => withFrame(tabId, 'dx-i' + n, url, fid => readItems(tabId, fid, wantApi, sec));
// Ünvan məlum deyilsə: çərçivədə siyahını aç, qaiməni tap, sətrinə klik et
const openByClick = (tabId, inv, n, ctx, wantApi) => withFrame(tabId, 'dx-c' + n, ORIGIN + ctx.base, async fid => {
  const f = await inFrame(tabId, fid, invoiceList, [{ mode: 'find', tab: ctx.tab, serial: inv.serial, maxPages: 300 }]);
  if (!f || !f.found) return { error: 'çərçivədəki siyahıda tapılmadı (' + ((f && (f.error || f.note)) || '?') + ')' };
  const st = await inFrame(tabId, fid, clickInvoiceRow, [inv.serial]);
  if (st !== 'ok') return { error: 'siyahıdan açmaq: ' + st };
  return await readItems(tabId, fid, wantApi, 12);
});

// Qaimənin ünvanının necə qurulduğunu ilk qaimədə öyrənir
async function learnView(tabId, first, ctx) {
  if (first.href) return { tpl: null, how: 'sətirdəki keçid' };
  const ids = [['@rowkey', first.key], ...Object.entries(first.cands || {}).sort((a, b) => /id|key|code|hash|token/i.test(b[0]) - /id|key|code|hash|token/i.test(a[0]))].filter(([, v]) => v);
  const r = await openByClick(tabId, first, 'L', ctx, true);
  if (r && !r.error && r.url) {
    const hit = ids.filter(([, v]) => r.url.includes(v)).sort((a, b) => b[1].length - a[1].length)[0];
    if (hit) return { tpl: { key: hit[0], url: r.url.replace(hit[1], '{id}') }, how: 'kliklə öyrənildi (' + hit[0] + ')', firstRes: r };
    return { tpl: null, clickOnly: true, how: 'yalnız klik (ünvan sətirdə yoxdur; sahələr: ' + ids.map(x => x[0]).join(',') + ')', firstRes: r };
  }
  for (const [k, v] of ids.slice(0, 4)) {
    const res = await openByUrl(tabId, `${ORIGIN}/eportal/invoice/view/${v}?source=avis`, 'G', true, 6);
    if (res && !res.error && (!res.serial || res.serial === first.serial)) return { tpl: { key: k, url: '/eportal/invoice/view/{id}?source=avis' }, how: 'təxminlə tapıldı (' + k + ')', firstRes: res };
  }
  return { tpl: null, clickOnly: true, how: 'alınmadı: ' + mask(r && r.error) };
}

async function readInvoice(tabId, inv, n, ctx, wantApi) {
  const url = viewUrl(inv, ctx.tpl); let res = null;
  if (url) {
    res = await openByUrl(tabId, url, n, wantApi);
    if (res && !res.error && res.serial && res.serial !== inv.serial) res = { error: 'başqa qaimə açıldı' };
    if (!res || !res.error || res.frameFail) return res;
  }
  const first = res && res.error;
  res = await openByClick(tabId, inv, n, ctx, wantApi);
  if (res && res.error && first) res.error = first + ' || ' + res.error;
  return res;
}

// Siyahının qalan səhifələrini gizli çərçivələrdə, ünvandakı "page" parametri ilə oxuyur (kliklə keçmək alınmayanda)
async function listViaFrames(tabId, list, fromN, toN, add) {
  const urlOf = n => { const u = new URL(ORIGIN + list.base); u.searchParams.set('page', n); return u.pathname + u.search; };
  const readPage = n => withFrame(tabId, 'dx-l' + n, ORIGIN + urlOf(n), fid => inFrame(tabId, fid, invoiceList, [{ mode: 'page' }]));
  const check = await readPage(1);
  if (!check || check.error || check.sig !== list.sig1) return { pages: 0, note: check && check.frameFail ? 'gizli çərçivə açılmadı' : 'çərçivədəki siyahı əsas səhifədəki ilə üst-üstə düşmür' };
  let page = list.lastPage + 1, prev = list.lastSig, pages = 0, seen = 0;
  for (;;) {
    if (cancel) return { pages, seen, note: 'dayandırıldı' };
    if (list.pages + pages >= 300) return { pages, seen, note: 'səhifə limiti' };
    log(`Qaimə siyahısı oxunur: ${page}-ci səhifədən...`);
    const batch = await Promise.all([0, 1, 2, 3].map(k => readPage(page + k).catch(e => ({ error: e.message }))));
    for (const r of batch) {
      if (!r || r.error) return { pages, seen, note: 'səhifə oxunmadı: ' + (r && r.error) };
      if (!r.rows.length) return { pages, seen, note: 'son səhifə' };
      if (r.sig === prev || r.sig === list.sig1) return { pages, seen, note: pages ? 'son səhifə' : 'ünvandakı səhifə nömrəsi işləmir' };
      pages++; seen += r.rows.length; prev = r.sig; add(r.rows);
      if (r.desc && r.rows[0].dnum && r.rows[0].dnum < fromN) return { pages, seen, note: 'tarix aralığından köhnə' };
    }
    page += 4;
  }
}

// Siyahını oxuyur (lazım olsa çərçivələrlə davam edir); tarix aralığındakı bütün qaimələri qaytarır
async function gatherList(tabId, tab, fromN, toN, fnName) {
  log(`Qaimə siyahısı oxunur (${tab})...`);
  const args = [{ mode: 'walk', tab, fromN, toN, maxPages: 300 }];
  let list;
  try { list = (await chrome.scripting.executeScript({ target: { tabId }, func: invoiceList, args, world: 'MAIN' }))[0].result; } catch (e) { list = null; }
  if (!list) list = (await exec(tabId, invoiceList, args))[0].result;
  if (!list || list.error) throw new Error((list && list.error) || 'Qaimə siyahısı oxunmadı.');
  const all = new Map(list.rows.map(x => [x.serial, x])); let viaFrames = null;
  if (list.more) {
    viaFrames = await listViaFrames(tabId, list, fromN, toN, rows => rows.filter(x => x.dnum >= fromN && x.dnum <= toN).forEach(x => { if (!all.has(x.serial)) all.set(x.serial, x); }));
    try { await exec(tabId, rmAllFrames); } catch (e) {}
  }
  const pagesTotal = list.pages + (viaFrames ? viaFrames.pages : 0), seenTotal = list.seen + (viaFrames && viaFrames.seen || 0);
  const base = { versiya: VERSION, funksiya: fnName, bolme: tab + ' (' + list.tabState + ')',
    siyahi: { gorulen: seenTotal, sehife: list.pages, cemiSehife: list.total, usul: list.how, setirSayi: list.size, dayanma: list.stop, cerceve: viaFrames, araliqda: all.size, unvan: list.idSource, setir: list.skeleton, sehifeleme: list.pagSkel } };
  await chrome.storage.local.set({ report: base });
  const partial = list.more && !(viaFrames && /son səhifə|köhnə/.test(viaFrames.note || ''));   // siyahının sonuna çatmaq alınmadı
  return { list, inDates: [...all.values()], pagesTotal, seenTotal, base, partial };
}

// Seçilmiş qaimələrin içini görünməz çərçivələrdə paralel oxuyur
async function readAll(tabId, sel, ctx, progress) {
  cancel = false;
  const results = new Array(sel.length).fill(null);
  let doneCount = 0, api = null, apiAsked = true, header = null, next = 0;
  progress(0);
  const learned = await learnView(tabId, sel[0], ctx);
  ctx.tpl = learned.tpl;
  if (learned.firstRes) { results[0] = learned.firstRes; doneCount = 1; next = 1; if (learned.firstRes.api && learned.firstRes.api.length) api = learned.firstRes.api; if (learned.firstRes.header.length) header = learned.firstRes.header; }
  apiAsked = false;
  progress(doneCount);
  try {
    await Promise.all(Array.from({ length: Math.min(learned.clickOnly ? 3 : CONC, sel.length) }, async () => {
      while (!cancel && next < sel.length) {
        const i = next++; let res;
        const wantApi = !api && !apiAsked; if (wantApi) apiAsked = true;
        try { res = await readInvoice(tabId, sel[i], i, ctx, wantApi); } catch (e) { res = { error: 'İstisna: ' + e.message }; }
        if (res && res.api && res.api.length) api = res.api; else if (wantApi) apiAsked = false;
        if (res && !res.error && !header && res.header.length) header = res.header;
        results[i] = res; doneCount++; progress(doneCount);
      }
    }));
  } finally { try { await exec(tabId, rmAllFrames); } catch (e) {} }
  return { results, header, api, learned };
}

async function runItemsDom({ tabId, from, to, dir, statuses, types }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to);
  const tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  const { list, inDates, pagesTotal, seenTotal, base, partial } = await gatherList(tabId, tab, fromN, toN, 'mallar');
  // Status və növ seçimi: siyahıdakı mətnə görə. Siyahıda tanınmayan status/növ çıxsa, "Digər" seçiminə görə qərar verilir
  const nz = s => String(s || '').toLocaleLowerCase('az').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const pick = (f, v, unknown) => { if (!f) return true; const k = nz(v); if (f.on.some(x => nz(x) === k)) return true; if (f.known.some(x => nz(x) === k)) return false; unknown.add(v || '(boş)'); return f.other !== false; };
  const unkS = new Set(), unkT = new Set();
  const sel = inDates.filter(x => pick(statuses, x.status, unkS) & pick(types, x.type, unkT)).sort((a, b) => a.dnum - b.dnum);
  base.secim = { tarixde: inDates.length, secilen: sel.length, taninmayanStatus: [...unkS].slice(0, 8), taninmayanNov: [...unkT].slice(0, 8) };
  await chrome.storage.local.set({ report: base });
  if (!inDates.length) throw new Error(`"${tab}" bölməsində bu tarix aralığında qaimə tapılmadı (${pagesTotal} səhifədə ${seenTotal} qaiməyə baxıldı). Səhifədə seçilmiş ili yoxla.`);
  if (!sel.length) throw new Error(`Bu tarixlərdə ${inDates.length} qaimə var, amma heç biri seçdiyin status və növə uyğun deyil.`);

  const stats = d => [{ l: 'Səhifə', v: pagesTotal }, { l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }];
  const { results, header, api, learned } = await readAll(tabId, sel, { tab, base: list.base, tpl: null },
    d => log(`${d} / ${sel.length} qaimə oxundu. Siyahı səhifəsini açıq saxla.`, false, { i: d, n: sel.length, stats: stats(d) }));

  const rows = [], notes = [], errs = []; let items = 0, ok = 0, empty = 0, err = 0, noQeyd = 0;
  const codeCol = (header || []).findIndex(h => /kodu/i.test(h));
  sel.forEach((d, i) => {
    const res = results[i]; if (!res) return;
    if (res.error) { err++; errs.push(res.error); notes.push(['Xəta', d.serial, d.date, mask(res.error)]); return; }
    const info = res.info || {}; if (!info.qeyd) noQeyd++;
    const meta = [d.date, d.voen, d.name, d.serial, d.type, d.status, info.esas || d.basis || '', info.qeyd || ''];
    if (!res.rows.length) { empty++; notes.push(['Məlumat', d.serial, d.date, 'Mal sətri yoxdur']); return; }
    ok++; items += res.rows.length;
    res.rows.forEach(row => { const code = codeCol > -1 ? String(row[codeCol] || '').trim() : ''; rows.push([...meta, code ? (code.startsWith('99') ? 'Xidmət' : 'Mal') : '', ...row]); });
  });
  if (unkS.size) notes.push(['Məlumat', '', '', 'Siyahıda tanınmayan status: ' + [...unkS].join('; ')]);
  if (unkT.size) notes.push(['Məlumat', '', '', 'Siyahıda tanınmayan növ: ' + [...unkT].join('; ')]);
  if (partial) notes.push(['Xəbərdarlıq', '', '', `Siyahının yalnız ${pagesTotal} səhifəsi oxundu, davamı açılmadı. Aralıqdakı bəzi qaimələr faylda olmaya bilər.`]);
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan qaimələr fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...base, qaimeUnvani: learned.how, sablon: learned.tpl ? learned.tpl.url.replace(/[A-Za-z0-9]{9,}/g, m => '<' + m.length + '>') : null, saniye: sec, oxundu: ok, bos: empty, xeta: err,
    dahaEtrafli: sel.some((d, i) => results[i] && results[i].info && results[i].info.more), elaveQeydTapilmayan: noQeyd, xetalar: [...new Set(errs.map(mask))].slice(0, 4), api } });

  await saveXlsx(`DataX-mallar-${dir === 'out' ? 'gonderilen' : 'gelen'}-${from}_${to}.xlsx`, [
    { name: 'Mallar və xidmətlər', header: ['İmzalanma tarixi', 'VÖEN', 'Adı', 'Seriya və nömrə', 'Qaimənin növü', 'Status', 'Əsas', 'Əlavə qeyd', 'Mal/xidmət', ...(header || [])], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Seriya və nömrə', 'Tarix', 'Qeyd'], rows: notes, numeric: false }]);
  const parts = [`${tab}: ${pagesTotal} səhifədən ${sel.length} qaimə` + (sel.length < inDates.length ? ` (tarixdə ${inDates.length}, seçimə uyğun ${sel.length})` : ''), `${items} mal/xidmət sətri`];
  if (empty) parts.push(`${empty} qaimədə sətir yoxdur`);
  if (err) parts.push(`${err} qaimə oxunmadı`);
  log((partial ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${parts.join(', ')}.` + (partial ? '\nSiyahının davamı açılmadı: dəstək məlumatını göndər.' : ' Fayl Yükləmələr qovluğundadır.'), true,
    { i: sel.length, n: sel.length, hasErrors: !!err || partial, stats: [{ l: 'Səhifə', v: pagesTotal }, { l: 'Qaimə', v: sel.length }, { l: 'Mal sətri', v: items }] });
}

// =====================================================================================
// FUNKSİYA 3: Alt sənədlər (təhvil-təslim aktı, razılaşma protokolu, hesab-faktura)
// =====================================================================================
const DOCS = { akt: 'Təhvil-təslim aktı', prot: 'Razılaşma protokolu', hf: 'Hesab-faktura' };
const BLANK = '________';
const fmt2 = v => (Math.round(v * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
function azWords(n) {
  const ones = ['', 'bir', 'iki', 'üç', 'dörd', 'beş', 'altı', 'yeddi', 'səkkiz', 'doqquz'], tens = ['', 'on', 'iyirmi', 'otuz', 'qırx', 'əlli', 'altmış', 'yetmiş', 'səksən', 'doxsan'], units = ['', 'min', 'milyon', 'milyard'];
  if (!n) return 'sıfır';
  const tri = x => { const h = Math.floor(x / 100), t = Math.floor(x % 100 / 10), o = x % 10; return [h ? (h > 1 ? ones[h] + ' ' : '') + 'yüz' : '', tens[t], ones[o]].filter(Boolean).join(' '); };
  const parts = [];
  for (let i = 0; n > 0 && i < 4; i++, n = Math.floor(n / 1000)) { const x = n % 1000; if (x) parts.unshift(((i === 1 && x === 1) ? '' : tri(x) + ' ') + units[i]); }
  return parts.join(' ').replace(/\s+/g, ' ').trim();
}
const amountWords = v => { const c = Math.round(Math.abs(v) * 100); return `${azWords(Math.floor(c / 100))} manat ${String(c % 100).padStart(2, '0')} qəpik`; };
const partyOf = s => { const m = String(s || '').match(/^\s*(\d{6,})\s*\/\s*(.+)$/); return m ? { voen: m[1], name: m[2].trim() } : null; };
const parseBasis = t => { t = String(t || ''); const no = (t.match(/müqavilə\s*(?:№|No\.?|N\.?|nömrə(?:si)?|#)?\s*[:.]?\s*([\p{L}\p{N}\-\/]+)/iu) || [])[1]; return { no: no && /\d/.test(no) ? no : '', date: (t.match(/\d{2}[./]\d{2}[./]\d{4}/) || [''])[0] }; };

// zip (sıxılmış): docx üçün
async function zipDeflate(files) {
  const enc = new TextEncoder(), chunks = [], central = []; let offset = 0;
  for (const [fname, text] of files) {
    const name = enc.encode(fname), raw = typeof text === 'string' ? enc.encode(text) : text, crc = crc32(raw); let data = raw, method = 0;
    try { const c = new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer()); if (c.length < raw.length) { data = c; method = 8; } } catch (e) {}
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, method, true); lh.setUint16(12, 0x21, true);
    lh.setUint32(14, crc, true); lh.setUint32(18, data.length, true); lh.setUint32(22, raw.length, true); lh.setUint16(26, name.length, true);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, method, true); ch.setUint16(14, 0x21, true);
    ch.setUint32(16, crc, true); ch.setUint32(20, data.length, true); ch.setUint32(24, raw.length, true); ch.setUint16(28, name.length, true); ch.setUint32(42, offset, true);
    chunks.push(new Uint8Array(lh.buffer), name, data); central.push(new Uint8Array(ch.buffer), name);
    offset += 30 + name.length + data.length;
  }
  const cdSize = central.reduce((s, c) => s + c.length, 0), end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
  const all = [...chunks, ...central, new Uint8Array(end.buffer)], out = new Uint8Array(all.reduce((s, c) => s + c.length, 0));
  let p = 0; for (const c of all) { out.set(c, p); p += c.length; }
  return out;
}
const tplCache = {};
const loadTpl = async key => tplCache[key] || (tplCache[key] = await (await fetch(chrome.runtime.getURL(`tpl/${key}.json`))).json());
// Şablonu doldurur: mal sətri hər mal üçün təkrarlanır, {{AD}} yer tutucuları əvəz olunur
function fillDoc(xml, data, items) {
  const fill = (s, d) => s.replace(/\{\{([A-Z_]+)\}\}/g, (m, k) => xmlEsc(d[k] != null && String(d[k]).trim() !== '' ? d[k] : BLANK));
  xml = xml.replace(/&quot;\{\{(ICRACI_ADI|SIFARISCI_ADI)\}\}&quot;/g, (m, k) => /["“”„«»]/.test(data[k] || '') ? `{{${k}}}` : m);   // adda dırnaq varsa, ikiqat dırnaq olmasın
  const i = xml.indexOf('{{MAL_ADI}}');
  if (i > -1) {
    let a = -1; for (const m of xml.slice(0, i).matchAll(/<w:tr[ >]/g)) a = m.index;
    const b = xml.indexOf('</w:tr>', i) + 7, row = xml.slice(a, b);
    xml = xml.slice(0, a) + (items.length ? items : [{}]).map((it, n) => fill(row, { NO: n + 1, ...it })).join('') + xml.slice(b);
  }
  return fill(xml, data);
}
async function makeDocx(key, data, items) {
  const tpl = await loadTpl(key);
  return zipDeflate(tpl.files.map(([n, t]) => [n, n === 'word/document.xml' ? fillDoc(t, data, items) : t]));
}
// Bir qaimənin bütün alt sənədləri bir qovluqda: tək yükləmə (<seriya>.zip, içində <seriya>/ qovluğu)
async function saveInvoiceDocs(keys, data, items, serial) {
  const files = [];
  for (const k of keys) files.push([`${serial}/${serial} - ${DOCS[k]}.docx`, await makeDocx(k, data, items)]);
  const u8 = await zipDeflate(files);
  let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
  const name = `DataX alt sənədlər/${serial}.zip`; await pendAdd('job', { name, mime: 'application/zip', b64: btoa(bin) }); jobFiles.push(name);
  return files.length;
}

// Çərçivədə: "Şəxsi məlumatlar" səhifəsindən (/eportal/profile) daxil olmuş vergi ödəyicisinin adı, VÖEN-i və şəhəri
async function ownFromProfile() {
  const sleep = ms => new Promise(r => setTimeout(r, ms)), clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const LEGAL = /MMC|ASC|QSC|MƏHDUD|CƏMİYYƏT|SƏHMDAR|MÜƏSSİSƏ|FİLİAL|KOOPERATİV|BİRLİY|İDARƏ|["“”«»]/i, V = /VÖEN\s*:?\s*(\d{10})/;
  const V2 = /VÖEN və qeydiyyat tarixi\s*:?\s*(\d{10})/, V3 = /VÖEN[^0-9]{0,40}(\d{10})(?!\d)/;
  for (let i = 0; i < 150 && !V.test(document.body.innerText) && !V2.test(document.body.innerText); i++) await sleep(100);
  await sleep(300);
  const text = clean(document.body.innerText), voen = (text.match(V) || text.match(V2) || text.match(V3) || [])[1] || '';
  const leaves = [...document.querySelectorAll('body *')].filter(e => e.childElementCount === 0 && clean(e.textContent) && !e.closest('script, style, noscript, template'));
  // Ad (ehtiyat üçün; əsas mənbə ana səhifədir): "VÖEN:" sətrindən bir az əvvəlki, dırnaqlı və ya hüquqi formalı mətn
  const k = leaves.findIndex(e => /^VÖEN\s*:/.test(clean(e.textContent)));
  const before = (k > -1 ? leaves.slice(Math.max(0, k - 14), k) : []).filter(e => !e.closest('button, a, nav, [role="tab"], [role="button"]')).map(e => clean(e.textContent)).filter(t => t.length >= 4 && t.length <= 160 && !/^\d/.test(t));
  const isCo = s => { const t = String(s || '').trim(), l = t.toLocaleLowerCase('az');
    return t.length >= 3 && t.length <= 160 && !/[!?]/.test(t) && !/(?<!\p{L})(tələb|istifadə|nəzərdən|edin|olunur|edilir|daxil olun|xahiş|bildiriş|məlumat|diqqət|yeni e-portal)(?!\p{L})/u.test(l)
      && (/["“”«»„]/.test(t) || /məhdud|məsuliyyətli|səhmdar|cəmiyyət|müəssisə|kooperativ|birliy|filial|şirkət|holdinq|\b(mmc|asc|qsc|ltd|llc)\b/.test(l)); };
  const name = before.filter(isCo).filter(t => /["“”«»]/.test(t)).pop() || before.filter(isCo).pop() || '';
  const addr = (text.match(/Hüquqi ünvan\s*:?\s*(.{0,120})/) || [])[1] || '', city = (addr.match(/([\p{L}]+\s+şəhəri)/u) || [])[1] || '';
  return { name, voen, city, yol: location.pathname.replace(/\d{6,}/g, '#'), uzunluq: text.length, voenSozu: /VÖEN/.test(text) };
}
// Çərçivədə: ana səhifədəki salamlamadan sonra yazılan vergi ödəyicisinin adı
async function ownFromHome() {
  const sleep = ms => new Promise(r => setTimeout(r, ms)), clean = t => (t || '').replace(/\s+/g, ' ').trim();
  for (let i = 0; i < 100 && !/Xoş Gəlmişsiniz/i.test(document.body.innerText); i++) await sleep(100);
  const leaves = [...document.querySelectorAll('body *')].filter(e => e.childElementCount === 0 && clean(e.textContent) && !e.closest('script, style, noscript, template'));
  const k = leaves.findIndex(e => /Xoş Gəlmişsiniz/i.test(e.textContent)); if (k < 0) return {};
  const isCo = s => { const t = String(s || '').trim(), l = t.toLocaleLowerCase('az');
    return t.length >= 3 && t.length <= 160 && !/[!?]/.test(t) && !/(?<!\p{L})(tələb|istifadə|nəzərdən|edin|olunur|edilir|daxil olun|xahiş|bildiriş|məlumat|diqqət|yeni e-portal)(?!\p{L})/u.test(l)
      && (/["“”«»„]/.test(t) || /məhdud|məsuliyyətli|səhmdar|cəmiyyət|müəssisə|kooperativ|birliy|filial|şirkət|holdinq|\b(mmc|asc|qsc|ltd|llc)\b/.test(l)); };
  const rest = clean(leaves[k].textContent).split('!').slice(1).join('!').trim();
  const near = [rest, ...leaves.slice(k + 1, k + 8).filter(e => !e.closest('[role="dialog"], [role="alert"], .ant-modal, .ant-notification, .ant-message, .ant-alert')).map(e => clean(e.textContent))];
  return { name: near.find(isCo) || '' };
}
// Saytın kontekstində (açıq olan səhifənin özündə): şirkətin VÖEN-i və adı.
// Mənbələr: hook.js-in saxladığı profil cavabı, saytın öz brauzer yaddaşındakı JSON, lazım olsa saytın öz başlıqları ilə profil sorğusu.
async function ownFromTop(homeName) {
  const LEGAL = /MMC|ASC|QSC|MƏHDUD|CƏMİYYƏT|SƏHMDAR|MÜƏSSİSƏ|FİLİAL|KOOPERATİV|BİRLİY|İDARƏ|["“”«»]/i, nz = s => String(s || '').toLocaleLowerCase('az').replace(/[^\p{L}\p{N}]+/gu, '');
  const out = { hook: Array.isArray(window.__dxProf), cavab: 0, yaddas: 0, sorgu: [], basliq: Object.keys(window.__dxAuth || {}) };
  const pool = [...(window.__dxProf || [])]; out.cavab = pool.length;
  try {
    for (const st of [localStorage, sessionStorage]) for (let i = 0; i < st.length; i++) {
      const v = st.getItem(st.key(i)); if (!v || v.length > 300000 || !/\d{10}/.test(v) || !/^\s*[[{"]/.test(v)) continue;
      try { let j = JSON.parse(v); if (typeof j === 'string' && /^\s*[[{]/.test(j)) j = JSON.parse(j); if (j && typeof j === 'object') { pool.push(j); out.yaddas++; } } catch (e) {}
    }
  } catch (e) {}
  const isCo = s => { const t = String(s || '').trim(), l = t.toLocaleLowerCase('az');
    return t.length >= 3 && t.length <= 160 && !/[!?]/.test(t) && !/(?<!\p{L})(tələb|istifadə|nəzərdən|edin|olunur|edilir|daxil olun|xahiş|bildiriş|məlumat|diqqət|yeni e-portal)(?!\p{L})/u.test(l)
      && (/["“”«»„]/.test(t) || /məhdud|məsuliyyətli|səhmdar|cəmiyyət|müəssisə|kooperativ|birliy|filial|şirkət|holdinq|\b(mmc|asc|qsc|ltd|llc)\b/.test(l)); };
  const vkey = k => !/phone|mobil|tel|fax|account|iban|pin|fin|date|time|code|kod/i.test(k);
  const pick = () => {
    const vs = [], ns = [];
    const walk = (o, key, d, near) => {
      if (o == null || d > 8) return;
      if (typeof o === 'object') {
        // bu obyektdə VÖEN varsa, eyni obyektdəki ad ona aiddir
        const own = !Array.isArray(o) && Object.entries(o).some(([k, v]) => /^\d{10}$/.test(String(v).trim()) && vkey(k) && /voen|vöen|(^|_)tin$|taxpayer|payer/i.test(k));
        for (const [k, v] of Array.isArray(o) ? o.slice(0, 30).map(x => [key, x]) : Object.entries(o)) walk(v, k, d + 1, own && (v == null || typeof v !== 'object'));
        return;
      }
      const s = String(o).trim(), k = String(key || '');
      if (/^\d{10}$/.test(s) && vkey(k)) vs.push({ k, v: s, s: /voen|vöen/i.test(k) ? 3 : /(^|_)tin$|taxpayer|payer/i.test(k) ? 2 : 0 });
      else if (typeof o === 'string' && isCo(s) && !/^https?:|@/.test(s))
        ns.push({ k, v: s, s: (homeName && nz(s) === nz(homeName) ? 10 : 0) + (near ? 4 : 0) + (/["“”«»]/.test(s) ? 3 : 0) + (LEGAL.test(s) ? 2 : 0) + (/name|title|(^|_)ad(i|ı)?$/i.test(k) ? 1 : 0) + (/company|legal|org|taxpayer|payer|full/i.test(k) ? 1 : 0) - (/message|text|desc|note|content|body|notif|alert|info/i.test(k) ? 5 : 0) });
    };
    pool.forEach(j => walk(j, '', 0, false));
    vs.sort((a, b) => b.s - a.s); ns.sort((a, b) => b.s - a.s);
    const one = new Set(vs.map(x => x.v)).size === 1, v = vs[0] && (vs[0].s > 0 || one) ? vs[0] : null, n = ns[0] && ns[0].s >= 3 ? ns[0] : null;
    return { voen: v ? v.v : '', name: n ? n.v : '', acar: [v ? v.k : null, n ? n.k : null] };
  };
  let r = pick();
  if (!r.voen || !r.name) {
    const urls = [...new Set([...performance.getEntriesByType('resource').map(x => x.name).filter(u => /\/api\/[^?]*(profile|taxpayer|userinfo|user-info)/i.test(u)), location.origin + '/api/po/profile/public/v2/profile'])].slice(0, 4);
    for (const u of urls) {
      try {
        const res = await fetch(u, { credentials: 'include', headers: { ...(window.__dxAuth || {}) } }); out.sorgu.push(res.status);
        if (res.ok && (res.headers.get('content-type') || '').includes('json')) { pool.push(await res.json()); r = pick(); if (r.voen && r.name) break; }
      } catch (e) { out.sorgu.push('x'); }
    }
  }
  return { ...out, ...r };
}
// Şirkət adının qısa forması: "İNŞAATÇI 2025" Məhdud Məsuliyyətli Cəmiyyəti → "İNŞAATÇI 2025" MMC
function shortName(s) {
  let t = String(s || '').replace(/\s+/g, ' ').trim(); if (!t) return '';
  const low = t.toLocaleLowerCase('az');
  if (low.length !== t.length) return t;
  for (const [rx, ab] of [[/məhdud\s+məsuliyyətli\s+cəmiyyəti?/, 'MMC'], [/açıq\s+səhmdar\s+cəmiyyəti?/, 'ASC'], [/qapalı\s+səhmdar\s+cəmiyyəti?/, 'QSC'], [/\b(mmc|asc|qsc)\b/, null]]) {
    const m = low.match(rx); if (!m) continue;
    const form = ab || t.substr(m.index, m[0].length).toLocaleUpperCase('az');
    let core = (t.slice(0, m.index) + ' ' + t.slice(m.index + m[0].length)).replace(/\s+/g, ' ').trim();
    const q = core.match(/["“”«»„]\s*(.+?)\s*["“”«»]/); core = (q ? q[1] : core).replace(/^["“”«»„\s]+|["“”«»\s]+$/g, '').trim();
    return core ? `"${core.toLocaleUpperCase('az')}" ${form}` : t;
  }
  return t;
}
async function detectOwn(tabId) {
  const own = { voen: '', name: '', city: '', menbe: [] }, rep = {};
  let T = {};
  try { T = (await chrome.scripting.executeScript({ target: { tabId }, func: ownFromTop, args: [''], world: 'MAIN' }))[0].result || {}; } catch (e) { T = { xeta: e.message }; }
  rep.buSehife = { hook: T.hook, cavab: T.cavab, yaddas: T.yaddas, sorgu: T.sorgu, basliqAdlari: T.basliq, voen: !!T.voen, ad: !!T.name, acar: T.acar || null, xeta: T.xeta || null };
  if (T.voen) own.voen = T.voen; if (T.name) own.name = T.name;
  if (T.voen || T.name) own.menbe.push('bu səhifə');
  if (!own.voen || !own.name) {
    const fr = (tag, url, fn) => withFrame(tabId, tag, url, async fid => { const r = await inFrame(tabId, fid, fn, []) || {}; try { r.api = await inFrame(tabId, fid, ownFromTop, [r.name || ''], 'MAIN'); } catch (e) {} return r; }).catch(e => ({ error: e.message }));
    const [p, h] = await Promise.all([fr('dx-prof', ORIGIN + '/eportal/profile', ownFromProfile), fr('dx-home', ORIGIN + '/eportal/', ownFromHome)]);
    const P = p || {}, H = h || {}, A = [H.api, P.api].filter(Boolean), av = A.find(x => x.voen), an = A.find(x => x.name);
    rep.sexsiMelumatlar = P.error ? { xeta: P.error } : { ad: !!P.name, voen: !!P.voen, seher: !!P.city, uzunluq: P.uzunluq, voenSozu: P.voenSozu };
    rep.anaSehife = H.error ? { xeta: H.error } : { ad: !!H.name };
    rep.cerceveSorgusu = A.map(x => ({ cavab: x.cavab, sorgu: x.sorgu, voen: !!x.voen, ad: !!x.name }));
    if (!own.voen) own.voen = P.voen || (av ? av.voen : '');
    if (!own.name) own.name = H.name || P.name || (an ? an.name : '');        // ad ana səhifədə tam yazılır
    own.city = P.city || '';
    if (H.name) own.menbe.push('ana səhifə'); if (P.voen || P.name) own.menbe.push('şəxsi məlumatlar'); if (av || an) own.menbe.push('çərçivə sorğusu');
  }
  const isCo = s => { const t = String(s || '').trim(), l = t.toLocaleLowerCase('az');
    return t.length >= 3 && t.length <= 160 && !/[!?]/.test(t) && !/(?<!\p{L})(tələb|istifadə|nəzərdən|edin|olunur|edilir|daxil olun|xahiş|bildiriş|məlumat|diqqət|yeni e-portal)(?!\p{L})/u.test(l)
      && (/["“”«»„]/.test(t) || /məhdud|məsuliyyətli|səhmdar|cəmiyyət|müəssisə|kooperativ|birliy|filial|şirkət|holdinq|\b(mmc|asc|qsc|ltd|llc)\b/.test(l)); };
  if (own.name && !isCo(own.name)) { rep.reddEdilenAd = true; own.name = ''; }
  own.name = shortName(own.name);
  return { own, rep };
}

// Bir qaimənin məlumatından sənədlərin sahələrini qurur
function docData(d, res, dir, own, o, seq) {
  const info = res.info || {}, h = res.header || [], col = rx => h.findIndex(x => rx.test(x || ''));
  const cName = h.findIndex(x => /adı/i.test(x || '') && /mal|iş|xidmət/i.test(x)), cUnit = col(/ölçü vahidi/i), cQty = col(/miqdar/i), cPrice = col(/qiymət/i), cSum = col(/cəmi məbləğ/i), cVat = col(/ƏDV məbləği|ödənilməli ƏDV/i), cTot = col(/yekun/i);
  const cell = (r, c) => c > -1 ? String(r[c] == null ? '' : r[c]).trim() : '';
  const items = res.rows.map(r => ({ MAL_ADI: cell(r, cName), OLCU_VAHIDI: cell(r, cUnit), MIQDAR: cell(r, cQty), QIYMET: cell(r, cPrice), SETIR_CEMI: cell(r, cSum) }));
  const sum = c => c > -1 ? res.rows.reduce((s, r) => s + num(r[c]), 0) : null;
  const vat = d.vat ? num(d.vat) : (sum(cVat) || 0), tot = d.total ? num(d.total) : (sum(cTot) || (sum(cSum) || 0) + vat);
  // Qarşı tərəf siyahıdan (qaimədə tam adı varsa, o); öz şirkət: göndərilən qaimədə icraçı, gələndə sifarişçi
  const other = (info.parties || []).find(p => p.voen === d.voen) || { voen: d.voen, name: d.name }, me = own || {};
  const seller = dir === 'out' ? me : other, buyer = dir === 'out' ? other : me, bank = o.bank || {};
  const dmy = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? `${m[3]}.${m[2]}.${m[1]}` : (s || ''); };
  const data = { TARIX: ((info.created || d.date || '').match(/\d{2}\.\d{2}\.\d{4}/) || [''])[0], SEHER: me.city || 'Bakı şəhəri', ICRACI_ADI: seller.name, ICRACI_VOEN: seller.voen, SIFARISCI_ADI: buyer.name, SIFARISCI_VOEN: buyer.voen,
    MUQAVILE_NO: o.contractNo, MUQAVILE_TARIXI: dmy(o.contractDate), ELAVE_NO: seq, CEMI_EDVSIZ: fmt2(tot - vat), EDV: fmt2(vat), CEMI_EDVLI: fmt2(tot), YEKUN_MEBLEG_SOZLE: amountWords(tot),
    BANK_ADI: bank.bank, BANK_KODU: bank.code, SWIFT: bank.swift, MUXBIR_HESAB: bank.corr, HESAB_NOMRESI: bank.acc };
  return { data, items, noOwn: !me.name || !me.voen };
}

async function runDocsDom({ tabId, serials, voen, from, to, dir, docs, opts }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  const want = new Set((serials || []).map(s => s.toUpperCase())), keys = Object.keys(DOCS).filter(k => docs && docs[k]);
  // Nömrə verilibsə: seriyadakı il-aya (MT2611...) görə siyahının haraya qədər oxunacağı müəyyən olunur
  let fromN, toN;
  if (want.size) {
    const yms = [...want].map(s => (s.match(/^[A-Z]{2}(\d{2})(\d{2})/) || []).slice(1).map(Number)).filter(x => x.length === 2 && x[1] >= 1 && x[1] <= 12);
    fromN = yms.length === want.size ? Math.min(...yms.map(([y, m]) => (2000 + y) * 10000 + m * 100 + 1)) : 0; toN = 99991231;
  } else { fromN = N(from); toN = N(to); }
  const g = await gatherList(tabId, tab, fromN, toN, 'altSenedler');
  const hit = x => (!want.size || want.has(x.serial)) && (!voen || x.voen === voen);
  const sel = g.inDates.filter(hit).sort((a, b) => a.dnum - b.dnum);
  const notFound = [...want].filter(s => !sel.some(x => x.serial === s));
  g.base.secim = { nomre: want.size, voenSecimi: !!voen, tapildi: sel.length, tapilmadi: notFound.length };
  await chrome.storage.local.set({ report: g.base });
  if (!sel.length) throw new Error(want.size ? `Yazdığın ${want.size} qaimədən heç biri "${tab}" siyahısında tapılmadı (${g.pagesTotal} səhifəyə baxıldı). Bölməni (Gələn/Göndərilən), VÖEN-i və saytda seçilmiş ili yoxla.`
    : `"${tab}" bölməsində bu VÖEN və tarixlərə uyğun qaimə tapılmadı (${g.pagesTotal} səhifəyə baxıldı).`);

  const stats = (d, f) => [{ l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }, { l: 'Sənəd', v: f }];
  const r = await readAll(tabId, sel, { tab, base: g.list.base, tpl: null }, d => log(`${d} / ${sel.length} qaimə oxundu. Siyahı səhifəsini açıq saxla.`, false, { i: d, n: sel.length, stats: stats(d, 0) }));

  // Öz şirkət: e-taxes-in "Şəxsi məlumatlar" səhifəsindən; orada tapılmayan hissə qaimənin özündən (qarşı tərəf olmayan VÖEN) tamamlanır
  const o = opts || {};
  const fromInv = (d, res) => ((res.info || {}).parties || []).find(p => p.voen !== d.voen) || null;
  const src = {};
  log('Şirkətin məlumatı "Şəxsi məlumatlar"dan götürülür...', false, { i: sel.length, n: sel.length, stats: stats(sel.length, 0) });
  const det = await detectOwn(tabId), detected = det.own, detRep = det.rep;
  try { await exec(tabId, rmAllFrames); } catch (e) {}
  let files = 0, okInv = 0, err = 0, noOwn = 0, seq = 0; const errs = [], labels = new Set();
  for (let i = 0; i < sel.length; i++) {
    const d = sel[i], res = r.results[i]; if (!res) continue;
    if (res.error) { err++; errs.push(res.error); continue; }
    ((res.info || {}).labels || []).forEach(l => labels.add(l));
    const inv = fromInv(d, res) || {}, own = { name: detected.name || inv.name || '', voen: detected.voen || inv.voen || '', city: detected.city };
    const s = [...detected.menbe, ...((!detected.name || !detected.voen) && inv.voen ? ['qaimə'] : [])].join('+') || 'yoxdur'; src[s] = (src[s] || 0) + 1;
    const dd = docData(d, { ...res, header: res.header.length ? res.header : (r.header || []) }, dir, own, o, ++seq);
    if (dd.noOwn) noOwn++;
    files += await saveInvoiceDocs(keys, dd.data, dd.items, d.serial);
    okInv++; log(`Sənədlər hazırlanır: ${okInv} / ${sel.length} qaimə...`, false, { i: i + 1, n: sel.length, stats: stats(sel.length, files) });
  }
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ ownSeen: { name: detected.name, voen: detected.voen, t: Date.now() } });
  await chrome.storage.local.set({ report: { ...g.base, qaimeUnvani: r.learned.how, saniye: sec, senedSayi: files, xeta: err, ozSirket: { menbe: src, tapilmadi: noOwn, axtaris: detRep },
    basliqEtiketleri: [...labels].slice(0, 30), sutunlar: r.header, xetalar: [...new Set(errs.map(mask))].slice(0, 4), api: r.api } });
  const warn = [];
  if (notFound.length) warn.push(`Tapılmadı: ${notFound.slice(0, 6).join(', ')}${notFound.length > 6 ? ' və daha ' + (notFound.length - 6) : ''}.`);
  if (err) warn.push(`${err} qaimə oxunmadı.`);
  if (noOwn) warn.push(`${noOwn} qaimədə öz şirkətinin adı və ya VÖEN-i avtomatik tapılmadı, yerinə xətt çəkilib.`);
  if (g.partial) warn.push('Siyahının davamı açılmadı, bəzi qaimələr tapılmaya bilər.');
  log((notFound.length || err || g.partial ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${okInv} qaimə üçün ${files} sənəd hazırdır. «Yüklə» düyməsini bassan, "Yükləmələr / DataX alt sənədlər" içində hər qaimə üçün bir qovluq (zip) olacaq.` + ((detected.name || detected.voen) ? `\nŞirkətin: ${detected.name || '?'}, VÖEN ${detected.voen || '?'}` : '') + (warn.length ? '\n' + warn.join('\n') : ''), true,
    { i: sel.length, n: sel.length, hasErrors: !!(notFound.length || err), stats: [{ l: 'Qaimə', v: okInv }, { l: 'Sənəd', v: files }, { l: 'Tapılmadı', v: notFound.length }] });
}

// =====================================================================================
// FUNKSİYA 4: Bəyannamələrin içi (bütün vergi növləri, bölmələr üzrə)
// =====================================================================================
const TAXES = [                                            // e-taxes-dəki əsas bəyannamə növləri və dövrləri
  { k: 'menfeet', ab: 'Mənfəət', rx: /mənfəət vergisi/, per: 'il' },
  { k: 'sadelesdirilmis', ab: 'Sadələşdirilmiş', rx: /sadələşdirilmiş/, per: 'rub' },
  { k: 'gelir', ab: 'Gəlir', rx: /gəlir vergisi/, per: 'il' },
  { k: 'edvevez', ab: 'ƏDV əvəzləşmə', rx: /əlavə dəyər vergisi.*əvəzləş/, per: 'ay' },            // seçiləndə "ƏDV əvəzləşmə" funksiyası işləyir
  { k: 'edv', ab: 'ƏDV', rx: /əlavə dəyər vergisi/, per: 'ay' },
  { k: 'muzdlu', ab: 'Muzdlu iş', rx: /muzdlu iş/, per: 'rub' },
  { k: 'omv', ab: 'Ödəmə mənbəyi', rx: /ödəmə mənbəyində(n)? tutulan/, per: 'rub' }];
const taxOf = title => { const l = String(title || '').toLocaleLowerCase('az'); return TAXES.find(t => t.rx.test(l)) || { k: 'diger', ab: String(title || 'Digər').slice(0, 14) }; };
const MONTHS_AZ = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avqust', 'sentyabr', 'oktyabr', 'noyabr', 'dekabr'];
// Dövr mətni → ay aralığı: "Sentyabr 2026", "3-cü rüb 2026", "III rüb 2026", "1-ci yarımil 2026", "2025", "2025-ci il"
function periodRange(p) {
  const l = String(p || '').toLocaleLowerCase('az').replace(/\s+/g, ' ').trim(), y = +((l.match(/(20\d{2})/) || [])[1] || 0);
  if (!y) return null;
  const mi = MONTHS_AZ.findIndex(m => l.startsWith(m)); if (mi > -1) return { y, a: mi + 1, b: mi + 1 };
  const roman = { i: 1, ii: 2, iii: 3, iv: 4 };
  let q = l.match(/(\d|iv|i{1,3})\s*[-–]?\s*(?:ci|cü|cu|cı)?\s*rüb/); if (q) { const n = +q[1] || roman[q[1]]; if (n >= 1 && n <= 4) return { y, a: n * 3 - 2, b: n * 3 }; }
  q = l.match(/(\d|i{1,2})\s*[-–]?\s*(?:ci|cü|cu|cı)?\s*yarım\s*il/); if (q) { const n = +q[1] || roman[q[1]]; if (n === 1 || n === 2) return { y, a: n * 6 - 5, b: n * 6 }; }
  return { y, a: 1, b: 12 };
}

// Səhifədə: bəyannamələr siyahısındakı BÜTÜN bölmələr (hər vergi növü öz cədvəli və səhifələməsi ilə)
async function declList(waitSec) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const RX = /^(.+?)\s*\/\s*(.+?)\s+Sənəd nömrəsi:\s*(\d+)/;
  const cells = tr => [...tr.children].filter(c => /^(TD|TH)$/.test(c.tagName));
  const readRows = t => [...t.querySelectorAll('tr')].map(tr => {
    const c = cells(tr); if (c.length < 4) return null;
    const ti = c.findIndex(x => RX.test(clean(x.innerText))); if (ti < 0) return null;
    const txt = clean(c[ti].innerText), m = txt.match(RX);
    const rest = c.slice(ti + 1).map(x => clean(x.innerText));
    return { period: clean(m[1]), type: clean(m[2]), docNo: m[3], kind: clean((txt.match(/Təqdim edilmə növü:\s*([^|]+)/) || [])[1]), kameral: /kameral/i.test(txt),
      date: rest.find(v => /^\d{2}\.\d{2}\.\d{4}/.test(v)) || '', status: rest.find(v => /təsdiq|qəbul|imtina|qaralama|göndəril|ləğv/i.test(v)) || '', amount: rest.find(v => /^-?[\d\s]+,\d{2}$/.test(v)) || '' };
  }).filter(Boolean);
  // Cədvəlin başlığı: cədvəldən əvvəl gələn ən yaxın mətn (vergi növünün adı)
  const titleOf = w => {
    for (let e = w; e && e !== document.body; e = e.parentElement) {
      for (let s = e.previousElementSibling; s; s = s.previousElementSibling) {
        const t = clean(s.innerText); if (t && t.length <= 200 && !s.querySelector('table')) return t.split('\n')[0];
        if (s.querySelector('table')) break;
      }
    }
    return '';
  };
  for (let i = 0; i < waitSec * 10 && !document.querySelector('tbody tr'); i++) { if (i > 25 && document.querySelector('.ant-empty')) break; await sleep(100); }
  await sleep(300);
  const wraps = () => { const w = [...document.querySelectorAll('.ant-table-wrapper')]; return w.length ? w : [...document.querySelectorAll('table')]; };
  const out = [], sections = [];
  const n = wraps().length;
  for (let wi = 0; wi < n; wi++) {
    let w = wraps()[wi]; if (!w) break;
    const title = titleOf(w); let pages = 0, cnt = 0;
    const sig = () => { const x = wraps()[wi]; return x ? clean((x.querySelector('tbody') || x).innerText).slice(0, 300) : ''; };
    // 1-ci səhifədən başla
    const first = w.querySelector('.ant-pagination-item-1');
    if (first && !first.classList.contains('ant-pagination-item-active')) { const o = sig(); first.click(); for (let i = 0; i < 60 && sig() === o; i++) await sleep(100); }
    for (let p = 0; p < 100; p++) {
      w = wraps()[wi]; if (!w) break;
      const rows = readRows(w); pages++; cnt += rows.length;
      rows.forEach(r => out.push({ ...r, section: title }));
      const nx = w.querySelector('.ant-pagination-next');
      if (!nx || nx.classList.contains('ant-pagination-disabled') || nx.getAttribute('aria-disabled') === 'true') break;
      const o = sig(); (nx.querySelector('button') || nx).click();
      let changed = false; for (let i = 0; i < 80; i++) { await sleep(100); if (sig() !== o) { changed = true; break; } }
      if (!changed) break;
      await sleep(200);
    }
    if (cnt) sections.push({ title, pages, rows: cnt });
  }
  return { rows: out, sections };
}

// Səhifədə: açıq bəyannamə bölməsinin bütün məzmunu (cədvəllər və sahələr). Cədvəl səhifələnirsə, bütün səhifələr oxunur.
async function readDeclPage(waitSec) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const visible = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const valOf = c => {
    const ins = [...c.querySelectorAll('input, textarea, select')].filter(i => i.type !== 'hidden');
    const sel = c.querySelector('.ant-select-selection-item'); if (sel) return clean(sel.textContent);
    if (ins.length) return ins.map(i => i.type === 'checkbox' || i.type === 'radio' ? (i.checked ? 'Bəli' : 'Xeyr') : i.tagName === 'SELECT' ? clean((i.selectedOptions[0] || {}).textContent) : clean(i.value)).join(' ');
    return clean(c.innerText);
  };
  // Səhifənin yüklənməsini gözlə: məzmun sabitləşənə qədər
  let last = '', same = 0;
  for (let i = 0; i < waitSec * 10; i++) {
    const s = clean(document.body.innerText).length + '|' + document.querySelectorAll('tr').length + '|' + !!document.querySelector('.ant-spin-spinning');
    if (s === last && !document.querySelector('.ant-spin-spinning, .ant-skeleton-active')) { if (++same >= 5) break; } else { same = 0; last = s; }
    await sleep(100);
  }
  // Yan panel (addımlar siyahısı): "Siyahıya qayıt" olan blok
  const back = [...document.querySelectorAll('body *')].find(e => e.childElementCount === 0 && /^Siyahıya qayıt$/.test(clean(e.textContent)));
  let side = null;
  for (let e = back; e && e !== document.body; e = e.parentElement) { if ([...e.querySelectorAll('*')].filter(x => x.childElementCount === 0 && /^\d{1,2}$/.test(clean(x.textContent))).length >= 2) { side = e; break; } }
  const inSide = e => side && side.contains(e);
  // Bölmənin adı: yan paneldə aktiv addım, yoxsa məzmundakı ilk başlıq
  let title = '';
  if (side) {
    const act = [...side.querySelectorAll('*')].find(e => /(^|[\s_-])(active|current|selected|process)([\s_-]|$)/i.test(typeof e.className === 'string' ? e.className : '') && /\p{L}{3}/u.test(e.innerText || '') && e.innerText.length < 200);
    if (act) title = clean(act.innerText).replace(/^\d{1,2}\s*/, '');
  }
  if (!title) { const h = [...document.querySelectorAll('h1, h2, h3, h4')].find(e => !inSide(e) && visible(e) && clean(e.textContent)); if (h) title = clean(h.textContent); }

  // Cədvəllər: bir neçə hissəyə bölünmüş Ant cədvəli (ayrı başlıq) bir cədvəl sayılır; ara başlıq və "CƏMİ" sətirləri yeni blok açır
  const tableRoots = () => { const a = [...document.querySelectorAll('.ant-table')].filter(e => !inSide(e)); return a.length ? a : [...document.querySelectorAll('table')].filter(t => !inSide(t) && !t.parentElement.closest('table')); };
  const readTable = root => {
    const blocks = []; let cur = null, pendingTitle = '';
    for (const tr of root.querySelectorAll('tr')) {
      if (tr.getAttribute('aria-hidden') === 'true' || /measure-row/.test(tr.className)) continue;
      const cs = [...tr.children].filter(c => /^(TD|TH)$/.test(c.tagName)); if (!cs.length) continue;
      const v = cs.map(c => clean(c.innerText)), filled = v.filter(Boolean);
      if (!filled.length) continue;                                                       // filtr xanaları sətri
      if (v.every((x, i) => x === String(i + 1) || x === '')) continue;                   // sütun nömrələri sətri
      const isHead = cs.every(c => c.tagName === 'TH') || (!!tr.closest('thead'));
      if (filled.length === 1 && cs.length > 2 && !isHead && !/^\d{2,4}([.\-]\d+)*\.?(\s|$)/.test(filled[0])) { pendingTitle = filled[0]; cur = null; continue; }      // "CƏMİ" kimi ara başlıq (boş sətir kodu yox)
      const labels = filled.length >= 2 && filled.every(x => /\p{L}/u.test(x) && !/^-?[\d\s]+([.,]\d+)?$/.test(x));
      if (isHead || (!cur && labels)) {
        if (cur && cur.head && !cur.rows.length) { cur.header = cur.header.map((h, i) => [h, v[i]].filter(Boolean).join(' / ')); for (let i = cur.header.length; i < v.length; i++) cur.header.push(v[i]); continue; }   // çoxsətirli başlıq
        cur = { title: pendingTitle, header: v, rows: [], head: true }; blocks.push(cur); pendingTitle = ''; continue;
      }
      if (!cur) { cur = { title: pendingTitle, header: v.map((_, i) => 'Sütun ' + (i + 1)), rows: [] }; blocks.push(cur); pendingTitle = ''; }
      cur.rows.push(v);
    }
    return blocks.filter(b => b.rows.length);
  };
  const sigT = () => tableRoots().map(r => clean((r.querySelector('tbody') || r).innerText).slice(0, 200)).join('|');
  const tables = []; let pagesRead = 0;
  const roots0 = tableRoots().length;
  const kvTable = root => { if (root.querySelector('th')) return null; const trs = [...root.querySelectorAll('tr')].filter(tr => tr.getAttribute('aria-hidden') !== 'true'); if (!trs.length) return null;
    const pairs = trs.map(tr => [...tr.children].filter(c => /^(TD|TH)$/.test(c.tagName)).map(c => clean(c.innerText)));
    return pairs.every(p => p.length === 2 && p[0] && /\p{L}/u.test(p[0]) && !/^\d{2,4}([.\-]\d+)*\.?(\s|$)/.test(p[0])) ? pairs : null; };
  const kvFields = [];
  for (let ti = 0; ti < roots0; ti++) {
    const kv = kvTable(tableRoots()[ti]); if (kv) { kv.forEach(p => kvFields.push(p)); continue; }
    const seen = new Set();
    for (let p = 0; p < 200; p++) {
      const root = tableRoots()[ti]; if (!root) break;
      const blocks = readTable(root), key = JSON.stringify(blocks.map(b => b.rows.slice(0, 2)));
      if (seen.has(key)) break; seen.add(key); pagesRead++;
      blocks.forEach((b, bi) => { const t = tables.find(x => x.ti === ti && x.bi === bi && x.header.join('|') === b.header.join('|')); if (t) t.rows.push(...b.rows); else tables.push({ ti, bi, ...b }); });
      // növbəti səhifə: Ant səhifələməsi və ya "Görünür a - b / c"
      const wrap = root.closest('.ant-table-wrapper') || root.parentElement;
      let nx = wrap && wrap.querySelector('.ant-pagination-next');
      if (nx && (nx.classList.contains('ant-pagination-disabled') || nx.getAttribute('aria-disabled') === 'true')) break;
      if (!nx) {
        const g = [...document.querySelectorAll('body *')].find(e => e.childElementCount === 0 && /^Görünür/.test(clean(e.textContent)) && (root.compareDocumentPosition(e) & 4));
        const m = g && clean(g.textContent).match(/(\d+)\s*-\s*(\d+)\s*\/\s*(\d+)/); if (!m || +m[2] >= +m[3]) break;
        nx = [...document.querySelectorAll('button, li, a, span')].find(e => e.childElementCount === 0 && clean(e.textContent) === String(p + 2) && (g.compareDocumentPosition(e) & 4));
        if (!nx) break;
      }
      const o = sigT(); (nx.querySelector && nx.querySelector('button') || nx).click();
      let ch = false; for (let i = 0; i < 80; i++) { await sleep(100); if (sigT() !== o) { ch = true; break; } }
      if (!ch) break; await sleep(250);
    }
  }
  // Sahələr: forma elementləri, "Ad: dəyər" cütləri (yan paneldəki Dövr, Qeydiyyat nömrəsi və s. daxil)
  const fields = [], seenF = new Set();
  kvFields.forEach(p => fields.push(['bölmə', p[0], p[1]]));
  const add = (k, v, where) => { k = clean(k).replace(/[:：]\s*$/, ''); v = clean(v); const key = k + '|' + v; if (!k || !v || k.length > 160 || seenF.has(key)) return; seenF.add(key); fields.push([where, k, v]); };
  document.querySelectorAll('.ant-form-item').forEach(f => { if (f.closest('table')) return; const l = f.querySelector('.ant-form-item-label, label'), c = f.querySelector('.ant-form-item-control') || f; if (l) add(l.innerText, valOf(c), inSide(f) ? 'panel' : 'bölmə'); });
  document.querySelectorAll('.ant-descriptions-item, .ant-descriptions-row > th').forEach(d => { const l = d.querySelector('.ant-descriptions-item-label'), c = d.querySelector('.ant-descriptions-item-content'); if (l && c) add(l.innerText, c.innerText, inSide(d) ? 'panel' : 'bölmə'); });
  [...document.querySelectorAll('body *')].filter(e => e.childElementCount === 0 && !e.closest('table, .ant-form-item, .ant-descriptions, button, a') && /^[^:]{2,80}:\s*$/.test(clean(e.textContent))).forEach(l => {
    const n = l.nextElementSibling || (l.parentElement && l.parentElement.nextElementSibling); if (n && !n.querySelector('table')) add(l.textContent, valOf(n), inSide(l) ? 'panel' : 'bölmə');
  });
  return { side: !!side, title, path: location.pathname, tables: tables.map(t => ({ title: t.title, header: t.header, rows: t.rows })), fields, pages: pagesRead, hasNext: !!nextButton() };
  function nextButton() { return [...document.querySelectorAll('button, a')].find(b => /^İrəli$/.test(clean(b.innerText)) && visible(b) && !b.disabled && b.getAttribute('aria-disabled') !== 'true'); }
}
// Səhifədə: "İrəli" düyməsi ilə növbəti bölməyə keçir: 'ok' | 'end'
async function declNext() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clean = t => (t || '').replace(/\s+/g, ' ').trim();
  const b = [...document.querySelectorAll('button, a')].find(x => /^İrəli$/.test(clean(x.innerText)) && x.getBoundingClientRect().width > 0 && !x.disabled && x.getAttribute('aria-disabled') !== 'true');
  if (!b) return 'end';
  const o = location.pathname + location.search; b.click();
  for (let i = 0; i < 150; i++) { await sleep(100); if (location.pathname + location.search !== o) return 'ok'; }
  return 'end';
}

// Bir bəyannamənin bütün bölmələri (görünməz çərçivədə)
async function readWholeDecl(tabId, fid) {
  const out = [], seen = new Set();
  for (let s = 0; s < 30; s++) {
    if (cancel) break;
    const pg = await inFrame(tabId, fid, readDeclPage, [15]);
    if (!pg || seen.has(pg.path)) break; seen.add(pg.path);
    out.push(pg);
    if (!pg.hasNext || await inFrame(tabId, fid, declNext, []) !== 'ok') break;
  }
  return out;
}
const declAt = (tabId, d, url, tag) => withFrame(tabId, tag, url, async fid => ({ sections: await readWholeDecl(tabId, fid), url: await inFrame(tabId, fid, getHref, []) }));
const declClickAll = (tabId, d) => withFrame(tabId, 'dx-b' + d.docNo, ORIGIN + '/eportal/declarations', async fid => {
  const y = await inFrame(tabId, fid, setYear, [d.listYear]);
  if (!y || !/^(ok|same)$/.test(y.state)) return { error: 'çərçivədə il seçilmədi: ' + (y && y.state) };
  const c = await clickDeclIn(tabId, fid, d.docNo);
  if (!c || c.error) return { error: (c && c.error) || 'klik alınmadı' };
  return { sections: await readWholeDecl(tabId, fid), first: c.url };
});

async function runDeclsDom({ tabId, from, to, taxes, skipKameral }) {
  const t0 = Date.now();
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), nowY = new Date().getFullYear();
  const F = fy * 12 + fm, T = ty * 12 + tm, years = [];
  for (let y = fy; y <= Math.min(ty + 1, nowY); y++) years.push(y);
  if (!years.length) years.push(fy);
  // 1) Hər ilin siyahısı (bütün vergi növləri)
  const byDoc = new Map(), yearNotes = [], secSeen = {}; let origYear = null;
  for (const y of years) {
    if (cancel) break;
    log(`${y}-ci ilin bəyannamələr siyahısı oxunur...`);
    const st = (await exec(tabId, setYear, [y]))[0].result || { state: 'cavab yoxdur' };
    if (origYear === null && st.was) origYear = st.was;
    if (!/^(ok|same)$/.test(st.state)) { if (y >= fy && y <= ty) yearNotes.push(`${y}: ${st.state}`); continue; }
    const L = (await exec(tabId, declList, [st.state === 'ok' ? 6 : 12]))[0].result || { rows: [], sections: [] };
    L.sections.forEach(s => { secSeen[s.title] = (secSeen[s.title] || 0) + s.rows; });
    L.rows.forEach(x => { if (!byDoc.has(x.docNo)) byDoc.set(x.docNo, { ...x, listYear: y }); });
  }
  if (origYear && String(years[years.length - 1]) !== origYear) { try { await exec(tabId, setYear, [+origYear]); } catch (e) {} }

  // 2) Seçim: vergi növü, dövr aralığı; hər vergi növü və dövr üçün ən son bəyannamə
  const want = taxes && taxes.length ? new Set(taxes) : null, unknownPeriod = [];
  const cand = [...byDoc.values()].map(x => ({ ...x, tax: taxOf(x.section), pr: periodRange(x.period) })).filter(x => {
    if (want && !want.has(x.tax.k) && !(want.has('diger') && x.tax.k === 'diger')) return false;
    if (!x.pr) { unknownPeriod.push(x.period); return false; }
    return x.pr.y * 12 + x.pr.b >= F && x.pr.y * 12 + x.pr.a <= T;
  });
  const best = {};
  cand.filter(x => !(skipKameral && x.kameral)).forEach(x => {
    const k = x.section + '|' + x.pr.y + '|' + x.pr.a + '|' + x.pr.b, b = best[k];
    if (!b || dnum(x.date) > dnum(b.date) || (dnum(x.date) === dnum(b.date) && x.docNo > b.docNo)) best[k] = x;
  });
  const sel = Object.values(best).sort((a, b) => a.tax.ab.localeCompare(b.tax.ab, 'az') || (a.pr.y * 12 + a.pr.a) - (b.pr.y * 12 + b.pr.a));
  const baseReport = { versiya: VERSION, funksiya: 'beyannameler', iller: years, ilQeydleri: yearNotes, bolmeler: Object.fromEntries(Object.entries(secSeen).map(([k, v]) => [taxOf(k).ab, v])),
    siyahi: byDoc.size, araliqda: cand.length, secilen: sel.length, dovruTanınmayan: [...new Set(unknownPeriod)].slice(0, 6) };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş vergi növləri və aylar üçün bəyannamə tapılmadı.' + (yearNotes.length ? ` Bu illərin siyahısı açılmadı: ${yearNotes.join('; ')}.` : ''));

  // 3) Hər vergi növü və il üçün ünvan bir dəfə kliklə öyrənilir, qalanları birbaşa açılır
  cancel = false;
  const results = new Array(sel.length).fill(null), tpl = {}, learnNotes = [];
  let done = 0, secCount = 0;
  const report = () => log(`${done} / ${sel.length} bəyannamə oxundu. Siyahı səhifəsini açıq saxla.`, false, { i: done, n: sel.length, stats: [{ l: 'Bəyannamə', v: sel.length }, { l: 'Oxundu', v: done }, { l: 'Bölmə', v: secCount }] });
  const keyOf = d => d.tax.k + '|' + d.section + '|' + d.pr.y;            // forma versiyası dövrün ilinə bağlıdır
  const record = (i, r) => { results[i] = r; done++; if (r && r.sections) secCount += r.sections.length; report(); };
  report();
  try {
    for (const k of [...new Set(sel.map(keyOf))]) {
      if (cancel) break;
      const i = sel.findIndex(d => keyOf(d) === k);
      let r = null;
      if (sel[i].tax.k === 'edv') for (const v of [sel[i].pr.y, sel[i].listYear]) {
        const g = `/eportal/declaration/type/vat/${v}.1/confirmation?reg-number={reg}`;
        try { const t = await declAt(tabId, sel[i], ORIGIN + g.replace('{reg}', sel[i].docNo), 'dx-g' + sel[i].docNo); if (t && !t.error && t.sections && t.sections.length && t.sections[0].side) { r = t; tpl[k] = g; break; } } catch (e) {}
      }
      if (!r) { try { r = await declClickAll(tabId, sel[i]); } catch (e) { r = { error: 'İstisna: ' + e.message }; } }
      if (r && r.first && r.first.includes(sel[i].docNo)) tpl[k] = r.first.replace(sel[i].docNo, '{reg}');
      if (r && r.error) learnNotes.push(`${sel[i].tax.ab} ${sel[i].listYear}: ${mask(r.error)}`);
      record(i, r);
    }
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(CONC, sel.length) }, async () => {
      while (!cancel && next < sel.length) {
        const i = next++; if (results[i]) continue;
        const d = sel[i], t = tpl[keyOf(d)];
        let r = null;
        if (t) { try { r = await declAt(tabId, d, ORIGIN + t.replace('{reg}', d.docNo), 'dx-b' + d.docNo); } catch (e) { r = { error: 'İstisna: ' + e.message }; } }
        if (!r || r.error || !r.sections || !r.sections.length || !r.sections[0].side) { try { const r2 = await declClickAll(tabId, d); if (r2 && !r2.error) r = r2; else r = { error: [r && r.error, r2 && r2.error].filter(Boolean).join(' || ') || 'açılmadı' }; } catch (e) { r = { error: 'İstisna: ' + e.message }; } }
        record(i, r);
      }
    }));
  } finally { try { await exec(tabId, rmAllFrames); } catch (e) {} }

  await declExcel({ sel, results, baseReport, yearNotes, unknownPeriod, tpl, learnNotes, from, to, t0 });
}

async function declExcel({ sel, results, baseReport, yearNotes, unknownPeriod, tpl, learnNotes, from, to, t0, apiMode }) {
  // 4) Excel. "Hesabat": hər bəyannamə bir sətir, sütunlar bölmə → sətir kodu → sütun (formadakı qaydada).
  //    Sətir kodu olmayan cədvəllər (qaimə, şəxs siyahıları) ayrıca vərəqlərdə; sahələr ayrıca vərəqdə.
  const CODE = /^(\d{2,4}(?:[.\-]\d+)*)\.?(?:\s+([\s\S]*))?$/;
  const codeOf = s => { const m = String(s || '').trim().match(CODE); return m ? { code: m[1], label: (m[2] || '').trim() } : null; };
  const isNumV = s => /^-?[\d\s ]+([.,]\d+)?$/.test(String(s || '').trim());
  // Cədvəlin sətir kodu sütunu: dəyərlərin çoxu kod kimidir və kodlar təkrarlanmır
  const codedTable = t => {
    const R = t.rows; if (!R.length) return null;
    const ncol = Math.max(t.header.length, ...R.map(r => r.length));
    const cands = [];
    for (let c = 0; c < Math.min(3, ncol); c++) {
      const vals = R.map(r => r[c]).filter(v => String(v || '').trim()), codes = vals.map(codeOf).filter(Boolean);
      if (!vals.length || codes.length / vals.length < 0.6 || new Set(codes.map(x => x.code)).size / codes.length < 0.8 || /^sıra/i.test(t.header[c] || '')) continue;
      // forma sətirləri adətən adı ilə gəlir (kodun yanında və ya növbəti sütunda); ad yoxdursa, ən azı 2 fərqli kod və "kod" başlığı olmalıdır
      const named = R.filter(r => (codeOf(r[c]) || {}).label || (c + 1 < ncol && String(r[c + 1] || '').trim() && !isNumV(r[c + 1]) && !/^\d{2}\.\d{2}\.\d{4}/.test(String(r[c + 1]).trim()))).length;
      if (named / codes.length < 0.5 && !(codes.length >= 2 && /kod/i.test(t.header[c] || ''))) continue;
      cands.push({ c, s: (/kod|göstərici/i.test(t.header[c] || '') ? 2 : 0) + (named ? 1 : 0) });
    }
    if (!cands.length) return null;
    const cc = cands.sort((a, b) => b.s - a.s || a.c - b.c)[0].c;
    const lc = R.some(r => (codeOf(r[cc]) || {}).label) ? -1 : (cc + 1 < ncol && R.every(r => !String(r[cc + 1] || '').trim() || !isNumV(r[cc + 1])) ? cc + 1 : -1);
    const vcols = []; for (let c = 0; c < ncol; c++) if (c !== cc && c !== lc && !/^sıra/i.test(t.header[c] || '')) vcols.push(c);
    return { cc, lc, vcols };
  };
  const reports = new Map(), sheets = new Map(), names = new Set(['bəyannamələr', 'qeydlər']), list = [], notes = [];
  const safe = s => String(s || '').replace(/[\\/?*[\]:]/g, ' ').replace(/\s+/g, ' ').trim();
  const uniq = name => { let n = safe(name).slice(0, 31), i = 2; while (names.has(n.toLocaleLowerCase('az'))) { const suf = ' ' + i++; n = safe(name).slice(0, 31 - suf.length) + suf; } names.add(n.toLocaleLowerCase('az')); return n; };
  const sheetFor = (key, name, base) => { if (!sheets.has(key)) sheets.set(key, { name: uniq(name), base, cols: [], rows: [] }); return sheets.get(key); };
  const addRows = (sh, header, rows, pre) => {
    const idx = header.map(h => { let j = sh.cols.indexOf(h); if (j < 0) { sh.cols.push(h); j = sh.cols.length - 1; } return j; });
    rows.forEach(r => { const o = []; r.forEach((v, c) => { if (idx[c] != null) o[idx[c]] = v; }); sh.rows.push([...pre, ...o]); });
  };
  let ok = 0, err = 0, rowsTotal = 0, codedCells = 0;
  sel.forEach((d, i) => {
    const r = results[i] || { error: 'oxunmadı' }, pre = [d.period, d.type, d.docNo];
    if (r.error) { err++; notes.push(['Xəta', d.tax.ab + ' / ' + d.period + ' / ' + d.type, d.docNo, mask(r.error)]); list.push([d.tax.ab, d.period, d.type, d.docNo, d.date, d.status, d.amount, 0, 'oxunmadı']); return; }
    ok++;
    list.push([d.tax.ab, d.period, d.type, d.docNo, d.date, d.status, d.amount, r.sections.length, r.sections.map(s => s.title).filter(Boolean).join('; ')]);
    if (!reports.has(d.tax.k)) reports.set(d.tax.k, { tax: d.tax, cols: new Map(), rows: [] });
    const rep = reports.get(d.tax.k), vals = new Map();
    rep.rows.push({ d, vals });
    r.sections.forEach((s, si) => {
      const sec = s.title || ('Bölmə ' + (si + 1));
      if (s.fields.length) addRows(sheetFor(d.tax.k + '|f', `${d.tax.ab} - sahələr`, ['Dövr', 'Növ', 'Sənəd nömrəsi', 'Bölmə']), ['Sahə', 'Dəyər'], s.fields.map(f => [f[1], f[2]]), [...pre, sec]);
      s.tables.forEach(t => {
        const ct = t.coded || codedTable(t);
        if (ct) {
          t.rows.forEach(row => {
            const cd = t.coded ? { code: String(row[ct.cc]), label: '' } : codeOf(row[ct.cc]); if (!cd) return;
            const label = cd.label || (ct.lc > -1 ? String(row[ct.lc] || '').trim() : '');
            ct.vcols.forEach(c => {
              const key = [sec, t.title || '', cd.code, t.header[c] || ('Sütun ' + (c + 1))].join('\u0001');
              if (!rep.cols.has(key)) rep.cols.set(key, { sec: sec + (t.title ? ' / ' + t.title : ''), code: cd.code, label, col: t.header[c] || '' });
              else if (label && !rep.cols.get(key).label) rep.cols.get(key).label = label;
              const v = String(row[c] == null ? '' : row[c]).trim(); if (v) { vals.set(key, v); codedCells++; }
            });
          });
          rowsTotal += t.rows.length;
        } else { const sh = sheetFor(d.tax.k + '|' + sec, `${d.tax.ab} - ${sec}`, ['Dövr', 'Növ', 'Sənəd nömrəsi', 'Cədvəl']); addRows(sh, t.header, t.rows, [...pre, t.title || '']); rowsTotal += t.rows.length; }
      });
    });
  });
  if (yearNotes.length) yearNotes.forEach(n => notes.push(['Xəbərdarlıq', n.split(':')[0] + '-ci il', '', 'Bu ilin siyahısı açılmadı. Saytda ili əl ilə seçib yenidən başlat.']));
  if (unknownPeriod.length) notes.push(['Məlumat', '', '', 'Dövrü tanınmayan bəyannamələr keçildi: ' + [...new Set(unknownPeriod)].slice(0, 8).join('; ')]);
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan bəyannamələr fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...baseReport, rejim: apiMode ? 'api' : 'sehife', saniye: sec, oxundu: ok, xeta: err, kodluXana: codedCells, unvan: Object.fromEntries(Object.entries(tpl).map(([k, v]) => [taxOf(k.split('|')[1]).ab + ' ' + k.split('|')[2], v.replace(/\d{6,}/g, '#')])), oyrenme: learnNotes,
    bolmeQurulusu: sel.slice(0, 40).map((d, i) => results[i] && results[i].sections ? d.tax.ab + ': ' + results[i].sections.map(s => `${s.title || '?'}(${s.tables.length}c/${s.tables.reduce((a, t) => a + t.rows.length, 0)}s/${s.fields.length}f/${s.tables.filter(t => t.coded || codedTable(t)).length}k)`).join(', ') : null).filter(Boolean).slice(0, 12),
    xetalar: [...new Set(sel.map((d, i) => results[i] && results[i].error ? mask(results[i].error) : null).filter(Boolean))].slice(0, 5) } });

  const out = [];
  const META = ['Dövr', 'Növ', 'Sənəd nömrəsi', 'Tarix', 'Status'], M = META.length;
  for (const rep of reports.values()) {
    const cols = [...rep.cols.entries()];
    if (!cols.length) continue;
    const h1 = [...META], h2 = [...META.map(() => '')], h3 = [...META.map(() => '')], merges = [];
    META.forEach((_, c) => merges.push(`${colName(c)}1:${colName(c)}3`));
    cols.forEach(([, k]) => { h1.push(k.sec); h2.push(k.code + (k.label ? '. ' + k.label : '')); h3.push(k.col); });
    const runs = (row, from, same) => { let s = from; for (let c = from + 1; c <= row.length; c++) if (c === row.length || !same(s, c)) { if (c - 1 > s) merges.push(`${colName(s)}${row === h1 ? 1 : 2}:${colName(c - 1)}${row === h1 ? 1 : 2}`); s = c; } };
    runs(h1, M, (a, c) => h1[a] === h1[c]);
    runs(h2, M, (a, c) => h1[a] === h1[c] && h2[a] === h2[c]);
    const rows = rep.rows.map(({ d, vals }) => [d.period, d.type, d.docNo, d.date, d.status, ...cols.map(([key]) => vals.get(key) || '')]);
    const sum = rows.length ? cols.map(([key, k], j) => {
      if (/dərəcə|faiz/i.test(k.col) || /dərəcə|faiz/i.test(k.code) || /verginin dərəcəsi|faizlə/i.test(k.label)) return '';      // dərəcələr toplanmır
      let s = 0, any = false; rows.forEach(r => { const v = String(r[M + j] || '').trim(); if (/^-?[\d\s ]+(,\d+)?$/.test(v)) { s += parseFloat(v.replace(/[\s ]/g, '').replace(',', '.')); any = true; } });
      return any ? (Math.round(s * 100) / 100).toFixed(2).replace('.', ',') : '';
    }) : [];
    if (rows.length > 1) rows.push(['Cəmi', '', '', '', '', ...sum]);
    out.push({ name: uniq(`${rep.tax.ab} - hesabat`), heads: [h1, h2, h3], header: h3, rows, merges, numFrom: M, total: rows.length > 1, freezeCols: 1, maxW: 22, keep: true });
  }
  out.push({ name: 'Bəyannamələr', header: ['Vergi növü', 'Dövr', 'Növ', 'Sənəd nömrəsi', 'Tarix', 'Status', 'Məbləğ, manatla', 'Oxunan bölmə', 'Bölmələr'], rows: list, keep: true });
  for (const sh of sheets.values()) out.push({ name: sh.name, header: [...sh.base, ...sh.cols], rows: sh.rows });
  out.push({ name: 'Qeydlər', header: ['Növ', 'Bəyannamə', 'Sənəd nömrəsi', 'Qeyd'], rows: notes, numeric: false });
  await saveXlsx(`DataX-beyannameler-${from}_${to}.xlsx`, out);
  const bad = yearNotes.length ? `\n${yearNotes.map(n => n.split(':')[0]).join(', ')}-ci ilin siyahısı açılmadı.` : '';
  log((bad || err ? 'Natamam' : 'Hazırdır') + ` (${sec} san): ${ok} bəyannamə, ${out.length} vərəq.` + (err ? ` ${err} bəyannamə oxunmadı.` : '') + (bad || ' Fayl Yükləmələr qovluğundadır.'), true,
    { i: sel.length, n: sel.length, hasErrors: !!(err || bad), stats: [{ l: 'Bəyannamə', v: ok }, { l: 'Vərəq', v: out.length }, { l: 'Göstərici', v: codedCells }] });
}

// =====================================================================================
// Excel (.xlsx) faylı: başlıq sətri, avtomatik filtr, dondurulmuş başlıq. Kitabxanasız.
// =====================================================================================
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = u8 => { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC_T[(c ^ u8[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function zipStore(files) {
  const enc = new TextEncoder(), chunks = [], central = []; let offset = 0;
  for (const f of files) {
    const name = enc.encode(f.name), data = enc.encode(f.text), crc = crc32(data), n = data.length;
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(12, 0x21, true);
    lh.setUint32(14, crc, true); lh.setUint32(18, n, true); lh.setUint32(22, n, true); lh.setUint16(26, name.length, true);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(14, 0x21, true);
    ch.setUint32(16, crc, true); ch.setUint32(20, n, true); ch.setUint32(24, n, true); ch.setUint16(28, name.length, true); ch.setUint32(42, offset, true);
    chunks.push(new Uint8Array(lh.buffer), name, data); central.push(new Uint8Array(ch.buffer), name);
    offset += 30 + name.length + n;
  }
  const cdSize = central.reduce((s, c) => s + c.length, 0), end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
  const all = [...chunks, ...central, new Uint8Array(end.buffer)], out = new Uint8Array(all.reduce((s, c) => s + c.length, 0));
  let p = 0; for (const c of all) { out.set(c, p); p += c.length; }
  return out;
}
const xmlEsc = s => String(s == null ? '' : s).replace(/[^\x09\x0A\x0D\x20-퟿-�]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const colName = i => { let s = ''; for (i++; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + (i - 1) % 26) + s; return s; };
const NUMCOL = /məbləğ|qiymət|miqdar|həcm|ədv|aksiz|cəmi|yekun|yol vergisi/i, NUMVAL = /^-?\d[\d\s ]*(,\d+)?$/;
// sheets: [{ name, header: [..], rows: [[..]], numeric: true/false, heads: [[..],[..]] (çoxsətirli başlıq), merges: ['A1:C1'], numFrom: n (bu sütundan sonrakı rəqəmlər), total: true (son sətir qalın), maxW }]
const NUMDOT = /^-?\d{1,3}(,\d{3})*\.\d+$|^-?\d+\.\d+$/;
function makeXlsx(sheets) {
  const sheetXml = sh => {
    const heads = sh.heads || [sh.header], H = heads.length, top = heads[H - 1];
    const ncol = sh.rows.reduce((m, r) => Math.max(m, r.length), Math.max(...heads.map(h => h.length), 1));
    const isNum = Array.from({ length: ncol }, (_, c) => sh.numCols ? sh.numCols.includes(c) : sh.numFrom != null ? c >= sh.numFrom : sh.numeric !== false && NUMCOL.test(top[c] || ''));
    const intC = sh.intCols || [], fills = sh.fills || [];
    const maxW = sh.maxW || 60;
    const widths = Array.from({ length: ncol }, (_, c) => Math.min(maxW, Math.max(8, String(top[c] || '').length + 3, ...sh.rows.slice(0, 200).map(r => String(r[c] == null ? '' : r[c]).length + 2))));
    const num = s => NUMVAL.test(s) ? s.replace(/[\s ]/g, '').replace(',', '.') : NUMDOT.test(s) ? s.replace(/,/g, '') : null;
    const cell = (v, r, c, st) => {
      const f = st === 0 ? fills[r - H] : null; if (f === 'warn') st = 7; else if (f === 'risk') st = 9;
      const ref = colName(c) + (r + 1), s = String(v == null ? '' : v).trim(), sa = st ? ` s="${st}"` : '';
      if (st !== 1 && st !== 2 && isNum[c] && s.replace(/\D/g, '').length <= 15) { const n = num(s); if (n != null) { const ns = st === 3 ? 5 : st === 7 ? 8 : st === 9 ? 10 : intC.includes(c) ? 6 : sh.numFrom != null || sh.fmt2 ? 4 : st; return `<c r="${ref}"${ns ? ` s="${ns}"` : ''}><v>${n}</v></c>`; } }
      if (!s) return st === 1 || st === 2 || st === 7 || st === 9 ? `<c r="${ref}"${sa}/>` : '';
      return `<c r="${ref}" t="inlineStr"${sa}><is><t xml:space="preserve">${xmlEsc(s)}</t></is></c>`;
    };
    const all = [...heads, ...sh.rows], hs = H > 1 ? 2 : 1, lastRow = all.length;
    const rows = all.map((row, r) => {
      const st = r < H ? hs : (sh.total && r === lastRow - 1 ? 3 : 0), full = r < H ? Array.from({ length: ncol }, (_, i) => row[i]) : row;
      return `<row r="${r + 1}"${r < H && H > 1 ? ' ht="' + (r === H - 1 ? 64 : r === H - 2 ? 48 : 30) + '" customHeight="1"' : ''}>${full.map((v, c) => cell(v, r, c, st)).join('')}</row>`;
    }).join('');
    const last = colName(ncol - 1) + lastRow, xs = sh.freezeCols || 0;
    const pane = xs ? `<pane xSplit="${xs}" ySplit="${H}" topLeftCell="${colName(xs)}${H + 1}" activePane="bottomRight" state="frozen"/>` : `<pane ySplit="${H}" topLeftCell="A${H + 1}" activePane="bottomLeft" state="frozen"/>`;
    const merges = (sh.merges || []).length ? `<mergeCells count="${sh.merges.length}">${sh.merges.map(m => `<mergeCell ref="${m}"/>`).join('')}</mergeCells>` : '';
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      `<dimension ref="A1:${last}"/><sheetViews><sheetView workbookViewId="0">${pane}</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>` +
      `<cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${rows}</sheetData><autoFilter ref="A${H}:${colName(ncol - 1)}${sh.total ? lastRow - 1 : lastRow}"/>${merges}</worksheet>`;
  };
  const head = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
  const files = [
    { name: '[Content_Types].xml', text: head + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('') + '</Types>' },
    { name: '_rels/.rels', text: head + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
    { name: 'xl/workbook.xml', text: head + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + sheets.map((s, i) => `<sheet name="${xmlEsc(s.name.slice(0, 31))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('') + '</sheets></workbook>' },
    { name: 'xl/_rels/workbook.xml.rels', text: head + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('') + `<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', text: head + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="6"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F3B4D"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDCEFEA"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF0C7"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF9D5D0"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FF5B7385"/></left><right style="thin"><color rgb="FF5B7385"/></right><top style="thin"><color rgb="FF5B7385"/></top><bottom style="thin"><color rgb="FF5B7385"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="11"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="4" fontId="2" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="0" fillId="4" borderId="0" xfId="0" applyFill="1"/><xf numFmtId="4" fontId="0" fillId="4" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1"/><xf numFmtId="0" fontId="0" fillId="5" borderId="0" xfId="0" applyFill="1"/><xf numFmtId="4" fontId="0" fillId="5" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, text: sheetXml(s) }))
  ];
  return zipStore(files);
}
// group: 'job' (panel işi, varsayılan), başqa ad (səhifələr) və ya null — dərhal yüklə (istifadəçi özü «yüklə» basıb)
async function saveXlsx(filename, sheets, group = 'job') {
  const u8 = makeXlsx(sheets.filter(s => s && (s.rows.length || s.keep)));
  let bin = ''; for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
  if (capture) { capture.push({ filename, b64: btoa(bin) }); return; }
  if (!group) { await chrome.downloads.download({ url: `data:${XLSX_MIME};base64,` + btoa(bin), filename }); return; }
  await pendAdd(group, { name: filename, mime: XLSX_MIME, b64: btoa(bin) }, group !== 'job');
  if (group === 'job') jobFiles.push(filename);
}

importScripts('api.js');
