// Əvəzləşmə analizi: səhifənin idarəsi (fayl seçimi, sütunların yoxlanması, nəticə)
const $ = id => document.getElementById(id);
$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
chrome.runtime.sendMessage({ type: 'lic' }, r => { document.body.classList.toggle('nolic', !(r && r.ok)); });
const state = { inv: null, decl: null };
const fmt = v => (Math.round((v || 0) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const say = (msg, err, ok) => { const s = $('st'); s.textContent = msg; s.classList.toggle('err', !!err); s.classList.toggle('ok', !!ok); };

function setup(kind) {
  const drop = $('d-' + kind), input = drop.querySelector('input');
  const take = f => { if (f) load(kind, f); };
  input.onchange = () => take(input.files[0]);
  drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } };
  drop.ondragover = e => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); take(e.dataTransfer.files[0]); };
}
async function load(kind, file) {
  const info = $('i-' + kind); info.className = 'info'; info.textContent = 'Oxunur...'; $('m-' + kind).replaceChildren();
  state[kind] = null; refresh();
  try {
    const sheets = await readTable(file), k = kind === 'inv' ? 'inv' : 'decl', det = detect(sheets, k);
    if (!det) throw new Error('Faylda başlıq sətri tanınmadı: VÖEN, seriya/nömrə və ƏDV sütunları olmalıdır.');
    state[kind] = { file: file.name, sheets, si: det.si, hi: det.hi, header: det.header, map: det.map, rows: sheets[det.si].rows };
    $('d-' + kind).classList.add('done'); $('d-' + kind).querySelector('b').textContent = file.name;
    if (kind === 'inv') $('item').checked = det.map.item != null;
    renderMap(kind);
  } catch (e) { info.className = 'info err'; info.textContent = e.message; $('d-' + kind).classList.remove('done'); }
  refresh();
}
function renderMap(kind) {
  const s = state[kind], k = kind === 'inv' ? 'inv' : 'decl', F = FIELDS[k], box = $('m-' + kind), info = $('i-' + kind);
  const recs = recordsOf(s.rows, s.hi, s.map, k), miss = missing(s.map, k);
  info.className = 'info' + (miss.length ? ' err' : '');
  info.innerHTML = '';
  const t = document.createElement('span'); t.className = miss.length ? '' : 'ok';
  t.textContent = miss.length ? 'Tapılmayan sütun: ' + miss.join(', ') + '. Aşağıdan seç.' : `✓ ${recs.length} sətir tanındı`;
  info.append(t, document.createTextNode(` · vərəq "${s.sheets[s.si].name}", başlıq ${s.hi + 1}-ci sətirdə`));
  box.replaceChildren();
  if (s.sheets.length > 1) {
    const w = document.createElement('div'), sel = document.createElement('select'); w.className = 'sheet'; w.append('Vərəq:');
    s.sheets.forEach((sh, i) => sel.add(new Option(sh.name, i, false, i === s.si)));
    sel.onchange = () => { const i = +sel.value, hi = findHeader(s.sheets[i].rows, k); Object.assign(s, { si: i, rows: s.sheets[i].rows, hi: Math.max(0, hi) });
      s.header = (s.rows[s.hi] || []).map(x => String(x == null ? '' : x).trim()); s.map = autoMap(s.header, k, s.rows, s.hi); renderMap(kind); refresh(); };
    w.append(sel); box.append(w);
  }
  const d = document.createElement('details'); d.className = 'map'; if (miss.length) d.open = true;
  d.innerHTML = '<summary>Sütunları yoxla</summary>';
  const g = document.createElement('div'); g.className = 'grid';
  Object.entries(F).forEach(([key, f]) => {
    const l = document.createElement('label'), sel = document.createElement('select'); l.textContent = f.l;
    sel.add(new Option('— yoxdur —', ''));
    s.header.forEach((h, c) => { const sample = (s.rows[s.hi + 1] || [])[c]; sel.add(new Option(`${h || 'Sütun ' + (c + 1)}${sample !== undefined && sample !== '' ? '  ·  ' + String(sample).slice(0, 24) : ''}`, c, false, s.map[key] === c)); });
    sel.onchange = () => { if (sel.value === '') delete s.map[key]; else s.map[key] = +sel.value; renderMap(kind); refresh(); };
    l.htmlFor = sel.id = `${kind}-${key}`; g.append(l, sel);
  });
  d.append(g); box.append(d);
}
function refresh() {
  const ok = ['inv', 'decl'].every(k => state[k] && !missing(state[k].map, k === 'inv' ? 'inv' : 'decl').length);
  $('go').disabled = !ok;
  if (!state.inv || !state.decl) say('Hər iki faylı seç.'); else if (!ok) say('Tapılmayan sütunları seç.', true); else say('Hazırdır: "Analiz et" düyməsini bas.');
}
setup('inv'); setup('decl');

$('go').onclick = async () => {
  $('go').disabled = true; say('Analiz edilir...');
  try {
    const tol = Math.max(0, parseFloat(String($('tol').value).replace(',', '.')) || 0), itemLevel = $('item').checked;
    const inv = recordsOf(state.inv.rows, state.inv.hi, state.inv.map, 'inv'), decl = recordsOf(state.decl.rows, state.decl.hi, state.decl.map, 'decl');
    if (!inv.length) throw new Error('Daxil olanlar faylında qaimə sətri tapılmadı.');
    if (!decl.length) throw new Error('Əvəzləşmə faylında qaimə sətri tapılmadı.');
    const res = analyze(inv, decl, { tol, itemLevel });
    const now = new Date(), when = now.toLocaleString('az-AZ');
    const sheets = buildSheets(res, { inv: { header: state.inv.header, rows: state.inv.rows, hi: state.inv.hi, map: state.inv.map }, itemLevel,
      invName: state.inv.file, invSheet: state.inv.sheets[state.inv.si].name, declName: state.decl.file, declSheet: state.decl.sheets[state.decl.si].name, tol, when });
    const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
    const r = await chrome.runtime.sendMessage({ type: 'xlsx', filename: `DataX-evezlesme-analizi-${stamp}.xlsx`, sheets });
    if (!r || !r.ok) throw new Error((r && r.error) || 'Fayl yaradılmadı.');
    const act = [...res.full, ...res.part, ...res.none, ...res.over], vat = act.reduce((a, x) => a + x.vat, 0), off = act.reduce((a, x) => a + x.off, 0);
    const risk = res.mism.filter(m => m.risk === 'Yüksək').length + res.ctrl.filter(m => m.risk === 'Yüksək').length;
    const tiles = [['Qaimə', act.length, fmt(vat) + ' ƏDV'], ['Tam', res.full.length, ''], ['Qismən', res.part.length, fmt(res.part.reduce((a, x) => a + x.diff, 0)) + ' qalıq'],
      ['Əvəzləşməyən', res.none.length, fmt(res.none.reduce((a, x) => a + x.vat, 0))], ['Uyğunsuz', res.mism.length, risk + ' yüksək risk', risk > 0], ['Əvəzləşmə', (vat ? Math.round(off / vat * 1000) / 10 : 0).toString().replace('.', ',') + '%', fmt(off)]];
    $('tiles').replaceChildren(...tiles.map(([l, v, s, red]) => { const d = document.createElement('div'); if (red) d.className = 'r'; d.innerHTML = '<b></b><span></span><small></small>'; d.children[0].textContent = v; d.children[1].textContent = l; d.children[2].textContent = s; return d; }));
    $('tiles').style.display = 'grid'; $('legend').style.display = 'block';
    say(`Hazırdır: ${act.length} qaimə tutuşduruldu. Excel faylı Yükləmələr qovluğundadır.`, false, true);
  } catch (e) { say('Xəta: ' + e.message, true); }
  $('go').disabled = false;
};
