// DataX Advisory — Əvəzləşmə analizi: Excel oxuma, sütunların tanınması, müqayisə və nəticə vərəqləri.
// Saf funksiyalar: brauzerdə (analiz.html) və sınaqda eyni kod işləyir.
'use strict';
const AZ_MONTHS = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avqust', 'sentyabr', 'oktyabr', 'noyabr', 'dekabr'];
const low = s => String(s == null ? '' : s).toLocaleLowerCase('az').replace(/\s+/g, ' ').trim();

// ---------------- ZIP / XLSX / CSV oxuma ----------------
async function unzip(buf) {
  const u8 = new Uint8Array(buf), dv = new DataView(buf instanceof ArrayBuffer ? buf : u8.buffer);
  let e = -1; for (let i = u8.length - 22; i >= Math.max(0, u8.length - 66000); i--) if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('Fayl Excel (.xlsx) deyil və ya zədəlidir.');
  const n = dv.getUint16(e + 10, true), dec = new TextDecoder(); let p = dv.getUint32(e + 16, true); const out = {};
  for (let k = 0; k < n; k++) {
    if (dv.getUint32(p, true) !== 0x02014b50) break;
    const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), lh = dv.getUint32(p + 42, true);
    const name = dec.decode(u8.subarray(p + 46, p + 46 + nl)); p += 46 + nl + xl + cl;
    out[name] = { method, start: lh + 30 + dv.getUint16(lh + 26, true) + dv.getUint16(lh + 28, true), csize };
  }
  const read = async name => {
    const f = out[name]; if (!f) return null;
    const data = u8.subarray(f.start, f.start + f.csize);
    if (f.method === 0) return dec.decode(data);
    const s = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return dec.decode(new Uint8Array(await new Response(s).arrayBuffer()));
  };
  return { names: Object.keys(out), read };
}
const xmlDoc = s => new DOMParser().parseFromString(s, 'application/xml');
const tags = (node, name) => Array.from(node.getElementsByTagName(name));
const colIdx = ref => { const m = /^([A-Z]+)/.exec(ref || ''); if (!m) return -1; let n = 0; for (const ch of m[1]) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
const DATE_IDS = new Set([14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 46, 47]);
const serialToDmy = v => { const d = new Date(Math.round((v - 25569) * 86400000)); return `${String(d.getUTCDate()).padStart(2, '0')}.${String(d.getUTCMonth() + 1).padStart(2, '0')}.${d.getUTCFullYear()}`; };
// Bütün vərəqlər: [{ name, rows: [[...]] }]
async function readXlsx(buf) {
  const z = await unzip(buf);
  const wb = xmlDoc(await z.read('xl/workbook.xml') || '<x/>'), rels = xmlDoc(await z.read('xl/_rels/workbook.xml.rels') || '<x/>');
  const relMap = {}; tags(rels, 'Relationship').forEach(r => { relMap[r.getAttribute('Id')] = r.getAttribute('Target'); });
  const ssXml = await z.read('xl/sharedStrings.xml'), ss = ssXml ? tags(xmlDoc(ssXml), 'si').map(si => tags(si, 't').map(t => t.textContent).join('')) : [];
  const stXml = await z.read('xl/styles.xml'), dateXf = [];
  if (stXml) {
    const st = xmlDoc(stXml), custom = {};
    tags(st, 'numFmt').forEach(f => { custom[f.getAttribute('numFmtId')] = f.getAttribute('formatCode') || ''; });
    const cx = st.getElementsByTagName('cellXfs')[0];
    if (cx) tags(cx, 'xf').forEach((x, i) => { const id = +x.getAttribute('numFmtId'); const code = (custom[id] || '').replace(/"[^"]*"|\[[^\]]*\]/g, ''); dateXf[i] = DATE_IDS.has(id) || (/[dy]/i.test(code) && /m/i.test(code)); });
  }
  const sheets = [];
  for (const s of tags(wb, 'sheet')) {
    const rid = s.getAttribute('r:id') || s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id');
    let target = relMap[rid] || ''; target = target.startsWith('/') ? target.slice(1) : 'xl/' + target.replace(/^\.\//, '');
    const xml = await z.read(target); if (!xml) continue;
    const doc = xmlDoc(xml), rows = [];
    tags(doc, 'row').forEach(r => {
      const ri = +r.getAttribute('r') - 1 || rows.length, row = [];
      tags(r, 'c').forEach((c, k) => {
        const ci = c.getAttribute('r') ? colIdx(c.getAttribute('r')) : k, t = c.getAttribute('t'), v = c.getElementsByTagName('v')[0], sIdx = +c.getAttribute('s') || 0;
        let val = '';
        if (t === 's') val = v ? ss[+v.textContent] || '' : '';
        else if (t === 'inlineStr') val = tags(c, 't').map(x => x.textContent).join('');
        else if (t === 'b') val = v ? (v.textContent === '1' ? 'TRUE' : 'FALSE') : '';
        else if (t === 'str' || t === 'e') val = v ? v.textContent : '';
        else if (v) { const n = +v.textContent; val = isNaN(n) ? v.textContent : dateXf[sIdx] && n > 20000 && n < 80000 ? serialToDmy(n) : n; }
        row[ci] = val;
      });
      rows[ri] = Array.from(row, x => x === undefined ? '' : x);
    });
    sheets.push({ name: s.getAttribute('name'), rows: Array.from(rows, x => x || []) });
  }
  return sheets;
}
function readCsv(text) {
  text = text.replace(/^﻿/, '');
  const first = text.split(/\r?\n/)[0] || '', d = [';', '\t', ','].sort((a, b) => first.split(b).length - first.split(a).length)[0];
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
    else if (ch === '"') q = true; else if (ch === d) { row.push(cur); cur = ''; }
    else if (ch === '\n') { row.push(cur.replace(/\r$/, '')); rows.push(row); row = []; cur = ''; } else cur += ch;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return [{ name: 'CSV', rows }];
}
async function readTable(file) {
  const name = file.name || '', buf = await file.arrayBuffer();
  if (/\.csv$|\.txt$/i.test(name)) return readCsv(new TextDecoder().decode(buf));
  if (/\.xls$/i.test(name) && new Uint8Array(buf)[0] === 0xD0) throw new Error('Köhnə .xls formatıdır. Faylı Excel-də açıb "Farklı saxla → Excel iş kitabı (.xlsx)" ilə saxla və yenidən seç.');
  return readXlsx(buf);
}

// ---------------- Sütunların tanınması ----------------
// Hər sahə: uyğun (+bal), üstünlük (+2), istisna
const FIELDS = {
  inv: {
    voen: { l: 'Təchizatçının VÖEN-i', m: /vöen|voen|vön/, p: /satıcı|göndərən|təchizatçı|təqdim edən|vöen\/ad/, x: /alıcı|qəbul edən/ },
    name: { l: 'Təchizatçının adı', m: /ad[ıi]\b|adı|təchizatçı|satıcı|göndərən|tərəf|vöen\/ad/, p: /satıcı|göndərən|təchizatçı|adı$/, x: /mal|məhsul|xidmət|təsnifat|alıcı|ölçü/ },
    serial: { l: 'Seriya və nömrə (birlikdə)', m: /seriya.*nömrə|seriya\/nömrə|qaimə.*nömrə/, x: /sıra/ },
    series: { l: 'Seriya', m: /seriya/, x: /nömrə/ },
    number: { l: 'Nömrə', m: /nömrə|№/, x: /seriya|sıra|sənəd nömrəsi|qeydiyyat|bəyannamə|telefon|hesab|barkod/ },
    date: { l: 'Tarix', m: /tarix/, p: /imzalanma|qaimə|yaradılma|təqdim/, x: /bəyannamə|dəqiq/ },
    base: { l: 'Vergi tutulan məbləğ', m: /vergi tutulan|ədv-?siz|ədv-yə 18|18% cəlb|cəlb edilən|cəmi məbləğ|ümumi məbləğ|dəyər/, p: /vergi tutulan|ədv-?siz|18/, x: /yekun|ödənilmiş|ədv məbləği|cəlb edilməyən|azad|0%|aksiz|yol/ },
    vat: { l: 'ƏDV məbləği', m: /ədv|vat/, p: /ədv məbləği|^ədv$/, x: /ədv-?siz|cəlb|azad|0%|18%|ödənilmiş|dərəcə|depozit|qaytarıl/ },
    total: { l: 'Yekun məbləğ', m: /yekun|ümumi məbləğ$|cəmi$/, x: /ədv-?siz|ödənilmiş/ },
    status: { l: 'Status', m: /status|vəziyyət/ },
    item: { l: 'Mal sətri (varsa)', m: /malın kodu|malın adı|mal\/xidmət|məhsulun/ }
  },
  decl: {
    voen: { l: 'Satıcının VÖEN-i', m: /vöen|voen/, p: /satıcı/ },
    series: { l: 'Qaimənin seriyası', m: /seriya/, x: /nömrə/ },
    number: { l: 'Qaimənin nömrəsi', m: /nömrə|№/, x: /seriya|sıra|sənəd nömrəsi|qeydiyyat|bəyannamə/ },
    serial: { l: 'Seriya və nömrə (birlikdə)', m: /seriya.*nömrə|seriya\/nömrə/ },
    date: { l: 'Qaimənin tarixi', m: /tarix/, p: /qaimə/, x: /bəyannamə|qeydiyyat/ },
    base: { l: 'Ümumi məbləğ (ƏDV-siz)', m: /ümumi məbləğ|ədv-?siz|vergi tutulan|məbləğ/, p: /ədv-?siz|ümumi/, x: /ödənilmiş|ədv məbləği/ },
    vat: { l: 'ƏDV məbləği', m: /ədv/, p: /ədv məbləği/, x: /ödənilmiş|ədv-?siz/ },
    paid: { l: 'Ödənilmiş (əvəzləşdirilən) ƏDV', m: /ödənilmiş.*ədv|əvəzləşdiril.*ədv/ },
    period: { l: 'Dövr', m: /^dövr|hesabat dövrü/ },
    declNo: { l: 'Bəyannamənin nömrəsi', m: /sənəd nömrəsi|qeydiyyat nömrəsi|bəyannamə.*nömrə/ },
    declType: { l: 'Bəyannamənin növü', m: /^növ$|bəyannamə növü/ }
  }
};
function scoreCol(f, h) { const s = low(h); if (!s || !f.m.test(s)) return -1; if (f.x && f.x.test(s)) return -1; return 1 + (f.p && f.p.test(s) ? 2 : 0) + (s.length < 40 ? 0.5 : 0); }
// Başlıq sətri: ilk 20 sətirdən ən çox sahə tanınan
function findHeader(rows, kind) {
  const F = FIELDS[kind]; let best = { i: -1, s: 0 };
  rows.slice(0, 20).forEach((r, i) => { const s = Object.values(F).filter(f => (r || []).some(h => scoreCol(f, h) > 0)).length; if (s > best.s) best = { i, s }; });
  return best.s >= 3 ? best.i : -1;
}
function autoMap(header, kind) {
  const F = FIELDS[kind], cand = [];
  Object.entries(F).forEach(([k, f]) => header.forEach((h, c) => { const s = scoreCol(f, h); if (s > 0) cand.push({ k, c, s }); }));
  cand.sort((a, b) => b.s - a.s || a.c - b.c);
  const map = {}, used = new Set();
  cand.forEach(({ k, c }) => { if (map[k] == null && !used.has(c)) { map[k] = c; used.add(c); } });
  if (map.serial != null && map.series != null && map.number != null) delete map.serial;
  // "VÖEN/Adı" kimi birləşmiş sütun: ad üçün də eyni sütun
  if (map.voen != null && map.name == null && /ad/.test(low(header[map.voen]))) map.name = map.voen;
  return map;
}
// Ən uyğun vərəq və başlıq
function detect(sheets, kind) {
  let best = null;
  sheets.forEach((sh, si) => { const hi = findHeader(sh.rows, kind); if (hi < 0) return; const header = sh.rows[hi].map(x => String(x == null ? '' : x).trim()); const map = autoMap(header, kind);
    const need = kind === 'inv' ? ['voen', 'vat'] : ['voen', 'vat']; const ok = need.every(k => map[k] != null) && (map.serial != null || (map.series != null && map.number != null));
    const sc = Object.keys(map).length + (ok ? 10 : 0) + (kind === 'decl' && /əlavə 1/i.test(sh.name) ? 3 : 0);
    if (!best || sc > best.sc) best = { si, hi, header, map, sc, ok }; });
  return best;
}
function missing(map, kind) {
  const m = [];
  if (map.voen == null) m.push(FIELDS[kind].voen.l);
  if (map.serial == null && (map.series == null || map.number == null)) m.push('Seriya və nömrə');
  if (map.vat == null && !(kind === 'decl' && map.paid != null)) m.push('ƏDV məbləği');
  return m;
}

// ---------------- Normallaşdırma ----------------
const CYR = { 'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O', 'Р': 'P', 'С': 'C', 'Т': 'T', 'Х': 'X', 'У': 'Y' };
const normSer = s => String(s == null ? '' : s).toUpperCase().replace(/[АВЕКМНОРСТХУ]/g, c => CYR[c]).replace(/[^A-Z0-9]/g, '');
const normVoen = s => { const d = String(s == null ? '' : s).replace(/\.0+$/, '').replace(/\D/g, ''); return d.length === 9 ? '0' + d : d; };
function num(v) {
  if (typeof v === 'number') return v;
  let s = String(v == null ? '' : v).replace(/[\s ₼]|AZN|manat/gi, ''); if (!s) return null;
  if (/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, '');
  else s = s.replace(',', '.');
  const n = parseFloat(s); return isNaN(n) ? null : n;
}
const r2 = v => Math.round((v || 0) * 100) / 100;
// Tarix → { t: 20251003, s: '03.10.2025' }
function toDate(v) {
  if (typeof v === 'number' && v > 20000 && v < 80000) v = serialToDmy(v);
  const s = String(v == null ? '' : v).trim();
  let m = s.match(/(\d{1,2})[./-](\d{1,2})[./-](\d{4})/); if (m) return { t: +m[3] * 10000 + +m[2] * 100 + +m[1], s: `${m[1].padStart(2, '0')}.${m[2].padStart(2, '0')}.${m[3]}` };
  m = s.match(/(\d{4})-(\d{2})-(\d{2})/); if (m) return { t: +(m[1] + m[2] + m[3]), s: `${m[3]}.${m[2]}.${m[1]}` };
  return { t: 0, s };
}
// "Oktyabr 2025" → 202510
function periodYm(p) { const l = low(p), y = (l.match(/(20\d{2})/) || [])[1]; if (!y) return 0; const mi = AZ_MONTHS.findIndex(m => l.includes(m)); return mi < 0 ? 0 : +y * 100 + mi + 1; }
// seriya + nömrə: "MT2511" + "10535518"; birlikdə "MT251110535518"
function splitSerial(full) { const s = normSer(full), m = s.match(/^([A-Z]{2}\d{4})(\d+)$/); return m ? { series: m[1], number: m[2] } : { series: '', number: s }; }
function joinSerial(series, number) {
  const se = normSer(series); let no = normSer(typeof number === 'number' ? Math.round(number) : number);
  if (/^[A-Z]{2}\d{4}$/.test(se) && /^\d+$/.test(no) && no.length < 8) no = no.padStart(8, '0');
  return { series: se, number: no, full: se + no };
}
const CANCEL = /ləğv|silin|passiv|deactiv|cancel|delet/i;

// Sətirləri qaimə qeydlərinə çevirir
function recordsOf(rows, hi, map, kind) {
  const recs = [], get = (r, k) => map[k] == null ? '' : r[map[k]];
  for (let i = hi + 1; i < rows.length; i++) {
    const r = rows[i] || []; if (!r.some(x => String(x == null ? '' : x).trim())) continue;
    let voenRaw = get(r, 'voen'), name = map.name != null && map.name !== map.voen ? String(get(r, 'name') || '').trim() : '';
    const vm = String(voenRaw || '').match(/^\s*(\d{9,10})\s*[\/|-]\s*(.+)$/); if (vm) { voenRaw = vm[1]; if (!name) name = vm[2].trim(); }
    const ser = map.serial != null ? splitSerial(get(r, 'serial')) : null, j = ser ? joinSerial(ser.series, ser.number) : joinSerial(get(r, 'series'), get(r, 'number'));
    const voen = normVoen(voenRaw);
    if (!voen && !j.full) continue;
    if (/^(cəmi|yekun|total)/i.test(String(r[0] || '').trim()) && !j.full) continue;
    const d = toDate(get(r, 'date'));
    recs.push({ row: i, voen, name, series: j.series, number: j.number, key: voen + '|' + j.full, serial: j.full, date: d.s, dt: d.t,
      base: num(get(r, 'base')), vat: num(get(r, 'vat')), total: num(get(r, 'total')), status: String(get(r, 'status') || '').trim(),
      paid: kind === 'decl' ? num(get(r, 'paid')) : null, period: String(get(r, 'period') || '').trim(), declNo: String(get(r, 'declNo') || '').trim(), declType: String(get(r, 'declType') || '').trim() });
  }
  return recs;
}

// ---------------- Müqayisə ----------------
function analyze(inv, decl, opt = {}) {
  const tol = opt.tol == null ? 0.05 : opt.tol, itemLevel = !!opt.itemLevel;
  // 1) Daxil olanlar: unikal qaimələr (mal sətirlərindən ibarət fayl cəmlənir)
  const invMap = new Map(), dupInv = [];
  inv.forEach(r => {
    const e = invMap.get(r.key);
    if (!e) { invMap.set(r.key, { ...r, rows: [r.row], n: 1 }); return; }
    if (itemLevel) { e.rows.push(r.row); ['base', 'vat', 'total'].forEach(k => { if (r[k] != null) e[k] = (e[k] || 0) + r[k]; }); e.n++; }
    else { e.rows.push(r.row); dupInv.push(r); }
  });
  invMap.forEach(e => { if (e.base == null && e.total != null && e.vat != null) e.base = e.total - e.vat; });
  // 2) Bəyannamə (Əlavə 1): qaimə üzrə cəm, dövrlər
  const dMap = new Map(), dupDecl = [];
  decl.forEach(r => {
    const off = r.paid != null ? r.paid : (r.vat || 0);
    let e = dMap.get(r.key);
    if (!e) { e = { key: r.key, voen: r.voen, series: r.series, number: r.number, serial: r.serial, date: r.date, dt: r.dt, vat: r.vat, base: r.base, paid: 0, periods: [], rows: [], seen: new Map() }; dMap.set(r.key, e); }
    e.paid += off || 0; e.rows.push(r);
    if (r.vat != null && (e.vat == null || r.vat > e.vat)) e.vat = r.vat;
    if (r.base != null && (e.base == null || r.base > e.base)) e.base = r.base;
    const pk = (r.period || '') + '|' + (r.declNo || '');
    if (e.seen.has(pk)) dupDecl.push(r); else e.seen.set(pk, 1);
    if (r.period && !e.periods.includes(r.period)) e.periods.push(r.period);
  });
  const bySerial = new Map(), byVoenNo = new Map(), byVoenVat = new Map();
  dMap.forEach(e => {
    (bySerial.get(e.serial) || bySerial.set(e.serial, []).get(e.serial)).push(e);
    const k2 = e.voen + '|' + e.number; (byVoenNo.get(k2) || byVoenNo.set(k2, []).get(k2)).push(e);
    const k3 = e.voen + '|' + r2(e.vat) + '|' + e.dt; (byVoenVat.get(k3) || byVoenVat.set(k3, []).get(k3)).push(e);
  });
  const dates = [...invMap.values()].map(e => e.dt).filter(Boolean), dMin = dates.length ? Math.min(...dates) : 0, dMax = dates.length ? Math.max(...dates) : 0;
  const res = { full: [], part: [], none: [], over: [], cancelled: [], mism: [], ctrl: [], invRows: new Map(), suppliers: new Map(), dMin, dMax };
  const linked = new Set();
  const addM = (risk, type, o) => res.mism.push({ risk, type, ...o });
  const addC = (risk, type, o) => res.ctrl.push({ risk, type, ...o });
  invMap.forEach(e => {
    const d = dMap.get(e.key), vat = e.vat || 0, cancelled = CANCEL.test(e.status);
    const rec = { inv: e, d, vat, off: d ? d.paid : 0, periods: d ? d.periods.join(', ') : '', note: [], flag: null, cat: '' };
    rec.diff = r2(vat - rec.off); rec.pct = vat ? Math.round(rec.off / vat * 10000) / 100 : (rec.off ? 100 : 0);
    if (d) linked.add(d.key);
    if (cancelled) {
      rec.cat = 'Ləğv/silinmiş (hesablamaya daxil edilmədi)'; res.cancelled.push(rec);
      if (d) { rec.flag = 'risk'; rec.note.push('Ləğv edilmiş/silinmiş qaimə əvəzləşdirilib'); addC('Yüksək', 'Ləğv edilmiş qaimə əvəzləşdirilib', { src: 'Hər ikisi', e, d, inv: vat, dec: d.paid, why: `Status: ${e.status}` }); }
    } else if (!d) {
      rec.cat = 'Əvəzləşməyən';
      // Şübhəli uyğunluq: eyni seriya/nömrə başqa VÖEN-lə; eyni VÖEN + nömrə, başqa seriya; eyni VÖEN + ƏDV + tarix
      const s1 = (bySerial.get(e.serial) || []).filter(x => x.voen !== e.voen), s2 = (byVoenNo.get(e.voen + '|' + e.number) || []).filter(x => x.serial !== e.serial),
        s3 = e.dt ? (byVoenVat.get(e.voen + '|' + r2(e.vat) + '|' + e.dt) || []).filter(x => x.serial !== e.serial && !s2.includes(x)) : [];
      const sus = [...s1.map(x => [x, 'VÖEN fərqlidir', `Bəyannamədə eyni seriya/nömrə VÖEN ${x.voen} ilə göstərilib`]),
        ...s2.map(x => [x, 'Seriya fərqlidir', `Bəyannamədə eyni nömrə ${x.series} seriyası ilə göstərilib`]),
        ...s3.map(x => [x, 'Seriya/nömrə fərqlidir (ehtimal)', `Eyni VÖEN, tarix və ƏDV; bəyannamədə ${x.serial}`])];
      sus.forEach(([x, type, why]) => { linked.add(x.key); x.sus = true; addM(type === 'VÖEN fərqlidir' ? 'Yüksək' : 'Orta', type, { e, d: x, inv: vat, dec: x.paid, why }); });
      if (sus.length) { rec.flag = 'warn'; rec.note.push('Şübhəli uyğunluq: ' + sus.map(s => s[0].serial + ' (' + s[1] + ')').join('; ')); }
      res.none.push(rec);
    } else {
      if (Math.abs(rec.diff) <= tol) { rec.cat = 'Tam əvəzləşən'; res.full.push(rec); }
      else if (rec.diff > tol) { rec.cat = rec.off > tol ? 'Qismən əvəzləşən' : 'Əvəzləşməyən'; (rec.off > tol ? res.part : res.none).push(rec); if (rec.off <= tol) rec.note.push('Bəyannamədə var, ödənilmiş ƏDV sıfırdır'); }
      else { rec.cat = 'Artıq əvəzləşdirilib'; rec.flag = 'risk'; res.over.push(rec); rec.note.push(`Qaimədəki ƏDV-dən ${r2(-rec.diff)} AZN çox əvəzləşdirilib`); addM('Yüksək', 'Artıq əvəzləşdirilib', { e, d, inv: vat, dec: d.paid, why: rec.note[rec.note.length - 1] }); }
      if (d.vat != null && Math.abs((d.vat || 0) - vat) > tol) { rec.flag = rec.flag || 'warn'; rec.note.push('Bəyannamədəki qaimə ƏDV-si fərqlidir: ' + r2(d.vat)); addM('Orta', 'ƏDV məbləği fərqlidir', { e, d, inv: vat, dec: d.vat, why: 'Qaimə üzrə ƏDV siyahıda və bəyannamədə fərqlidir' }); }
      if (d.base != null && e.base != null && Math.abs(d.base - e.base) > Math.max(tol, 0.05)) { rec.flag = rec.flag || 'warn'; rec.note.push('Vergi tutulan məbləğ fərqlidir: ' + r2(d.base)); addM('Orta', 'Vergi tutulan məbləğ fərqlidir', { e, d, inv: vat, dec: d.paid, why: `Siyahıda ${r2(e.base)}, bəyannamədə ${r2(d.base)}` }); }
      if (d.dt && e.dt && d.dt !== e.dt) { rec.note.push('Tarix fərqlidir: ' + d.date); addM('Aşağı', 'Tarix fərqlidir', { e, d, inv: vat, dec: d.paid, why: `Siyahıda ${e.date}, bəyannamədə ${d.date}` }); }
      // Qaimə tarixindən əvvəlki dövrdə əvəzləşmə
      const early = d.rows.filter(r => { const p = periodYm(r.period); return p && e.dt && p < Math.floor(e.dt / 100); });
      if (early.length) { rec.flag = 'risk'; rec.note.push('Qaimə tarixindən əvvəlki dövrdə əvəzləşdirilib'); addC('Yüksək', 'Qaimə tarixindən əvvəlki dövrdə əvəzləşdirilib', { src: 'Bəyannamə', e, d, inv: vat, dec: d.paid, why: 'Dövr: ' + early.map(r => r.period).join(', ') }); }
      if (d.periods.length > 1) addC('Aşağı', 'Bir neçə dövrdə əvəzləşdirilib', { src: 'Bəyannamə', e, d, inv: vat, dec: d.paid, why: 'Dövrlər: ' + d.periods.join(', ') });
    }
    res.invRows.set(e.key, rec);
    const sk = e.voen; let s = res.suppliers.get(sk);
    if (!s) res.suppliers.set(sk, s = { voen: e.voen, name: e.name, n: 0, vat: 0, off: 0, rest: 0, full: 0, part: 0, none: 0, mism: 0 });
    if (!s.name && e.name) s.name = e.name;
    if (!cancelled) { s.n++; s.vat += vat; s.off += rec.off; s.rest += Math.max(0, rec.diff); if (rec.cat === 'Tam əvəzləşən') s.full++; else if (rec.cat === 'Qismən əvəzləşən') s.part++; else if (rec.cat === 'Əvəzləşməyən') s.none++; if (rec.flag) s.mism++; }
  });
  // Bəyannamədə olub siyahıda olmayan
  res.declOnly = [];
  dMap.forEach(d => {
    if (linked.has(d.key)) return;
    const inRange = d.dt && dMin && d.dt >= dMin && d.dt <= dMax;
    res.declOnly.push(d);
    addM(inRange ? 'Yüksək' : 'Orta', 'Bəyannamədə var, siyahıda yoxdur', { d, dec: d.paid, why: inRange ? 'Qaimə tarixi siyahının dövrünə düşür, amma daxil olanlar siyahısında yoxdur' : 'Qaimə tarixi siyahının tarix aralığından kənardadır (əvvəlki dövrün qaiməsi ola bilər)' });
  });
  dupInv.forEach(r => addC('Orta', 'Siyahıda təkrar qaimə', { src: 'Daxil olanlar', e: r, inv: r.vat, why: `Sətir ${r.row + 1}: eyni VÖEN, seriya və nömrə təkrarlanır` }));
  dupDecl.forEach(r => addC('Yüksək', 'Eyni bəyannamədə təkrar qaimə', { src: 'Bəyannamə', d: r, dec: r.paid != null ? r.paid : r.vat, why: `Dövr ${r.period || '?'}: qaimə iki dəfə göstərilib (ikiqat əvəzləşmə riski)` }));
  res.invCount = invMap.size; res.declCount = dMap.size; res.dupInv = dupInv.length; res.dupDecl = dupDecl.length;
  res.declPaidTotal = decl.reduce((a, r) => a + (r.paid != null ? r.paid : (r.vat || 0)), 0);
  res.periods = new Map(); decl.forEach(r => { const p = r.period || '(dövr yoxdur)'; const x = res.periods.get(p) || { n: 0, paid: 0, ym: periodYm(p) }; x.n++; x.paid += r.paid != null ? r.paid : (r.vat || 0); res.periods.set(p, x); });
  return res;
}

// ---------------- Nəticə vərəqləri ----------------
const RISK_ORDER = { 'Yüksək': 0, 'Orta': 1, 'Aşağı': 2 };
function buildSheets(res, src) {
  const n = v => v == null || v === '' || isNaN(v) ? '' : String(r2(v));
  const STD = ['Təchizatçının adı', 'VÖEN', 'Tarix', 'Seriya', 'Nömrə', 'Vergi tutulan məbləğ', 'Qaimə üzrə ƏDV', 'Bəyannamədə əks olunan ƏDV', 'Fərq', 'Əvəzləşmə, %', 'Əvəzləşdirildiyi dövr(lər)', 'Qeyd'];
  const stdRow = r => [r.inv.name, r.inv.voen, r.inv.date, r.inv.series, r.inv.number, n(r.inv.base), n(r.vat), n(r.off), n(r.diff), n(r.pct), r.periods, r.note.join('; ')];
  const totalRow = (rows, cols) => { const t = Array(rows[0] ? rows[0].length : 0).fill(''); t[0] = 'Cəmi'; cols.forEach(c => { t[c] = String(r2(rows.reduce((a, x) => a + (+x[c] || 0), 0))); }); return t; };
  const stdSheet = (name, recs, diffName) => {
    const sorted = [...recs].sort((a, b) => (a.inv.dt - b.inv.dt) || a.inv.serial.localeCompare(b.inv.serial)), rows = sorted.map(stdRow), fills = sorted.map(r => r.flag);
    if (rows.length > 1) rows.push(totalRow(rows, [5, 6, 7, 8]));
    const header = [...STD]; if (diffName) header[8] = diffName;
    return { name, header, rows, fills, numCols: [5, 6, 7, 8, 9], fmt2: true, total: rows.length > 1, keep: true, maxW: 40 };
  };
  // 1. Daxil Olanlar: ilkin sütunlar olduğu kimi + nəticə sütunları
  const H = src.inv.header, extra = ['Nəticə', 'Əvəzləşdirilmiş ƏDV', 'Fərq', 'Qeyd'];
  const rowRec = new Map(); res.invRows.forEach(r => r.inv.rows.forEach(i => rowRec.set(i, r)));
  const inRows = [], inFills = [];
  for (let i = src.inv.hi + 1; i < src.inv.rows.length; i++) {
    const raw = src.inv.rows[i] || []; if (!raw.some(x => String(x == null ? '' : x).trim())) continue;
    const r = rowRec.get(i), o = H.map((_, c) => raw[c] == null ? '' : raw[c]);
    const dup = r && r.inv.rows[0] !== i && !src.itemLevel;
    inRows.push([...o, r ? (dup ? 'Təkrar sətir' : r.cat) : 'Tanınmadı', r && !dup ? n(r.off) : '', r && !dup ? n(r.diff) : '', r ? (dup ? 'Bu qaimə siyahıda təkrarlanır' : r.note.join('; ')) : 'VÖEN və ya seriya/nömrə oxunmadı']);
    inFills.push(!r || dup ? 'warn' : r.flag);
  }
  const L = H.length, origNum = H.map((h, c) => c).filter(c => [src.inv.map.base, src.inv.map.vat, src.inv.map.total].includes(c));
  const sheets = [{ name: 'Daxil Olanlar', header: [...H.map((h, c) => h || 'Sütun ' + (c + 1)), ...extra], rows: inRows, fills: inFills, numCols: [...origNum, L + 1, L + 2], fmt2: true, keep: true, maxW: 40 }];
  sheets.push(stdSheet('Tam Əvəzləşənlər', res.full));
  sheets.push(stdSheet('Qismən Əvəzləşənlər', res.part, 'Qalıq ƏDV (fərq)'));
  sheets.push(stdSheet('Əvəzləşməyənlər', res.none));
  // 5. Uyğun Olmayanlar
  const MH = ['Risk', 'Uyğunsuzluq növü', 'Təchizatçının adı', 'VÖEN (siyahı)', 'VÖEN (bəyannamə)', 'Tarix (siyahı)', 'Tarix (bəyannamə)', 'Seriya', 'Nömrə', 'Vergi tutulan (siyahı)', 'Vergi tutulan (bəyannamə)', 'Qaimə üzrə ƏDV', 'Bəyannamədə əks olunan ƏDV', 'Fərq', 'Dövr(lər)', 'İzah'];
  const ms = [...res.mism].sort((a, b) => RISK_ORDER[a.risk] - RISK_ORDER[b.risk] || a.type.localeCompare(b.type, 'az'));
  const mRows = ms.map(m => { const e = m.e || {}, d = m.d || {}; return [m.risk, m.type, e.name || '', e.voen || '', d.voen || '', e.date || '', d.date || '', e.series || d.series || '', e.number || d.number || '', n(e.base), n(d.base), n(m.inv), n(m.dec), m.inv != null && m.dec != null ? n(m.inv - m.dec) : '', (d.periods || [d.period].filter(Boolean)).join(', '), m.why || '']; });
  sheets.push({ name: 'Uyğun Olmayanlar', header: MH, rows: mRows, fills: ms.map(m => m.risk === 'Yüksək' ? 'risk' : m.risk === 'Orta' ? 'warn' : null), numCols: [9, 10, 11, 12, 13], fmt2: true, keep: true, maxW: 44 });
  // 6. Ümumi Nəticə
  const act = [...res.full, ...res.part, ...res.none, ...res.over], sum = (a, f) => a.reduce((s, r) => s + f(r), 0);
  const totVat = sum(act, r => r.vat), totOff = sum(act, r => r.off), totRest = sum(act, r => Math.max(0, r.diff)), pct = v => totVat ? String(Math.round(v / totVat * 10000) / 100) : '';
  const hi = res.mism.filter(m => m.risk === 'Yüksək').length + res.ctrl.filter(m => m.risk === 'Yüksək').length;
  const S = [
    ['Daxil olan qaimələr (hesablamaya daxil)', act.length, n(totVat), pct(totVat)],
    ['Tam əvəzləşənlər', res.full.length, n(sum(res.full, r => r.off)), pct(sum(res.full, r => r.off))],
    ['Qismən əvəzləşənlər (əvəzləşdirilən hissə)', res.part.length, n(sum(res.part, r => r.off)), pct(sum(res.part, r => r.off))],
    ['Qismən əvəzləşənlər (qalıq ƏDV)', res.part.length, n(sum(res.part, r => r.diff)), pct(sum(res.part, r => r.diff))],
    ['Əvəzləşməyənlər', res.none.length, n(sum(res.none, r => r.vat)), pct(sum(res.none, r => r.vat))],
    ['Artıq əvəzləşdirilənlər (artıq hissə)', res.over.length, n(sum(res.over, r => -r.diff)), ''],
    ['', '', '', ''],
    ['Ümumi ƏDV (qaimələr üzrə)', act.length, n(totVat), '100'],
    ['Əvəzləşdirilmiş ƏDV', '', n(totOff), pct(totOff)],
    ['Əvəzləşdirilməmiş ƏDV (qalıq)', '', n(totRest), pct(totRest)],
    ['Əvəzləşmə faizi', '', '', pct(totOff)],
    ['', '', '', ''],
    ['Bəyannamədə cəmi əvəzləşdirilən ƏDV (Əlavə 1)', res.declCount, n(res.declPaidTotal), ''],
    ['Bəyannamədə olub siyahıda olmayan qaimələr', res.declOnly.length, n(sum(res.declOnly, d => d.paid)), ''],
    ['Uyğunsuzluqlar', res.mism.length, '', ''],
    ['Yüksək riskli hallar', hi, '', ''],
    ['Təkrar sətirlər (siyahı / bəyannamə)', `${res.dupInv} / ${res.dupDecl}`, '', ''],
    ['Ləğv edilmiş / silinmiş (daxil edilmədi)', res.cancelled.length, n(sum(res.cancelled, r => r.vat)), ''],
    ['', '', '', ''],
    ['Bəyannamə dövrləri üzrə', 'Qaimə sətri', 'Əvəzləşdirilən ƏDV', ''],
    ...[...res.periods.entries()].sort((a, b) => a[1].ym - b[1].ym).map(([p, x]) => [p, x.n, n(x.paid), '']),
    ['', '', '', ''],
    ['Daxil olanlar faylı', src.invName + ' / ' + src.invSheet, '', ''],
    ['Bəyannamə faylı', src.declName + ' / ' + src.declSheet, '', ''],
    ['Yoxlama həddi (AZN)', String(src.tol).replace('.', ','), '', ''],
    ['Analiz tarixi', src.when, '', '']];
  const sFill = S.map(r => /Yüksək riskli/.test(r[0]) && +r[1] > 0 ? 'risk' : /Uyğunsuzluq|olmayan qaimə/.test(r[0]) && +r[1] > 0 ? 'warn' : null);
  sheets.push({ name: 'Ümumi Nəticə', header: ['Göstərici', 'Qaimə sayı', 'ƏDV məbləği, AZN', 'Pay, %'], rows: S.map(r => r.map(x => String(x))), fills: sFill, numCols: [1, 2, 3], intCols: [1], fmt2: true, keep: true, maxW: 52 });
  // 7. Nəzarət: təkrarlar və risklər
  const cs = [...res.ctrl].sort((a, b) => RISK_ORDER[a.risk] - RISK_ORDER[b.risk] || a.type.localeCompare(b.type, 'az'));
  sheets.push({ name: 'Nəzarət (təkrar və risk)', header: ['Risk', 'Nəzarət növü', 'Mənbə', 'Təchizatçının adı', 'VÖEN', 'Tarix', 'Seriya', 'Nömrə', 'Qaimə üzrə ƏDV', 'Bəyannamədə əks olunan ƏDV', 'Dövr(lər)', 'İzah'],
    rows: cs.map(m => { const e = m.e || {}, d = m.d || {}; return [m.risk, m.type, m.src || '', e.name || '', e.voen || d.voen || '', e.date || d.date || '', e.series || d.series || '', e.number || d.number || '', n(m.inv), n(m.dec), (d.periods || [d.period].filter(Boolean)).join(', '), m.why || '']; }),
    fills: cs.map(m => m.risk === 'Yüksək' ? 'risk' : m.risk === 'Orta' ? 'warn' : null), numCols: [8, 9], fmt2: true, keep: true, maxW: 48 });
  // 8. Təchizatçılar üzrə
  const sup = [...res.suppliers.values()].filter(s => s.n).sort((a, b) => b.rest - a.rest || b.vat - a.vat);
  const supRows = sup.map(s => [s.name, s.voen, s.n, n(s.vat), n(s.off), n(s.rest), s.vat ? String(Math.round(s.off / s.vat * 10000) / 100) : '', s.full, s.part, s.none, s.mism].map(x => String(x)));
  if (supRows.length > 1) { const t = ['Cəmi', '', 0, 0, 0, 0, '', 0, 0, 0, 0]; [2, 3, 4, 5, 7, 8, 9, 10].forEach(c => { t[c] = supRows.reduce((a, r) => a + (+r[c] || 0), 0); }); t[6] = t[3] ? Math.round(t[4] / t[3] * 10000) / 100 : ''; supRows.push(t.map(x => typeof x === 'number' ? String(r2(x)) : x)); }
  sheets.push({ name: 'Təchizatçılar üzrə', header: ['Təchizatçının adı', 'VÖEN', 'Qaimə sayı', 'Qaimə üzrə ƏDV', 'Əvəzləşdirilmiş ƏDV', 'Əvəzləşdirilməmiş ƏDV', 'Əvəzləşmə, %', 'Tam', 'Qismən', 'Əvəzləşməyən', 'Uyğunsuz / şübhəli'],
    rows: supRows, fills: sup.map(s => s.mism ? 'warn' : null), numCols: [2, 3, 4, 5, 6, 7, 8, 9, 10], intCols: [2, 7, 8, 9, 10], fmt2: true, total: supRows.length > 1, keep: true, maxW: 44 });
  return sheets;
}
if (typeof module !== 'undefined') module.exports = { readCsv, findHeader, autoMap, detect, recordsOf, analyze, buildSheets, missing, FIELDS, joinSerial, splitSerial, num, toDate };
