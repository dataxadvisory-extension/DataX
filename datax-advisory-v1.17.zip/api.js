// =====================================================================================
// e-taxes-in öz məlumat xidməti (API). Sayt səhifələri bu ünvanlardan JSON alır; extension da
// istifadəçinin açıq sessiyası ilə eyni ünvanlara müraciət edir. Səhifəyə klik, çərçivə lazım deyil.
// Xidmət cavab verməsə, köhnə üsul (səhifəni oxumaq) işə düşür.
// =====================================================================================

// Səhifədə (MAIN world) işləyir: sorğuları saytın öz giriş açarı ilə göndərir
async function etApi(reqs, conc) {
  const key = () => localStorage.getItem('aztax-jwt');
  if (!key()) return { error: 'sessiya tapılmadı' };
  const wait = ms => new Promise(z => setTimeout(z, ms));
  const one = async r => {
    for (let a = 0; a < 3; a++) {
      try {
        const res = await fetch(r.u, { method: r.m || 'GET', credentials: 'include',
          headers: { 'x-authorization': 'Bearer ' + key(), accept: 'application/json, text/plain, */*', ...(r.b ? { 'content-type': 'application/json' } : {}) },
          body: r.b ? JSON.stringify(r.b) : undefined });
        if (res.status === 401) return { st: 401, error: 'HTTP 401' };
        if (res.status >= 500 || res.status === 429) { await wait(700 * (a + 1)); if (a < 2) continue; }
        const t = await res.text();
        if (!res.ok) return { st: res.status, error: 'HTTP ' + res.status + (t ? ': ' + t.slice(0, 160) : '') };
        try { return { st: res.status, data: t ? JSON.parse(t) : null }; } catch (e) { return { st: res.status, error: 'cavab JSON deyil' }; }
      } catch (e) { if (a === 2) return { error: String(e && e.message || e) }; await wait(500); }
    }
    return { error: 'cavab yoxdur' };
  };
  const out = new Array(reqs.length); let i = 0;
  await Promise.all(Array.from({ length: Math.max(1, Math.min(conc || 6, reqs.length)) }, async () => { while (i < reqs.length) { const k = i++; out[k] = await one(reqs[k]); } }));
  return { out };
}

const apiErr = m => Object.assign(new Error('API: ' + m), { apiFail: true });
const SESSION_END = 'e-taxes sessiyası bitib. Saytda səhifəni yenilə, yenidən daxil ol və təkrar başlat.';
async function api(tabId, reqs, conc = 6) {
  if (!reqs.length) return [];
  let r;
  try { r = (await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: etApi, args: [reqs, conc] }))[0].result; }
  catch (e) { throw apiErr('skript: ' + e.message); }
  if (!r) throw apiErr('cavab yoxdur');
  if (r.error) throw apiErr(r.error);
  if (r.out.some(x => x && x.st === 401)) throw apiErr('HTTP 401 (sessiya qəbul edilmədi)');
  return r.out;
}
async function api1(tabId, u, m, b) { const [x] = await api(tabId, [{ u, m, b }], 1); if (x.error) throw apiErr(x.error); return x.data; }
// Əvvəl API, alınmasa köhnə üsul
async function apiFirst(name, apiFn, domFn, m) {
  try { return await apiFn(m); }
  catch (e) {
    if (!e.apiFail || cancel) throw e;
    await chrome.storage.local.set({ apiXeta: { funksiya: name, xeta: mask(e.message), t: Date.now() } });
    log('Birbaşa oxuma alınmadı, səhifə üsulu ilə davam edilir...');
    return domFn(m);
  }
}
const run = m => apiFirst('elave1', runVatApi, runVatDom, m);
const runItems = m => apiFirst('mallar', runItemsApi, runItemsDom, m);
const runDocs = m => apiFirst('altSenedler', runDocsApi, runDocsDom, m);
const runDecls = m => apiFirst('beyannameler', runDeclsApi, runDeclsDom, m);

const MONTHS_UP = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'İyun', 'İyul', 'Avqust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'];
const ord = n => n + (n === 3 || n === 4 ? '-cü' : '-ci');
const p2 = n => String(n).padStart(2, '0');
const isoDmy = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}):(\d{2}))?/); return m ? `${m[3]}.${m[2]}.${m[1]}` + (m[4] ? ` ${m[4]}:${m[5]}:${m[6]}` : '') : String(s || ''); };
const isoN = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? +(m[1] + m[2] + m[3]) : 0; };
const nstr = v => v == null || v === '' || isNaN(+v) ? '' : String(Math.round(+v * 10000) / 10000);          // Excel üçün nöqtəli
const ncom = v => v == null || v === '' || isNaN(+v) ? '' : String(Math.round(+v * 10000) / 10000).replace('.', ',');   // hesabat üçün vergüllü

// ---------------- Bəyannamə siyahısı ----------------
const D_TYPE = { CURRENT: 'Cari', CLARIFYING: 'Dəqiqləşdirilmiş' };
const D_STAT = { CONFIRMED: 'Təsdiqlənib', SENT: 'Göndərilib', SUBMITTED: 'Göndərilib', REJECTED: 'İmtina edilib', DRAFT: 'Qaralama', ON_REVIEW: 'Baxılır' };
function apiDecl(x, listYear) {
  const p = x.reportingPeriod || {}, y = +p.year || +String(x.registrationDate || '').slice(0, 4) || 0, m = +p.month || 1, t = String(p.type || '').toUpperCase();
  let a = 1, b = 12, period = `${y}`;
  if (t === 'MONTH') { a = b = m; period = `${MONTHS_UP[m - 1] || m} ${y}`; }
  else if (t === 'QUARTER') { const q = Math.floor((m - 1) / 3) + 1; a = q * 3 - 2; b = q * 3; period = `${ord(q)} rüb ${y}`; }
  else if (/HALF/.test(t)) { const h = m > 6 ? 2 : 1; a = h * 6 - 5; b = h * 6; period = `${ord(h)} yarımil ${y}`; }
  return { docNo: String(x.registrationNumber || x.id), period, type: D_TYPE[x.declarationType] || x.declarationType || '', date: isoDmy(String(x.registrationDate || x.submissionDate || '').slice(0, 10)),
    status: D_STAT[x.declarationStatus] || x.declarationStatus || '', amount: x.taxAmount == null ? '' : ncom(x.taxAmount), kameral: !!x.cameralAudit, section: x.taxName || '', taxCode: x.taxCode || '',
    last: x.lastClarifying || '', ts: Date.parse(x.submissionDate || x.registrationDate || '') || 0, year: y, month: a, pr: { y, a, b }, listYear, rawStatus: x.declarationStatus || '' };
}
async function apiDeclList(tabId, years) {
  const out = await api(tabId, years.map(y => ({ u: `/api/po/declaration/public/v1/declaration/list?year=${y}` })), 3);
  const by = new Map(), notes = [];
  out.forEach((x, i) => {
    const arr = x && x.data && x.data.declarations;
    if (!Array.isArray(arr)) { notes.push(`${years[i]}: ${x && x.error ? mask(x.error) : 'gözlənilməz cavab'}`); return; }
    arr.forEach(w => { const d = w && (w.declaration || w); if (d && (d.registrationNumber || d.id)) { const v = apiDecl(d, years[i]); if (!by.has(v.docNo)) by.set(v.docNo, v); } });
  });
  if (notes.length === years.length) throw apiErr('bəyannamə siyahısı: ' + notes.join('; '));
  return { list: [...by.values()].filter(d => !/DRAFT|DELETE|CANCEL|REJECT/i.test(d.rawStatus)), notes };
}
// Eyni dövr üçün ən son bəyannamə: saytın "son dəqiqləşmə" işarəsi, sonra göndərilmə vaxtı
const declBetter = (x, b) => { if (!b) return true; const r = d => d.last === 'LAST' ? 1 : 0; return r(x) !== r(b) ? r(x) > r(b) : x.ts !== b.ts ? x.ts > b.ts : x.docNo > b.docNo; };
const yearsFor = (fy, ty) => { const nowY = new Date().getFullYear(), ys = []; for (let y = fy; y <= Math.min(ty + 1, nowY); y++) ys.push(y); return ys.length ? ys : [fy]; };

// ---------------- FUNKSİYA 1: ƏDV Əlavə 1 qaimələri ----------------
const A1_HDR = ['Sıra №', 'Satıcının VÖEN-i', 'Qaimənin seriyası', 'Qaimənin nömrəsi', 'Qaimənin tarixi', 'Ümumi məbləğ (ƏDV-siz)', 'ƏDV məbləği', 'Ödənilmiş məbləğ', 'Ödənilmiş ƏDV məbləği'];
async function runVatApi({ tabId, from, to, skipKameral }) {
  const t0 = Date.now();
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), years = yearsFor(fy, ty);
  log('Bəyannamələr siyahısı alınır...');
  const { list, notes: yearNotes } = await apiDeclList(tabId, years);
  const vat = list.filter(d => d.taxCode === '_0300' || /^əlavə dəyər vergisi$/i.test(d.section.trim()));
  const inRange = vat.filter(x => { const v = x.year * 12 + x.month; return v >= fy * 12 + fm && v <= ty * 12 + tm; });
  const best = {};
  inRange.filter(x => !(skipKameral && x.kameral)).forEach(x => { const k = x.year * 12 + x.month; if (declBetter(x, best[k])) best[k] = x; });
  const sel = Object.values(best).sort((a, b) => a.year * 12 + a.month - (b.year * 12 + b.month));
  const baseReport = { versiya: VERSION, funksiya: 'elave1', rejim: 'api', iller: years, ilQeydleri: yearNotes, siyahi: { hamisi: list.length, edv: vat.length, araliqda: inRange.length, kameral: inRange.filter(x => x.kameral).length } };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş aylarda ƏDV bəyannaməsi tapılmadı.');

  const summaries = [], rows = [], notes = []; let done = 0, ok = 0, skip = 0, err = 0, total = 0;
  const short = t => t === 'Cari' ? 'Cari' : /^Dəqiq/.test(t) ? 'Dəqiq.' : t;
  const report = () => log(`${done} / ${sel.length} bəyannamə oxundu.`, false, { i: done, n: sel.length, summary: summaries.filter(Boolean) });
  report();
  const url = (d, off) => `/api/po/declaration/public/v1/calc/VAT_APPENDIX_1_REPORT_PERIOD_INVOICE?reg_number=${d.docNo}&offset=${off}&maxCount=1000`;
  const parts = new Array(sel.length).fill(null).map(() => []), errs = new Array(sel.length).fill(null);
  for (let s = 0; s < sel.length && !cancel; s += 12) {
    const chunk = sel.slice(s, s + 12), out = await api(tabId, chunk.map(d => ({ u: url(d, 0) })), 6);
    for (let j = 0; j < chunk.length; j++) {
      const i = s + j, x = out[j];
      if (x.error) { errs[i] = x.error; continue; }
      let arr; try { arr = JSON.parse((x.data || {}).calcPartJson || '[]'); } catch (e) { errs[i] = 'format'; continue; }
      if (!Array.isArray(arr)) { errs[i] = 'format'; continue; }
      parts[i] = arr;
      for (let off = 1000; arr.length === 1000 && off < 50000; off += 1000) {                  // çox böyük siyahı: davamı
        const y = await api1(tabId, url(chunk[j], off)); arr = JSON.parse((y || {}).calcPartJson || '[]'); parts[i].push(...arr);
      }
    }
    if (out.every(x => x.error) && s === 0) throw apiErr('Əlavə 1: ' + out[0].error);
    for (let j = 0; j < chunk.length; j++) {
      const i = s + j, d = sel[i], arr = parts[i];
      if (errs[i]) { err++; summaries[i] = { p: d.period, k: short(d.type), note: 'oxunmadı' }; notes.push(['Xəta', d.period + ' / ' + d.type, d.docNo, mask(errs[i])]); }
      else if (!arr.length) { skip++; summaries[i] = { p: d.period, k: short(d.type), note: 'Əlavə 1 yoxdur' }; notes.push(['Məlumat', d.period + ' / ' + d.type, d.docNo, 'Əlavə 1 boşdur və ya açıq deyil, keçildi']); }
      else {
        ok++; total += arr.length;
        arr.sort((a, b) => (a.rowOrder || 0) - (b.rowOrder || 0)).forEach((r, k) => rows.push([d.period, d.type, d.docNo, k + 1, r.tin || '', r.documentSerial || '', r.documentNumber || '', isoDmy(r.documentDate), nstr(r.amount), nstr(r.vat), nstr(r.paidAmount), nstr(r.paidVat)]));
        summaries[i] = { p: d.period, k: short(d.type), c: arr.length, t: arr.reduce((a, r) => a + (+r.amount || 0), 0), v: arr.reduce((a, r) => a + (+r.vat || 0), 0) };
      }
      done++;
    }
    report();
  }
  yearNotes.forEach(n => notes.push(['Xəbərdarlıq', n.split(':')[0] + '-ci il', '', 'Bu ilin siyahısı alınmadı: ' + n.split(': ')[1]]));
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan aylar fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...baseReport, saniye: sec, secilen: sel.length, oxundu: ok, elave1Yox: skip, xeta: err, xetalar: [...new Set(errs.filter(Boolean).map(mask))].slice(0, 5) } });
  await saveXlsx(`DataX-elave1-${from}_${to}.xlsx`, [
    { name: 'Əlavə 1 qaimələri', header: ['Dövr', 'Növ', 'Sənəd nömrəsi', ...A1_HDR], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Bəyannamə', 'Sənəd nömrəsi', 'Qeyd'], rows: notes, numeric: false }]);
  const ps = [`${ok} bəyannamədən ${total} qaimə`]; if (skip) ps.push(`${skip} bəyannamədə Əlavə 1 yoxdur`); if (err) ps.push(`${err} bəyannamə oxunmadı`);
  log((err || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san): ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true, { i: sel.length, n: sel.length, summary: summaries.filter(Boolean), hasErrors: !!err });
}

// ---------------- Qaimələr ----------------
const INV_STATUS = { approved: 'Təsdiqləndi', cancelationRefused: 'Təsdiqləndi', correctionRefused: 'Təsdiqləndi', onApproval: 'Təsdiq gözləyir', updateApproval: 'Düzəliş edildi',
  updateRequested: 'Düzəlişə qaytarıldı', cancelRequested: 'Ləğvə göndərildi', approvedBySystem: 'Sistem tərəfindən təsdiqləndi', onApprovalEdited: 'Düzəlişə göndərildi',
  canceled: 'Ləğv edildi', cancelled: 'Ləğv edildi', deleted: 'Silindi', deletedBySystem: 'Sistem tərəfindən silindi', deactivated: 'Passiv' };
const INV_KIND = { defaultInvoice: 'Malların, işlərin və xidmətlərin təqdim edilməsi barədə elektron qaimə-faktura',
  agent: 'Malların, işlərin və xidmətlərin vəkalətverən (komitent) tərəfindən agentə (komisyonçuya) verilməsi barədə elektron qaimə-faktura',
  resale: 'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin alıcısına (subagentə) təqdim edilməsi barədə elektron qaimə-faktura',
  recycling: 'Malların emala yaxud saxlamaya verilməsi barədə elektron qaimə-faktura',
  taxCodex163: 'Qaytarma istisna olmaqla VM-in 163-cü maddəsinə əsasən dəqiqləşdirilməsi barədə elektron qaimə-faktura',
  taxCodex177_5: 'VM-in 177.5-ci maddəsinə əsasən təqdim edilməsi barədə elektron qaimə-faktura',
  returnInvoice: 'Malların qaytarılması barədə elektron qaimə-faktura',
  returnByAgent: 'Agent (komisyonçu) tərəfindən malların, işlərin və xidmətlərin vəkalətverənə (komitentə) qaytarılması barədə elektron qaimə-faktura',
  returnRecycled: 'Emal prosesi keçmiş, yaxud saxlamaya verilmiş malların qaytarılması barədə elektron qaimə-faktura',
  exportNoteInvoice: 'Malların ixrac qeydi ilə satışı barədə elektron qaimə-faktura',
  exciseGoodsTransfer: 'Aksizli malların (neft məhsulları istisna olmaqla) təsərrüfatdaxili yerdəyişməsi barədə elektron qaimə-faktura',
  advanceInvoice: 'Alınmış avans ödənişləri barədə elektron qaimə-faktura',
  mtkInvoice: 'Yaşayış və qeyri-yaşayış sahələrinə görə ödənilmiş əlavə dəyər vergisinin qaytarılması' };
const ST_MAIN = ['approved', 'onApproval', 'updateApproval', 'updateRequested', 'cancelRequested', 'approvedBySystem', 'onApprovalEdited', 'deactivated', 'cancelationRefused', 'correctionRefused'];
const ST_GONE = ['canceled', 'deleted', 'deletedBySystem'];
const KINDS = ['defaultInvoice', 'agent', 'resale', 'recycling', 'taxCodex163', 'taxCodex177_5', 'returnInvoice', 'returnByAgent', 'returnRecycled', 'exportNoteInvoice', 'exciseGoodsTransfer', 'advanceInvoice'];
const ITEM_HDR = ['Sıra №', 'Malın kodu', 'Malın adı', 'Təsnifat üzrə adı', 'Barkod', 'Ölçü vahidi', 'Miqdarı', 'Vahidinin qiyməti', 'Cəmi məbləğ', 'Aksiz dərəcəsi', 'Aksiz məbləği',
  'ƏDV-yə 18% cəlb edilən', 'ƏDV-yə cəlb edilməyən', 'ƏDV-yə 0% cəlb edilən', 'ƏDV-dən azad', 'Yol vergisi', 'ƏDV məbləği', 'Yekun məbləğ'];
const dmyDash = n => { const s = String(n); return `${s.slice(6, 8)}-${s.slice(4, 6)}-${s.slice(0, 4)} 00:00`; };
const nextDay = n => { const s = String(n), d = new Date(Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8) + 1)); return d.getUTCFullYear() * 10000 + (d.getUTCMonth() + 1) * 100 + d.getUTCDate(); };
// İl-il bölünmüş tarix aralıqları (sayt uzun aralığı qəbul etməyə bilər)
const yearChunks = (fromN, toN) => { const out = []; for (let y = Math.floor(fromN / 10000); y <= Math.floor(toN / 10000); y++) out.push([Math.max(fromN, y * 10000 + 101), Math.min(toN, y * 10000 + 1231)]); return out; };

async function apiInvList(tabId, dir, fromN, toN, extra, onPage) {
  const u = `/api/po/invoice/public/v2/invoice/find.${dir === 'out' ? 'outbox' : 'inbox'}`;
  const body = (a, b, statuses) => ({ sortBy: 'creationDate', sortAsc: true, statuses, types: ['current', 'corrected'], kinds: KINDS, serialNumber: null, senderTin: null, senderName: null,
    productName: null, productCode: null, receiverTin: null, receiverName: null, creationDateFrom: dmyDash(a), creationDateTo: dmyDash(nextDay(b)), amountFrom: null, amountTo: null, actionOwner: null, ...(extra || {}) });
  const all = [], seen = new Set(); let pages = 0, goneOk = true;
  for (const [a, b] of yearChunks(fromN, toN)) {
    let statuses = [...ST_MAIN, ...ST_GONE];
    for (let off = 0; !cancel; off += 50) {
      let [x] = await api(tabId, [{ u, m: 'POST', b: { ...body(a, b, statuses), offset: off, maxCount: 50 } }], 1);
      if (x.error && off === 0 && statuses.length > ST_MAIN.length && x.st === 400) { statuses = ST_MAIN; goneOk = false; [x] = await api(tabId, [{ u, m: 'POST', b: { ...body(a, b, statuses), offset: 0, maxCount: 50 } }], 1); }
      if (x.error) throw apiErr('qaimə siyahısı: ' + x.error);
      const arr = x.data && x.data.invoices; if (!Array.isArray(arr)) throw apiErr('qaimə siyahısı: gözlənilməz cavab');
      arr.forEach(v => { if (v && v.id && !seen.has(v.id)) { seen.add(v.id); all.push(v); } });
      pages++; if (onPage) onPage(pages, all.length);
      if (arr.length < 50 || pages > 600) break;
    }
  }
  return { all, pages, goneOk };
}
function invRow(v, dir) {
  const cp = (dir === 'out' ? v.receiver : v.sender) || {};
  return { id: v.id, src: v.sourceSystem || 'avis', serial: v.serialNumber || '', date: isoDmy(v.createdAt), dnum: isoN(v.createdAt), voen: cp.tin || cp.fin || cp.pin || '', name: cp.name || '',
    type: INV_KIND[v.kind] || v.kind || '', status: INV_STATUS[v.status] || v.status || '', basis: v.invoiceComment || '', total: v.amount, vat: v.vat, corrected: v.type === 'corrected' };
}
const itemRows = items => (items || []).map((it, k) => {
  const g = it.productGroup || {}, vat = (+it.vat18 || 0) * 0.18, base = (+it.cost || 0) + (+it.excise || 0) + (+it.roadTax || 0);
  return [String(k + 1), g.code || '', it.productName || '', (g.name && g.name.az) || '', it.barcode || '', (it.unitFromDict && it.unitFromDict.name && it.unitFromDict.name.az) || it.unit || '',
    nstr(it.quantity), nstr(it.pricePerUnit), nstr(it.cost), nstr(it.exciseRate), nstr(it.excise), nstr(it.vat18), nstr(it.vatFree), nstr(it.vat0), nstr(it.exempt), nstr(it.roadTax), nstr(vat), nstr(base + vat)];
});
// Qaimələrin içi (mallar). progress(n) hər hissədən sonra
async function apiInvItems(tabId, sel, progress) {
  const results = new Array(sel.length).fill(null);
  for (let s = 0; s < sel.length && !cancel; s += 40) {
    const chunk = sel.slice(s, s + 40), out = await api(tabId, chunk.map(d => ({ u: `/api/po/invoice/public/v2/invoice/${encodeURIComponent(d.id)}?sourceSystem=${encodeURIComponent(d.src)}` })), 8);
    if (s === 0 && out.every(x => x.error)) throw apiErr('qaimənin içi: ' + out[0].error);
    out.forEach((x, j) => {
      const v = x.data;
      if (x.error || !v || !Array.isArray(v.items)) { results[s + j] = { error: x.error || 'qaimənin içi boş gəldi' }; return; }
      results[s + j] = { header: ITEM_HDR, rows: itemRows(v.items),
        info: { esas: v.invoiceComment || '', qeyd: v.invoiceComment2 || '', created: isoDmy(v.createdAt),
          parties: [v.sender, v.receiver].filter(Boolean).map(p => ({ voen: p.tin || p.pin || '', name: p.name || '' })) } };
    });
    progress(Math.min(sel.length, s + chunk.length));
  }
  return results;
}

// ---------------- FUNKSİYA 2: Qaimə üzrə mallar və xidmətlər ----------------
async function runItemsApi({ tabId, from, to, dir, statuses, types }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), fromN = N(from), toN = N(to), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  log(`"${tab}" siyahısı alınır...`);
  const L = await apiInvList(tabId, dir, fromN, toN, null, (p, n) => log(`"${tab}" siyahısı alınır: ${n} qaimə...`, false, { stats: [{ l: 'Səhifə', v: p }, { l: 'Qaimə', v: n }] }));
  const inDates = L.all.map(v => invRow(v, dir)).filter(d => d.dnum >= fromN && d.dnum <= toN);
  const nz = s => String(s || '').toLocaleLowerCase('az').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const pick = (f, v, unknown) => { if (!f) return true; const k = nz(v); if (f.on.some(x => nz(x) === k)) return true; if (f.known.some(x => nz(x) === k)) return false; unknown.add(v || '(boş)'); return f.other !== false; };
  const unkS = new Set(), unkT = new Set();
  const sel = inDates.filter(x => pick(statuses, x.status, unkS) & pick(types, x.type, unkT)).sort((a, b) => a.dnum - b.dnum || a.date.localeCompare(b.date));
  const base = { versiya: VERSION, funksiya: 'mallar', rejim: 'api', bolme: tab, sehife: L.pages, siyahi: L.all.length, legvSilinmisAlindi: L.goneOk,
    secim: { tarixde: inDates.length, secilen: sel.length, taninmayanStatus: [...unkS].slice(0, 8), taninmayanNov: [...unkT].slice(0, 8) } };
  await chrome.storage.local.set({ report: base });
  if (!inDates.length) throw new Error(`"${tab}" bölməsində bu tarix aralığında qaimə tapılmadı.`);
  if (!sel.length) throw new Error(`Bu tarixlərdə ${inDates.length} qaimə var, amma heç biri seçdiyin status və növə uyğun deyil.`);
  const stats = d => [{ l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }];
  const results = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimə oxundu.`, false, { i: d, n: sel.length, stats: stats(d) }));

  const rows = [], notes = []; let items = 0, ok = 0, empty = 0, err = 0;
  sel.forEach((d, i) => {
    const res = results[i]; if (!res) return;
    if (res.error) { err++; notes.push(['Xəta', d.serial, d.date, mask(res.error)]); return; }
    const info = res.info, meta = [d.date, d.voen, d.name, d.serial, d.type, d.status, info.esas || d.basis || '', info.qeyd || ''];
    if (!res.rows.length) { empty++; notes.push(['Məlumat', d.serial, d.date, 'Mal sətri yoxdur']); return; }
    ok++; items += res.rows.length;
    res.rows.forEach(row => { const code = String(row[1] || '').trim(); rows.push([...meta, code ? (code.startsWith('99') ? 'Xidmət' : 'Mal') : '', ...row]); });
  });
  if (unkS.size) notes.push(['Məlumat', '', '', 'Tanınmayan status: ' + [...unkS].join('; ')]);
  if (unkT.size) notes.push(['Məlumat', '', '', 'Tanınmayan növ: ' + [...unkT].join('; ')]);
  if (!L.goneOk && statuses && statuses.on.some(x => /ləğv edildi|silindi/i.test(x))) notes.push(['Xəbərdarlıq', '', '', 'Ləğv edilmiş və silinmiş qaimələr sayt tərəfindən verilmədi.']);
  if (cancel) notes.push(['Xəta', 'Dayandırıldı', '', 'İstifadəçi dayandırdı, oxunmayan qaimələr fayla düşmədi']);
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ report: { ...base, saniye: sec, oxundu: ok, bos: empty, xeta: err, xetalar: [...new Set(results.filter(r => r && r.error).map(r => mask(r.error)))].slice(0, 4) } });
  await saveXlsx(`DataX-mallar-${dir === 'out' ? 'gonderilen' : 'gelen'}-${from}_${to}.xlsx`, [
    { name: 'Mallar və xidmətlər', header: ['İmzalanma tarixi', 'VÖEN', 'Adı', 'Seriya və nömrə', 'Qaimənin növü', 'Status', 'Əsas', 'Əlavə qeyd', 'Mal/xidmət', ...ITEM_HDR], rows, keep: true },
    { name: 'Qeydlər', header: ['Növ', 'Seriya və nömrə', 'Tarix', 'Qeyd'], rows: notes, numeric: false }]);
  const ps = [`${tab}: ${sel.length} qaimə` + (sel.length < inDates.length ? ` (tarixdə ${inDates.length}, seçimə uyğun ${sel.length})` : ''), `${items} mal/xidmət sətri`];
  if (empty) ps.push(`${empty} qaimədə sətir yoxdur`); if (err) ps.push(`${err} qaimə oxunmadı`);
  log((err || cancel ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${ps.join(', ')}. Fayl Yükləmələr qovluğundadır.`, true,
    { i: sel.length, n: sel.length, hasErrors: !!err, stats: [{ l: 'Qaimə', v: sel.length }, { l: 'Mal sətri', v: items }, { l: 'Saniyə', v: sec }] });
}

// ---------------- FUNKSİYA 3: Alt sənədlər ----------------
async function ownFromApi(tabId) {
  const d = await api1(tabId, '/api/po/profile/public/v2/profile'), p = (d && d.profile) || d || {};
  const name = p.companyName || p.individualName || '', voen = p.tin || '';
  if (!name && !voen) throw apiErr('profil boşdur');
  const ad = String(p.legalAddress || p.actualAddress || '').toLocaleLowerCase('az'), m = ad.match(/(\p{L}[\p{L}\-]*)\s+şəhəri/u) || ad.match(/(\p{L}[\p{L}\-]*)\s+rayonu/u);
  const city = m ? m[0].replace(/^\p{L}/u, c => c.toLocaleUpperCase('az')) : '';
  return { name: shortName(name), voen, city, menbe: ['profil (birbaşa)'] };
}
async function runDocsApi({ tabId, serials, voen, from, to, dir, docs, opts }) {
  const t0 = Date.now(), N = s => +s.replace(/-/g, ''), tab = dir === 'out' ? 'Göndərilənlər' : 'Gələnlər';
  const want = [...new Set((serials || []).map(s => s.toUpperCase()))], keys = Object.keys(DOCS).filter(k => docs && docs[k]);
  const today = (d => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate())(new Date());
  const found = new Map(); let pages = 0;
  log('Qaimələr axtarılır...');
  if (want.length) {
    for (let i = 0; i < want.length && !cancel; i++) {
      const s = want[i], m = s.match(/^[A-Z]{2}(\d{2})(\d{2})/), y = m ? 2000 + +m[1] : 0, mo = m ? +m[2] : 0;
      const a = y && mo >= 1 && mo <= 12 ? y * 10000 + mo * 100 + 1 : 20190101;
      const b = y && mo >= 1 && mo <= 12 ? Math.min(today, (mo > 9 ? (y + 1) * 10000 + (mo - 9) * 100 : y * 10000 + (mo + 3) * 100) + 1) : today;
      const L = await apiInvList(tabId, dir, a, b, { serialNumber: s }, null); pages += L.pages;
      L.all.filter(v => String(v.serialNumber || '').toUpperCase() === s).forEach(v => found.set(v.id, v));
      log(`Qaimələr axtarılır: ${i + 1} / ${want.length}...`);
    }
  } else {
    const L = await apiInvList(tabId, dir, N(from), N(to), voen ? (dir === 'out' ? { receiverTin: voen } : { senderTin: voen }) : null, null); pages = L.pages;
    L.all.forEach(v => found.set(v.id, v));
  }
  const sel = [...found.values()].map(v => invRow(v, dir)).filter(d => !voen || d.voen === voen).filter(d => want.length || (d.dnum >= N(from) && d.dnum <= N(to))).sort((a, b) => a.dnum - b.dnum || a.date.localeCompare(b.date));
  const notFound = want.filter(s => !sel.some(x => x.serial.toUpperCase() === s));
  const base = { versiya: VERSION, funksiya: 'altSenedler', rejim: 'api', bolme: tab, sehife: pages, secim: { nomre: want.length, voenSecimi: !!voen, tapildi: sel.length, tapilmadi: notFound.length } };
  await chrome.storage.local.set({ report: base });
  if (!sel.length) throw new Error(want.length ? `Yazdığın ${want.length} qaimədən heç biri "${tab}" bölməsində tapılmadı. Bölməni (Gələn/Göndərilən) və nömrələri yoxla.` : `"${tab}" bölməsində bu VÖEN və tarixlərə uyğun qaimə tapılmadı.`);
  const stats = (d, f) => [{ l: 'Qaimə', v: sel.length }, { l: 'Oxundu', v: d }, { l: 'Sənəd', v: f }];
  const results = await apiInvItems(tabId, sel, d => log(`${d} / ${sel.length} qaimə oxundu.`, false, { i: d, n: sel.length, stats: stats(d, 0) }));
  let own; try { own = await ownFromApi(tabId); } catch (e) { if (e.message === SESSION_END) throw e; own = (await detectOwn(tabId)).own; try { await exec(tabId, rmAllFrames); } catch (e2) {} }
  const o = opts || {}; let files = 0, okInv = 0, err = 0, noOwn = 0, seq = 0; const errs = [];
  for (let i = 0; i < sel.length && !cancel; i++) {
    const d = sel[i], res = results[i]; if (!res) continue;
    if (res.error) { err++; errs.push(res.error); continue; }
    const inv = (res.info.parties || []).find(p => p.voen !== d.voen) || {};
    const me = { name: own.name || shortName(inv.name || ''), voen: own.voen || inv.voen || '', city: own.city };
    const dd = docData(d, res, dir, me, o, ++seq); if (dd.noOwn) noOwn++;
    files += await saveInvoiceDocs(keys, dd.data, dd.items, d.serial);
    okInv++; log(`Sənədlər hazırlanır: ${okInv} / ${sel.length} qaimə...`, false, { i: i + 1, n: sel.length, stats: stats(sel.length, files) });
  }
  const sec = Math.round((Date.now() - t0) / 1000);
  await chrome.storage.local.set({ ownSeen: { name: own.name, voen: own.voen, t: Date.now() } });
  await chrome.storage.local.set({ report: { ...base, saniye: sec, senedSayi: files, xeta: err, ozSirket: { menbe: own.menbe, tapilmadi: noOwn }, xetalar: [...new Set(errs.map(mask))].slice(0, 4) } });
  const warn = [];
  if (notFound.length) warn.push(`Tapılmadı: ${notFound.slice(0, 6).join(', ')}${notFound.length > 6 ? ' və daha ' + (notFound.length - 6) : ''}.`);
  if (err) warn.push(`${err} qaimə oxunmadı.`);
  if (noOwn) warn.push(`${noOwn} qaimədə öz şirkətinin adı və ya VÖEN-i tapılmadı, yerinə xətt çəkilib.`);
  log((notFound.length || err ? 'Natamam' : 'Hazırdır') + ` (${sec} san). ${okInv} qaimə üçün ${files} sənəd hazırdır: "Yükləmələr / DataX alt sənədlər" içində hər qaimə üçün bir qovluq (zip) var.` + ((own.name || own.voen) ? `\nŞirkətin: ${own.name || '?'}, VÖEN ${own.voen || '?'}` : '') + (warn.length ? '\n' + warn.join('\n') : ''), true,
    { i: sel.length, n: sel.length, hasErrors: !!(notFound.length || err), stats: [{ l: 'Qaimə', v: okInv }, { l: 'Sənəd', v: files }, { l: 'Tapılmadı', v: notFound.length }] });
}

// ---------------- FUNKSİYA 4: Bəyannamələrin içi ----------------
const SEC_AZ = { common: 'Ümumi məlumat', administrative: 'İnzibati məlumat', payerInfo: 'Vergi ödəyicisi', declarationInfo: 'Bəyannamə', indicators: 'Göstəricilər', term: 'Dövr',
  mainTax: 'Əsas vergi', calculations: 'Hesablamalar', debtorDebt: 'Debitor borclar', refundCalculations: 'Əvəzləşdirilən vergi', totalCalculations: 'Hesablaşmalar',
  vatOperations: 'ƏDV tutulan və tutulmayan əməliyyatlar', reportPeriodInvoiceTotal: 'Əvəzləşdirmə üçün e-qaimələr (cəmi)', agroProductsRetailTotal: 'Kənd təsərrüfatı məhsulları',
  unsoldAgroProducts: 'Satılmamış k/t məhsulları', creditors: 'Kreditorlar', totalCertificateInfo: 'Sertifikatlar', totalObjectInfo: 'Obyektlər' };
const FLD_AZ = { cost: 'Dəyəri', amount: 'Məbləğ', vat: 'ƏDV', paidAmount: 'Ödənilmiş məbləğ', paidVat: 'Ödənilmiş ƏDV', previousDebt: 'Dövrün əvvəlinə borc', incurredDebt: 'Yaranmış borc',
  removedDebt: 'Silinmiş borc', lastDebt: 'Dövrün sonuna borc', mustBePaid: 'Ödənilməli', mustBeReturned: 'Qaytarılmalı', startRemains: 'Dövrün əvvəlinə qalıq', purchased: 'Alınıb', sold: 'Satılıb',
  resultRemains: 'Dövrün sonuna qalıq', tradeSupplementCost: 'Ticarət əlavəsi', tradeSupplementVat: 'Ticarət əlavəsinin ƏDV-si', totalCost: 'Ümumi dəyər', obtainedCost: 'Alınmış dəyər', soldCost: 'Satılmış dəyər',
  taxAmount: 'Vergi məbləği', tax: 'Vergi', rate: 'Dərəcə', taxRate: 'Vergi dərəcəsi', date: 'Tarix', tin: 'VÖEN', name: 'Ad', currency: 'Valyuta', count: 'Say', quantity: 'Miqdar', income: 'Gəlir', expense: 'Xərc',
  departmentCode: 'Vergi orqanının kodu', taxPayerFullName: 'Vergi ödəyicisinin adı', payerType: 'Ödəyicinin növü', taxPayerGroup: 'Ödəyici qrupu', mainActivityCode: 'Əsas fəaliyyət kodu',
  mainActivityName: 'Əsas fəaliyyət', attachmentCount: 'Əlavələrin sayı', declarationType: 'Bəyannamə növü', notificationNo: 'Bildiriş №', type: 'Növ', year: 'İl', month: 'Ay' };
const camel = k => String(k).replace(/([a-z])([A-Z0-9])/g, '$1 $2').replace(/^./, c => c.toUpperCase());
const secName = k => SEC_AZ[k] || (/^appendix(\d+)$/i.test(k) ? 'Əlavə ' + k.replace(/\D/g, '') : /^section(\d+)$/i.test(k) ? 'Bölmə ' + k.replace(/\D/g, '') : camel(k));
const fldName = k => FLD_AZ[k] || camel(k);
const scal = v => v == null || typeof v !== 'object';
// Bəyannamənin JSON-u → bölmələr (köhnə üsulun formatı): kodlu cədvəllər hesabata, qalan siyahılar ayrıca vərəqə, mətnlər "sahələr"ə
function declToSections(o) {
  const secs = new Map();
  const S = path => { const t = path.length ? secName(path[0]) : 'Ümumi'; if (!secs.has(t)) secs.set(t, { title: t, side: true, tables: [], fields: [] }); return secs.get(t); };
  const sub = path => path.slice(1).map(secName).join(' / ');
  const walk = (v, path) => {
    if (Array.isArray(v)) {
      const objs = v.filter(x => x && typeof x === 'object' && !Array.isArray(x)); if (!objs.length) return;
      const keys = []; objs.forEach(x => Object.keys(x).forEach(k => { if (!keys.includes(k) && k !== 'id' && k !== 'rowOrder') keys.push(k); }));
      if (objs.every(x => x.indicator != null)) {
        const vk = keys.filter(k => k !== 'indicator' && objs.some(x => scal(x[k])));
        S(path).tables.push({ title: sub(path), header: ['Kod', ...vk.map(fldName)], coded: { cc: 0, lc: -1, vcols: vk.map((_, i) => i + 1) },
          rows: objs.map(x => [String(x.indicator).replace(/^_/, ''), ...vk.map(k => typeof x[k] === 'number' ? ncom(x[k]) : scal(x[k]) && x[k] != null ? String(x[k]) : '')]) });
        objs.forEach((x, i) => keys.filter(k => !scal(x[k])).forEach(k => walk(x[k], [...path, String(x.indicator).replace(/^_/, ''), k])));
      } else {
        const vk = keys.filter(k => objs.some(x => scal(x[k])));
        if (vk.length) S(path).tables.push({ title: sub(path) || secName(path[path.length - 1] || ''), header: vk.map(fldName), rows: objs.map(x => vk.map(k => typeof x[k] === 'number' ? ncom(x[k]) : x[k] == null ? '' : String(x[k]))) });
        objs.forEach(x => keys.filter(k => !scal(x[k])).forEach(k => walk(x[k], [...path, k])));
      }
      return;
    }
    if (!v || typeof v !== 'object') return;
    const nums = [], texts = [];
    Object.entries(v).forEach(([k, x]) => { if (typeof x === 'number') nums.push([k, x]); else if (scal(x)) { if (x != null && x !== '') texts.push([k, x]); } else walk(x, [...path, k]); });
    if (nums.length) S(path).tables.push({ title: sub(path), header: ['Kod', 'Dəyər'], coded: { cc: 0, lc: -1, vcols: [1] }, rows: nums.map(([k, x]) => [fldName(k), ncom(x)]) });
    texts.forEach(([k, x]) => S(path).fields.push(['', [sub(path), fldName(k)].filter(Boolean).join(' / '), typeof x === 'boolean' ? (x ? 'Bəli' : 'Xeyr') : String(x)]));
  };
  const ti = o.taxInformation;
  if (o.common) walk(o.common, ['common']);
  if (o.indicators) walk(o.indicators, ['indicators']);
  if (ti && typeof ti === 'object') Object.entries(ti).forEach(([k, v]) => walk(v, [k]));
  Object.entries(o).forEach(([k, v]) => { if (!['common', 'indicators', 'taxInformation', 'taxCode', 'version'].includes(k) && v && typeof v === 'object') walk(v, [k]); });
  return [...secs.values()].filter(s => s.tables.length || s.fields.length);
}
async function runDeclsApi({ tabId, from, to, taxes, skipKameral }) {
  const t0 = Date.now();
  const [fy, fm] = from.split('-').map(Number), [ty, tm] = to.split('-').map(Number), F = fy * 12 + fm, T = ty * 12 + tm, years = yearsFor(fy, ty);
  log('Bəyannamələr siyahısı alınır...');
  const { list, notes: yearNotes } = await apiDeclList(tabId, years);
  const want = taxes && taxes.length ? new Set(taxes) : null;
  const cand = list.map(x => ({ ...x, tax: taxOf(x.section) })).filter(x => {
    if (want && !want.has(x.tax.k) && !(want.has('diger') && x.tax.k === 'diger')) return false;
    return x.pr.y * 12 + x.pr.b >= F && x.pr.y * 12 + x.pr.a <= T;
  });
  const best = {};
  cand.filter(x => !(skipKameral && x.kameral)).forEach(x => { const k = x.section + '|' + x.pr.y + '|' + x.pr.a + '|' + x.pr.b; if (declBetter(x, best[k])) best[k] = x; });
  const sel = Object.values(best).sort((a, b) => a.tax.ab.localeCompare(b.tax.ab, 'az') || (a.pr.y * 12 + a.pr.a) - (b.pr.y * 12 + b.pr.a));
  const per = {}; list.forEach(x => { const a = taxOf(x.section).ab; per[a] = (per[a] || 0) + 1; });
  const baseReport = { versiya: VERSION, funksiya: 'beyannameler', rejim: 'api', iller: years, ilQeydleri: yearNotes, bolmeler: per, siyahi: list.length, araliqda: cand.length, secilen: sel.length };
  await chrome.storage.local.set({ report: baseReport });
  if (!sel.length) throw new Error('Seçilmiş vergi növləri və dövrlər üçün bəyannamə tapılmadı.');

  const results = new Array(sel.length).fill(null); let done = 0, secCount = 0;
  const report = () => log(`${done} / ${sel.length} bəyannamə oxundu.`, false, { i: done, n: sel.length, stats: [{ l: 'Bəyannamə', v: sel.length }, { l: 'Oxundu', v: done }, { l: 'Bölmə', v: secCount }] });
  report();
  for (let s = 0; s < sel.length && !cancel; s += 12) {
    const chunk = sel.slice(s, s + 12), out = await api(tabId, chunk.map(d => ({ u: `/api/po/declaration/public/v1/base?reg_number=${d.docNo}` })), 6);
    if (s === 0 && out.every(x => x.error)) throw apiErr('bəyannamənin içi: ' + out[0].error);
    out.forEach((x, j) => {
      let r;
      if (x.error) r = { error: x.error };
      else { try { const o = JSON.parse((x.data || {}).baseJson || 'null'); r = o ? { sections: declToSections(o) } : { error: 'bəyannamənin içi boş gəldi' }; } catch (e) { r = { error: 'format: ' + e.message }; } }
      if (r.sections && !r.sections.length) r = { error: 'bəyannamədə məlumat yoxdur' };
      results[s + j] = r; done++; if (r.sections) secCount += r.sections.length;
    });
    report();
  }
  await declExcel({ sel, results, baseReport, yearNotes: yearNotes.map(n => n), unknownPeriod: [], tpl: {}, learnNotes: [], from, to, t0, apiMode: true });
}
